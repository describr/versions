<?php
/**
 * Template for the "User Rejected Email".
 * 
 * Whether to send the user an email when a user is rejected.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-rejected.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$this->query_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(sprintf(
            	/*translators: %: Site's title.*/
            	__( 'Your %s membership was rejected.', 'describr' ),
            	"<strong>{$args['blogname']}</strong>"
            )) . "\r\n\r\n"; ?>
    </td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Username.*/
		__( '<strong>Username:</strong> %s', 'describr' ),
		$args['user']->user_login
		)) . "\r\n"; ?>
	    </p>
	</td>
</tr>
<?php
$this->query_template( 'footer', $args );