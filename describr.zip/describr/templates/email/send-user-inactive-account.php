<?php
/**
 * Template for the "User Deactivated Email".
 * 
 * Whether to send the user an email when account is deactivated by admin.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-inactive-account.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo esc_html( sprintf(
		/*translators: %s: User's display name.*/
		__( 'Hello %s,', 'describr' ), 
		$args['display_name'] 
		) ) . "\r\n\r\n"; ?></td>
</tr>
<tr>
	<td style="padding: 20px 0; vertical-align: baseline;"><?php esc_html_e( 'Your account has been deactivated.', 'describr' ) . "\r\n"; ?></td>
</tr>
<?php
$this->get_template( 'footer', $args );