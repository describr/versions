<?php
/**
 * Template for the "User Pending Review Email".
 * 
 * Whether to send the admin an email when a user is moderated.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-admin-pending-user-register-notification.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(sprintf(
		/*translators: %s: Site's title.*/
		__( 'A new user has registered on %s.', 'describr' ),
		"<strong>{$args['blogname']}</strong>"
	)) . "\r\n\r\n"; ?>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Username.*/
		__( '<strong>Username:</strong> %s', 'describr' ),
		$args['user']->user_login
		)) . "\r\n\r\n"; ?>
	    </p>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Email address.*/
		__( '<strong>Email:</strong> %s', 'describr' ),
		$args['user']->user_email
		)) . "\r\n\r\n"; ?>
	    </p>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post(_x( '<strong>Status:</strong> Awaiting review', 'user','describr' )) . "\r\n\r\n"; ?></p>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		###HTMLEDIT_USER:
		<div style="padding: 20px 0; margin: 0;">
			<?php 
	        echo wp_kses_post( $this->btn( $args['url'], __( 'Approve User', 'describr' ), 'admin_approve_user' ) );
		    ?>
	    </div>
        ###HTMLEDIT_USER
        ###TEXTEDIT_USER:
        <?php
        echo wp_kses_post(sprintf(
        	/*translators: %s: Users Screen URL.*/
        	__( 'You may approve this user by visiting the following link: %s.', 'describr' ),
        	$args['url']
        )) . "\r\n";
        ?>
        ###TEXTEDIT_USER
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );