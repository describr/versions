<?php 
/**
 * An array of states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 * @since 3.0.2 Data no longer translatable.
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array (
  'ET' => 
  array (
    'SN' => 
    array (
      'name' => 'Southern Nations, Nationalities, and Peoples&#039; Region',
      'cities' => 
      array (
        0 => 'Alaba Special Wereda',
        1 => 'Arba Minch',
        2 => 'Bako',
        3 => 'Bench Maji Zone',
        4 => 'Bodītī',
        5 => 'Bonga',
        6 => 'Butajīra',
        7 => 'Dīla',
        8 => 'Felege Neway',
        9 => 'Gedeo Zone',
        10 => 'Guraghe Zone',
        11 => 'Gīdolē',
        12 => 'Hadiya Zone',
        13 => 'Hawassa',
        14 => 'Hosa&#039;ina',
        15 => 'Hāgere Selam',
        16 => 'Jinka',
        17 => 'Kembata Alaba Tembaro Zone',
        18 => 'Konso',
        19 => 'K&#039;olīto',
        20 => 'Leku',
        21 => 'Lobuni',
        22 => 'Mīzan Teferī',
        23 => 'Sheka Zone',
        24 => 'Sidama Zone',
        25 => 'Sodo',
        26 => 'Tippi',
        27 => 'Turmi',
        28 => 'Wendo',
        29 => 'Wolayita Zone',
        30 => 'Yem',
        31 => 'Yirga &#039;Alem',
        32 => 'Āreka',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Somali Region',
      'cities' => 
      array (
        0 => 'Afder Zone',
        1 => 'Degehabur Zone',
        2 => 'Gode Zone',
        3 => 'Jijiga',
        4 => 'Liben zone',
        5 => 'Shinile Zone',
      ),
    ),
    'AM' => 
    array (
      'name' => 'Amhara Region',
      'cities' => 
      array (
        0 => 'Abomsa',
        1 => 'Addiet Canna',
        2 => 'Bahir Dar',
        3 => 'Batī',
        4 => 'Bichena',
        5 => 'Burē',
        6 => 'Dabat',
        7 => 'Debark&#039;',
        8 => 'Debre Birhan',
        9 => 'Debre Mark&#039;os',
        10 => 'Debre Sīna',
        11 => 'Debre Tabor',
        12 => 'Debre Werk&#039;',
        13 => 'Dejen',
        14 => 'Desē',
        15 => 'Finote Selam',
        16 => 'Gondar',
        17 => 'Kemisē',
        18 => 'Kombolcha',
        19 => 'Lalībela',
        20 => 'North Shewa Zone',
        21 => 'North Wollo Zone',
        22 => 'Robīt',
        23 => 'South Gondar Zone',
        24 => 'South Wollo Zone',
        25 => 'Wag Hemra Zone',
        26 => 'Were Īlu',
        27 => 'Werota',
        28 => 'Ādīs Zemen',
      ),
    ),
    'TI' => 
    array (
      'name' => 'Tigray Region',
      'cities' => 
      array (
        0 => 'Axum',
        1 => 'Inda Silasē',
        2 => 'Korem',
        3 => 'Maych&#039;ew',
        4 => 'Mek&#039;ele',
        5 => 'Southeastern Tigray Zone',
        6 => 'Southern Tigray Zone',
        7 => 'Ādīgrat',
      ),
    ),
    'OR' => 
    array (
      'name' => 'Oromia Region',
      'cities' => 
      array (
        0 => 'Arsi Zone',
        1 => 'Bedelē',
        2 => 'Bedēsa',
        3 => 'Bishoftu',
        4 => 'Deder',
        5 => 'Dembī Dolo',
        6 => 'Dodola',
        7 => 'East Harerghe Zone',
        8 => 'East Shewa Zone',
        9 => 'East Wellega Zone',
        10 => 'Fichē',
        11 => 'Gebre Guracha',
        12 => 'Gelemso',
        13 => 'Genet',
        14 => 'Gimbi',
        15 => 'Ginir',
        16 => 'Goba',
        17 => 'Gorē',
        18 => 'Guji Zone',
        19 => 'Gēdo',
        20 => 'Hagere Maryam',
        21 => 'Huruta',
        22 => 'Hāgere Hiywet',
        23 => 'Hīrna',
        24 => 'Illubabor Zone',
        25 => 'Jimma',
        26 => 'Jimma Zone',
        27 => 'Kibre Mengist',
        28 => 'Kofelē',
        29 => 'Mendī',
        30 => 'Metahāra',
        31 => 'Metu',
        32 => 'Mojo',
        33 => 'Mēga',
        34 => 'Nazrēt',
        35 => 'Nejo',
        36 => 'North Shewa Zone',
        37 => 'Sebeta',
        38 => 'Sendafa',
        39 => 'Shakiso',
        40 => 'Shambu',
        41 => 'Shashemenē',
        42 => 'Sirre',
        43 => 'Tulu Bolo',
        44 => 'Waliso',
        45 => 'Wenjī',
        46 => 'West Harerghe Zone',
        47 => 'West Wellega Zone',
        48 => 'Yabēlo',
        49 => 'Ziway',
        50 => 'Ādīs &#039;Alem',
        51 => 'Āgaro',
        52 => 'Āsasa',
        53 => 'Āsbe Teferī',
      ),
    ),
    'AF' => 
    array (
      'name' => 'Afar Region',
      'cities' => 
      array (
        0 => 'Administrative Zone 2',
        1 => 'Administrative Zone 3',
        2 => 'Asaita',
        3 => 'Dubti',
        4 => 'Gewanē',
        5 => 'Semera',
        6 => 'Āwash',
      ),
    ),
    'HA' => 
    array (
      'name' => 'Harari Region',
      'cities' => 
      array (
        0 => 'Harar',
      ),
    ),
    'DD' => 
    array (
      'name' => 'Dire Dawa',
      'cities' => 
      array (
        0 => 'Dire Dawa',
      ),
    ),
    'BE' => 
    array (
      'name' => 'Benishangul-Gumuz Region',
      'cities' => 
      array (
        0 => 'Asosa',
        1 => 'Metekel',
        2 => 'Āsosa',
      ),
    ),
    'GA' => 
    array (
      'name' => 'Gambela Region',
      'cities' => 
      array (
        0 => 'Administrative Zone 1',
        1 => 'Gambēla',
      ),
    ),
    'AA' => 
    array (
      'name' => 'Addis Ababa',
      'cities' => 
      array (
        0 => 'Addis Ababa',
      ),
    ),
  ),
  'ME' => 
  array (
    '02' => 
    array (
      'name' => 'Bar Municipality',
      'cities' => 
      array (
        0 => 'Bar',
        1 => 'Stari Bar',
        2 => 'Sutomore',
        3 => 'Šušanj',
      ),
    ),
    '07' => 
    array (
      'name' => 'Danilovgrad Municipality',
      'cities' => 
      array (
        0 => 'Danilovgrad',
        1 => 'Spuž',
      ),
    ),
    '03' => 
    array (
      'name' => 'Berane Municipality',
      'cities' => 
      array (
        0 => 'Berane',
      ),
    ),
    '01' => 
    array (
      'name' => 'Andrijevica Municipality',
      'cities' => 
      array (
        0 => 'Andrijevica',
      ),
    ),
    '04' => 
    array (
      'name' => 'Bijelo Polje Municipality',
      'cities' => 
      array (
        0 => 'Bijelo Polje',
      ),
    ),
    '06' => 
    array (
      'name' => 'Old Royal Capital Cetinje',
      'cities' => 
      array (
        0 => 'Cetinje',
      ),
    ),
    '05' => 
    array (
      'name' => 'Budva Municipality',
      'cities' => 
      array (
        0 => 'Budva',
        1 => 'Petrovac na Moru',
      ),
    ),
    '09' => 
    array (
      'name' => 'Kolašin Municipality',
      'cities' => 
      array (
        0 => 'Kolašin',
      ),
    ),
  ),
  'NA' => 
  array (
    'KU' => 
    array (
      'name' => 'Kunene Region',
      'cities' => 
      array (
        0 => 'Epupa Constituency',
        1 => 'Khorixas',
        2 => 'Khorixas Constituency',
        3 => 'Opuwo',
        4 => 'Opuwo Constituency',
        5 => 'Outjo',
        6 => 'Sesfontein Constituency',
      ),
    ),
    'KE' => 
    array (
      'name' => 'Kavango East Region',
      'cities' => 
      array (
        0 => 'Rundu',
      ),
    ),
    'ON' => 
    array (
      'name' => 'Oshana Region',
      'cities' => 
      array (
        0 => 'Ondangwa',
        1 => 'Ongwediva',
        2 => 'Oshakati',
      ),
    ),
    'HA' => 
    array (
      'name' => 'Hardap Region',
      'cities' => 
      array (
        0 => 'Aranos',
        1 => 'Hoachanas',
        2 => 'Maltahöhe',
        3 => 'Mariental',
        4 => 'Rehoboth',
      ),
    ),
    'OS' => 
    array (
      'name' => 'Omusati Region',
      'cities' => 
      array (
        0 => 'Okahao',
        1 => 'Ongandjera',
        2 => 'Outapi',
      ),
    ),
    'OW' => 
    array (
      'name' => 'Ohangwena Region',
      'cities' => 
      array (
        0 => 'Oshikango',
      ),
    ),
    'OH' => 
    array (
      'name' => 'Omaheke Region',
      'cities' => 
      array (
        0 => 'Gobabis',
      ),
    ),
    'OT' => 
    array (
      'name' => 'Oshikoto Region',
      'cities' => 
      array (
        0 => 'Omuthiya',
        1 => 'Tsumeb',
      ),
    ),
    'ER' => 
    array (
      'name' => 'Erongo Region',
      'cities' => 
      array (
        0 => 'Arandis',
        1 => 'Hentiesbaai',
        2 => 'Karibib',
        3 => 'Omaruru',
        4 => 'Otjimbingwe',
        5 => 'Swakopmund',
        6 => 'Swakopmund Constituency',
        7 => 'Usakos',
        8 => 'Walvis Bay',
      ),
    ),
    'KH' => 
    array (
      'name' => 'Khomas Region',
      'cities' => 
      array (
        0 => 'Katutura',
        1 => 'Windhoek',
      ),
    ),
    'KA' => 
    array (
      'name' => 'Karas Region',
      'cities' => 
      array (
        0 => 'Bethanie',
        1 => 'Karasburg',
        2 => 'Keetmanshoop',
        3 => 'Lüderitz',
        4 => 'Oranjemund',
        5 => 'Tses',
        6 => 'Warmbad',
      ),
    ),
    'OD' => 
    array (
      'name' => 'Otjozondjupa Region',
      'cities' => 
      array (
        0 => 'Grootfontein',
        1 => 'Okahandja',
        2 => 'Okakarara',
        3 => 'Otavi',
        4 => 'Otjiwarongo',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Zambezi Region',
      'cities' => 
      array (
        0 => 'Bagani',
        1 => 'Katima Mulilo',
      ),
    ),
  ),
  'GH' => 
  array (
    'AH' => 
    array (
      'name' => 'Ashanti Region',
      'cities' => 
      array (
        0 => 'Agogo',
        1 => 'Bekwai',
        2 => 'Ejura',
        3 => 'Konongo',
        4 => 'Kumasi',
        5 => 'Mampong',
        6 => 'Obuase',
        7 => 'Tafo',
      ),
    ),
    'WP' => 
    array (
      'name' => 'Western Region',
      'cities' => 
      array (
        0 => 'Aboso',
        1 => 'Axim',
        2 => 'Bibiani',
        3 => 'Prestea',
        4 => 'Sekondi-Takoradi',
        5 => 'Shama Junction',
        6 => 'Takoradi',
        7 => 'Tarkwa',
      ),
    ),
    'EP' => 
    array (
      'name' => 'Eastern Region',
      'cities' => 
      array (
        0 => 'Aburi',
        1 => 'Akim Oda',
        2 => 'Akim Swedru',
        3 => 'Akropong',
        4 => 'Akwatia',
        5 => 'Asamankese',
        6 => 'Begoro',
        7 => 'Kibi',
        8 => 'Koforidua',
        9 => 'Mpraeso',
        10 => 'Nsawam',
        11 => 'Suhum',
      ),
    ),
    'NP' => 
    array (
      'name' => 'Northern Region',
      'cities' => 
      array (
        0 => 'Kpandae',
        1 => 'Salaga',
        2 => 'Savelugu',
        3 => 'Tamale',
        4 => 'Yendi',
      ),
    ),
    'CP' => 
    array (
      'name' => 'Central Region',
      'cities' => 
      array (
        0 => 'Apam',
        1 => 'Cape Coast',
        2 => 'Dunkwa',
        3 => 'Elmina',
        4 => 'Foso',
        5 => 'Kasoa',
        6 => 'Mumford',
        7 => 'Saltpond',
        8 => 'Swedru',
        9 => 'Winneba',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Brong-Ahafo Region',
      'cities' => 
      array (
        0 => 'Bechem',
        1 => 'Berekum',
        2 => 'Duayaw-Nkwanta',
        3 => 'Japekrom',
        4 => 'Kintampo',
        5 => 'Sunyani',
        6 => 'Techiman',
        7 => 'Wenchi',
      ),
    ),
    'AA' => 
    array (
      'name' => 'Greater Accra Region',
      'cities' => 
      array (
        0 => 'Accra',
        1 => 'Atsiaman',
        2 => 'Dome',
        3 => 'Gbawe',
        4 => 'Medina Estates',
        5 => 'Nungua',
        6 => 'Tema',
        7 => 'Teshi Old Town',
      ),
    ),
    'UE' => 
    array (
      'name' => 'Upper East Region',
      'cities' => 
      array (
        0 => 'Bawku',
        1 => 'Bolgatanga',
        2 => 'Navrongo',
      ),
    ),
    'TV' => 
    array (
      'name' => 'Volta Region',
      'cities' => 
      array (
        0 => 'Aflao',
        1 => 'Anloga',
        2 => 'Ho',
        3 => 'Hohoe',
        4 => 'Keta',
        5 => 'Kete Krachi',
        6 => 'Kpandu',
      ),
    ),
    'UW' => 
    array (
      'name' => 'Upper West Region',
      'cities' => 
      array (
        0 => 'Wa',
      ),
    ),
  ),
  'SM' => 
  array (
    '07' => 
    array (
      'name' => 'San Marino',
      'cities' => 
      array (
        0 => 'San Marino',
      ),
    ),
    '01' => 
    array (
      'name' => 'Acquaviva',
      'cities' => 
      array (
        0 => 'Acquaviva',
      ),
    ),
    '02' => 
    array (
      'name' => 'Chiesanuova',
      'cities' => 
      array (
        0 => 'Poggio di Chiesanuova',
      ),
    ),
    '06' => 
    array (
      'name' => 'Borgo Maggiore',
      'cities' => 
      array (
        0 => 'Borgo Maggiore',
      ),
    ),
    '04' => 
    array (
      'name' => 'Faetano',
      'cities' => 
      array (
        0 => 'Faetano',
      ),
    ),
    '08' => 
    array (
      'name' => 'Montegiardino',
      'cities' => 
      array (
        0 => 'Monte Giardino',
      ),
    ),
    '03' => 
    array (
      'name' => 'Domagnano',
      'cities' => 
      array (
        0 => 'Domagnano',
      ),
    ),
    '09' => 
    array (
      'name' => 'Serravalle',
      'cities' => 
      array (
        0 => 'Serravalle',
      ),
    ),
    '05' => 
    array (
      'name' => 'Fiorentino',
      'cities' => 
      array (
        0 => 'Fiorentino',
      ),
    ),
  ),
  'MT' => 
  array (
    '09' => 
    array (
      'name' => 'Floriana',
      'cities' => 
      array (
        0 => 'Floriana',
      ),
    ),
    '05' => 
    array (
      'name' => 'Birżebbuġa',
      'cities' => 
      array (
        0 => 'Birżebbuġa',
      ),
    ),
    '04' => 
    array (
      'name' => 'Birkirkara',
      'cities' => 
      array (
        0 => 'Birkirkara',
      ),
    ),
    '03' => 
    array (
      'name' => 'Birgu',
      'cities' => 
      array (
        0 => 'Vittoriosa',
      ),
    ),
    '02' => 
    array (
      'name' => 'Balzan',
      'cities' => 
      array (
        0 => 'Balzan',
      ),
    ),
    '01' => 
    array (
      'name' => 'Attard',
      'cities' => 
      array (
        0 => 'Attard',
      ),
    ),
    '07' => 
    array (
      'name' => 'Dingli',
      'cities' => 
      array (
        0 => 'Dingli',
      ),
    ),
    '08' => 
    array (
      'name' => 'Fgura',
      'cities' => 
      array (
        0 => 'Fgura',
      ),
    ),
    '06' => 
    array (
      'name' => 'Cospicua',
      'cities' => 
      array (
        0 => 'Cospicua',
      ),
    ),
  ),
  'KZ' => 
  array (
    'MAN' => 
    array (
      'name' => 'Mangystau Region',
      'cities' => 
      array (
        0 => 'Aktau',
        1 => 'Baūtīno',
        2 => 'Beyneu',
        3 => 'Fort-Shevchenko',
        4 => 'Munayshy',
        5 => 'Sayötesh',
        6 => 'Shetpe',
        7 => 'Taūshyq',
        8 => 'Yeraliyev',
        9 => 'Zhanaozen',
        10 => 'Zhetibay',
        11 => 'Ömirzaq',
      ),
    ),
    'KZY' => 
    array (
      'name' => 'Kyzylorda Region',
      'cities' => 
      array (
        0 => 'Aral',
        1 => 'Ayteke Bi',
        2 => 'Belköl',
        3 => 'Dzhalagash',
        4 => 'Kyzylorda',
        5 => 'Qazaly',
        6 => 'Sekseūil',
        7 => 'Shalqīya',
        8 => 'Shīeli',
        9 => 'Tasböget',
        10 => 'Terenozek',
        11 => 'Yanykurgan',
        12 => 'Zhosaly',
      ),
    ),
    'ALM' => 
    array (
      'name' => 'Almaty Region',
      'cities' => 
      array (
        0 => 'Bakanas',
        1 => 'Balpyk Bī',
        2 => 'Burunday',
        3 => 'Chemolgan',
        4 => 'Druzhba',
        5 => 'Esik',
        6 => 'Kapshagay',
        7 => 'Kegen',
        8 => 'Lepsy',
        9 => 'Matay',
        10 => 'Otegen Batyra',
        11 => 'Pervomayka',
        12 => 'Sarkand',
        13 => 'Saryozek',
        14 => 'Taldykorgan',
        15 => 'Talghar',
        16 => 'Tekeli',
        17 => 'Turgen',
        18 => 'Ush-Tyube',
        19 => 'Zharkent',
        20 => 'Ülken',
      ),
    ),
    'SEV' => 
    array (
      'name' => 'North Kazakhstan Region',
      'cities' => 
      array (
        0 => 'Birlestik',
        1 => 'Bishkul',
        2 => 'Bulayevo',
        3 => 'Būrabay',
        4 => 'Kzyltu',
        5 => 'Novoishimskiy',
        6 => 'Petropavl',
        7 => 'Sergeyevka',
        8 => 'Smirnovo',
        9 => 'Taiynsha',
        10 => 'Talshik',
        11 => 'Timiryazevo',
        12 => 'Volodarskoye',
        13 => 'Yavlenka',
      ),
    ),
    'AKM' => 
    array (
      'name' => 'Akmola Region',
      'cities' => 
      array (
        0 => 'Akkol',
        1 => 'Akkol&#039;',
        2 => 'Aksu',
        3 => 'Astrakhan',
        4 => 'Atbasar',
        5 => 'Balkashino',
        6 => 'Bestobe',
        7 => 'Derzhavīnsk',
        8 => 'Egindiköl',
        9 => 'Esil',
        10 => 'Kokshetau',
        11 => 'Krasnogorskiy',
        12 => 'Makinsk',
        13 => 'Shantobe',
        14 => 'Shchuchinsk',
        15 => 'Shortandy',
        16 => 'Stepnogorsk',
        17 => 'Stepnyak',
        18 => 'Yermentau',
        19 => 'Zavodskoy',
        20 => 'Zhaqsy',
        21 => 'Zholymbet',
      ),
    ),
    'PAV' => 
    array (
      'name' => 'Pavlodar Region',
      'cities' => 
      array (
        0 => 'Aksu',
        1 => 'Bayanaul',
        2 => 'Belogor&#039;ye',
        3 => 'Ekibastuz',
        4 => 'Irtyshsk',
        5 => 'Kalkaman',
        6 => 'Leninskiy',
        7 => 'Mayqayyng',
        8 => 'Pavlodar',
        9 => 'Qashyr',
        10 => 'Zhelezinka',
      ),
    ),
    'ZHA' => 
    array (
      'name' => 'Jambyl Region',
      'cities' => 
      array (
        0 => 'Aqbaqay',
        1 => 'Chu',
        2 => 'Georgiyevka',
        3 => 'Granitogorsk',
        4 => 'Karatau',
        5 => 'Khantaū',
        6 => 'Lugovoy',
        7 => 'Lugovoye',
        8 => 'Merke',
        9 => 'Moyynkum',
        10 => 'Mynaral',
        11 => 'Oytal',
        12 => 'Sarykemer',
        13 => 'Shyghanaq',
        14 => 'Taraz',
        15 => 'Zhangatas',
      ),
    ),
    'ZAP' => 
    array (
      'name' => 'West Kazakhstan Province',
      'cities' => 
      array (
        0 => 'Aqsay',
        1 => 'Burlin',
        2 => 'Chapaev',
        3 => 'Chingirlau',
        4 => 'Dzhambeyty',
        5 => 'Fedorovka',
        6 => 'Kaztalovka',
        7 => 'Krūgloozernoe',
        8 => 'Oral',
        9 => 'Peremetnoe',
        10 => 'Saykhin',
        11 => 'Tasqala',
        12 => 'Zhänibek',
      ),
    ),
    'YUZ' => 
    array (
      'name' => 'Turkestan Region',
      'cities' => 
      array (
        0 => 'Arys',
        1 => 'Ashchysay',
        2 => 'Asyqata',
        3 => 'Atakent',
        4 => 'Bayzhansay',
        5 => 'Belyye Vody',
        6 => 'Chardara',
        7 => 'Chayan',
        8 => 'Chulakkurgan',
        9 => 'Kantagi',
        10 => 'Kentau',
        11 => 'Kokterek',
        12 => 'Lenger',
        13 => 'Leninskoye',
        14 => 'Maqtaaral Aūdany',
        15 => 'Myrzakent',
        16 => 'Qogham',
        17 => 'Saryaghash',
        18 => 'Saryaghash Aūdany',
        19 => 'Sastobe',
        20 => 'Sozaq Aūdany',
        21 => 'Temirlanovka',
        22 => 'Turar Ryskulov',
        23 => 'Turkestan',
        24 => 'Tyul&#039;kubas',
        25 => 'Zhabagly',
      ),
    ),
    'KAR' => 
    array (
      'name' => 'Karaganda Region',
      'cities' => 
      array (
        0 => 'Abay',
        1 => 'Abay Qalasy',
        2 => 'Aksu-Ayuly',
        3 => 'Aktas',
        4 => 'Aktau',
        5 => 'Aktogay',
        6 => 'Aqadyr',
        7 => 'Aqshataū',
        8 => 'Aqtoghay Aūdany',
        9 => 'Atasū',
        10 => 'Balqash',
        11 => 'Bukhar-Zhyrau',
        12 => 'Dolinka',
        13 => 'Karagandy',
        14 => 'Koktal',
        15 => 'Kushoky',
        16 => 'Kyzylzhar',
        17 => 'Kīevka',
        18 => 'Moyynty',
        19 => 'Novodolinskiy',
        20 => 'Osakarovka',
        21 => 'Prigorodnoye',
        22 => 'Priozersk',
        23 => 'Qarazhal',
        24 => 'Qarqaraly',
        25 => 'Saryshaghan',
        26 => 'Sayaq',
        27 => 'Shakhan',
        28 => 'Shakhtinsk',
        29 => 'Shashūbay',
        30 => 'Shubarköl',
        31 => 'Soran',
        32 => 'Temirtau',
        33 => 'Tokarevka',
        34 => 'Verkhniye Kayrakty',
        35 => 'Zhambyl',
        36 => 'Zharyk',
        37 => 'Zhezqazghan',
      ),
    ),
    'AKT' => 
    array (
      'name' => 'Aktobe Region',
      'cities' => 
      array (
        0 => 'Aktobe',
        1 => 'Batamshinskiy',
        2 => 'Bayganin',
        3 => 'Embi',
        4 => 'Kandyagash',
        5 => 'Khromtau',
        6 => 'Martuk',
        7 => 'Shalqar',
        8 => 'Shubarkuduk',
        9 => 'Shubarshi',
        10 => 'Temir',
        11 => 'Yrghyz',
      ),
    ),
    'ALA' => 
    array (
      'name' => 'Almaty',
      'cities' => 
      array (
        0 => 'Almaty',
      ),
    ),
    'ATY' => 
    array (
      'name' => 'Atyrau Region',
      'cities' => 
      array (
        0 => 'Akkol&#039;',
        1 => 'Atyrau',
        2 => 'Balykshi',
        3 => 'Bayshonas',
        4 => 'Dossor',
        5 => 'Inderbor',
        6 => 'Makhambet',
        7 => 'Maloye Ganyushkino',
        8 => 'Maqat',
        9 => 'Miyaly',
        10 => 'Qaraton',
        11 => 'Qulsary',
        12 => 'Shalkar',
      ),
    ),
    'VOS' => 
    array (
      'name' => 'East Kazakhstan Region',
      'cities' => 
      array (
        0 => 'Altayskiy',
        1 => 'Aqtoghay',
        2 => 'Asūbulaq',
        3 => 'Auezov',
        4 => 'Ayagoz',
        5 => 'Belogorskīy',
        6 => 'Belousovka',
        7 => 'Borodulikha',
        8 => 'Georgīevka',
        9 => 'Glubokoye',
        10 => 'Kurchatov',
        11 => 'Kurchum',
        12 => 'Maleyevsk',
        13 => 'Ognevka',
        14 => 'Priisk Boko',
        15 => 'Qaraūyl',
        16 => 'Ridder',
        17 => 'Semey',
        18 => 'Shar',
        19 => 'Shemonaīkha',
        20 => 'Suykbulak',
        21 => 'Tūghyl',
        22 => 'Urzhar',
        23 => 'Ust-Kamenogorsk',
        24 => 'Zaysan',
        25 => 'Zhalghyztobe',
        26 => 'Zhanga Buqtyrma',
        27 => 'Zhezkent',
        28 => 'Zyryanovsk',
        29 => 'Ūst&#039;-Talovka',
      ),
    ),
    'BAY' => 
    array (
      'name' => 'Baikonur',
      'cities' => 
      array (
        0 => 'Baikonur',
      ),
    ),
    'AST' => 
    array (
      'name' => 'Nur-Sultan',
      'cities' => 
      array (
        0 => 'Nur-Sultan',
      ),
    ),
    'KUS' => 
    array (
      'name' => 'Kostanay Region',
      'cities' => 
      array (
        0 => 'Arkalyk',
        1 => 'Ayat',
        2 => 'Borovskoy',
        3 => 'Dzhetygara',
        4 => 'Fyodorovka',
        5 => 'Karasu',
        6 => 'Komsomolets',
        7 => 'Kostanay',
        8 => 'Lisakovsk',
        9 => 'Ordzhonikidze',
        10 => 'Qashar',
        11 => 'Qusmuryn',
        12 => 'Rudnyy',
        13 => 'Tobol',
        14 => 'Torghay',
        15 => 'Troyebratskiy',
      ),
    ),
  ),
  'KE' => 
  array (
    '04' => 
    array (
      'name' => 'Busia County',
      'cities' => 
      array (
        0 => 'Busia',
        1 => 'Luanda',
        2 => 'Lugulu',
        3 => 'Malaba',
        4 => 'Nambare',
        5 => 'Port Victoria',
      ),
    ),
    '06' => 
    array (
      'name' => 'Embu County',
      'cities' => 
      array (
        0 => 'Embu',
      ),
    ),
    '03' => 
    array (
      'name' => 'Bungoma County',
      'cities' => 
      array (
        0 => 'Bungoma',
        1 => 'Malikisi',
        2 => 'Webuye',
      ),
    ),
    '09' => 
    array (
      'name' => 'Isiolo County',
      'cities' => 
      array (
        0 => 'Isiolo',
      ),
    ),
    '01' => 
    array (
      'name' => 'Baringo County',
      'cities' => 
      array (
        0 => 'Baringo',
        1 => 'Eldama Ravine',
        2 => 'Kabarnet',
      ),
    ),
    '08' => 
    array (
      'name' => 'Homa Bay County',
      'cities' => 
      array (
        0 => 'Homa Bay',
        1 => 'Oyugis',
        2 => 'Rachuonyo District',
      ),
    ),
    '07' => 
    array (
      'name' => 'Garissa County',
      'cities' => 
      array (
        0 => 'Garissa',
      ),
    ),
    '02' => 
    array (
      'name' => 'Bomet County',
      'cities' => 
      array (
        0 => 'Sotik',
        1 => 'Sotik Post',
      ),
    ),
  ),
  'AO' => 
  array (
    'BIE' => 
    array (
      'name' => 'Bié Province',
      'cities' => 
      array (
        0 => 'Camacupa',
        1 => 'Catabola',
        2 => 'Chissamba',
        3 => 'Cuito',
      ),
    ),
    'HUA' => 
    array (
      'name' => 'Huambo Province',
      'cities' => 
      array (
        0 => 'Caála',
        1 => 'Chela',
        2 => 'Huambo',
        3 => 'Longonjo',
      ),
    ),
    'ZAI' => 
    array (
      'name' => 'Zaire Province',
      'cities' => 
      array (
        0 => 'Mbanza Congo',
        1 => 'N&#039;zeto',
        2 => 'Soio',
      ),
    ),
    'CNN' => 
    array (
      'name' => 'Cunene Province',
      'cities' => 
      array (
        0 => 'Ondjiva',
      ),
    ),
    'CUS' => 
    array (
      'name' => 'Cuanza Sul',
      'cities' => 
      array (
        0 => 'Quibala',
        1 => 'Sumbe',
        2 => 'Uacu Cungo',
      ),
    ),
    'CNO' => 
    array (
      'name' => 'Cuanza Norte Province',
      'cities' => 
      array (
        0 => 'Camabatela',
        1 => 'N&#039;dalatando',
      ),
    ),
    'BGU' => 
    array (
      'name' => 'Benguela Province',
      'cities' => 
      array (
        0 => 'Benguela',
        1 => 'Catumbela',
        2 => 'Lobito',
      ),
    ),
    'MOX' => 
    array (
      'name' => 'Moxico Province',
      'cities' => 
      array (
        0 => 'Luau',
        1 => 'Luena',
        2 => 'Lumeje',
        3 => 'Léua',
      ),
    ),
    'LSU' => 
    array (
      'name' => 'Lunda Sul Province',
      'cities' => 
      array (
        0 => 'Cazaji',
        1 => 'Saurimo',
      ),
    ),
    'BGO' => 
    array (
      'name' => 'Bengo Province',
      'cities' => 
      array (
        0 => 'Caxito',
      ),
    ),
    'LUA' => 
    array (
      'name' => 'Luanda Province',
      'cities' => 
      array (
        0 => 'Belas',
        1 => 'Icolo e Bengo',
        2 => 'Luanda',
      ),
    ),
    'LNO' => 
    array (
      'name' => 'Lunda Norte Province',
      'cities' => 
      array (
        0 => 'Lucapa',
      ),
    ),
    'UIG' => 
    array (
      'name' => 'Uíge Province',
      'cities' => 
      array (
        0 => 'Uíge',
      ),
    ),
    'HUI' => 
    array (
      'name' => 'Huíla Province',
      'cities' => 
      array (
        0 => 'Caconda',
        1 => 'Caluquembe',
        2 => 'Chibia',
        3 => 'Chicomba',
        4 => 'Chipindo',
        5 => 'Cuvango',
        6 => 'Gambos',
        7 => 'Humpata',
        8 => 'Jamba',
        9 => 'Lubango',
        10 => 'Matala',
        11 => 'Quilengues',
        12 => 'Quipungo',
      ),
    ),
    'CCU' => 
    array (
      'name' => 'Cuando Cubango Province',
      'cities' => 
      array (
        0 => 'Menongue',
      ),
    ),
    'MAL' => 
    array (
      'name' => 'Malanje Province',
      'cities' => 
      array (
        0 => 'Malanje',
      ),
    ),
    'CAB' => 
    array (
      'name' => 'Cabinda Province',
      'cities' => 
      array (
        0 => 'Cabinda',
      ),
    ),
  ),
  'BT' => 
  array (
    'GA' => 
    array (
      'name' => 'Gasa District',
      'cities' => 
      array (
        0 => 'Gasa',
      ),
    ),
  ),
  'ML' => 
  array (
    'BKO' => 
    array (
      'name' => 'Bamako',
      'cities' => 
      array (
        0 => 'Bamako',
      ),
    ),
  ),
  'RW' => 
  array (
    '05' => 
    array (
      'name' => 'Southern Province',
      'cities' => 
      array (
        0 => 'Butare',
        1 => 'Eglise Catholique, Centrale GIKO',
        2 => 'Gitarama',
        3 => 'Nzega',
      ),
    ),
    '04' => 
    array (
      'name' => 'Western Province',
      'cities' => 
      array (
        0 => 'Cyangugu',
        1 => 'Gisenyi',
        2 => 'Kibuye',
      ),
    ),
    '02' => 
    array (
      'name' => 'Eastern Province',
      'cities' => 
      array (
        0 => 'Kibungo',
        1 => 'Rwamagana',
      ),
    ),
    '01' => 
    array (
      'name' => 'Kigali district',
      'cities' => 
      array (
        0 => 'Kigali',
      ),
    ),
    '03' => 
    array (
      'name' => 'Northern Province',
      'cities' => 
      array (
        0 => 'Byumba',
        1 => 'Musanze',
      ),
    ),
  ),
  'BZ' => 
  array (
    'BZ' => 
    array (
      'name' => 'Belize District',
      'cities' => 
      array (
        0 => 'Belize City',
        1 => 'San Pedro',
      ),
    ),
    'SC' => 
    array (
      'name' => 'Stann Creek District',
      'cities' => 
      array (
        0 => 'Dangriga',
        1 => 'Placencia',
      ),
    ),
    'CZL' => 
    array (
      'name' => 'Corozal District',
      'cities' => 
      array (
        0 => 'Corozal',
      ),
    ),
    'TOL' => 
    array (
      'name' => 'Toledo District',
      'cities' => 
      array (
        0 => 'Punta Gorda',
      ),
    ),
    'OW' => 
    array (
      'name' => 'Orange Walk District',
      'cities' => 
      array (
        0 => 'Hopelchén',
        1 => 'Orange Walk',
        2 => 'Shipyard',
      ),
    ),
    'CY' => 
    array (
      'name' => 'Cayo District',
      'cities' => 
      array (
        0 => 'Belmopan',
        1 => 'Benque Viejo el Carmen',
        2 => 'San Ignacio',
        3 => 'Valley of Peace',
      ),
    ),
  ),
  'ST' => 
  array (
    'P' => 
    array (
      'name' => 'Príncipe Province',
      'cities' => 
      array (
        0 => 'Santo António',
      ),
    ),
    'S' => 
    array (
      'name' => 'São Tomé Province',
      'cities' => 
      array (
        0 => 'Cantagalo District',
        1 => 'Caué District',
        2 => 'São Tomé',
        3 => 'Trindade',
      ),
    ),
  ),
  'CU' => 
  array (
    '03' => 
    array (
      'name' => 'Havana Province',
      'cities' => 
      array (
        0 => 'Alamar',
        1 => 'Arroyo Naranjo',
        2 => 'Boyeros',
        3 => 'Centro Habana',
        4 => 'Cerro',
        5 => 'Diez de Octubre',
        6 => 'Guanabacoa',
        7 => 'Habana del Este',
        8 => 'Havana',
        9 => 'La Habana Vieja',
        10 => 'Regla',
        11 => 'San Miguel del Padrón',
        12 => 'Santiago de las Vegas',
      ),
    ),
    '07' => 
    array (
      'name' => 'Sancti Spíritus Province',
      'cities' => 
      array (
        0 => 'Cabaiguán',
        1 => 'Condado',
        2 => 'Fomento',
        3 => 'Guayos',
        4 => 'Jatibonico',
        5 => 'La Sierpe',
        6 => 'Municipio de Cabaiguán',
        7 => 'Municipio de Jatibonico',
        8 => 'Municipio de Sancti Spíritus',
        9 => 'Municipio de Trinidad',
        10 => 'Sancti Spíritus',
        11 => 'Topes de Collantes',
        12 => 'Trinidad',
        13 => 'Yaguajay',
        14 => 'Zaza del Medio',
      ),
    ),
    '01' => 
    array (
      'name' => 'Pinar del Río Province',
      'cities' => 
      array (
        0 => 'Consolación del Sur',
        1 => 'Guane',
        2 => 'Los Palacios',
        3 => 'Mantua',
        4 => 'Minas de Matahambre',
        5 => 'Municipio de Consolación del Sur',
        6 => 'Municipio de Guane',
        7 => 'Municipio de La Palma',
        8 => 'Municipio de Los Palacios',
        9 => 'Pinar del Río',
        10 => 'Puerto Esperanza',
        11 => 'San Diego de Los Baños',
        12 => 'San Luis',
        13 => 'Viñales',
      ),
    ),
    '05' => 
    array (
      'name' => 'Villa Clara Province',
      'cities' => 
      array (
        0 => 'Caibarién',
        1 => 'Calabazar de Sagua',
        2 => 'Camajuaní',
        3 => 'Cifuentes',
        4 => 'Corralillo',
        5 => 'Encrucijada',
        6 => 'Esperanza',
        7 => 'Isabela de Sagua',
        8 => 'Manicaragua',
        9 => 'Municipio de Placetas',
        10 => 'Municipio de Santa Clara',
        11 => 'Placetas',
        12 => 'Quemado de Güines',
        13 => 'Rancho Veloz',
        14 => 'Ranchuelo',
        15 => 'Sagua la Grande',
        16 => 'Santa Clara',
        17 => 'Santo Domingo',
      ),
    ),
    '08' => 
    array (
      'name' => 'Ciego de Ávila Province',
      'cities' => 
      array (
        0 => 'Baraguá',
        1 => 'Chambas',
        2 => 'Ciego de Ávila',
        3 => 'Ciro Redondo',
        4 => 'Florencia',
        5 => 'Morón',
        6 => 'Municipio de Ciego de Ávila',
        7 => 'Municipio de Morón',
        8 => 'Primero de Enero',
        9 => 'Venezuela',
      ),
    ),
    '04' => 
    array (
      'name' => 'Matanzas Province',
      'cities' => 
      array (
        0 => 'Alacranes',
        1 => 'Bolondrón',
        2 => 'Calimete',
        3 => 'Colón',
        4 => 'Cárdenas',
        5 => 'Jagüey Grande',
        6 => 'Jovellanos',
        7 => 'Limonar',
        8 => 'Los Arabos',
        9 => 'Manguito',
        10 => 'Martí',
        11 => 'Matanzas',
        12 => 'Municipio de Cárdenas',
        13 => 'Municipio de Matanzas',
        14 => 'Pedro Betancourt',
        15 => 'Perico',
        16 => 'Unión de Reyes',
        17 => 'Varadero',
      ),
    ),
    '09' => 
    array (
      'name' => 'Camagüey Province',
      'cities' => 
      array (
        0 => 'Camagüey',
        1 => 'El Caney',
        2 => 'Esmeralda',
        3 => 'Florida',
        4 => 'Guáimaro',
        5 => 'Jimaguayú',
        6 => 'Minas',
        7 => 'Municipio de Florida',
        8 => 'Municipio de Nuevitas',
        9 => 'Nuevitas',
        10 => 'Santa Cruz del Sur',
        11 => 'Sibanicú',
        12 => 'Vertientes',
      ),
    ),
    '06' => 
    array (
      'name' => 'Cienfuegos Province',
      'cities' => 
      array (
        0 => 'Abreus',
        1 => 'Aguada de Pasajeros',
        2 => 'Cienfuegos',
        3 => 'Cruces',
        4 => 'Cumanayagua',
        5 => 'Lajas',
        6 => 'Municipio de Abreus',
        7 => 'Municipio de Cienfuegos',
        8 => 'Palmira',
        9 => 'Rodas',
      ),
    ),
  ),
  'NG' => 
  array (
    'JI' => 
    array (
      'name' => 'Jigawa State',
      'cities' => 
      array (
        0 => 'Babura',
        1 => 'Birnin Kudu',
        2 => 'Birniwa',
        3 => 'Dutse',
        4 => 'Gagarawa',
        5 => 'Gumel',
        6 => 'Gwaram',
        7 => 'Hadejia',
        8 => 'Kafin Hausa',
        9 => 'Kazaure',
        10 => 'Kiyawa',
        11 => 'Mallammaduri',
        12 => 'Ringim',
        13 => 'Samamiya',
      ),
    ),
    'EN' => 
    array (
      'name' => 'Enugu State',
      'cities' => 
      array (
        0 => 'Adani',
        1 => 'Ake-Eze',
        2 => 'Aku',
        3 => 'Amagunze',
        4 => 'Awgu',
        5 => 'Eha Amufu',
        6 => 'Enugu',
        7 => 'Enugu-Ezike',
        8 => 'Ete',
        9 => 'Ikem',
        10 => 'Mberubu',
        11 => 'Nsukka',
        12 => 'Obolo-Eke (1)',
        13 => 'Opi',
        14 => 'Udi',
      ),
    ),
    'KE' => 
    array (
      'name' => 'Kebbi State',
      'cities' => 
      array (
        0 => 'Argungu',
        1 => 'Bagudo',
        2 => 'Bena',
        3 => 'Bin Yauri',
        4 => 'Birnin Kebbi',
        5 => 'Dabai',
        6 => 'Dakingari',
        7 => 'Gulma',
        8 => 'Gwandu',
        9 => 'Jega',
        10 => 'Kamba',
        11 => 'Kangiwa',
        12 => 'Kende',
        13 => 'Mahuta',
        14 => 'Maiyama',
        15 => 'Shanga',
        16 => 'Wasagu',
        17 => 'Zuru',
      ),
    ),
    'BE' => 
    array (
      'name' => 'Benue State',
      'cities' => 
      array (
        0 => 'Aliade',
        1 => 'Boju',
        2 => 'Igbor',
        3 => 'Makurdi',
        4 => 'Ochobo',
        5 => 'Otukpa',
        6 => 'Takum',
        7 => 'Ugbokpo',
        8 => 'Yandev',
        9 => 'Zaki Biam',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Sokoto State',
      'cities' => 
      array (
        0 => 'Binji',
        1 => 'Dange',
        2 => 'Gandi',
        3 => 'Goronyo',
        4 => 'Gwadabawa',
        5 => 'Illela',
        6 => 'Rabah',
        7 => 'Sokoto',
        8 => 'Tambuwal',
        9 => 'Wurno',
      ),
    ),
    'FC' => 
    array (
      'name' => 'Federal Capital Territory',
      'cities' => 
      array (
        0 => 'Abuja',
        1 => 'Kuje',
        2 => 'Kwali',
        3 => 'Madala',
      ),
    ),
    'KD' => 
    array (
      'name' => 'Kaduna State',
      'cities' => 
      array (
        0 => 'Anchau',
        1 => 'Burumburum',
        2 => 'Dutsen Wai',
        3 => 'Hunkuyi',
        4 => 'Kachia',
        5 => 'Kaduna',
        6 => 'Kafanchan',
        7 => 'Kagoro',
        8 => 'Kajuru',
        9 => 'Kujama',
        10 => 'Lere',
        11 => 'Mando',
        12 => 'Saminaka',
        13 => 'Soba',
        14 => 'Sofo-Birnin-Gwari',
        15 => 'Zaria',
      ),
    ),
    'KW' => 
    array (
      'name' => 'Kwara State',
      'cities' => 
      array (
        0 => 'Ajasse Ipo',
        1 => 'Bode Saadu',
        2 => 'Gwasero',
        3 => 'Ilorin',
        4 => 'Jebba',
        5 => 'Kaiama',
        6 => 'Lafiagi',
        7 => 'Offa',
        8 => 'Okuta',
        9 => 'Omu-Aran',
        10 => 'Patigi',
        11 => 'Suya',
        12 => 'Yashikera',
      ),
    ),
    'OY' => 
    array (
      'name' => 'Oyo State',
      'cities' => 
      array (
        0 => 'Ago Are',
        1 => 'Alapa',
        2 => 'Fiditi',
        3 => 'Ibadan',
        4 => 'Igbeti',
        5 => 'Igbo-Ora',
        6 => 'Igboho',
        7 => 'Kisi',
        8 => 'Lalupon',
        9 => 'Ogbomoso',
        10 => 'Okeho',
        11 => 'Orita Eruwa',
        12 => 'Oyo',
        13 => 'Saki',
      ),
    ),
    'YO' => 
    array (
      'name' => 'Yobe State',
      'cities' => 
      array (
        0 => 'Damaturu',
        1 => 'Dankalwa',
        2 => 'Dapchi',
        3 => 'Daura',
        4 => 'Fika',
        5 => 'Gashua',
        6 => 'Geidam',
        7 => 'Goniri',
        8 => 'Gorgoram',
        9 => 'Gujba',
        10 => 'Gwio Kura',
        11 => 'Kumagunnam',
        12 => 'Lajere',
        13 => 'Machina',
        14 => 'Nguru',
        15 => 'Potiskum',
      ),
    ),
    'KO' => 
    array (
      'name' => 'Kogi State',
      'cities' => 
      array (
        0 => 'Abocho',
        1 => 'Adoru',
        2 => 'Ankpa',
        3 => 'Bugana',
        4 => 'Dekina',
        5 => 'Egbe',
        6 => 'Icheu',
        7 => 'Idah',
        8 => 'Isanlu-Itedoijowa',
        9 => 'Kabba',
        10 => 'Koton-Karfe',
        11 => 'Lokoja',
        12 => 'Ogaminana',
        13 => 'Ogurugu',
        14 => 'Okene',
      ),
    ),
    'ZA' => 
    array (
      'name' => 'Zamfara State',
      'cities' => 
      array (
        0 => 'Anka',
        1 => 'Dan Sadau',
        2 => 'Gummi',
        3 => 'Gusau',
        4 => 'Kaura Namoda',
        5 => 'Kwatarkwashi',
        6 => 'Maru',
        7 => 'Moriki',
        8 => 'Sauri',
        9 => 'Tsafe',
      ),
    ),
    'KN' => 
    array (
      'name' => 'Kano State',
      'cities' => 
      array (
        0 => 'Dan Gora',
        1 => 'Gaya',
        2 => 'Kano',
      ),
    ),
    'NA' => 
    array (
      'name' => 'Nasarawa State',
      'cities' => 
      array (
        0 => 'Buga',
        1 => 'Doma',
        2 => 'Keffi',
        3 => 'Lafia',
        4 => 'Nasarawa',
        5 => 'Wamba',
      ),
    ),
    'PL' => 
    array (
      'name' => 'Plateau State',
      'cities' => 
      array (
        0 => 'Amper',
        1 => 'Bukuru',
        2 => 'Dengi',
        3 => 'Jos',
        4 => 'Kwolla',
        5 => 'Langtang',
        6 => 'Pankshin',
        7 => 'Panyam',
        8 => 'Vom',
        9 => 'Yelwa',
      ),
    ),
    'AB' => 
    array (
      'name' => 'Abia State',
      'cities' => 
      array (
        0 => 'Aba',
        1 => 'Amaigbo',
        2 => 'Arochukwu',
        3 => 'Bende',
        4 => 'Ohafia-Ifigh',
        5 => 'Umuahia',
      ),
    ),
    'AK' => 
    array (
      'name' => 'Akwa Ibom State',
      'cities' => 
      array (
        0 => 'Eket',
        1 => 'Esuk Oron',
        2 => 'Ikot Ekpene',
        3 => 'Itu',
        4 => 'Uyo',
      ),
    ),
    'BY' => 
    array (
      'name' => 'Bayelsa State',
      'cities' => 
      array (
        0 => 'Amassoma',
        1 => 'Twon-Brass',
        2 => 'Yenagoa',
      ),
    ),
    'LA' => 
    array (
      'name' => 'Lagos',
      'cities' => 
      array (
        0 => 'Apapa',
        1 => 'Badagry',
        2 => 'Ebute Ikorodu',
        3 => 'Ejirin',
        4 => 'Epe',
        5 => 'Ikeja',
        6 => 'Lagos',
        7 => 'Makoko',
      ),
    ),
    'BO' => 
    array (
      'name' => 'Borno State',
      'cities' => 
      array (
        0 => 'Bama',
        1 => 'Benisheikh',
        2 => 'Biu',
        3 => 'Bornu Yassu',
        4 => 'Damasak',
        5 => 'Damboa',
        6 => 'Dikwa',
        7 => 'Gamboru',
        8 => 'Gwoza',
        9 => 'Kukawa',
        10 => 'Magumeri',
        11 => 'Maiduguri',
        12 => 'Marte',
        13 => 'Miringa',
        14 => 'Monguno',
        15 => 'Ngala',
        16 => 'Shaffa',
        17 => 'Shani',
        18 => 'Tokombere',
        19 => 'Uba',
        20 => 'Wuyo',
        21 => 'Yajiwa',
      ),
    ),
    'IM' => 
    array (
      'name' => 'Imo State',
      'cities' => 
      array (
        0 => 'Iho',
        1 => 'Oguta',
        2 => 'Okigwe',
        3 => 'Orlu',
        4 => 'Orodo',
        5 => 'Owerri',
      ),
    ),
    'EK' => 
    array (
      'name' => 'Ekiti State',
      'cities' => 
      array (
        0 => 'Ado-Ekiti',
        1 => 'Aramoko-Ekiti',
        2 => 'Efon-Alaaye',
        3 => 'Emure-Ekiti',
        4 => 'Ifaki',
        5 => 'Igbara-Odo',
        6 => 'Igede-Ekiti',
        7 => 'Ijero-Ekiti',
        8 => 'Ikere-Ekiti',
        9 => 'Ipoti',
        10 => 'Ise-Ekiti',
        11 => 'Oke Ila',
        12 => 'Omuo-Ekiti',
      ),
    ),
    'GO' => 
    array (
      'name' => 'Gombe State',
      'cities' => 
      array (
        0 => 'Akko',
        1 => 'Bara',
        2 => 'Billiri',
        3 => 'Dadiya',
        4 => 'Deba',
        5 => 'Dukku',
        6 => 'Garko',
        7 => 'Gombe',
        8 => 'Hinna',
        9 => 'Kafarati',
        10 => 'Kaltungo',
        11 => 'Kumo',
        12 => 'Nafada',
        13 => 'Pindiga',
      ),
    ),
    'EB' => 
    array (
      'name' => 'Ebonyi State',
      'cities' => 
      array (
        0 => 'Abakaliki',
        1 => 'Afikpo',
        2 => 'Effium',
        3 => 'Ezza-Ohu',
        4 => 'Isieke',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Bauchi State',
      'cities' => 
      array (
        0 => 'Azare',
        1 => 'Bauchi',
        2 => 'Boi',
        3 => 'Bununu',
        4 => 'Darazo',
        5 => 'Dass',
        6 => 'Dindima',
        7 => 'Disina',
        8 => 'Gabarin',
        9 => 'Gwaram',
        10 => 'Kari',
        11 => 'Lame',
        12 => 'Lere',
        13 => 'Madara',
        14 => 'Misau',
        15 => 'Sade',
        16 => 'Yamrat',
        17 => 'Yanda Bayo',
        18 => 'Yuli',
        19 => 'Zadawa',
        20 => 'Zalanga',
      ),
    ),
    'KT' => 
    array (
      'name' => 'Katsina State',
      'cities' => 
      array (
        0 => 'Danja',
        1 => 'Dankama',
        2 => 'Daura',
        3 => 'Dutsin-Ma',
        4 => 'Funtua',
        5 => 'Gora',
        6 => 'Jibia',
        7 => 'Jikamshi',
        8 => 'Kankara',
        9 => 'Katsina',
        10 => 'Mashi',
        11 => 'Ruma',
        12 => 'Runka',
        13 => 'Wagini',
      ),
    ),
    'CR' => 
    array (
      'name' => 'Cross River State',
      'cities' => 
      array (
        0 => 'Akankpa',
        1 => 'Calabar',
        2 => 'Gakem',
        3 => 'Ikang',
        4 => 'Ugep',
      ),
    ),
    'AN' => 
    array (
      'name' => 'Anambra State',
      'cities' => 
      array (
        0 => 'Agulu',
        1 => 'Atani',
        2 => 'Awka',
        3 => 'Enugu-Ukwu',
        4 => 'Igbo-Ukwu',
        5 => 'Ihiala',
        6 => 'Nkpor',
        7 => 'Nnewi',
        8 => 'Onitsha',
        9 => 'Ozubulu',
        10 => 'Uga',
        11 => 'Uruobo-Okija',
      ),
    ),
    'DE' => 
    array (
      'name' => 'Delta State',
      'cities' => 
      array (
        0 => 'Abraka',
        1 => 'Agbor',
        2 => 'Asaba',
        3 => 'Bomadi',
        4 => 'Burutu',
        5 => 'Kwale',
        6 => 'Obiaruku',
        7 => 'Ogwashi-Uku',
        8 => 'Orerokpe',
        9 => 'Patani',
        10 => 'Sapele',
        11 => 'Ughelli',
        12 => 'Umunede',
        13 => 'Warri',
      ),
    ),
    'NI' => 
    array (
      'name' => 'Niger State',
      'cities' => 
      array (
        0 => 'Auna',
        1 => 'Babana',
        2 => 'Badeggi',
        3 => 'Baro',
        4 => 'Bokani',
        5 => 'Duku',
        6 => 'Ibeto',
        7 => 'Konkwesso',
        8 => 'Kontagora',
        9 => 'Kusheriki',
        10 => 'Kuta',
        11 => 'Lapai',
        12 => 'Minna',
        13 => 'New Shagunnu',
        14 => 'Suleja',
        15 => 'Tegina',
        16 => 'Ukata',
        17 => 'Wawa',
        18 => 'Zungeru',
      ),
    ),
    'ED' => 
    array (
      'name' => 'Edo State',
      'cities' => 
      array (
        0 => 'Agenebode',
        1 => 'Auchi',
        2 => 'Benin City',
        3 => 'Ekpoma',
        4 => 'Igarra',
        5 => 'Illushi',
        6 => 'Siluko',
        7 => 'Ubiaja',
        8 => 'Uromi',
      ),
    ),
    'TA' => 
    array (
      'name' => 'Taraba State',
      'cities' => 
      array (
        0 => 'Baissa',
        1 => 'Beli',
        2 => 'Gassol',
        3 => 'Gembu',
        4 => 'Ibi',
        5 => 'Jalingo',
        6 => 'Lau',
        7 => 'Mutum Biyu',
        8 => 'Riti',
        9 => 'Wukari',
      ),
    ),
    'AD' => 
    array (
      'name' => 'Adamawa State',
      'cities' => 
      array (
        0 => 'Ganye',
        1 => 'Gombi',
        2 => 'Holma',
        3 => 'Jimeta',
        4 => 'Madagali',
        5 => 'Mayo-Belwa',
        6 => 'Mubi',
        7 => 'Ngurore',
        8 => 'Numan',
        9 => 'Toungo',
        10 => 'Yola',
      ),
    ),
    'ON' => 
    array (
      'name' => 'Ondo State',
      'cities' => 
      array (
        0 => 'Agbabu',
        1 => 'Akure',
        2 => 'Idanre',
        3 => 'Ifon',
        4 => 'Ilare',
        5 => 'Ode',
        6 => 'Ondo',
        7 => 'Ore',
        8 => 'Owo',
      ),
    ),
    'OS' => 
    array (
      'name' => 'Osun State',
      'cities' => 
      array (
        0 => 'Apomu',
        1 => 'Ejigbo',
        2 => 'Gbongan',
        3 => 'Ijebu-Jesa',
        4 => 'Ikire',
        5 => 'Ikirun',
        6 => 'Ila Orangun',
        7 => 'Ile-Ife',
        8 => 'Ilesa',
        9 => 'Ilobu',
        10 => 'Inisa',
        11 => 'Iwo',
        12 => 'Modakeke',
        13 => 'Oke Mesi',
        14 => 'Olupona',
        15 => 'Osogbo',
        16 => 'Otan Ayegbaju',
        17 => 'Oyan',
      ),
    ),
    'OG' => 
    array (
      'name' => 'Ogun State',
      'cities' => 
      array (
        0 => 'Abeokuta',
        1 => 'Ado Odo',
        2 => 'Idi Iroko',
        3 => 'Ifo',
        4 => 'Ijebu-Ife',
        5 => 'Ijebu-Igbo',
        6 => 'Ijebu-Ode',
        7 => 'Ilaro',
        8 => 'Imeko',
        9 => 'Iperu',
        10 => 'Isara',
        11 => 'Owode',
      ),
    ),
  ),
  'UG' => 
  array (
    'N' => 
    array (
      'name' => 'Northern Region',
      'cities' => 
      array (
        0 => 'Adjumani',
        1 => 'Amudat',
        2 => 'Apac',
        3 => 'Arua',
        4 => 'Gulu',
        5 => 'Kitgum',
        6 => 'Kotido',
        7 => 'Lira',
        8 => 'Moroto',
        9 => 'Moyo',
        10 => 'Nebbi',
        11 => 'Otuke District',
        12 => 'Oyam District',
        13 => 'Pader',
        14 => 'Pader Palwo',
        15 => 'Paidha',
        16 => 'Yumbe',
      ),
    ),
    'W' => 
    array (
      'name' => 'Western Region',
      'cities' => 
      array (
        0 => 'Bundibugyo',
        1 => 'Bwizibwera',
        2 => 'Fort Portal',
        3 => 'Hoima',
        4 => 'Ibanda',
        5 => 'Ibanda District',
        6 => 'Kabale',
        7 => 'Kagadi',
        8 => 'Kamwenge',
        9 => 'Kanungu',
        10 => 'Kasese',
        11 => 'Kibale',
        12 => 'Kigorobya',
        13 => 'Kilembe',
        14 => 'Kiruhura',
        15 => 'Kisoro',
        16 => 'Kyenjojo',
        17 => 'Margherita',
        18 => 'Masindi',
        19 => 'Masindi Port',
        20 => 'Mbarara',
        21 => 'Muhororo',
        22 => 'Ntungamo',
        23 => 'Nyachera',
        24 => 'Rukungiri',
      ),
    ),
    'E' => 
    array (
      'name' => 'Eastern Region',
      'cities' => 
      array (
        0 => 'Bugembe',
        1 => 'Bugiri',
        2 => 'Bukwa District',
        3 => 'Bulambuli District',
        4 => 'Busembatia',
        5 => 'Busia',
        6 => 'Buwenge',
        7 => 'Iganga',
        8 => 'Jinja',
        9 => 'Kamuli',
        10 => 'Kapchorwa',
        11 => 'Kibuku District',
        12 => 'Kumi',
        13 => 'Mayuge',
        14 => 'Mbale',
        15 => 'Pallisa',
        16 => 'Sironko',
        17 => 'Soroti',
        18 => 'Tororo',
      ),
    ),
    'C' => 
    array (
      'name' => 'Central Region',
      'cities' => 
      array (
        0 => 'Bukomansimbi District',
        1 => 'Buvuma District',
        2 => 'Bweyogerere',
        3 => 'Byakabanda',
        4 => 'Entebbe',
        5 => 'Gomba District',
        6 => 'Kajansi',
        7 => 'Kampala',
        8 => 'Kampala District',
        9 => 'Kanoni',
        10 => 'Kayunga',
        11 => 'Kiboga',
        12 => 'Kireka',
        13 => 'Kyotera',
        14 => 'Lugazi',
        15 => 'Luwero',
        16 => 'Lyantonde',
        17 => 'Masaka',
        18 => 'Mityana',
        19 => 'Mpigi',
        20 => 'Mubende',
        21 => 'Mubende District',
        22 => 'Mukono',
        23 => 'Nakasongola',
        24 => 'Namasuba',
        25 => 'Njeru',
        26 => 'Sembabule',
        27 => 'Wakiso',
        28 => 'Wakiso District',
        29 => 'Wobulenzi',
      ),
    ),
  ),
  'LI' => 
  array (
    '08' => 
    array (
      'name' => 'Schellenberg',
      'cities' => 
      array (
        0 => 'Schellenberg',
      ),
    ),
    '07' => 
    array (
      'name' => 'Schaan',
      'cities' => 
      array (
        0 => 'Schaan',
      ),
    ),
    '02' => 
    array (
      'name' => 'Eschen',
      'cities' => 
      array (
        0 => 'Eschen',
      ),
    ),
    '06' => 
    array (
      'name' => 'Ruggell',
      'cities' => 
      array (
        0 => 'Ruggell',
      ),
    ),
    '05' => 
    array (
      'name' => 'Planken',
      'cities' => 
      array (
        0 => 'Planken',
      ),
    ),
    '04' => 
    array (
      'name' => 'Mauren',
      'cities' => 
      array (
        0 => 'Mauren',
      ),
    ),
    '03' => 
    array (
      'name' => 'Gamprin',
      'cities' => 
      array (
        0 => 'Gamprin',
      ),
    ),
    '01' => 
    array (
      'name' => 'Balzers',
      'cities' => 
      array (
        0 => 'Balzers',
      ),
    ),
    '09' => 
    array (
      'name' => 'Triesen',
      'cities' => 
      array (
        0 => 'Triesen',
      ),
    ),
  ),
  'BA' => 
  array (
    'BRC' => 
    array (
      'name' => 'Brčko District',
      'cities' => 
      array (
        0 => 'Brka',
        1 => 'Brčko',
      ),
    ),
    'BIH' => 
    array (
      'name' => 'Federation of Bosnia and Herzegovina',
      'cities' => 
      array (
        0 => 'Banovići',
        1 => 'Barice',
        2 => 'Bihać',
        3 => 'Bijela',
        4 => 'Bila',
        5 => 'Blagaj',
        6 => 'Bosanska Krupa',
        7 => 'Bosanski Petrovac',
        8 => 'Bosansko Grahovo',
        9 => 'Breza',
        10 => 'Bugojno',
        11 => 'Busovača',
        12 => 'Bužim',
        13 => 'Cazin',
        14 => 'Cim',
        15 => 'Crnići',
        16 => 'Divičani',
        17 => 'Dobrinje',
        18 => 'Domaljevac',
        19 => 'Donja Dubica',
        20 => 'Donja Mahala',
        21 => 'Donja Međiđa',
        22 => 'Donji Vakuf',
        23 => 'Drežnica',
        24 => 'Drinovci',
        25 => 'Drvar',
        26 => 'Dubrave Donje',
        27 => 'Dubrave Gornje',
        28 => 'Dubravica',
        29 => 'Fojnica',
        30 => 'Glamoč',
        31 => 'Gnojnica',
        32 => 'Goražde',
        33 => 'Gorica',
        34 => 'Gornja Breza',
        35 => 'Gornja Koprivna',
        36 => 'Gornja Tuzla',
        37 => 'Gornje Moštre',
        38 => 'Gornje Živinice',
        39 => 'Gornji Vakuf',
        40 => 'Gostovići',
        41 => 'Gradačac',
        42 => 'Gračanica',
        43 => 'Gromiljak',
        44 => 'Grude',
        45 => 'Hadžići',
        46 => 'Hercegovačko-Neretvanski Kanton',
        47 => 'Hotonj',
        48 => 'Ilijaš',
        49 => 'Ilići',
        50 => 'Izačić',
        51 => 'Jablanica',
        52 => 'Jajce',
        53 => 'Jelah',
        54 => 'Jezerski',
        55 => 'Kakanj',
        56 => 'Kanton Sarajevo',
        57 => 'Karadaglije',
        58 => 'Kačuni',
        59 => 'Kiseljak',
        60 => 'Kladanj',
        61 => 'Ključ',
        62 => 'Kobilja Glava',
        63 => 'Konjic',
        64 => 'Kovači',
        65 => 'Kočerin',
        66 => 'Liješnica',
        67 => 'Livno',
        68 => 'Ljubuški',
        69 => 'Lokvine',
        70 => 'Lukavac',
        71 => 'Lukavica',
        72 => 'Maglaj',
        73 => 'Mahala',
        74 => 'Mala Kladuša',
        75 => 'Malešići',
        76 => 'Mionica',
        77 => 'Mostar',
        78 => 'Mramor',
        79 => 'Neum',
        80 => 'Novi Travnik',
        81 => 'Novi Šeher',
        82 => 'Odžak',
        83 => 'Olovo',
        84 => 'Omanjska',
        85 => 'Orahovica Donja',
        86 => 'Orašac',
        87 => 'Orašje',
        88 => 'Orguz',
        89 => 'Ostrožac',
        90 => 'Otoka',
        91 => 'Pajić Polje',
        92 => 'Pazarić',
        93 => 'Peći',
        94 => 'Pećigrad',
        95 => 'Pjanići',
        96 => 'Podhum',
        97 => 'Podzvizd',
        98 => 'Polje',
        99 => 'Polje-Bijela',
        100 => 'Potoci',
        101 => 'Prozor',
        102 => 'Puračić',
        103 => 'Radišići',
        104 => 'Rodoč',
        105 => 'Rumboci',
        106 => 'Sanica',
        107 => 'Sanski Most',
        108 => 'Sapna',
        109 => 'Sarajevo',
        110 => 'Skokovi',
        111 => 'Sladna',
        112 => 'Solina',
        113 => 'Srebrenik',
        114 => 'Stijena',
        115 => 'Stjepan-Polje',
        116 => 'Stolac',
        117 => 'Tasovčići',
        118 => 'Tešanj',
        119 => 'Tešanjka',
        120 => 'Todorovo',
        121 => 'Tojšići',
        122 => 'Tomislavgrad',
        123 => 'Travnik',
        124 => 'Tržačka Raštela',
        125 => 'Turbe',
        126 => 'Tuzla',
        127 => 'Ustikolina',
        128 => 'Vareš',
        129 => 'Varoška Rijeka',
        130 => 'Velagići',
        131 => 'Velika Kladuša',
        132 => 'Vidoši',
        133 => 'Visoko',
        134 => 'Vitez',
        135 => 'Vitina',
        136 => 'Vogošća',
        137 => 'Voljevac',
        138 => 'Vrnograč',
        139 => 'Vukovije Donje',
        140 => 'Zabrišće',
        141 => 'Zavidovići',
        142 => 'Zborište',
        143 => 'Zenica',
        144 => 'Ćoralići',
        145 => 'Čapljina',
        146 => 'Čelić',
        147 => 'Čitluk',
        148 => 'Šerići',
        149 => 'Široki Brijeg',
        150 => 'Šturlić',
        151 => 'Šumatac',
        152 => 'Željezno Polje',
        153 => 'Žepče',
        154 => 'Živinice',
      ),
    ),
    'SRP' => 
    array (
      'name' => 'Republika Srpska',
      'cities' => 
      array (
        0 => 'Balatun',
        1 => 'Banja Luka',
        2 => 'Bijeljina',
        3 => 'Bileća',
        4 => 'Blatnica',
        5 => 'Brod',
        6 => 'Bronzani Majdan',
        7 => 'Derventa',
        8 => 'Doboj',
        9 => 'Dobrljin',
        10 => 'Dvorovi',
        11 => 'Foča',
        12 => 'Gacko',
        13 => 'Gradiška',
        14 => 'Hiseti',
        15 => 'Istočni Mostar',
        16 => 'Janja',
        17 => 'Kalenderovci Donji',
        18 => 'Kneževo',
        19 => 'Knežica',
        20 => 'Koran',
        21 => 'Kostajnica',
        22 => 'Kotor Varoš',
        23 => 'Kozarska Dubica',
        24 => 'Krupa na Vrbasu',
        25 => 'Laktaši',
        26 => 'Lamovita',
        27 => 'Ljubinje',
        28 => 'Lopare',
        29 => 'Maglajani',
        30 => 'Marićka',
        31 => 'Maslovare',
        32 => 'Mejdan - Obilićevo',
        33 => 'Milići',
        34 => 'Modriča',
        35 => 'Mrkonjić Grad',
        36 => 'Nevesinje',
        37 => 'Novi Grad',
        38 => 'Obudovac',
        39 => 'Omarska',
        40 => 'Opština Oštra Luka',
        41 => 'Opština Višegrad',
        42 => 'Oštra Luka',
        43 => 'Pale',
        44 => 'Pelagićevo',
        45 => 'Petkovci',
        46 => 'Piskavica',
        47 => 'Podbrdo',
        48 => 'Popovi',
        49 => 'Pribinić',
        50 => 'Priboj',
        51 => 'Prijedor',
        52 => 'Rogatica',
        53 => 'Rudo',
        54 => 'Sokolac',
        55 => 'Srbac',
        56 => 'Srebrenica',
        57 => 'Stanari',
        58 => 'Starcevica',
        59 => 'Svodna',
        60 => 'Teslić',
        61 => 'Trebinje',
        62 => 'Trn',
        63 => 'Ugljevik',
        64 => 'Velika Obarska',
        65 => 'Višegrad',
        66 => 'Vlasenica',
        67 => 'Zvornik',
        68 => 'Čajniče',
        69 => 'Čelinac',
        70 => 'Čečava',
        71 => 'Šamac',
        72 => 'Šekovići',
        73 => 'Šipovo',
        74 => 'Živinice',
      ),
    ),
  ),
  'SN' => 
  array (
    'DK' => 
    array (
      'name' => 'Dakar',
      'cities' => 
      array (
        0 => 'Dakar',
        1 => 'Dakar Department',
        2 => 'Guédiawaye Department',
        3 => 'Mermoz Boabab',
        4 => 'N&#039;diareme limamoulaye',
        5 => 'Pikine',
        6 => 'Pikine Department',
        7 => 'Rufisque Department',
      ),
    ),
    'KD' => 
    array (
      'name' => 'Kolda',
      'cities' => 
      array (
        0 => 'Kolda',
        1 => 'Kolda Department',
        2 => 'Marsassoum',
        3 => 'Vélingara',
      ),
    ),
    'KA' => 
    array (
      'name' => 'Kaffrine',
      'cities' => 
      array (
        0 => 'Kaffrine',
        1 => 'Koungheul',
      ),
    ),
    'MT' => 
    array (
      'name' => 'Matam',
      'cities' => 
      array (
        0 => 'Diawara',
        1 => 'Kanel',
        2 => 'Matam',
        3 => 'Matam Department',
        4 => 'Ouro Sogui',
        5 => 'Ranérou',
        6 => 'Sémé',
        7 => 'Waoundé',
      ),
    ),
    'SL' => 
    array (
      'name' => 'Saint-Louis',
      'cities' => 
      array (
        0 => 'Goléré',
        1 => 'Ndioum',
        2 => 'Polel Diaoubé',
        3 => 'Richard-Toll',
        4 => 'Rosso',
        5 => 'Saint-Louis',
      ),
    ),
    'ZG' => 
    array (
      'name' => 'Ziguinchor',
      'cities' => 
      array (
        0 => 'Adéane',
        1 => 'Bignona',
        2 => 'Oussouye',
        3 => 'Tionk Essil',
        4 => 'Ziguinchor',
      ),
    ),
    'FK' => 
    array (
      'name' => 'Fatick',
      'cities' => 
      array (
        0 => 'Diofior',
        1 => 'Fatick Department',
        2 => 'Foundiougne',
        3 => 'Guinguinéo',
        4 => 'Passi',
        5 => 'Pourham',
        6 => 'Sokone',
      ),
    ),
    'DB' => 
    array (
      'name' => 'Diourbel Region',
      'cities' => 
      array (
        0 => 'Mbacké',
        1 => 'Mbaké',
        2 => 'Tiébo',
        3 => 'Touba',
      ),
    ),
    'KE' => 
    array (
      'name' => 'Kédougou',
      'cities' => 
      array (
        0 => 'Département de Salémata',
        1 => 'Kédougou',
        2 => 'Kédougou Department',
        3 => 'Saraya',
      ),
    ),
    'SE' => 
    array (
      'name' => 'Sédhiou',
      'cities' => 
      array (
        0 => 'Goudomp Department',
        1 => 'Sédhiou',
      ),
    ),
    'KL' => 
    array (
      'name' => 'Kaolack',
      'cities' => 
      array (
        0 => 'Gandiaye',
        1 => 'Kaolack',
        2 => 'Ndofane',
        3 => 'Nioro du Rip',
      ),
    ),
    'TH' => 
    array (
      'name' => 'Thiès Region',
      'cities' => 
      array (
        0 => 'Joal-Fadiout',
        1 => 'Kayar',
        2 => 'Khombole',
        3 => 'Mbour',
        4 => 'Mékhé',
        5 => 'Nguékhokh',
        6 => 'Pout',
        7 => 'Thiès',
        8 => 'Thiès Nones',
        9 => 'Tiadiaye',
        10 => 'Tivaouane',
        11 => 'Warang',
      ),
    ),
    'LG' => 
    array (
      'name' => 'Louga',
      'cities' => 
      array (
        0 => 'Dara',
        1 => 'Guéoul',
        2 => 'Linguere Department',
        3 => 'Louga',
        4 => 'Ndibène Dahra',
      ),
    ),
    'TC' => 
    array (
      'name' => 'Tambacounda Region',
      'cities' => 
      array (
        0 => 'Tambacounda',
        1 => 'Tambacounda Department',
      ),
    ),
  ),
  'AD' => 
  array (
    '03' => 
    array (
      'name' => 'Encamp',
      'cities' => 
      array (
        0 => 'Encamp',
        1 => 'Pas de la Casa',
      ),
    ),
    '07' => 
    array (
      'name' => 'Andorra la Vella',
      'cities' => 
      array (
        0 => 'Andorra la Vella',
      ),
    ),
    '02' => 
    array (
      'name' => 'Canillo',
      'cities' => 
      array (
        0 => 'Canillo',
        1 => 'El Tarter',
      ),
    ),
    '06' => 
    array (
      'name' => 'Sant Julià de Lòria',
      'cities' => 
      array (
        0 => 'Sant Julià de Lòria',
      ),
    ),
    '05' => 
    array (
      'name' => 'Ordino',
      'cities' => 
      array (
        0 => 'Ordino',
      ),
    ),
    '08' => 
    array (
      'name' => 'Escaldes-Engordany',
      'cities' => 
      array (
        0 => 'les Escaldes',
      ),
    ),
    '04' => 
    array (
      'name' => 'La Massana',
      'cities' => 
      array (
        0 => 'Arinsal',
        1 => 'la Massana',
      ),
    ),
  ),
  'SC' => 
  array (
    '05' => 
    array (
      'name' => 'Anse Royale',
      'cities' => 
      array (
        0 => 'Anse Royale',
      ),
    ),
    '08' => 
    array (
      'name' => 'Beau Vallon',
      'cities' => 
      array (
        0 => 'Beau Vallon',
      ),
    ),
    '02' => 
    array (
      'name' => 'Anse Boileau',
      'cities' => 
      array (
        0 => 'Anse Boileau',
      ),
    ),
  ),
  'AZ' => 
  array (
    'SA' => 
    array (
      'name' => 'Shaki',
      'cities' => 
      array (
        0 => 'Sheki',
      ),
    ),
    'TAR' => 
    array (
      'name' => 'Tartar District',
      'cities' => 
      array (
        0 => 'Martakert',
        1 => 'Terter',
      ),
    ),
    'SR' => 
    array (
      'name' => 'Shirvan',
      'cities' => 
      array (
        0 => 'Şirvan',
      ),
    ),
    'QAZ' => 
    array (
      'name' => 'Qazakh District',
      'cities' => 
      array (
        0 => 'Qazax',
      ),
    ),
    'YEV' => 
    array (
      'name' => 'Yevlakh District',
      'cities' => 
      array (
        0 => 'Aran',
        1 => 'Qaramanlı',
      ),
    ),
    'XCI' => 
    array (
      'name' => 'Khojali District',
      'cities' => 
      array (
        0 => 'Askyaran',
        1 => 'Xocalı',
      ),
    ),
    'KAL' => 
    array (
      'name' => 'Kalbajar District',
      'cities' => 
      array (
        0 => 'Kerbakhiar',
        1 => 'Vank',
      ),
    ),
    'QAX' => 
    array (
      'name' => 'Qakh District',
      'cities' => 
      array (
        0 => 'Qax',
        1 => 'Qax İngiloy',
        2 => 'Qaxbaş',
        3 => 'Çinarlı',
      ),
    ),
    'FUZ' => 
    array (
      'name' => 'Fizuli District',
      'cities' => 
      array (
        0 => 'Fizuli',
        1 => 'Horadiz',
      ),
    ),
    'AST' => 
    array (
      'name' => 'Astara District',
      'cities' => 
      array (
        0 => 'Astara',
        1 => 'Kizhaba',
      ),
    ),
    'SMI' => 
    array (
      'name' => 'Shamakhi District',
      'cities' => 
      array (
        0 => 'Shamakhi',
      ),
    ),
    'NEF' => 
    array (
      'name' => 'Neftchala District',
      'cities' => 
      array (
        0 => 'Neftçala',
        1 => 'Severo-Vostotchnyi Bank',
        2 => 'Sovetabad',
        3 => 'Xıllı',
      ),
    ),
    'GOY' => 
    array (
      'name' => 'Goychay',
      'cities' => 
      array (
        0 => 'Geoktschai',
      ),
    ),
    'BIL' => 
    array (
      'name' => 'Bilasuvar District',
      'cities' => 
      array (
        0 => 'Pushkino',
      ),
    ),
    'TOV' => 
    array (
      'name' => 'Tovuz District',
      'cities' => 
      array (
        0 => 'Dondar Quşçu',
        1 => 'Qaraxanlı',
        2 => 'Tovuz',
        3 => 'Yanıqlı',
        4 => 'Çatax',
        5 => 'Çobansığnaq',
      ),
    ),
    'SMX' => 
    array (
      'name' => 'Samukh District',
      'cities' => 
      array (
        0 => 'Qarayeri',
        1 => 'Qırmızı Samux',
        2 => 'Samux',
      ),
    ),
    'XIZ' => 
    array (
      'name' => 'Khizi District',
      'cities' => 
      array (
        0 => 'Altıağac',
        1 => 'Khyzy',
        2 => 'Kilyazi',
        3 => 'Şuraabad',
      ),
    ),
    'YE' => 
    array (
      'name' => 'Yevlakh',
      'cities' => 
      array (
        0 => 'Yevlakh',
      ),
    ),
    'UCA' => 
    array (
      'name' => 'Ujar District',
      'cities' => 
      array (
        0 => 'Ujar',
      ),
    ),
    'ABS' => 
    array (
      'name' => 'Absheron District',
      'cities' => 
      array (
        0 => 'Ceyranbatan',
        1 => 'Digah',
        2 => 'Gyuzdek',
        3 => 'Khirdalan',
        4 => 'Qobu',
        5 => 'Saray',
      ),
    ),
    'LAC' => 
    array (
      'name' => 'Lachin District',
      'cities' => 
      array (
        0 => 'Laçın',
      ),
    ),
    'QAB' => 
    array (
      'name' => 'Qabala District',
      'cities' => 
      array (
        0 => 'Qutqashen',
      ),
    ),
    'AGA' => 
    array (
      'name' => 'Agstafa District',
      'cities' => 
      array (
        0 => 'Aghstafa',
        1 => 'Saloğlu',
        2 => 'Vurğun',
      ),
    ),
    'IMI' => 
    array (
      'name' => 'Imishli District',
      'cities' => 
      array (
        0 => 'Imishli',
      ),
    ),
    'SAL' => 
    array (
      'name' => 'Salyan District',
      'cities' => 
      array (
        0 => 'Qaraçala',
        1 => 'Salyan',
      ),
    ),
    'LER' => 
    array (
      'name' => 'Lerik District',
      'cities' => 
      array (
        0 => 'Lerik',
      ),
    ),
    'AGU' => 
    array (
      'name' => 'Agsu District',
      'cities' => 
      array (
        0 => 'Aghsu',
      ),
    ),
    'QBI' => 
    array (
      'name' => 'Qubadli District',
      'cities' => 
      array (
        0 => 'Qubadlı',
      ),
    ),
    'KUR' => 
    array (
      'name' => 'Kurdamir District',
      'cities' => 
      array (
        0 => 'Kyurdarmir',
      ),
    ),
    'YAR' => 
    array (
      'name' => 'Yardymli District',
      'cities' => 
      array (
        0 => 'Yardımlı',
      ),
    ),
    'GOR' => 
    array (
      'name' => 'Goranboy District',
      'cities' => 
      array (
        0 => 'Goranboy',
        1 => 'Qızılhacılı',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Baku',
      'cities' => 
      array (
        0 => 'Amirdzhan',
        1 => 'Badamdar',
        2 => 'Baku',
        3 => 'Bakıxanov',
        4 => 'Balakhani',
        5 => 'Bilajari',
        6 => 'Bilajer',
        7 => 'Binagadi',
        8 => 'Biny Selo',
        9 => 'Buzovna',
        10 => 'Hövsan',
        11 => 'Khodzhi-Gasan',
        12 => 'Korgöz',
        13 => 'Lökbatan',
        14 => 'Mardakan',
        15 => 'Maştağa',
        16 => 'Nardaran',
        17 => 'Nizami Rayonu',
        18 => 'Pirallahı',
        19 => 'Puta',
        20 => 'Qala',
        21 => 'Qaraçuxur',
        22 => 'Qobustan',
        23 => 'Ramana',
        24 => 'Sabunçu',
        25 => 'Sanqaçal',
        26 => 'Türkan',
        27 => 'Yeni Suraxanı',
        28 => 'Zabrat',
        29 => 'Zyrya',
      ),
    ),
    'AGS' => 
    array (
      'name' => 'Agdash District',
      'cities' => 
      array (
        0 => 'Ağdaş',
      ),
    ),
    'BEY' => 
    array (
      'name' => 'Beylagan District',
      'cities' => 
      array (
        0 => 'Beylagan',
        1 => 'Birinci Aşıqlı',
        2 => 'Dünyamalılar',
        3 => 'Orjonikidze',
        4 => 'Yuxarı Aran',
      ),
    ),
    'MAS' => 
    array (
      'name' => 'Masally District',
      'cities' => 
      array (
        0 => 'Boradigah',
        1 => 'Masally',
      ),
    ),
    'OGU' => 
    array (
      'name' => 'Oghuz District',
      'cities' => 
      array (
        0 => 'Oğuz',
      ),
    ),
    'SAT' => 
    array (
      'name' => 'Saatly District',
      'cities' => 
      array (
        0 => 'Saatlı',
        1 => 'Əhmədbəyli',
      ),
    ),
    'LA' => 
    array (
      'name' => 'Lankaran District',
      'cities' => 
      array (
        0 => 'Haftoni',
        1 => 'Lankaran',
      ),
    ),
    'AGM' => 
    array (
      'name' => 'Agdam District',
      'cities' => 
      array (
        0 => 'Ağdam',
      ),
    ),
    'BAL' => 
    array (
      'name' => 'Balakan District',
      'cities' => 
      array (
        0 => 'Belokany',
        1 => 'Qabaqçöl',
      ),
    ),
    'DAS' => 
    array (
      'name' => 'Dashkasan District',
      'cities' => 
      array (
        0 => 'Verkhniy Dashkesan',
        1 => 'Yukhary-Dashkesan',
      ),
    ),
    'NX' => 
    array (
      'name' => 'Nakhchivan Autonomous Republic',
      'cities' => 
      array (
        0 => 'Cahri',
        1 => 'Culfa',
        2 => 'Deste',
        3 => 'Heydarabad',
        4 => 'Julfa Rayon',
        5 => 'Nakhchivan',
        6 => 'Ordubad',
        7 => 'Ordubad Rayon',
        8 => 'Oğlanqala',
        9 => 'Qıvraq',
        10 => 'Sedarak',
        11 => 'Shahbuz Rayon',
        12 => 'Sharur City',
        13 => 'Sumbatan-diza',
        14 => 'Tazakend',
        15 => 'Yaycı',
        16 => 'Çalxanqala',
        17 => 'Şahbuz',
      ),
    ),
    'QBA' => 
    array (
      'name' => 'Quba District',
      'cities' => 
      array (
        0 => 'Hacıhüseynli',
        1 => 'Quba',
      ),
    ),
    'ISM' => 
    array (
      'name' => 'Ismailli District',
      'cities' => 
      array (
        0 => 'Basqal',
        1 => 'İsmayıllı',
      ),
    ),
    'SAB' => 
    array (
      'name' => 'Sabirabad District',
      'cities' => 
      array (
        0 => 'Sabirabad',
      ),
    ),
    'ZAQ' => 
    array (
      'name' => 'Zaqatala District',
      'cities' => 
      array (
        0 => 'Aliabad',
        1 => 'Faldarlı',
        2 => 'Mamrux',
        3 => 'Qandax',
        4 => 'Zaqatala',
      ),
    ),
    'XVD' => 
    array (
      'name' => 'Martuni',
      'cities' => 
      array (
        0 => 'Hadrut',
        1 => 'Novyy Karanlug',
        2 => 'Qırmızı Bazar',
      ),
    ),
    'BAR' => 
    array (
      'name' => 'Barda District',
      'cities' => 
      array (
        0 => 'Barda',
        1 => 'Samuxlu',
      ),
    ),
    'CAB' => 
    array (
      'name' => 'Jabrayil District',
      'cities' => 
      array (
        0 => 'Jebrail',
      ),
    ),
    'HAC' => 
    array (
      'name' => 'Hajigabul District',
      'cities' => 
      array (
        0 => 'Hacıqabul',
        1 => 'Mughan',
      ),
    ),
    'QOB' => 
    array (
      'name' => 'Gobustan District',
      'cities' => 
      array (
        0 => 'Qobustan',
      ),
    ),
    'GYG' => 
    array (
      'name' => 'Goygol District',
      'cities' => 
      array (
        0 => 'Yelenendorf',
      ),
    ),
    'ZAR' => 
    array (
      'name' => 'Zardab District',
      'cities' => 
      array (
        0 => 'Zardob',
      ),
    ),
    'AGC' => 
    array (
      'name' => 'Aghjabadi District',
      'cities' => 
      array (
        0 => 'Agdzhabedy',
        1 => 'Avşar',
      ),
    ),
    'CAL' => 
    array (
      'name' => 'Jalilabad District',
      'cities' => 
      array (
        0 => 'Jalilabad',
        1 => 'Prishibinskoye',
      ),
    ),
    'MI' => 
    array (
      'name' => 'Mingachevir',
      'cities' => 
      array (
        0 => 'Mingelchaur',
      ),
    ),
    'ZAN' => 
    array (
      'name' => 'Zangilan District',
      'cities' => 
      array (
        0 => 'Mincivan',
        1 => 'Zangilan',
      ),
    ),
    'SM' => 
    array (
      'name' => 'Sumqayit',
      'cities' => 
      array (
        0 => 'Corat',
        1 => 'Hacı Zeynalabdin',
        2 => 'Sumqayıt',
      ),
    ),
    'SKR' => 
    array (
      'name' => 'Shamkir District',
      'cities' => 
      array (
        0 => 'Dolyar',
        1 => 'Dzagam',
        2 => 'Qasım İsmayılov',
        3 => 'Shamkhor',
      ),
    ),
    'SIY' => 
    array (
      'name' => 'Siazan District',
      'cities' => 
      array (
        0 => 'Gilgilçay',
        1 => 'Kyzyl-Burun',
      ),
    ),
    'GA' => 
    array (
      'name' => 'Ganja',
      'cities' => 
      array (
        0 => 'Ganja',
      ),
    ),
    'SAK' => 
    array (
      'name' => 'Shaki District',
      'cities' => 
      array (
        0 => 'Baş Göynük',
      ),
    ),
    'QUS' => 
    array (
      'name' => 'Qusar District',
      'cities' => 
      array (
        0 => 'Qusar',
        1 => 'Samur',
      ),
    ),
    'GAD' => 
    array (
      'name' => 'Gədəbəy',
      'cities' => 
      array (
        0 => 'Arıqdam',
        1 => 'Arıqıran',
        2 => 'Böyük Qaramurad',
        3 => 'Kyadabek',
        4 => 'Novosaratovka',
      ),
    ),
    'XAC' => 
    array (
      'name' => 'Khachmaz District',
      'cities' => 
      array (
        0 => 'Xaçmaz',
        1 => 'Xudat',
      ),
    ),
    'SBN' => 
    array (
      'name' => 'Shabran District',
      'cities' => 
      array (
        0 => 'Divichibazar',
      ),
    ),
    'SUS' => 
    array (
      'name' => 'Shusha District',
      'cities' => 
      array (
        0 => 'Shushi',
      ),
    ),
  ),
  'AL' => 
  array (
    '08' => 
    array (
      'name' => 'Lezhë County',
      'cities' => 
      array (
        0 => 'Bashkia Kurbin',
        1 => 'Bashkia Lezhë',
        2 => 'Bashkia Mirditë',
        3 => 'Kurbnesh',
        4 => 'Laç',
        5 => 'Lezhë',
        6 => 'Mamurras',
        7 => 'Milot',
        8 => 'Rrethi i Kurbinit',
        9 => 'Rrëshen',
        10 => 'Rubik',
        11 => 'Shëngjin',
      ),
    ),
    '09' => 
    array (
      'name' => 'Dibër County',
      'cities' => 
      array (
        0 => 'Bashkia Bulqizë',
        1 => 'Bashkia Klos',
        2 => 'Bashkia Mat',
        3 => 'Bulqizë',
        4 => 'Burrel',
        5 => 'Klos',
        6 => 'Peshkopi',
        7 => 'Rrethi i Bulqizës',
        8 => 'Rrethi i Dibrës',
        9 => 'Rrethi i Matit',
        10 => 'Ulëz',
      ),
    ),
    'GJ' => 
    array (
      'name' => 'Gjirokastër District',
      'cities' => 
      array (
        0 => 'Bashkia Dropull',
        1 => 'Bashkia Kelcyrë',
        2 => 'Bashkia Libohovë',
        3 => 'Bashkia Memaliaj',
        4 => 'Bashkia Përmet',
        5 => 'Bashkia Tepelenë',
        6 => 'Gjinkar',
        7 => 'Gjirokastër',
        8 => 'Këlcyrë',
        9 => 'Lazarat',
        10 => 'Libohovë',
        11 => 'Memaliaj',
        12 => 'Përmet',
        13 => 'Tepelenë',
      ),
    ),
    'KU' => 
    array (
      'name' => 'Kukës District',
      'cities' => 
      array (
        0 => 'Bajram Curri',
        1 => 'Krumë',
        2 => 'Kukës',
        3 => 'Rrethi i Hasit',
        4 => 'Rrethi i Kukësit',
      ),
    ),
    'SH' => 
    array (
      'name' => 'Shkodër District',
      'cities' => 
      array (
        0 => 'Bashkia Malësi e Madhe',
        1 => 'Bashkia Pukë',
        2 => 'Bashkia Vau i Dejës',
        3 => 'Fushë-Arrëz',
        4 => 'Koplik',
        5 => 'Pukë',
        6 => 'Rrethi i Malësia e Madhe',
        7 => 'Rrethi i Shkodrës',
        8 => 'Shkodër',
        9 => 'Vau i Dejës',
        10 => 'Vukatanë',
      ),
    ),
    'BR' => 
    array (
      'name' => 'Berat District',
      'cities' => 
      array (
        0 => 'Banaj',
        1 => 'Bashkia Berat',
        2 => 'Bashkia Kuçovë',
        3 => 'Bashkia Poliçan',
        4 => 'Bashkia Skrapar',
        5 => 'Berat',
        6 => 'Kuçovë',
        7 => 'Poliçan',
        8 => 'Rrethi i Beratit',
        9 => 'Rrethi i Kuçovës',
        10 => 'Rrethi i Skraparit',
        11 => 'Ura Vajgurore',
        12 => 'Çorovodë',
      ),
    ),
    '06' => 
    array (
      'name' => 'Korçë County',
      'cities' => 
      array (
        0 => 'Bashkia Devoll',
        1 => 'Bashkia Kolonjë',
        2 => 'Bashkia Maliq',
        3 => 'Bashkia Pustec',
        4 => 'Bilisht',
        5 => 'Ersekë',
        6 => 'Korçë',
        7 => 'Leskovik',
        8 => 'Libonik',
        9 => 'Maliq',
        10 => 'Mborje',
        11 => 'Pogradec',
        12 => 'Rrethi i Devollit',
        13 => 'Rrethi i Kolonjës',
        14 => 'Velçan',
        15 => 'Voskopojë',
      ),
    ),
    '04' => 
    array (
      'name' => 'Fier County',
      'cities' => 
      array (
        0 => 'Ballsh',
        1 => 'Bashkia Divjakë',
        2 => 'Bashkia Fier',
        3 => 'Bashkia Mallakastër',
        4 => 'Bashkia Patos',
        5 => 'Divjakë',
        6 => 'Fier',
        7 => 'Fier-Çifçi',
        8 => 'Lushnjë',
        9 => 'Patos',
        10 => 'Patos Fshat',
        11 => 'Roskovec',
        12 => 'Rrethi i Mallakastrës',
      ),
    ),
    'TR' => 
    array (
      'name' => 'Tirana District',
      'cities' => 
      array (
        0 => 'Bashkia Kavajë',
        1 => 'Bashkia Vorë',
        2 => 'Kamëz',
        3 => 'Kavajë',
        4 => 'Krrabë',
        5 => 'Rrethi i Kavajës',
        6 => 'Rrethi i Tiranës',
        7 => 'Rrogozhinë',
        8 => 'Sinaballaj',
        9 => 'Tirana',
        10 => 'Vorë',
      ),
    ),
    'DR' => 
    array (
      'name' => 'Durrës District',
      'cities' => 
      array (
        0 => 'Bashkia Durrës',
        1 => 'Bashkia Krujë',
        2 => 'Bashkia Shijak',
        3 => 'Durrës',
        4 => 'Durrës District',
        5 => 'Fushë-Krujë',
        6 => 'Krujë',
        7 => 'Rrethi i Krujës',
        8 => 'Shijak',
        9 => 'Sukth',
      ),
    ),
  ),
  'MK' => 
  array (
    '05' => 
    array (
      'name' => 'Bogdanci Municipality',
      'cities' => 
      array (
        0 => 'Bogdanci',
        1 => 'Stojakovo',
      ),
    ),
    '07' => 
    array (
      'name' => 'Bosilovo Municipality',
      'cities' => 
      array (
        0 => 'Bosilovo',
        1 => 'Ilovica',
        2 => 'Sekirnik',
      ),
    ),
    '02' => 
    array (
      'name' => 'Aračinovo Municipality',
      'cities' => 
      array (
        0 => 'Арачиново',
      ),
    ),
    '08' => 
    array (
      'name' => 'Brvenica Municipality',
      'cities' => 
      array (
        0 => 'Brvenica',
        1 => 'Gurgurnica',
        2 => 'Miletino',
        3 => 'Čelopek',
      ),
    ),
    '04' => 
    array (
      'name' => 'Bitola Municipality',
      'cities' => 
      array (
        0 => 'Bistrica',
        1 => 'Bitola',
        2 => 'Capari',
        3 => 'Dolno Orizari',
        4 => 'Gorno Orizari',
        5 => 'Kukurečani',
        6 => 'Logovardi',
      ),
    ),
    '09' => 
    array (
      'name' => 'Butel Municipality',
      'cities' => 
      array (
        0 => 'Butel',
        1 => 'Radishani',
      ),
    ),
    '03' => 
    array (
      'name' => 'Berovo Municipality',
      'cities' => 
      array (
        0 => 'Berovo',
        1 => 'Rusinovo',
        2 => 'Vladimirovo',
      ),
    ),
    '06' => 
    array (
      'name' => 'Bogovinje Municipality',
      'cities' => 
      array (
        0 => 'Bogovinje',
        1 => 'Dolno Palčište',
        2 => 'Gradec',
        3 => 'Kamenjane',
      ),
    ),
  ),
  'HR' => 
  array (
    '02' => 
    array (
      'name' => 'Krapina-Zagorje County',
      'cities' => 
      array (
        0 => 'Bedekovčina',
        1 => 'Budinščina',
        2 => 'Grad Donja Stubica',
        3 => 'Grad Klanjec',
        4 => 'Grad Krapina',
        5 => 'Grad Zabok',
        6 => 'Grad Zlatar',
        7 => 'Jesenje',
        8 => 'Klanjec',
        9 => 'Konjščina',
        10 => 'Krapina',
        11 => 'Kumrovec',
        12 => 'Marija Bistrica',
        13 => 'Mače',
        14 => 'Mihovljan',
        15 => 'Oroslavje',
        16 => 'Pregrada',
        17 => 'Radoboj',
        18 => 'Stubičke Toplice',
        19 => 'Sveti Križ Začretje',
        20 => 'Zabok',
        21 => 'Zlatar',
        22 => 'Zlatar Bistrica',
        23 => 'Đurmanec',
      ),
    ),
    '09' => 
    array (
      'name' => 'Lika-Senj County',
      'cities' => 
      array (
        0 => 'Brinje',
        1 => 'Gospić',
        2 => 'Karlobag',
        3 => 'Lički Osik',
        4 => 'Novalja',
        5 => 'Otočac',
        6 => 'Perušić',
        7 => 'Plitvička Jezera',
        8 => 'Popovača',
        9 => 'Senj',
      ),
    ),
    '03' => 
    array (
      'name' => 'Sisak-Moslavina County',
      'cities' => 
      array (
        0 => 'Budaševo',
        1 => 'Dvor',
        2 => 'Glina',
        3 => 'Grad Glina',
        4 => 'Grad Hrvatska Kostajnica',
        5 => 'Grad Kutina',
        6 => 'Grad Novska',
        7 => 'Grad Petrinja',
        8 => 'Grad Sisak',
        9 => 'Gvozd',
        10 => 'Hrvatska Kostajnica',
        11 => 'Kutina',
        12 => 'Lekenik',
        13 => 'Lipovljani',
        14 => 'Martinska Ves',
        15 => 'Novska',
        16 => 'Općina Dvor',
        17 => 'Općina Gvozd',
        18 => 'Petrinja',
        19 => 'Popovača',
        20 => 'Repušnica',
        21 => 'Sisak',
        22 => 'Sunja',
        23 => 'Voloder',
      ),
    ),
    '07' => 
    array (
      'name' => 'Bjelovar-Bilogora County',
      'cities' => 
      array (
        0 => 'Bjelovar',
        1 => 'Brezovac',
        2 => 'Daruvar',
        3 => 'Dežanovac',
        4 => 'Garešnica',
        5 => 'Grad Bjelovar',
        6 => 'Grad Daruvar',
        7 => 'Grad Garešnica',
        8 => 'Grad Grubišno Polje',
        9 => 'Grad Čazma',
        10 => 'Grubišno Polje',
        11 => 'Gudovac',
        12 => 'Hercegovac',
        13 => 'Ivanska',
        14 => 'Kapela',
        15 => 'Končanica',
        16 => 'Predavac',
        17 => 'Rovišće',
        18 => 'Severin',
        19 => 'Sirač',
        20 => 'Velika Pisanica',
        21 => 'Veliki Grđevac',
        22 => 'Zrinski Topolovac',
        23 => 'Čazma',
        24 => 'Đulovac',
        25 => 'Šandrovac',
        26 => 'Ždralovi',
      ),
    ),
    '08' => 
    array (
      'name' => 'Primorje-Gorski Kotar County',
      'cities' => 
      array (
        0 => 'Bakar',
        1 => 'Banjol',
        2 => 'Baška',
        3 => 'Bribir',
        4 => 'Buzdohanj',
        5 => 'Cernik',
        6 => 'Cres',
        7 => 'Crikvenica',
        8 => 'Delnice',
        9 => 'Dražice',
        10 => 'Drenova',
        11 => 'Fužine',
        12 => 'Grad Crikvenica',
        13 => 'Grad Delnice',
        14 => 'Grad Krk',
        15 => 'Grad Opatija',
        16 => 'Grad Rijeka',
        17 => 'Grad Vrbovsko',
        18 => 'Grad Čabar',
        19 => 'Hreljin',
        20 => 'Jadranovo',
        21 => 'Kampor',
        22 => 'Kastav',
        23 => 'Klana',
        24 => 'Kraljevica',
        25 => 'Krasica',
        26 => 'Krk',
        27 => 'Lopar',
        28 => 'Lovran',
        29 => 'Mali Lošinj',
        30 => 'Malinska-Dubašnica',
        31 => 'Marinići',
        32 => 'Marčelji',
        33 => 'Matulji',
        34 => 'Mihotići',
        35 => 'Mrkopalj',
        36 => 'Njivice',
        37 => 'Novi Vinodolski',
        38 => 'Omišalj',
        39 => 'Opatija',
        40 => 'Podhum',
        41 => 'Punat',
        42 => 'Rab',
        43 => 'Rijeka',
        44 => 'Rubeši',
        45 => 'Selce',
        46 => 'Skrad',
        47 => 'Supetarska Draga',
        48 => 'Vinodolska općina',
        49 => 'Viškovo',
        50 => 'Vrbnik',
        51 => 'Vrbovsko',
        52 => 'Čavle',
        53 => 'Škrljevo',
      ),
    ),
    '01' => 
    array (
      'name' => 'Zagreb County',
      'cities' => 
      array (
        0 => 'Bestovje',
        1 => 'Bistra',
        2 => 'Brckovljani',
        3 => 'Brdovec',
        4 => 'Bregana',
        5 => 'Donja Bistra',
        6 => 'Donja Lomnica',
        7 => 'Donja Zdenčina',
        8 => 'Donji Stupnik',
        9 => 'Farkaševac',
        10 => 'Gornja Bistra',
        11 => 'Grad Dugo Selo',
        12 => 'Grad Jastrebarsko',
        13 => 'Grad Samobor',
        14 => 'Grad Sveti Ivan Zelina',
        15 => 'Grad Velika Gorica',
        16 => 'Grad Vrbovec',
        17 => 'Grad Zaprešić',
        18 => 'Gradec',
        19 => 'Gradići',
        20 => 'Gračec',
        21 => 'Jablanovec',
        22 => 'Jakovlje',
        23 => 'Jastrebarsko',
        24 => 'Kerestinec',
        25 => 'Križ',
        26 => 'Kuče',
        27 => 'Lonjica',
        28 => 'Luka',
        29 => 'Lukavec',
        30 => 'Lupoglav',
        31 => 'Mičevec',
        32 => 'Mraclin',
        33 => 'Novo Čiče',
        34 => 'Novoselec',
        35 => 'Općina Dubrava',
        36 => 'Orešje',
        37 => 'Pojatno',
        38 => 'Preseka',
        39 => 'Prigorje Brdovečko',
        40 => 'Pušća',
        41 => 'Rakitje',
        42 => 'Rakov Potok',
        43 => 'Rude',
        44 => 'Samobor',
        45 => 'Stupnik',
        46 => 'Sveta Nedelja',
        47 => 'Sveta Nedjelja',
        48 => 'Velika Gorica',
        49 => 'Velika Mlaka',
        50 => 'Velika Ostrna',
        51 => 'Vrbovec',
        52 => 'Zaprešić',
        53 => 'Zdenci Brdovečki',
      ),
    ),
    '05' => 
    array (
      'name' => 'Varaždin County',
      'cities' => 
      array (
        0 => 'Beretinec',
        1 => 'Breznica',
        2 => 'Breznički Hum',
        3 => 'Cestica',
        4 => 'Donje Ladanje',
        5 => 'Gornje Vratno',
        6 => 'Gornji Kneginec',
        7 => 'Grad Ivanec',
        8 => 'Grad Ludbreg',
        9 => 'Grad Novi Marof',
        10 => 'Grad Varaždin',
        11 => 'Hrašćica',
        12 => 'Ivanec',
        13 => 'Jalkovec',
        14 => 'Jalžabet',
        15 => 'Klenovnik',
        16 => 'Kućan Marof',
        17 => 'Lepoglava',
        18 => 'Ljubešćica',
        19 => 'Ludbreg',
        20 => 'Nedeljanec',
        21 => 'Petrijanec',
        22 => 'Remetinec',
        23 => 'Sračinec',
        24 => 'Sveti Đurđ',
        25 => 'Tužno',
        26 => 'Varaždin',
        27 => 'Vidovec',
        28 => 'Vinica',
      ),
    ),
    '06' => 
    array (
      'name' => 'Koprivnica-Križevci County',
      'cities' => 
      array (
        0 => 'Drnje',
        1 => 'Ferdinandovac',
        2 => 'Gola',
        3 => 'Gornja Rijeka',
        4 => 'Grad Koprivnica',
        5 => 'Grad Križevci',
        6 => 'Hlebine',
        7 => 'Kalinovac',
        8 => 'Koprivnica',
        9 => 'Koprivnički Ivanec',
        10 => 'Križevci',
        11 => 'Legrad',
        12 => 'Molve',
        13 => 'Novo Virje',
        14 => 'Peteranec',
        15 => 'Rasinja',
        16 => 'Reka',
        17 => 'Sigetec',
        18 => 'Virje',
        19 => 'Đelekovec',
        20 => 'Đurđevac',
      ),
    ),
  ),
  'CY' => 
  array (
    '06' => 
    array (
      'name' => 'Kyrenia District',
      'cities' => 
      array (
        0 => 'Kyrenia',
        1 => 'Kyrenia Municipality',
        2 => 'Lápithos',
      ),
    ),
    '01' => 
    array (
      'name' => 'Nicosia District',
      'cities' => 
      array (
        0 => 'Akáki',
        1 => 'Alámpra',
        2 => 'Aredioú',
        3 => 'Astromerítis',
        4 => 'Dáli',
        5 => 'Ergátes',
        6 => 'Géri',
        7 => 'Kakopetriá',
        8 => 'Klírou',
        9 => 'Kokkinotrimithiá',
        10 => 'Káto Defterá',
        11 => 'Káto Pýrgos',
        12 => 'Lythrodóntas',
        13 => 'Léfka',
        14 => 'Lýmpia',
        15 => 'Mámmari',
        16 => 'Méniko',
        17 => 'Mórfou',
        18 => 'Nicosia',
        19 => 'Nicosia Municipality',
        20 => 'Peristeróna',
        21 => 'Psimolofou',
        22 => 'Páno Defterá',
        23 => 'Péra',
        24 => 'Tséri',
      ),
    ),
    '05' => 
    array (
      'name' => 'Paphos District',
      'cities' => 
      array (
        0 => 'Argáka',
        1 => 'Chlórakas',
        2 => 'Emba',
        3 => 'Geroskipou',
        4 => 'Geroskípou (quarter)',
        5 => 'Geroskípou Municipality',
        6 => 'Kissonerga',
        7 => 'Koloni',
        8 => 'Konia',
        9 => 'Mesógi',
        10 => 'Paphos',
        11 => 'Pégeia',
        12 => 'Pólis',
        13 => 'Tsáda',
        14 => 'Tála',
      ),
    ),
    '03' => 
    array (
      'name' => 'Larnaca District',
      'cities' => 
      array (
        0 => 'Aradíppou',
        1 => 'Athíenou',
        2 => 'Dhromolaxia',
        3 => 'Kofínou',
        4 => 'Kolossi',
        5 => 'Kíti',
        6 => 'Kórnos',
        7 => 'Larnaca',
        8 => 'Livádia',
        9 => 'Meneou',
        10 => 'Mosfilotí',
        11 => 'Perivólia',
        12 => 'Psevdás',
        13 => 'Pérgamos',
        14 => 'Pýla',
        15 => 'Tersefánou',
        16 => 'Troúlloi',
        17 => 'Voróklini',
        18 => 'Xylofágou',
        19 => 'Xylotymbou',
        20 => 'Ágios Týchon',
      ),
    ),
    '02' => 
    array (
      'name' => 'Limassol District',
      'cities' => 
      array (
        0 => 'Erími',
        1 => 'Germasógeia',
        2 => 'Kyperoúnta',
        3 => 'Lemesós',
        4 => 'Limassol',
        5 => 'Mouttagiáka',
        6 => 'Parekklisha',
        7 => 'Peléndri',
        8 => 'Pissoúri',
        9 => 'Pyrgos',
        10 => 'Páchna',
        11 => 'Páno Polemídia',
        12 => 'Sotíra',
        13 => 'Soúni-Zanakiá',
        14 => 'Ágios Tomás',
        15 => 'Ýpsonas',
      ),
    ),
    '04' => 
    array (
      'name' => 'Famagusta District',
      'cities' => 
      array (
        0 => 'Acherítou',
        1 => 'Ammochostos Municipality',
        2 => 'Avgórou',
        3 => 'Ayia Napa',
        4 => 'Derýneia',
        5 => 'Famagusta',
        6 => 'Frénaros',
        7 => 'Lefkónoiko',
        8 => 'Leonárisso',
        9 => 'Liopétri',
        10 => 'Paralímni',
        11 => 'Protaras',
        12 => 'Rizokárpaso',
        13 => 'Tríkomo',
        14 => 'Áchna',
      ),
    ),
  ),
  'BD' => 
  array (
    'B' => 
    array (
      'name' => 'Chittagong Division',
      'cities' => 
      array (
        0 => 'Bandarban',
        1 => 'Bibir Hat',
        2 => 'Brahmanbaria',
        3 => 'Bāndarban',
        4 => 'Chandpur',
        5 => 'Chhāgalnāiya',
        6 => 'Chittagong',
        7 => 'Comilla',
        8 => 'Cox&#039;s Bazar',
        9 => 'Cox&#039;s Bāzār',
        10 => 'Feni',
        11 => 'Hājīganj',
        12 => 'Khagrachhari',
        13 => 'Lakshmipur',
        14 => 'Lakshmīpur',
        15 => 'Lākshām',
        16 => 'Manikchari',
        17 => 'Nabīnagar',
        18 => 'Noakhali',
        19 => 'Patiya',
        20 => 'Rangamati',
        21 => 'Raojān',
        22 => 'Rāipur',
        23 => 'Rāmganj',
        24 => 'Sandwīp',
        25 => 'Sātkania',
        26 => 'Teknāf',
      ),
    ),
    '06' => 
    array (
      'name' => 'Barisal District',
      'cities' => 
      array (
        0 => 'Barguna',
        1 => 'Barisal',
        2 => 'Barisāl',
        3 => 'Bhola',
        4 => 'Bhāndāria',
        5 => 'Burhānuddin',
        6 => 'Gaurnadi',
        7 => 'Jhalokati',
        8 => 'Lālmohan',
        9 => 'Mathba',
        10 => 'Mehendiganj',
        11 => 'Nālchiti',
        12 => 'Patuakhali',
        13 => 'Pirojpur',
      ),
    ),
  ),
  'JP' => 
  array (
    '05' => 
    array (
      'name' => 'Akita Prefecture',
      'cities' => 
      array (
        0 => 'Akita',
        1 => 'Akita Shi',
        2 => 'Daisen',
        3 => 'Daisen-shi',
        4 => 'Hanawa',
        5 => 'Kakunodatemachi',
        6 => 'Katagami',
        7 => 'Katagami-shi',
        8 => 'Kazuno Shi',
        9 => 'Kitaakita-shi',
        10 => 'Nikaho-shi',
        11 => 'Noshiro',
        12 => 'Noshiro Shi',
        13 => 'Oga',
        14 => 'Oga-shi',
        15 => 'Semboku-shi',
        16 => 'Takanosu',
        17 => 'Tennō',
        18 => 'Yokote',
        19 => 'Yokote-shi',
        20 => 'Yurihonjō',
        21 => 'Yurihonjō-shi',
        22 => 'Yuzawa',
        23 => 'Yuzawa-shi',
        24 => 'Ōdate',
        25 => 'Ōdate-shi',
        26 => 'Ōmagari',
      ),
    ),
    '01' => 
    array (
      'name' => 'Hokkaidō Prefecture',
      'cities' => 
      array (
        0 => 'Abashiri',
        1 => 'Abashiri Shi',
        2 => 'Akabira',
        3 => 'Akabira-shi',
        4 => 'Asahikawa',
        5 => 'Ashibetsu',
        6 => 'Ashibetsu-shi',
        7 => 'Bibai',
        8 => 'Chitose',
        9 => 'Chitose Shi',
        10 => 'Date',
        11 => 'Date-shi',
        12 => 'Ebetsu',
        13 => 'Eniwa-shi',
        14 => 'Fukagawa',
        15 => 'Fukagawa-shi',
        16 => 'Furano-shi',
        17 => 'Hakodate',
        18 => 'Hakodate Shi',
        19 => 'Hokuto',
        20 => 'Hokuto-shi',
        21 => 'Honchō',
        22 => 'Ishikari',
        23 => 'Ishikari-shi',
        24 => 'Iwamizawa',
        25 => 'Iwamizawa-shi',
        26 => 'Iwanai',
        27 => 'Kamiiso',
        28 => 'Kamikawa',
        29 => 'Kitahiroshima',
        30 => 'Kitahiroshima-shi',
        31 => 'Kitami',
        32 => 'Ktiami Shi',
        33 => 'Kushiro',
        34 => 'Kushiro Shi',
        35 => 'Makubetsu',
        36 => 'Mikasa',
        37 => 'Mikasa-shi',
        38 => 'Mombetsu',
        39 => 'Monbetsu Shi',
        40 => 'Motomachi',
        41 => 'Muroran',
        42 => 'Muroran-shi',
        43 => 'Nayoro',
        44 => 'Nayoro Shi',
        45 => 'Nemuro',
        46 => 'Nemuro-shi',
        47 => 'Niseko Town',
        48 => 'Noboribetsu',
        49 => 'Noboribetsu-shi',
        50 => 'Obihiro',
        51 => 'Obihiro Shi',
        52 => 'Otaru',
        53 => 'Otaru-shi',
        54 => 'Otofuke',
        55 => 'Rebun Gun',
        56 => 'Rishiri Gun',
        57 => 'Rishiri Town',
        58 => 'Rumoi',
        59 => 'Rumoi-shi',
        60 => 'Sapporo',
        61 => 'Sapporo-shi',
        62 => 'Shibetsu',
        63 => 'Shibetsu Shi',
        64 => 'Shimo-furano',
        65 => 'Shiraoi',
        66 => 'Shizunai-furukawachō',
        67 => 'Sunagawa',
        68 => 'Sunagawa-shi',
        69 => 'Takikawa',
        70 => 'Takikawa-shi',
        71 => 'Tomakomai',
        72 => 'Tomakomai Shi',
        73 => 'Tōbetsu',
        74 => 'Utashinai',
        75 => 'Utashinai-shi',
        76 => 'Wakkanai',
        77 => 'Wakkanai Shi',
        78 => 'Yoichi',
        79 => 'Yūbari',
        80 => 'Yūbari-shi',
      ),
    ),
    '06' => 
    array (
      'name' => 'Yamagata Prefecture',
      'cities' => 
      array (
        0 => 'Higashine',
        1 => 'Higashine Shi',
        2 => 'Kaminoyama',
        3 => 'Kaminoyama-shi',
        4 => 'Murayama',
        5 => 'Murayama Shi',
        6 => 'Nagai',
        7 => 'Nagai-shi',
        8 => 'Nanyō Shi',
        9 => 'Obanazawa',
        10 => 'Obanazawa Shi',
        11 => 'Sagae',
        12 => 'Sagae-shi',
        13 => 'Sakata',
        14 => 'Sakata Shi',
        15 => 'Shinjō',
        16 => 'Shinjō Shi',
        17 => 'Takahata',
        18 => 'Tendō',
        19 => 'Tendō Shi',
        20 => 'Tsuruoka',
        21 => 'Tsuruoka Shi',
        22 => 'Yamagata',
        23 => 'Yamagata Shi',
        24 => 'Yonezawa',
        25 => 'Yonezawa Shi',
        26 => 'Yuza',
      ),
    ),
    '02' => 
    array (
      'name' => 'Aomori Prefecture',
      'cities' => 
      array (
        0 => 'Aomori',
        1 => 'Aomori Shi',
        2 => 'Goshogawara',
        3 => 'Goshogawara Shi',
        4 => 'Hachinohe',
        5 => 'Hachinohe Shi',
        6 => 'Hirakawa',
        7 => 'Hirakawa Shi',
        8 => 'Hirosaki',
        9 => 'Hirosaki Shi',
        10 => 'Kuroishi',
        11 => 'Kuroishi Shi',
        12 => 'Misawa',
        13 => 'Misawa Shi',
        14 => 'Mutsu',
        15 => 'Mutsu-shi',
        16 => 'Namioka',
        17 => 'Shimokizukuri',
        18 => 'Towada Shi',
        19 => 'Tsugaru',
        20 => 'Tsugaru Shi',
      ),
    ),
    '07' => 
    array (
      'name' => 'Fukushima Prefecture',
      'cities' => 
      array (
        0 => 'Aizu-wakamatsu Shi',
        1 => 'Date-shi',
        2 => 'Fukushima',
        3 => 'Fukushima Shi',
        4 => 'Funehikimachi-funehiki',
        5 => 'Hobaramachi',
        6 => 'Inawashiro',
        7 => 'Ishikawa',
        8 => 'Iwaki',
        9 => 'Iwaki-shi',
        10 => 'Kitakata',
        11 => 'Kitakata-shi',
        12 => 'Kōriyama',
        13 => 'Kōriyama Shi',
        14 => 'Miharu',
        15 => 'Minami-Sōma',
        16 => 'Minamisōma Shi',
        17 => 'Motomiya',
        18 => 'Motomiya-shi',
        19 => 'Namie',
        20 => 'Nihommatsu',
        21 => 'Nihonmatsu Shi',
        22 => 'Shirakawa Shi',
        23 => 'Sukagawa',
        24 => 'Sukagawa Shi',
        25 => 'Sōma',
        26 => 'Sōma Shi',
        27 => 'Tamura',
        28 => 'Tamura-shi',
        29 => 'Yanagawamachi-saiwaichō',
      ),
    ),
    '08' => 
    array (
      'name' => 'Ibaraki Prefecture',
      'cities' => 
      array (
        0 => 'Ami',
        1 => 'Bandō',
        2 => 'Bandō-shi',
        3 => 'Chikusei',
        4 => 'Chikusei-shi',
        5 => 'Daigo',
        6 => 'Edosaki',
        7 => 'Fujishiro',
        8 => 'Funaishikawa',
        9 => 'Hitachi',
        10 => 'Hitachi-Naka',
        11 => 'Hitachi-ota',
        12 => 'Hitachi-shi',
        13 => 'Hitachinaka-shi',
        14 => 'Hitachiōmiya-shi',
        15 => 'Hitachiōta-shi',
        16 => 'Hokota-shi',
        17 => 'Inashiki',
        18 => 'Inashiki-shi',
        19 => 'Ishige',
        20 => 'Ishioka',
        21 => 'Ishioka-shi',
        22 => 'Itako',
        23 => 'Itako-shi',
        24 => 'Iwai',
        25 => 'Iwase',
        26 => 'Jōsō-shi',
        27 => 'Kamisu-shi',
        28 => 'Kasama',
        29 => 'Kasama-shi',
        30 => 'Kashima-shi',
        31 => 'Kasumigaura',
        32 => 'Kasumigaura-shi',
        33 => 'Katsuta',
        34 => 'Kitaibaraki',
        35 => 'Kitaibaraki-shi',
        36 => 'Koga',
        37 => 'Koga-shi',
        38 => 'Makabe',
        39 => 'Mito',
        40 => 'Mito-shi',
        41 => 'Mitsukaidō',
        42 => 'Moriya',
        43 => 'Moriya-shi',
        44 => 'Naka',
        45 => 'Naka-gun',
        46 => 'Namegata',
        47 => 'Namegata-shi',
        48 => 'Okunoya',
        49 => 'Omitama-shi',
        50 => 'Ryūgasaki',
        51 => 'Ryūgasaki-shi',
        52 => 'Sakai',
        53 => 'Sakuragawa',
        54 => 'Sakuragawa-shi',
        55 => 'Shimodate',
        56 => 'Shimotsuma-shi',
        57 => 'Takahagi',
        58 => 'Tomobe',
        59 => 'Toride',
        60 => 'Toride-shi',
        61 => 'Tsuchiura-shi',
        62 => 'Tsukuba',
        63 => 'Tsukuba-shi',
        64 => 'Tsukubamirai',
        65 => 'Tsukubamirai-shi',
        66 => 'Ushiku',
        67 => 'Ushiku-shi',
        68 => 'Yūki',
        69 => 'Yūki-shi',
        70 => 'Ōarai',
        71 => 'Ōmiya',
      ),
    ),
    '09' => 
    array (
      'name' => 'Tochigi Prefecture',
      'cities' => 
      array (
        0 => 'Ashikaga',
        1 => 'Fujioka',
        2 => 'Imaichi',
        3 => 'Kaminokawa',
        4 => 'Kanuma',
        5 => 'Kanuma-shi',
        6 => 'Karasuyama',
        7 => 'Kuroiso',
        8 => 'Mashiko',
        9 => 'Mibu',
        10 => 'Mooka',
        11 => 'Mooka-shi',
        12 => 'Motegi',
        13 => 'Nasukarasuyama',
        14 => 'Nasukarasuyama-shi',
        15 => 'Nasushiobara-shi',
        16 => 'Nikko-shi',
        17 => 'Nikkō',
        18 => 'Oyama',
        19 => 'Oyama-shi',
        20 => 'Sakura-shi',
        21 => 'Sano',
        22 => 'Sano-shi',
        23 => 'Shimotsuke-shi',
        24 => 'Tanuma',
        25 => 'Tochigi-shi',
        26 => 'Ujiie',
        27 => 'Utsunomiya',
        28 => 'Utsunomiya-shi',
        29 => 'Yaita',
        30 => 'Yaita-shi',
        31 => 'Ōtawara',
        32 => 'Ōtawara-shi',
      ),
    ),
    '03' => 
    array (
      'name' => 'Iwate Prefecture',
      'cities' => 
      array (
        0 => 'Hachimantai',
        1 => 'Hachimantai Shi',
        2 => 'Hanamaki',
        3 => 'Hanamaki Shi',
        4 => 'Ichinohe',
        5 => 'Ichinoseki',
        6 => 'Ichinoseki-shi',
        7 => 'Iwate-gun',
        8 => 'Kamaishi',
        9 => 'Kamaishi-shi',
        10 => 'Kitakami',
        11 => 'Kitakami-shi',
        12 => 'Kuji',
        13 => 'Kuji-shi',
        14 => 'Miyako',
        15 => 'Miyako-shi',
        16 => 'Mizusawa',
        17 => 'Morioka',
        18 => 'Morioka-shi',
        19 => 'Ninohe',
        20 => 'Ninohe Shi',
        21 => 'Rikuzentakata-shi',
        22 => 'Shizukuishi',
        23 => 'Takizawa-shi',
        24 => 'Tōno',
        25 => 'Tōno-shi',
        26 => 'Yamada',
        27 => 'Ōfunato',
        28 => 'Ōfunato-shi',
        29 => 'Ōshū',
        30 => 'Ōshū-shi',
        31 => 'Ōtsuchi',
      ),
    ),
    '04' => 
    array (
      'name' => 'Miyagi Prefecture',
      'cities' => 
      array (
        0 => 'Furukawa',
        1 => 'Higashimatshushima Shi',
        2 => 'Higashimatsushima',
        3 => 'Ishinomaki',
        4 => 'Ishinomaki Shi',
        5 => 'Iwanuma',
        6 => 'Iwanuma-shi',
        7 => 'Kakuda',
        8 => 'Kakuda Shi',
        9 => 'Kesennuma',
        10 => 'Kesennuma Shi',
        11 => 'Kogota',
        12 => 'Kurihara',
        13 => 'Kurihara Shi',
        14 => 'Marumori',
        15 => 'Matsushima',
        16 => 'Natori Shi',
        17 => 'Onagawa Chō',
        18 => 'Rifu',
        19 => 'Sendai',
        20 => 'Shiogama',
        21 => 'Shiroishi',
        22 => 'Shiroishi Shi',
        23 => 'Tagajō Shi',
        24 => 'Tome Shi',
        25 => 'Tomiya',
        26 => 'Wakuya',
        27 => 'Watari',
        28 => 'Watari-gun',
        29 => 'Yamoto',
        30 => 'Ōkawara',
        31 => 'Ōsaki',
        32 => 'Ōsaki Shi',
      ),
    ),
  ),
  'CA' => 
  array (
    'ON' => 
    array (
      'name' => 'Ontario',
      'cities' => 
      array (
        0 => 'Ajax',
        1 => 'Algoma',
        2 => 'Alliston',
        3 => 'Amherstburg',
        4 => 'Amigo Beach',
        5 => 'Ancaster',
        6 => 'Angus',
        7 => 'Arnprior',
        8 => 'Atikokan',
        9 => 'Attawapiskat',
        10 => 'Aurora',
        11 => 'Aylmer',
        12 => 'Azilda',
        13 => 'Ballantrae',
        14 => 'Bancroft',
        15 => 'Barrie',
        16 => 'Bath',
        17 => 'Belleville',
        18 => 'Bells Corners',
        19 => 'Belmont',
        20 => 'Binbrook',
        21 => 'Bluewater',
        22 => 'Bourget',
        23 => 'Bracebridge',
        24 => 'Brampton',
        25 => 'Brant',
        26 => 'Brantford',
        27 => 'Brockville',
        28 => 'Brussels',
        29 => 'Burford',
        30 => 'Burlington',
        31 => 'Cambridge',
        32 => 'Camlachie',
        33 => 'Capreol',
        34 => 'Carleton Place',
        35 => 'Casselman',
        36 => 'Chatham',
        37 => 'Chatham-Kent',
        38 => 'Clarence-Rockland',
        39 => 'Cobourg',
        40 => 'Cochrane District',
        41 => 'Collingwood',
        42 => 'Concord',
        43 => 'Constance Bay',
        44 => 'Cookstown',
        45 => 'Cornwall',
        46 => 'Corunna',
        47 => 'Deep River',
        48 => 'Delaware',
        49 => 'Deseronto',
        50 => 'Dorchester',
        51 => 'Dowling',
        52 => 'Dryden',
        53 => 'Durham',
        54 => 'Ear Falls',
        55 => 'East Gwillimbury',
        56 => 'East York',
        57 => 'Elliot Lake',
        58 => 'Elmvale',
        59 => 'Englehart',
        60 => 'Espanola',
        61 => 'Essex',
        62 => 'Etobicoke',
        63 => 'Fort Erie',
        64 => 'Fort Frances',
        65 => 'Gananoque',
        66 => 'Glencoe',
        67 => 'Goderich',
        68 => 'Golden',
        69 => 'Gravenhurst',
        70 => 'Greater Napanee',
        71 => 'Greater Sudbury',
        72 => 'Greenstone',
        73 => 'Guelph',
        74 => 'Haldimand County',
        75 => 'Haliburton Village',
        76 => 'Halton',
        77 => 'Hamilton',
        78 => 'Hanover',
        79 => 'Harriston',
        80 => 'Hawkesbury',
        81 => 'Hearst',
        82 => 'Hornepayne',
        83 => 'Huntsville',
        84 => 'Huron East',
        85 => 'Ingersoll',
        86 => 'Innisfil',
        87 => 'Iroquois Falls',
        88 => 'Jarvis',
        89 => 'Kanata',
        90 => 'Kapuskasing',
        91 => 'Kawartha Lakes',
        92 => 'Kenora',
        93 => 'Keswick',
        94 => 'Kincardine',
        95 => 'King',
        96 => 'Kingston',
        97 => 'Kirkland Lake',
        98 => 'Kitchener',
        99 => 'L&#039;Orignal',
        100 => 'Lakefield',
        101 => 'Lambton Shores',
        102 => 'Lappe',
        103 => 'Leamington',
        104 => 'Limoges',
        105 => 'Lindsay',
        106 => 'Listowel',
        107 => 'Little Current',
        108 => 'Lively',
        109 => 'London',
        110 => 'Lucan',
        111 => 'Madoc',
        112 => 'Manitoulin District',
        113 => 'Manitouwadge',
        114 => 'Marathon',
        115 => 'Markdale',
        116 => 'Markham',
        117 => 'Mattawa',
        118 => 'Meaford',
        119 => 'Metcalfe',
        120 => 'Midland',
        121 => 'Mildmay',
        122 => 'Millbrook',
        123 => 'Milton',
        124 => 'Mississauga',
        125 => 'Mississauga Beach',
        126 => 'Moose Factory',
        127 => 'Moosonee',
        128 => 'Morrisburg',
        129 => 'Mount Albert',
        130 => 'Mount Brydges',
        131 => 'Napanee',
        132 => 'Napanee Downtown',
        133 => 'Neebing',
        134 => 'Nepean',
        135 => 'New Hamburg',
        136 => 'Newmarket',
        137 => 'Niagara Falls',
        138 => 'Nipissing District',
        139 => 'Norfolk County',
        140 => 'North Bay',
        141 => 'North Perth',
        142 => 'North York',
        143 => 'Norwood',
        144 => 'Oakville',
        145 => 'Omemee',
        146 => 'Orangeville',
        147 => 'Orillia',
        148 => 'Osgoode',
        149 => 'Oshawa',
        150 => 'Ottawa',
        151 => 'Owen Sound',
        152 => 'Paisley',
        153 => 'Paris',
        154 => 'Parkhill',
        155 => 'Parry Sound',
        156 => 'Parry Sound District',
        157 => 'Peel',
        158 => 'Pembroke',
        159 => 'Perth',
        160 => 'Petawawa',
        161 => 'Peterborough',
        162 => 'Petrolia',
        163 => 'Pickering',
        164 => 'Picton',
        165 => 'Plantagenet',
        166 => 'Plattsville',
        167 => 'Port Colborne',
        168 => 'Port Hope',
        169 => 'Port Rowan',
        170 => 'Port Stanley',
        171 => 'Powassan',
        172 => 'Prescott',
        173 => 'Prince Edward',
        174 => 'Queenswood Heights',
        175 => 'Quinte West',
        176 => 'Rainy River District',
        177 => 'Rayside-Balfour',
        178 => 'Red Lake',
        179 => 'Regional Municipality of Waterloo',
        180 => 'Renfrew',
        181 => 'Richmond',
        182 => 'Richmond Hill',
        183 => 'Ridgetown',
        184 => 'Rockwood',
        185 => 'Russell',
        186 => 'Sarnia',
        187 => 'Sault Ste. Marie',
        188 => 'Scarborough',
        189 => 'Seaforth',
        190 => 'Shelburne',
        191 => 'Simcoe',
        192 => 'Sioux Lookout',
        193 => 'Skatepark',
        194 => 'Smiths Falls',
        195 => 'South Huron',
        196 => 'South River',
        197 => 'St. Catharines',
        198 => 'St. George',
        199 => 'St. Thomas',
        200 => 'Stirling',
        201 => 'Stoney Point',
        202 => 'Stratford',
        203 => 'Sudbury',
        204 => 'Tavistock',
        205 => 'Temiskaming Shores',
        206 => 'Thessalon',
        207 => 'Thorold',
        208 => 'Thunder Bay',
        209 => 'Thunder Bay District',
        210 => 'Timiskaming District',
        211 => 'Timmins',
        212 => 'Tobermory',
        213 => 'Toronto',
        214 => 'Toronto county',
        215 => 'Tottenham',
        216 => 'Tweed',
        217 => 'Uxbridge',
        218 => 'Valley East',
        219 => 'Vanier',
        220 => 'Vaughan',
        221 => 'Vineland',
        222 => 'Virgil',
        223 => 'Walpole Island',
        224 => 'Wasaga Beach',
        225 => 'Waterford',
        226 => 'Waterloo',
        227 => 'Watford',
        228 => 'Wawa',
        229 => 'Welland',
        230 => 'Wellesley',
        231 => 'Wendover',
        232 => 'West Lorne',
        233 => 'Willowdale',
        234 => 'Winchester',
        235 => 'Windsor',
        236 => 'Wingham',
        237 => 'Woodstock',
        238 => 'York',
      ),
    ),
    'MB' => 
    array (
      'name' => 'Manitoba',
      'cities' => 
      array (
        0 => 'Altona',
        1 => 'Beausejour',
        2 => 'Boissevain',
        3 => 'Brandon',
        4 => 'Carberry',
        5 => 'Carman',
        6 => 'Cross Lake 19A',
        7 => 'Dauphin',
        8 => 'De Salaberry',
        9 => 'Deloraine',
        10 => 'Flin Flon',
        11 => 'Gimli',
        12 => 'Grunthal',
        13 => 'Headingley',
        14 => 'Ile des Chênes',
        15 => 'Killarney',
        16 => 'La Broquerie',
        17 => 'Lac du Bonnet',
        18 => 'Landmark',
        19 => 'Lorette',
        20 => 'Melita',
        21 => 'Minnedosa',
        22 => 'Moose Lake',
        23 => 'Morden',
        24 => 'Morris',
        25 => 'Neepawa',
        26 => 'Niverville',
        27 => 'Portage la Prairie',
        28 => 'Rivers',
        29 => 'Roblin',
        30 => 'Selkirk',
        31 => 'Shilo',
        32 => 'Souris',
        33 => 'St. Adolphe',
        34 => 'Steinbach',
        35 => 'Stonewall',
        36 => 'Swan River',
        37 => 'The Pas',
        38 => 'Thompson',
        39 => 'Virden',
        40 => 'West St. Paul',
        41 => 'Winkler',
        42 => 'Winnipeg',
      ),
    ),
    'NB' => 
    array (
      'name' => 'New Brunswick',
      'cities' => 
      array (
        0 => 'Baie Ste. Anne',
        1 => 'Bathurst',
        2 => 'Bouctouche',
        3 => 'Campbellton',
        4 => 'Dieppe',
        5 => 'Edmundston',
        6 => 'Florenceville-Bristol',
        7 => 'Fredericton',
        8 => 'Fundy Bay',
        9 => 'Grande-Digue',
        10 => 'Greater Lakeburn',
        11 => 'Hampton',
        12 => 'Harrison Brook',
        13 => 'Keswick Ridge',
        14 => 'Lincoln',
        15 => 'Lutes Mountain',
        16 => 'McEwen',
        17 => 'Miramichi',
        18 => 'Moncton',
        19 => 'Nackawic',
        20 => 'New Maryland',
        21 => 'Noonan',
        22 => 'Oromocto',
        23 => 'Richibucto',
        24 => 'Sackville',
        25 => 'Saint Andrews',
        26 => 'Saint John',
        27 => 'Saint-Antoine',
        28 => 'Saint-Léonard',
        29 => 'Salisbury',
        30 => 'Shediac',
        31 => 'Shediac Bridge-Shediac River',
        32 => 'Shippagan',
        33 => 'Starlight Village',
        34 => 'Sussex',
        35 => 'Tracadie-Sheila',
        36 => 'Wells',
      ),
    ),
    'YT' => 
    array (
      'name' => 'Yukon',
      'cities' => 
      array (
        0 => 'Dawson City',
        1 => 'Haines Junction',
        2 => 'Watson Lake',
        3 => 'Whitehorse',
      ),
    ),
    'SK' => 
    array (
      'name' => 'Saskatchewan',
      'cities' => 
      array (
        0 => 'Assiniboia',
        1 => 'Biggar',
        2 => 'Canora',
        3 => 'Carlyle',
        4 => 'Dalmeny',
        5 => 'Esterhazy',
        6 => 'Estevan',
        7 => 'Foam Lake',
        8 => 'Gravelbourg',
        9 => 'Hudson Bay',
        10 => 'Humboldt',
        11 => 'Indian Head',
        12 => 'Kamsack',
        13 => 'Kerrobert',
        14 => 'Kindersley',
        15 => 'La Ronge',
        16 => 'Langenburg',
        17 => 'Langham',
        18 => 'Lanigan',
        19 => 'Lumsden',
        20 => 'Macklin',
        21 => 'Maple Creek',
        22 => 'Martensville',
        23 => 'Meadow Lake',
        24 => 'Melfort',
        25 => 'Melville',
        26 => 'Moose Jaw',
        27 => 'Moosomin',
        28 => 'Nipawin',
        29 => 'North Battleford',
        30 => 'Outlook',
        31 => 'Oxbow',
        32 => 'Pelican Narrows',
        33 => 'Pilot Butte',
        34 => 'Preeceville',
        35 => 'Prince Albert',
        36 => 'Regina',
        37 => 'Regina Beach',
        38 => 'Rosetown',
        39 => 'Rosthern',
        40 => 'Saskatoon',
        41 => 'Shaunavon',
        42 => 'Shellbrook',
        43 => 'Swift Current',
        44 => 'Tisdale',
        45 => 'Unity',
        46 => 'Wadena',
        47 => 'Warman',
        48 => 'Watrous',
        49 => 'Weyburn',
        50 => 'White City',
        51 => 'Wilkie',
        52 => 'Wynyard',
        53 => 'Yorkton',
      ),
    ),
    'PE' => 
    array (
      'name' => 'Prince Edward Island',
      'cities' => 
      array (
        0 => 'Alberton',
        1 => 'Belfast',
        2 => 'Charlottetown',
        3 => 'Cornwall',
        4 => 'Fallingbrook',
        5 => 'Kensington',
        6 => 'Montague',
        7 => 'Souris',
        8 => 'Summerside',
      ),
    ),
    'AB' => 
    array (
      'name' => 'Alberta',
      'cities' => 
      array (
        0 => 'Airdrie',
        1 => 'Athabasca',
        2 => 'Banff',
        3 => 'Barrhead',
        4 => 'Bassano',
        5 => 'Beaumont',
        6 => 'Beaverlodge',
        7 => 'Black Diamond',
        8 => 'Blackfalds',
        9 => 'Bon Accord',
        10 => 'Bonnyville',
        11 => 'Bow Island',
        12 => 'Brooks',
        13 => 'Calgary',
        14 => 'Calmar',
        15 => 'Camrose',
        16 => 'Canmore',
        17 => 'Cardston',
        18 => 'Carstairs',
        19 => 'Chestermere',
        20 => 'Claresholm',
        21 => 'Coaldale',
        22 => 'Coalhurst',
        23 => 'Cochrane',
        24 => 'Cold Lake',
        25 => 'Crossfield',
        26 => 'Devon',
        27 => 'Didsbury',
        28 => 'Drayton Valley',
        29 => 'Edmonton',
        30 => 'Edson',
        31 => 'Elk Point',
        32 => 'Fairview',
        33 => 'Falher',
        34 => 'Fort Macleod',
        35 => 'Fort McMurray',
        36 => 'Fort Saskatchewan',
        37 => 'Fox Creek',
        38 => 'Gibbons',
        39 => 'Grand Centre',
        40 => 'Grande Cache',
        41 => 'Grande Prairie',
        42 => 'Grimshaw',
        43 => 'Hanna',
        44 => 'Heritage Pointe',
        45 => 'High Level',
        46 => 'High Prairie',
        47 => 'High River',
        48 => 'Hinton',
        49 => 'Irricana',
        50 => 'Jasper Park Lodge',
        51 => 'Killam',
        52 => 'Lac La Biche',
        53 => 'Lacombe',
        54 => 'Lamont',
        55 => 'Larkspur',
        56 => 'Laurel',
        57 => 'Leduc',
        58 => 'Lethbridge',
        59 => 'Lloydminster',
        60 => 'Magrath',
        61 => 'Manning',
        62 => 'Mannville',
        63 => 'Maple Ridge',
        64 => 'Mayerthorpe',
        65 => 'Medicine Hat',
        66 => 'Mill Woods Town Centre',
        67 => 'Millet',
        68 => 'Morinville',
        69 => 'Nanton',
        70 => 'Okotoks',
        71 => 'Olds',
        72 => 'Peace River',
        73 => 'Penhold',
        74 => 'Picture Butte',
        75 => 'Pincher Creek',
        76 => 'Ponoka',
        77 => 'Provost',
        78 => 'Raymond',
        79 => 'Red Deer',
        80 => 'Rideau Park',
        81 => 'Rimbey',
        82 => 'Rocky Mountain House',
        83 => 'Sexsmith',
        84 => 'Sherwood Park',
        85 => 'Silver Berry',
        86 => 'Slave Lake',
        87 => 'Smoky Lake',
        88 => 'Spirit River',
        89 => 'Springbrook',
        90 => 'Spruce Grove',
        91 => 'St. Albert',
        92 => 'Stettler',
        93 => 'Stony Plain',
        94 => 'Strathmore',
        95 => 'Sundre',
        96 => 'Swan Hills',
        97 => 'Sylvan Lake',
        98 => 'Taber',
        99 => 'Tamarack',
        100 => 'Three Hills',
        101 => 'Tofield',
        102 => 'Two Hills',
        103 => 'Valleyview',
        104 => 'Vegreville',
        105 => 'Vermilion',
        106 => 'Viking',
        107 => 'Vulcan',
        108 => 'Wainwright',
        109 => 'Wembley',
        110 => 'Westlake',
        111 => 'Westlock',
        112 => 'Wetaskiwin',
        113 => 'Whitecourt',
        114 => 'Wild Rose',
      ),
    ),
    'QC' => 
    array (
      'name' => 'Quebec',
      'cities' => 
      array (
        0 => 'Abitibi-Témiscamingue',
        1 => 'Acton Vale',
        2 => 'Adstock',
        3 => 'Albanel',
        4 => 'Alma',
        5 => 'Amos',
        6 => 'Amqui',
        7 => 'Ange-Gardien',
        8 => 'Asbestos',
        9 => 'Baie-Comeau',
        10 => 'Baie-D&#039;Urfé',
        11 => 'Baie-Saint-Paul',
        12 => 'Barraute',
        13 => 'Bas-Saint-Laurent',
        14 => 'Beaconsfield',
        15 => 'Beauceville',
        16 => 'Beauharnois',
        17 => 'Beaupré',
        18 => 'Bedford',
        19 => 'Beloeil',
        20 => 'Berthierville',
        21 => 'Blainville',
        22 => 'Bois-des-Filion',
        23 => 'Boisbriand',
        24 => 'Bonaventure',
        25 => 'Boucherville',
        26 => 'Breakeyville',
        27 => 'Bromont',
        28 => 'Brossard',
        29 => 'Brownsburg-Chatham',
        30 => 'Buckingham',
        31 => 'Bécancour',
        32 => 'Cabano',
        33 => 'Cacouna',
        34 => 'Candiac',
        35 => 'Cantley',
        36 => 'Cap-Chat',
        37 => 'Cap-Santé',
        38 => 'Capitale-Nationale',
        39 => 'Carignan',
        40 => 'Carleton',
        41 => 'Carleton-sur-Mer',
        42 => 'Centre-du-Québec',
        43 => 'Chambly',
        44 => 'Chambord',
        45 => 'Chandler',
        46 => 'Chapais',
        47 => 'Charlemagne',
        48 => 'Chaudière-Appalaches',
        49 => 'Chertsey',
        50 => 'Chibougamau',
        51 => 'Chute-aux-Outardes',
        52 => 'Château-Richer',
        53 => 'Châteauguay',
        54 => 'Coaticook',
        55 => 'Contrecoeur',
        56 => 'Cookshire',
        57 => 'Cookshire-Eaton',
        58 => 'Coteau-du-Lac',
        59 => 'Cowansville',
        60 => 'Crabtree',
        61 => 'Côte-Nord',
        62 => 'Côte-Saint-Luc',
        63 => 'Danville',
        64 => 'Daveluyville',
        65 => 'Delson',
        66 => 'Deux-Montagnes',
        67 => 'Disraeli',
        68 => 'Dolbeau-Mistassini',
        69 => 'Dollard-Des Ormeaux',
        70 => 'Donnacona',
        71 => 'Dorval',
        72 => 'Drummondville',
        73 => 'Dunham',
        74 => 'East Angus',
        75 => 'East Broughton',
        76 => 'Farnham',
        77 => 'Ferme-Neuve',
        78 => 'Fermont',
        79 => 'Forestville',
        80 => 'Fort-Coulonge',
        81 => 'Fossambault-sur-le-Lac',
        82 => 'Franklin',
        83 => 'Gaspé',
        84 => 'Gaspésie-Îles-de-la-Madeleine',
        85 => 'Gatineau',
        86 => 'Godefroy',
        87 => 'Granby',
        88 => 'Hampstead',
        89 => 'Hauterive',
        90 => 'Havre-Saint-Pierre',
        91 => 'Hudson',
        92 => 'Huntingdon',
        93 => 'Hérouxville',
        94 => 'Joliette',
        95 => 'Jonquière',
        96 => 'Kingsey Falls',
        97 => 'Kirkland',
        98 => 'L&#039;Ancienne-Lorette',
        99 => 'L&#039;Ange-Gardien',
        100 => 'L&#039;Ascension-de-Notre-Seigneur',
        101 => 'L&#039;Assomption',
        102 => 'L&#039;Épiphanie',
        103 => 'L&#039;Île-Perrot',
        104 => 'La Conception',
        105 => 'La Haute-Saint-Charles',
        106 => 'La Malbaie',
        107 => 'La Minerve',
        108 => 'La Pocatière',
        109 => 'La Prairie',
        110 => 'La Sarre',
        111 => 'La Tuque',
        112 => 'Labelle',
        113 => 'Lac-Alouette',
        114 => 'Lac-Brome',
        115 => 'Lac-Connelly',
        116 => 'Lac-Lapierre',
        117 => 'Lac-Mégantic',
        118 => 'Lac-Simon',
        119 => 'Lachute',
        120 => 'Lacolle',
        121 => 'Lanoraie',
        122 => 'Laval',
        123 => 'Lavaltrie',
        124 => 'Le Bic',
        125 => 'Lebel-sur-Quévillon',
        126 => 'Leblanc',
        127 => 'Les Coteaux',
        128 => 'Les Cèdres',
        129 => 'Les Escoumins',
        130 => 'Linière',
        131 => 'Longueuil',
        132 => 'Lorraine',
        133 => 'Louiseville',
        134 => 'Luceville',
        135 => 'Lévis',
        136 => 'Macamic',
        137 => 'Magog',
        138 => 'Malartic',
        139 => 'Maliotenam',
        140 => 'Manawan',
        141 => 'Mandeville',
        142 => 'Maniwaki',
        143 => 'Maria',
        144 => 'Marieville',
        145 => 'Mascouche',
        146 => 'Maskinongé',
        147 => 'Matagami',
        148 => 'Matane',
        149 => 'Mauricie',
        150 => 'Melocheville',
        151 => 'Mercier',
        152 => 'Metabetchouan-Lac-a-la-Croix',
        153 => 'Mirabel',
        154 => 'Mistissini',
        155 => 'Mont-Joli',
        156 => 'Mont-Laurier',
        157 => 'Mont-Royal',
        158 => 'Mont-Saint-Grégoire',
        159 => 'Mont-Saint-Hilaire',
        160 => 'Mont-Tremblant',
        161 => 'Montmagny',
        162 => 'Montréal',
        163 => 'Montréal-Est',
        164 => 'Montréal-Ouest',
        165 => 'Morin-Heights',
        166 => 'Métabetchouan',
        167 => 'Napierville',
        168 => 'Neuville',
        169 => 'New Carlisle',
        170 => 'New-Richmond',
        171 => 'Nicolet',
        172 => 'Nord-du-Québec',
        173 => 'Normandin',
        174 => 'Notre-Dame-de-Grâce',
        175 => 'Notre-Dame-de-l&#039;Île-Perrot',
        176 => 'Notre-Dame-des-Prairies',
        177 => 'Notre-Dame-du-Lac',
        178 => 'Notre-Dame-du-Mont-Carmel',
        179 => 'Oka',
        180 => 'Ormstown',
        181 => 'Otterburn Park',
        182 => 'Outaouais',
        183 => 'Papineauville',
        184 => 'Parc-Boutin',
        185 => 'Piedmont',
        186 => 'Pierreville',
        187 => 'Pincourt',
        188 => 'Plessisville',
        189 => 'Pohénégamook',
        190 => 'Pointe-Calumet',
        191 => 'Pointe-Claire',
        192 => 'Pointe-du-Lac',
        193 => 'Pont Rouge',
        194 => 'Pont-Rouge',
        195 => 'Port-Cartier',
        196 => 'Portneuf',
        197 => 'Princeville',
        198 => 'Prévost',
        199 => 'Québec',
        200 => 'Rawdon',
        201 => 'Repentigny',
        202 => 'Richelieu',
        203 => 'Richmond',
        204 => 'Rigaud',
        205 => 'Rimouski',
        206 => 'Rivière-Rouge',
        207 => 'Rivière-du-Loup',
        208 => 'Roberval',
        209 => 'Rock Forest',
        210 => 'Rosemère',
        211 => 'Rougemont',
        212 => 'Rouyn-Noranda',
        213 => 'Sacré-Coeur',
        214 => 'Saguenay',
        215 => 'Saint-Adolphe-d&#039;Howard',
        216 => 'Saint-Alexandre',
        217 => 'Saint-Amable',
        218 => 'Saint-Ambroise',
        219 => 'Saint-André-Avellin',
        220 => 'Saint-Anselme',
        221 => 'Saint-Antoine-de-Tilly',
        222 => 'Saint-Augustin',
        223 => 'Saint-Augustin-de-Desmaures',
        224 => 'Saint-Barnabé-Sud',
        225 => 'Saint-Basile-le-Grand',
        226 => 'Saint-Boniface',
        227 => 'Saint-Bruno',
        228 => 'Saint-Bruno-de-Guigues',
        229 => 'Saint-Bruno-de-Montarville',
        230 => 'Saint-Canut',
        231 => 'Saint-Charles',
        232 => 'Saint-Constant',
        233 => 'Saint-Cyrille-de-Wendover',
        234 => 'Saint-Césaire',
        235 => 'Saint-Côme--Linière',
        236 => 'Saint-Damase',
        237 => 'Saint-Denis-sur-Richelieu',
        238 => 'Saint-Donat-de-Montcalm',
        239 => 'Saint-Elzéar',
        240 => 'Saint-Eustache',
        241 => 'Saint-Félicien',
        242 => 'Saint-Félix-de-Valois',
        243 => 'Saint-Gabriel',
        244 => 'Saint-Georges',
        245 => 'Saint-Germain-de-Grantham',
        246 => 'Saint-Gédéon',
        247 => 'Saint-Henri',
        248 => 'Saint-Hippolyte',
        249 => 'Saint-Honoré',
        250 => 'Saint-Hyacinthe',
        251 => 'Saint-Isidore',
        252 => 'Saint-Jacques-le-Mineur',
        253 => 'Saint-Jean-Baptiste',
        254 => 'Saint-Jean-sur-Richelieu',
        255 => 'Saint-Joseph',
        256 => 'Saint-Joseph-de-Beauce',
        257 => 'Saint-Joseph-de-Coleraine',
        258 => 'Saint-Joseph-du-Lac',
        259 => 'Saint-Jérôme',
        260 => 'Saint-Lambert-de-Lauzon',
        261 => 'Saint-Laurent',
        262 => 'Saint-Lazare',
        263 => 'Saint-Liboire',
        264 => 'Saint-Lin-Laurentides',
        265 => 'Saint-Léonard',
        266 => 'Saint-Léonard-d&#039;Aston',
        267 => 'Saint-Marc-des-Carrières',
        268 => 'Saint-Mathieu',
        269 => 'Saint-Michel',
        270 => 'Saint-Michel-des-Saints',
        271 => 'Saint-Nazaire',
        272 => 'Saint-Norbert',
        273 => 'Saint-Pacôme',
        274 => 'Saint-Pascal',
        275 => 'Saint-Philippe-de-La Prairie',
        276 => 'Saint-Pie',
        277 => 'Saint-Pierre-les-Becquets',
        278 => 'Saint-Prime',
        279 => 'Saint-Raphaël',
        280 => 'Saint-Raymond',
        281 => 'Saint-Rémi',
        282 => 'Saint-Rémi-de-Tingwick',
        283 => 'Saint-Sauveur',
        284 => 'Saint-Sauveur-des-Monts',
        285 => 'Saint-Siméon',
        286 => 'Saint-Thomas',
        287 => 'Saint-Tite',
        288 => 'Saint-Victor',
        289 => 'Saint-Zotique',
        290 => 'Saint-Édouard',
        291 => 'Saint-Éphrem-de-Beauce',
        292 => 'Sainte Catherine de la Jacques Cartier',
        293 => 'Sainte-Adèle',
        294 => 'Sainte-Agathe-des-Monts',
        295 => 'Sainte-Anne-de-Bellevue',
        296 => 'Sainte-Anne-des-Monts',
        297 => 'Sainte-Anne-des-Plaines',
        298 => 'Sainte-Béatrix',
        299 => 'Sainte-Catherine',
        300 => 'Sainte-Croix',
        301 => 'Sainte-Julie',
        302 => 'Sainte-Julienne',
        303 => 'Sainte-Madeleine',
        304 => 'Sainte-Marie',
        305 => 'Sainte-Marthe-sur-le-Lac',
        306 => 'Sainte-Martine',
        307 => 'Sainte-Sophie',
        308 => 'Sainte-Thècle',
        309 => 'Sainte-Thérèse',
        310 => 'Sainte-Élisabeth',
        311 => 'Salaberry-de-Valleyfield',
        312 => 'Salluit',
        313 => 'Senneterre',
        314 => 'Sept-Îles',
        315 => 'Shannon',
        316 => 'Shawinigan',
        317 => 'Shawville',
        318 => 'Sherbrooke',
        319 => 'Sorel-Tracy',
        320 => 'St-Jean-Port-Joli',
        321 => 'Sutton',
        322 => 'Terrasse-des-Pins',
        323 => 'Terrebonne',
        324 => 'Thetford-Mines',
        325 => 'Thurso',
        326 => 'Trois-Rivières',
        327 => 'Témiscaming',
        328 => 'Val-David',
        329 => 'Val-Morin',
        330 => 'Val-d&#039;Or',
        331 => 'Val-des-Monts',
        332 => 'Valcourt',
        333 => 'Vallée-Jonction',
        334 => 'Varennes',
        335 => 'Vaudreuil-Dorion',
        336 => 'Venise-en-Québec',
        337 => 'Verchères',
        338 => 'Victoriaville',
        339 => 'Ville-Marie',
        340 => 'Wakefield',
        341 => 'Warwick',
        342 => 'Waskaganish',
        343 => 'Waswanipi',
        344 => 'Waterloo',
        345 => 'Weedon Centre',
        346 => 'Westmount',
        347 => 'Weymontachie',
        348 => 'Windsor',
        349 => 'Yamachiche',
        350 => 'le Plateau',
      ),
    ),
    'NS' => 
    array (
      'name' => 'Nova Scotia',
      'cities' => 
      array (
        0 => 'Amherst',
        1 => 'Annapolis County',
        2 => 'Antigonish',
        3 => 'Berwick',
        4 => 'Bridgewater',
        5 => 'Cape Breton County',
        6 => 'Chester',
        7 => 'Colchester',
        8 => 'Cole Harbour',
        9 => 'Cow Bay',
        10 => 'Dartmouth',
        11 => 'Digby',
        12 => 'Digby County',
        13 => 'English Corner',
        14 => 'Eskasoni 3',
        15 => 'Fall River',
        16 => 'Glace Bay',
        17 => 'Greenwood',
        18 => 'Halifax',
        19 => 'Hantsport',
        20 => 'Hayes Subdivision',
        21 => 'Kentville',
        22 => 'Lake Echo',
        23 => 'Lantz',
        24 => 'Lower Sackville',
        25 => 'Lunenburg',
        26 => 'Middleton',
        27 => 'New Glasgow',
        28 => 'Oxford',
        29 => 'Parrsboro',
        30 => 'Pictou',
        31 => 'Pictou County',
        32 => 'Port Hawkesbury',
        33 => 'Port Williams',
        34 => 'Princeville',
        35 => 'Shelburne',
        36 => 'Springhill',
        37 => 'Sydney',
        38 => 'Sydney Mines',
        39 => 'Truro',
        40 => 'Windsor',
        41 => 'Wolfville',
        42 => 'Yarmouth',
      ),
    ),
    'BC' => 
    array (
      'name' => 'British Columbia',
      'cities' => 
      array (
        0 => 'Abbotsford',
        1 => 'Agassiz',
        2 => 'Aldergrove',
        3 => 'Aldergrove East',
        4 => 'Anmore',
        5 => 'Arbutus Ridge',
        6 => 'Armstrong',
        7 => 'Ashcroft',
        8 => 'Barrière',
        9 => 'Bowen Island',
        10 => 'Burnaby',
        11 => 'Burns Lake',
        12 => 'Cache Creek',
        13 => 'Campbell River',
        14 => 'Castlegar',
        15 => 'Cedar',
        16 => 'Central Coast Regional District',
        17 => 'Chase',
        18 => 'Chemainus',
        19 => 'Chetwynd',
        20 => 'Chilliwack',
        21 => 'Colwood',
        22 => 'Coombs',
        23 => 'Coquitlam',
        24 => 'Courtenay',
        25 => 'Cowichan Bay',
        26 => 'Cranbrook',
        27 => 'Creston',
        28 => 'Cumberland',
        29 => 'Dawson Creek',
        30 => 'Delta',
        31 => 'Denman Island',
        32 => 'Denman Island Trust Area',
        33 => 'Duck Lake',
        34 => 'Duncan',
        35 => 'East Wellington',
        36 => 'Elkford',
        37 => 'Ellison',
        38 => 'Enderby',
        39 => 'Fairwinds',
        40 => 'Fernie',
        41 => 'Fort Nelson',
        42 => 'Fort St. John',
        43 => 'Fraser Valley Regional District',
        44 => 'French Creek',
        45 => 'Fruitvale',
        46 => 'Gibsons',
        47 => 'Golden',
        48 => 'Grand Forks',
        49 => 'Hanceville',
        50 => 'Hope',
        51 => 'Hornby Island',
        52 => 'Houston',
        53 => 'Invermere',
        54 => 'Kamloops',
        55 => 'Kelowna',
        56 => 'Kimberley',
        57 => 'Kitimat',
        58 => 'Ladner',
        59 => 'Ladysmith',
        60 => 'Lake Cowichan',
        61 => 'Langford',
        62 => 'Langley',
        63 => 'Lillooet',
        64 => 'Lions Bay',
        65 => 'Logan Lake',
        66 => 'Lumby',
        67 => 'Mackenzie',
        68 => 'Maple Ridge',
        69 => 'Merritt',
        70 => 'Metchosin',
        71 => 'Metro Vancouver Regional District',
        72 => 'Mission',
        73 => 'Nakusp',
        74 => 'Nanaimo',
        75 => 'Nelson',
        76 => 'New Westminster',
        77 => 'North Cowichan',
        78 => 'North Oyster/Yellow Point',
        79 => 'North Saanich',
        80 => 'North Vancouver',
        81 => 'Oak Bay',
        82 => 'Okanagan',
        83 => 'Okanagan Falls',
        84 => 'Oliver',
        85 => 'Osoyoos',
        86 => 'Parksville',
        87 => 'Peace River Regional District',
        88 => 'Peachland',
        89 => 'Pemberton',
        90 => 'Penticton',
        91 => 'Pitt Meadows',
        92 => 'Port Alberni',
        93 => 'Port Coquitlam',
        94 => 'Port McNeill',
        95 => 'Port Moody',
        96 => 'Powell River',
        97 => 'Prince George',
        98 => 'Prince Rupert',
        99 => 'Princeton',
        100 => 'Puntledge',
        101 => 'Quesnel',
        102 => 'Regional District of Alberni-Clayoquot',
        103 => 'Regional District of Central Okanagan',
        104 => 'Revelstoke',
        105 => 'Richmond',
        106 => 'Rossland',
        107 => 'Royston',
        108 => 'Salmo',
        109 => 'Salmon Arm',
        110 => 'Salt Spring Island',
        111 => 'Saltair',
        112 => 'Sechelt',
        113 => 'Sicamous',
        114 => 'Six Mile',
        115 => 'Smithers',
        116 => 'Sooke',
        117 => 'South Pender Harbour',
        118 => 'Sparwood',
        119 => 'Summerland',
        120 => 'Surrey',
        121 => 'Terrace',
        122 => 'Tofino',
        123 => 'Trail',
        124 => 'Tsawwassen',
        125 => 'Tumbler Ridge',
        126 => 'Ucluelet',
        127 => 'Vancouver',
        128 => 'Vanderhoof',
        129 => 'Vernon',
        130 => 'Victoria',
        131 => 'Walnut Grove',
        132 => 'Welcome Beach',
        133 => 'West End',
        134 => 'West Kelowna',
        135 => 'West Vancouver',
        136 => 'Whistler',
        137 => 'White Rock',
        138 => 'Williams Lake',
      ),
    ),
    'NU' => 
    array (
      'name' => 'Nunavut',
      'cities' => 
      array (
        0 => 'Clyde River',
        1 => 'Gjoa Haven',
        2 => 'Iqaluit',
        3 => 'Kugluktuk',
        4 => 'Pangnirtung',
        5 => 'Rankin Inlet',
      ),
    ),
    'NL' => 
    array (
      'name' => 'Newfoundland and Labrador',
      'cities' => 
      array (
        0 => 'Bay Roberts',
        1 => 'Bay St. George South',
        2 => 'Bonavista',
        3 => 'Botwood',
        4 => 'Burgeo',
        5 => 'Carbonear',
        6 => 'Catalina',
        7 => 'Channel-Port aux Basques',
        8 => 'Clarenville-Shoal Harbour',
        9 => 'Conception Bay South',
        10 => 'Corner Brook',
        11 => 'Deer Lake',
        12 => 'Fogo Island',
        13 => 'Gambo',
        14 => 'Goulds',
        15 => 'Grand Bank',
        16 => 'Grand Falls-Windsor',
        17 => 'Happy Valley-Goose Bay',
        18 => 'Harbour Breton',
        19 => 'Labrador City',
        20 => 'Lewisporte',
        21 => 'Marystown',
        22 => 'Mount Pearl',
        23 => 'Pasadena',
        24 => 'Springdale',
        25 => 'St. Anthony',
        26 => 'St. John&#039;s',
        27 => 'Stephenville',
        28 => 'Stephenville Crossing',
        29 => 'Torbay',
        30 => 'Upper Island Cove',
        31 => 'Wabana',
      ),
    ),
    'NT' => 
    array (
      'name' => 'Northwest Territories',
      'cities' => 
      array (
        0 => 'Behchokǫ̀',
        1 => 'Fort McPherson',
        2 => 'Fort Smith',
        3 => 'Hay River',
        4 => 'Inuvik',
        5 => 'Norman Wells',
        6 => 'Yellowknife',
      ),
    ),
  ),
  'SD' => 
  array (
    'NW' => 
    array (
      'name' => 'White Nile',
      'cities' => 
      array (
        0 => 'Ad Douiem',
        1 => 'Al Kawa',
        2 => 'Al Qiţena',
        3 => 'Kosti',
        4 => 'Marabba',
        5 => 'Rabak',
        6 => 'Tandaltī',
        7 => 'Um Jar Al Gharbiyya',
        8 => 'Wad az Zāki',
      ),
    ),
    'RS' => 
    array (
      'name' => 'Red Sea',
      'cities' => 
      array (
        0 => 'Gebeit',
        1 => 'Port Sudan',
        2 => 'Sawākin',
        3 => 'Tokār',
      ),
    ),
    'KH' => 
    array (
      'name' => 'Khartoum',
      'cities' => 
      array (
        0 => 'Khartoum',
        1 => 'Omdurman',
      ),
    ),
    'SI' => 
    array (
      'name' => 'Sennar',
      'cities' => 
      array (
        0 => 'Ad Dindar',
        1 => 'As Sūkī',
        2 => 'Jalqani',
        3 => 'Kināna',
        4 => 'Maiurno',
        5 => 'Singa',
        6 => 'Sinnar',
      ),
    ),
    'KS' => 
    array (
      'name' => 'South Kordofan',
      'cities' => 
      array (
        0 => 'Abu Jibeha',
        1 => 'Al Fūlah',
        2 => 'Dilling',
        3 => 'Kadugli',
        4 => 'Talodi',
      ),
    ),
    'KA' => 
    array (
      'name' => 'Kassala',
      'cities' => 
      array (
        0 => 'Aroma',
        1 => 'Kassala',
        2 => 'Wagar',
      ),
    ),
    'GZ' => 
    array (
      'name' => 'Al Jazirah',
      'cities' => 
      array (
        0 => 'Al Hasaheisa',
        1 => 'Al Hilāliyya',
        2 => 'Al Kiremit al &#039;Arakiyyīn',
        3 => 'Al Manāqil',
        4 => 'Al Masallamiyya',
        5 => 'Wad Medani',
        6 => 'Wad Rāwah',
      ),
    ),
    'GD' => 
    array (
      'name' => 'Al Qadarif',
      'cities' => 
      array (
        0 => 'Al Qadarif',
        1 => 'Al Ḩawātah',
        2 => 'Doka',
      ),
    ),
    'NB' => 
    array (
      'name' => 'Blue Nile',
      'cities' => 
      array (
        0 => 'Ad-Damazin',
        1 => 'Ar Ruseris',
        2 => 'Kurmuk',
      ),
    ),
    'DW' => 
    array (
      'name' => 'West Darfur',
      'cities' => 
      array (
        0 => 'Geneina',
      ),
    ),
    'GK' => 
    array (
      'name' => 'West Kordofan',
      'cities' => 
      array (
        0 => 'Abū Zabad',
        1 => 'Al Lagowa',
        2 => 'Al Mijlad',
        3 => 'An Nuhūd',
      ),
    ),
    'DN' => 
    array (
      'name' => 'North Darfur',
      'cities' => 
      array (
        0 => 'El Fasher',
        1 => 'Kutum',
        2 => 'Umm Kaddadah',
      ),
    ),
    'NR' => 
    array (
      'name' => 'River Nile',
      'cities' => 
      array (
        0 => 'Atbara',
        1 => 'Berber',
        2 => 'Ed Damer',
        3 => 'El Bauga',
        4 => 'El Matama',
        5 => 'Shendi',
      ),
    ),
    'DE' => 
    array (
      'name' => 'East Darfur',
      'cities' => 
      array (
        0 => 'El Daein',
      ),
    ),
    'KN' => 
    array (
      'name' => 'North Kordofan',
      'cities' => 
      array (
        0 => 'Ar Rahad',
        1 => 'Bārah',
        2 => 'El Obeid',
        3 => 'Umm Ruwaba',
      ),
    ),
    'DS' => 
    array (
      'name' => 'South Darfur',
      'cities' => 
      array (
        0 => 'Gereida',
        1 => 'Nyala',
      ),
    ),
    'NO' => 
    array (
      'name' => 'Northern',
      'cities' => 
      array (
        0 => 'Ad Dabbah',
        1 => 'Argo',
        2 => 'Dongola',
        3 => 'Karmah an Nuzul',
        4 => 'Kuraymah',
        5 => 'Merowe',
      ),
    ),
    'DC' => 
    array (
      'name' => 'Central Darfur',
      'cities' => 
      array (
        0 => 'Zalingei',
      ),
    ),
  ),
  'GE' => 
  array (
    'TB' => 
    array (
      'name' => 'Tbilisi',
      'cities' => 
      array (
        0 => 'Tbilisi',
      ),
    ),
    'AJ' => 
    array (
      'name' => 'Adjara',
      'cities' => 
      array (
        0 => 'Akhaldaba',
        1 => 'Batumi',
        2 => 'Chakvi',
        3 => 'Dioknisi',
        4 => 'Khelvachauri',
        5 => 'Khulo',
        6 => 'Kobuleti',
        7 => 'Makhinjauri',
        8 => 'Ochkhamuri',
        9 => 'Shuakhevi',
        10 => 'Tsikhisdziri',
      ),
    ),
    'AB' => 
    array (
      'name' => 'Autonomous Republic of Abkhazia',
      'cities' => 
      array (
        0 => 'Bich&#039;vinta',
        1 => 'Dranda',
        2 => 'Gagra',
        3 => 'Gali',
        4 => 'Gantiadi',
        5 => 'Gudauta',
        6 => 'Kelasuri',
        7 => 'Och&#039;amch&#039;ire',
        8 => 'P&#039;rimorsk&#039;oe',
        9 => 'Sokhumi',
        10 => 'Stantsiya Novyy Afon',
        11 => 'Tqvarch&#039;eli',
      ),
    ),
    'MM' => 
    array (
      'name' => 'Mtskheta-Mtianeti',
      'cities' => 
      array (
        0 => 'Akhalgori',
        1 => 'Dzegvi',
        2 => 'Gudauri',
        3 => 'Java',
        4 => 'Mtskheta',
        5 => 'P&#039;asanauri',
        6 => 'Step&#039;antsminda',
        7 => 'Zhinvali',
      ),
    ),
    'SK' => 
    array (
      'name' => 'Shida Kartli',
      'cities' => 
      array (
        0 => 'Agara',
        1 => 'Gori',
        2 => 'Goris Munitsip&#039;alit&#039;et&#039;i',
        3 => 'Kaspi',
        4 => 'Khashuri',
        5 => 'Surami',
        6 => 'Ts&#039;khinvali',
      ),
    ),
    'KK' => 
    array (
      'name' => 'Kvemo Kartli',
      'cities' => 
      array (
        0 => 'Bolnisi',
        1 => 'Bolnisis Munitsip&#039;alit&#039;et&#039;i',
        2 => 'Didi Lilo',
        3 => 'Dmanisis Munitsip&#039;alit&#039;et&#039;i',
        4 => 'Gardabani',
        5 => 'Gardabnis Munitsip&#039;alit&#039;et&#039;i',
        6 => 'Manglisi',
        7 => 'Marneuli',
        8 => 'Marneulis Munitsip&#039;alit&#039;et&#039;i',
        9 => 'Naghvarevi',
        10 => 'Rust&#039;avi',
        11 => 'Tetrits&#039;q&#039;alos Munitsip&#039;alit&#039;et&#039;i',
        12 => 'Tsalka',
        13 => 'Ts&#039;alk&#039;is Munitsip&#039;alit&#039;et&#039;i',
        14 => 'T&#039;et&#039;ri Tsqaro',
      ),
    ),
    'IM' => 
    array (
      'name' => 'Imereti',
      'cities' => 
      array (
        0 => 'Baghdatis Munitsip&#039;alit&#039;et&#039;i',
        1 => 'Chiat&#039;ura',
        2 => 'Kharagauli',
        3 => 'Khoni',
        4 => 'Kutaisi',
        5 => 'K&#039;alak&#039;i Chiat&#039;ura',
        6 => 'K&#039;ulashi',
        7 => 'Sach&#039;khere',
        8 => 'Samtredia',
        9 => 'Shorapani',
        10 => 'Tqibuli',
        11 => 'Tsqaltubo',
        12 => 'Vani',
        13 => 'Zestap&#039;oni',
      ),
    ),
    'SJ' => 
    array (
      'name' => 'Samtskhe-Javakheti',
      'cities' => 
      array (
        0 => 'Adigeni',
        1 => 'Adigeni Municipality',
        2 => 'Akhaldaba',
        3 => 'Akhalk&#039;alak&#039;i',
        4 => 'Akhaltsikhe',
        5 => 'Akhaltsikhis Munitsip&#039;alit&#039;et&#039;i',
        6 => 'Aspindza',
        7 => 'Asp&#039;indzis Munitsip&#039;alit&#039;et&#039;i',
        8 => 'Bakuriani',
        9 => 'Borjomi',
        10 => 'Ninotsminda',
        11 => 'Tsaghveri',
        12 => 'Vale',
      ),
    ),
    'GU' => 
    array (
      'name' => 'Guria',
      'cities' => 
      array (
        0 => 'Lanchkhuti',
        1 => 'Naruja',
        2 => 'Ozurgeti',
        3 => 'Urek&#039;i',
      ),
    ),
    'SZ' => 
    array (
      'name' => 'Samegrelo-Zemo Svaneti',
      'cities' => 
      array (
        0 => 'Abasha',
        1 => 'Jvari',
        2 => 'Khobi',
        3 => 'Kveda Chkhorots&#039;q&#039;u',
        4 => 'Mart&#039;vili',
        5 => 'Mest&#039;ia',
        6 => 'Mest&#039;iis Munitsip&#039;alit&#039;et&#039;i',
        7 => 'Orsant&#039;ia',
        8 => 'P&#039;ot&#039;i',
        9 => 'Senak&#039;i',
        10 => 'Tsalenjikha',
        11 => 'Zugdidi',
      ),
    ),
    'RL' => 
    array (
      'name' => 'Racha-Lechkhumi and Kvemo Svaneti',
      'cities' => 
      array (
        0 => 'Ambrolauri',
        1 => 'Ambrolauris Munitsip&#039;alit&#039;et&#039;i',
        2 => 'Lent&#039;ekhi',
        3 => 'Oni',
      ),
    ),
    'KA' => 
    array (
      'name' => 'Kakheti',
      'cities' => 
      array (
        0 => 'Akhmet&#039;a',
        1 => 'Akhmet&#039;is Munitsip&#039;alit&#039;et&#039;i',
        2 => 'Gurjaani',
        3 => 'Lagodekhi',
        4 => 'Qvareli',
        5 => 'Sagarejo',
        6 => 'Sighnaghi',
        7 => 'Sighnaghis Munitsip&#039;alit&#039;et&#039;i',
        8 => 'Telavi',
        9 => 'Tsinandali',
        10 => 'Tsnori',
      ),
    ),
  ),
  'SL' => 
  array (
    'N' => 
    array (
      'name' => 'Northern Province',
      'cities' => 
      array (
        0 => 'Alikalia',
        1 => 'Bindi',
        2 => 'Binkolo',
        3 => 'Bombali District',
        4 => 'Bumbuna',
        5 => 'Gberia Fotombu',
        6 => 'Kabala',
        7 => 'Kamakwie',
        8 => 'Kambia',
        9 => 'Kassiri',
        10 => 'Koinadugu District',
        11 => 'Konakridee',
        12 => 'Kukuna',
        13 => 'Loma',
        14 => 'Lunsar',
        15 => 'Magburaka',
        16 => 'Makali',
        17 => 'Makeni',
        18 => 'Mambolo',
        19 => 'Mange',
        20 => 'Masaka',
        21 => 'Masingbi',
        22 => 'Masoyila',
        23 => 'Pepel',
        24 => 'Rokupr',
        25 => 'Sawkta',
        26 => 'Seidu',
        27 => 'Tintafor',
        28 => 'Tonkolili District',
        29 => 'Yonibana',
      ),
    ),
    'S' => 
    array (
      'name' => 'Southern Province',
      'cities' => 
      array (
        0 => 'Baiima',
        1 => 'Baoma',
        2 => 'Bo',
        3 => 'Bo District',
        4 => 'Bomi',
        5 => 'Bonthe',
        6 => 'Bonthe District',
        7 => 'Bumpe',
        8 => 'Foindu',
        9 => 'Gandorhun',
        10 => 'Gbewebu',
        11 => 'Koribundu',
        12 => 'Largo',
        13 => 'Mamboma',
        14 => 'Mogbwemo',
        15 => 'Moyamba',
        16 => 'Moyamba District',
        17 => 'Palima',
        18 => 'Potoru',
        19 => 'Pujehun',
        20 => 'Pujehun District',
        21 => 'Rotifunk',
        22 => 'Serabu',
        23 => 'Sumbuya',
        24 => 'Tongole',
        25 => 'Zimmi',
      ),
    ),
    'W' => 
    array (
      'name' => 'Western Area',
      'cities' => 
      array (
        0 => 'Freetown',
        1 => 'Hastings',
        2 => 'Kent',
        3 => 'Waterloo',
      ),
    ),
    'E' => 
    array (
      'name' => 'Eastern Province',
      'cities' => 
      array (
        0 => 'Barma',
        1 => 'Blama',
        2 => 'Boajibu',
        3 => 'Buedu',
        4 => 'Bunumbu',
        5 => 'Daru',
        6 => 'Giehun',
        7 => 'Gorahun',
        8 => 'Hangha',
        9 => 'Jojoima',
        10 => 'Kailahun',
        11 => 'Kailahun District',
        12 => 'Kayima',
        13 => 'Kenema',
        14 => 'Kenema District',
        15 => 'Koidu',
        16 => 'Kono District',
        17 => 'Koyima',
        18 => 'Manowa',
        19 => 'Mobai',
        20 => 'Motema',
        21 => 'Panguma',
        22 => 'Pendembu',
        23 => 'Segbwema',
        24 => 'Simbakoro',
        25 => 'Tefeya',
        26 => 'Tombodu',
        27 => 'Tombu',
        28 => 'Wima',
        29 => 'Yengema',
      ),
    ),
  ),
  'SO' => 
  array (
    'HI' => 
    array (
      'name' => 'Hiran',
      'cities' => 
      array (
        0 => 'Beledweyne',
        1 => 'Buulobarde',
        2 => 'Jalalaqsi',
      ),
    ),
    'MU' => 
    array (
      'name' => 'Mudug',
      'cities' => 
      array (
        0 => 'Gaalkacyo',
        1 => 'Hobyo',
        2 => 'Xarardheere',
      ),
    ),
    'BK' => 
    array (
      'name' => 'Bakool',
      'cities' => 
      array (
        0 => 'Tayeeglow',
        1 => 'Waajid',
        2 => 'Xuddur',
        3 => 'Yeed',
      ),
    ),
    'GA' => 
    array (
      'name' => 'Galguduud',
      'cities' => 
      array (
        0 => 'Ceelbuur',
        1 => 'Ceeldheer',
        2 => 'Dhuusamarreeb',
      ),
    ),
    'SA' => 
    array (
      'name' => 'Sanaag Region',
      'cities' => 
      array (
        0 => 'Ceerigaabo',
        1 => 'Las Khorey',
      ),
    ),
    'NU' => 
    array (
      'name' => 'Nugal',
      'cities' => 
      array (
        0 => 'Eyl',
        1 => 'Garoowe',
      ),
    ),
    'SH' => 
    array (
      'name' => 'Lower Shebelle',
      'cities' => 
      array (
        0 => 'Afgooye',
        1 => 'Marka',
        2 => 'Qoryooley',
        3 => 'Wanlaweyn',
      ),
    ),
    'JD' => 
    array (
      'name' => 'Middle Juba',
      'cities' => 
      array (
        0 => 'Dujuuma',
        1 => 'Jilib',
        2 => 'Saacow',
      ),
    ),
    'SD' => 
    array (
      'name' => 'Middle Shebelle',
      'cities' => 
      array (
        0 => 'Cadale',
        1 => 'Jawhar',
        2 => 'Mahaddayweyne',
      ),
    ),
    'JH' => 
    array (
      'name' => 'Lower Juba',
      'cities' => 
      array (
        0 => 'Buur Gaabo',
        1 => 'Jamaame',
        2 => 'Kismayo',
      ),
    ),
    'BY' => 
    array (
      'name' => 'Bay',
      'cities' => 
      array (
        0 => 'Baidoa',
        1 => 'Buurhakaba',
      ),
    ),
    'BN' => 
    array (
      'name' => 'Banaadir',
      'cities' => 
      array (
        0 => 'Mogadishu',
      ),
    ),
    'GE' => 
    array (
      'name' => 'Gedo',
      'cities' => 
      array (
        0 => 'Baardheere',
        1 => 'Garbahaarrey',
        2 => 'Luuq',
      ),
    ),
    'TO' => 
    array (
      'name' => 'Togdheer Region',
      'cities' => 
      array (
        0 => 'Burao',
        1 => 'Ceek',
        2 => 'Oodweyne',
      ),
    ),
    'BR' => 
    array (
      'name' => 'Bari',
      'cities' => 
      array (
        0 => 'Bandarbeyla',
        1 => 'Bargaal',
        2 => 'Bereeda',
        3 => 'Bosaso',
        4 => 'Caluula',
        5 => 'Iskushuban',
        6 => 'Qandala',
      ),
    ),
  ),
  'ZA' => 
  array (
    'NC' => 
    array (
      'name' => 'Northern Cape',
      'cities' => 
      array (
        0 => 'Barkly West',
        1 => 'Brandvlei',
        2 => 'Calvinia',
        3 => 'Carnarvon',
        4 => 'Colesberg',
        5 => 'Daniëlskuil',
        6 => 'De Aar',
        7 => 'Frances Baard District Municipality',
        8 => 'Fraserburg',
        9 => 'John Taolo Gaetsewe District Municipality',
        10 => 'Kathu',
        11 => 'Kenhardt',
        12 => 'Kimberley',
        13 => 'Kuruman',
        14 => 'Namakwa District Municipality',
        15 => 'Noupoort',
        16 => 'Orania',
        17 => 'Pampierstad',
        18 => 'Pixley ka Seme District Municipality',
        19 => 'Pofadder',
        20 => 'Postmasburg',
        21 => 'Prieska',
        22 => 'Ritchie',
        23 => 'Siyanda District Municipality',
        24 => 'Springbok',
        25 => 'Upington',
        26 => 'Van Wyksvlei',
        27 => 'Warrenton',
      ),
    ),
    'FS' => 
    array (
      'name' => 'Free State',
      'cities' => 
      array (
        0 => 'Allanridge',
        1 => 'Bethlehem',
        2 => 'Bloemfontein',
        3 => 'Bothaville',
        4 => 'Botshabelo',
        5 => 'Brandfort',
        6 => 'Clocolan',
        7 => 'Deneysville',
        8 => 'Fezile Dabi District Municipality',
        9 => 'Frankfort',
        10 => 'Harrismith',
        11 => 'Heilbron',
        12 => 'Hennenman',
        13 => 'Hoopstad',
        14 => 'Koppies',
        15 => 'Kroonstad',
        16 => 'Kutloanong',
        17 => 'Ladybrand',
        18 => 'Lejweleputswa District Municipality',
        19 => 'Lindley',
        20 => 'Mangaung Metropolitan Municipality',
        21 => 'Marquard',
        22 => 'Parys',
        23 => 'Phuthaditjhaba',
        24 => 'Reitz',
        25 => 'Sasolburg',
        26 => 'Senekal',
        27 => 'Thaba Nchu',
        28 => 'Thabo Mofutsanyana District Municipality',
        29 => 'Theunissen',
        30 => 'Ventersburg',
        31 => 'Viljoenskroon',
        32 => 'Villiers',
        33 => 'Virginia',
        34 => 'Vrede',
        35 => 'Vredefort',
        36 => 'Welkom',
        37 => 'Wesselsbron',
        38 => 'Winburg',
        39 => 'Xhariep District Municipality',
        40 => 'Zastron',
      ),
    ),
    'LP' => 
    array (
      'name' => 'Limpopo',
      'cities' => 
      array (
        0 => 'Bochum',
        1 => 'Capricorn District Municipality',
        2 => 'Duiwelskloof',
        3 => 'Ga-Kgapane',
        4 => 'Giyani',
        5 => 'Lebowakgomo',
        6 => 'Louis Trichardt',
        7 => 'Mankoeng',
        8 => 'Modimolle',
        9 => 'Mokopane',
        10 => 'Mopani District Municipality',
        11 => 'Musina',
        12 => 'Nkowakowa',
        13 => 'Phalaborwa',
        14 => 'Polokwane',
        15 => 'Sekhukhune District Municipality',
        16 => 'Thabazimbi',
        17 => 'Thohoyandou',
        18 => 'Thulamahashi',
        19 => 'Tzaneen',
        20 => 'Vhembe District Municipality',
        21 => 'Warmbaths',
        22 => 'Waterberg District Municipality',
      ),
    ),
    'NW' => 
    array (
      'name' => 'North West',
      'cities' => 
      array (
        0 => 'Bloemhof',
        1 => 'Bojanala Platinum District Municipality',
        2 => 'Brits',
        3 => 'Christiana',
        4 => 'Dr Kenneth Kaunda District Municipality',
        5 => 'Dr Ruth Segomotsi Mompati District Municipality',
        6 => 'Fochville',
        7 => 'Ga-Rankuwa',
        8 => 'Jan Kempdorp',
        9 => 'Klerksdorp',
        10 => 'Koster',
        11 => 'Lichtenburg',
        12 => 'Mahikeng',
        13 => 'Maile',
        14 => 'Mmabatho',
        15 => 'Ngaka Modiri Molema District Municipality',
        16 => 'Orkney',
        17 => 'Potchefstroom',
        18 => 'Rustenburg',
        19 => 'Schweizer-Reneke',
        20 => 'Stilfontein',
        21 => 'Vryburg',
        22 => 'Wolmaransstad',
        23 => 'Zeerust',
      ),
    ),
    'KZN' => 
    array (
      'name' => 'KwaZulu-Natal',
      'cities' => 
      array (
        0 => 'Amajuba District Municipality',
        1 => 'Ballito',
        2 => 'Berea',
        3 => 'Dundee',
        4 => 'Durban',
        5 => 'Ekuvukeni',
        6 => 'Empangeni',
        7 => 'Eshowe',
        8 => 'Glencoe',
        9 => 'Greytown',
        10 => 'Hluhluwe',
        11 => 'Howick',
        12 => 'Kokstad',
        13 => 'KwaDukuza',
        14 => 'Margate',
        15 => 'Mondlo',
        16 => 'Mooirivier',
        17 => 'Mpophomeni',
        18 => 'Mpumalanga',
        19 => 'Mtubatuba',
        20 => 'Ndwedwe',
        21 => 'Newcastle',
        22 => 'Pietermaritzburg',
        23 => 'Port Shepstone',
        24 => 'Richards Bay',
        25 => 'Richmond',
        26 => 'Scottburgh',
        27 => 'Sisonke District Municipality',
        28 => 'Sundumbili',
        29 => 'Ugu District Municipality',
        30 => 'Ulundi',
        31 => 'Utrecht',
        32 => 'Vryheid',
        33 => 'Zululand District Municipality',
        34 => 'eMkhomazi',
        35 => 'eSikhaleni',
        36 => 'eThekwini Metropolitan Municipality',
        37 => 'iLembe District Municipality',
        38 => 'uMgungundlovu District Municipality',
        39 => 'uMkhanyakude District Municipality',
        40 => 'uMzinyathi District Municipality',
        41 => 'uThukela District Municipality',
        42 => 'uThungulu District Municipality',
      ),
    ),
    'GP' => 
    array (
      'name' => 'Gauteng',
      'cities' => 
      array (
        0 => 'Alberton',
        1 => 'Benoni',
        2 => 'Boksburg',
        3 => 'Brakpan',
        4 => 'Bronkhorstspruit',
        5 => 'Carletonville',
        6 => 'Centurion',
        7 => 'City of Johannesburg Metropolitan Municipality',
        8 => 'City of Tshwane Metropolitan Municipality',
        9 => 'Cullinan',
        10 => 'Diepsloot',
        11 => 'Eastleigh',
        12 => 'Eden Glen',
        13 => 'Eden Glen Ext 60',
        14 => 'Edenvale',
        15 => 'Ekangala',
        16 => 'Ekurhuleni Metropolitan Municipality',
        17 => 'Heidelberg',
        18 => 'Johannesburg',
        19 => 'Krugersdorp',
        20 => 'Mabopane',
        21 => 'Midrand',
        22 => 'Midstream',
        23 => 'Modderfontein',
        24 => 'Muldersdriseloop',
        25 => 'Nigel',
        26 => 'Orange Farm',
        27 => 'Pretoria',
        28 => 'Randburg',
        29 => 'Randfontein',
        30 => 'Roodepoort',
        31 => 'Sedibeng District Municipality',
        32 => 'Soweto',
        33 => 'Springs',
        34 => 'Tembisa',
        35 => 'Vanderbijlpark',
        36 => 'Vereeniging',
        37 => 'West Rand District Municipality',
        38 => 'Westonaria',
      ),
    ),
    'MP' => 
    array (
      'name' => 'Mpumalanga',
      'cities' => 
      array (
        0 => 'Balfour',
        1 => 'Barberton',
        2 => 'Belfast',
        3 => 'Bethal',
        4 => 'Breyten',
        5 => 'Carolina',
        6 => 'Delmas',
        7 => 'Driefontein',
        8 => 'Ehlanzeni District',
        9 => 'Ermelo',
        10 => 'Gert Sibande District Municipality',
        11 => 'Hendrina',
        12 => 'Komatipoort',
        13 => 'Kriel',
        14 => 'Lydenburg',
        15 => 'Middelburg',
        16 => 'Nelspruit',
        17 => 'Nkangala District Municipality',
        18 => 'Piet Retief',
        19 => 'Secunda',
        20 => 'Siyabuswa',
        21 => 'Standerton',
        22 => 'Volksrust',
        23 => 'White River',
        24 => 'Witbank',
        25 => 'eMbalenhle',
      ),
    ),
    'EC' => 
    array (
      'name' => 'Eastern Cape',
      'cities' => 
      array (
        0 => 'Adelaide',
        1 => 'Alfred Nzo District Municipality',
        2 => 'Alice',
        3 => 'Aliwal North',
        4 => 'Amathole District Municipality',
        5 => 'Bhisho',
        6 => 'Buffalo City Metropolitan Municipality',
        7 => 'Burgersdorp',
        8 => 'Butterworth',
        9 => 'Cacadu District Municipality',
        10 => 'Chris Hani District Municipality',
        11 => 'Cradock',
        12 => 'Dordrecht',
        13 => 'East London',
        14 => 'Elliot',
        15 => 'Fort Beaufort',
        16 => 'Graaff-Reinet',
        17 => 'Grahamstown',
        18 => 'Ilinge',
        19 => 'Joe Gqabi District Municipality',
        20 => 'Kirkwood',
        21 => 'Kruisfontein',
        22 => 'Lady Frere',
        23 => 'Middelburg',
        24 => 'Molteno',
        25 => 'Mthatha',
        26 => 'Nelson Mandela Bay Metropolitan Municipality',
        27 => 'OR Tambo District Municipality',
        28 => 'Port Alfred',
        29 => 'Port Elizabeth',
        30 => 'Port Saint John&#039;s',
        31 => 'Queensdale',
        32 => 'Queenstown',
        33 => 'Somerset East',
        34 => 'Stutterheim',
        35 => 'Uitenhage',
        36 => 'Whittlesea',
        37 => 'Willowmore',
      ),
    ),
    'WC' => 
    array (
      'name' => 'Western Cape',
      'cities' => 
      array (
        0 => 'Albertina',
        1 => 'Arniston',
        2 => 'Atlantis',
        3 => 'Beaufort West',
        4 => 'Bergvliet',
        5 => 'Bredasdorp',
        6 => 'Caledon',
        7 => 'Calitzdorp',
        8 => 'Cape Town',
        9 => 'Cape Winelands District Municipality',
        10 => 'Central Karoo District Municipality',
        11 => 'Ceres',
        12 => 'City of Cape Town',
        13 => 'Clanwilliam',
        14 => 'Claremont',
        15 => 'Constantia',
        16 => 'De Rust',
        17 => 'Eden District Municipality',
        18 => 'George',
        19 => 'Grabouw',
        20 => 'Hardys Memories of Africa',
        21 => 'Hermanus',
        22 => 'Knysna',
        23 => 'Kraaifontein',
        24 => 'Ladismith',
        25 => 'Lansdowne',
        26 => 'Malmesbury',
        27 => 'Montagu',
        28 => 'Moorreesburg',
        29 => 'Mossel Bay',
        30 => 'Newlands',
        31 => 'Oudtshoorn',
        32 => 'Overberg District Municipality',
        33 => 'Paarl',
        34 => 'Piketberg',
        35 => 'Plettenberg Bay',
        36 => 'Prince Albert',
        37 => 'Retreat',
        38 => 'Riversdale',
        39 => 'Robertson',
        40 => 'Rondebosch',
        41 => 'Rosebank',
        42 => 'Saldanha',
        43 => 'Stellenbosch',
        44 => 'Sunset Beach',
        45 => 'Swellendam',
        46 => 'Vredenburg',
        47 => 'Vredendal',
        48 => 'Wellington',
        49 => 'West Coast District Municipality',
        50 => 'Worcester',
        51 => 'Zoar',
      ),
    ),
  ),
  'NI' => 
  array (
    'CO' => 
    array (
      'name' => 'Chontales Department',
      'cities' => 
      array (
        0 => 'Acoyapa',
        1 => 'Comalapa',
        2 => 'Cuapa',
        3 => 'El Ayote',
        4 => 'Juigalpa',
        5 => 'La Libertad',
        6 => 'Santo Domingo',
        7 => 'Santo Tomás',
        8 => 'Villa Sandino',
      ),
    ),
    'MN' => 
    array (
      'name' => 'Managua Department',
      'cities' => 
      array (
        0 => 'Ciudad Sandino',
        1 => 'El Crucero',
        2 => 'Managua',
        3 => 'Masachapa',
        4 => 'San Rafael del Sur',
        5 => 'Ticuantepe',
        6 => 'Tipitapa',
        7 => 'Valle San Francisco',
        8 => 'Villa El Carmen',
      ),
    ),
    'RI' => 
    array (
      'name' => 'Rivas Department',
      'cities' => 
      array (
        0 => 'Altagracia',
        1 => 'Belén',
        2 => 'Buenos Aires',
        3 => 'Cárdenas',
        4 => 'Moyogalpa',
        5 => 'Municipio de Altagracia',
        6 => 'Municipio de Belén',
        7 => 'Municipio de Buenos Aires',
        8 => 'Municipio de Cárdenas',
        9 => 'Municipio de Moyogalpa',
        10 => 'Municipio de Potosí',
        11 => 'Municipio de Rivas',
        12 => 'Municipio de San Jorge',
        13 => 'Municipio de San Juan del Sur',
        14 => 'Municipio de Tola',
        15 => 'Potosí',
        16 => 'Rivas',
        17 => 'San Jorge',
        18 => 'San Juan del Sur',
        19 => 'Tola',
      ),
    ),
    'GR' => 
    array (
      'name' => 'Granada Department',
      'cities' => 
      array (
        0 => 'Diriomo',
        1 => 'Diriá',
        2 => 'Granada',
        3 => 'Nandaime',
      ),
    ),
    'LE' => 
    array (
      'name' => 'León Department',
      'cities' => 
      array (
        0 => 'Achuapa',
        1 => 'El Jicaral',
        2 => 'El Sauce',
        3 => 'La Paz Centro',
        4 => 'Larreynaga',
        5 => 'León',
        6 => 'Nagarote',
        7 => 'Quezalguaque',
        8 => 'Santa Rosa del Peñón',
        9 => 'Telica',
      ),
    ),
    'ES' => 
    array (
      'name' => 'Estelí Department',
      'cities' => 
      array (
        0 => 'Condega',
        1 => 'Estelí',
        2 => 'La Trinidad',
        3 => 'Pueblo Nuevo',
        4 => 'San Juan de Limay',
      ),
    ),
    'BO' => 
    array (
      'name' => 'Boaco Department',
      'cities' => 
      array (
        0 => 'Boaco',
        1 => 'Camoapa',
        2 => 'San José de los Remates',
        3 => 'San Lorenzo',
        4 => 'Santa Lucía',
        5 => 'Teustepe',
      ),
    ),
    'MT' => 
    array (
      'name' => 'Matagalpa Department',
      'cities' => 
      array (
        0 => 'Ciudad Darío',
        1 => 'Matagalpa',
        2 => 'Matiguás',
        3 => 'Muy Muy',
        4 => 'Río Blanco',
        5 => 'San Dionisio',
        6 => 'San Ramón',
        7 => 'Terrabona',
      ),
    ),
    'MD' => 
    array (
      'name' => 'Madriz Department',
      'cities' => 
      array (
        0 => 'Las Sabanas',
        1 => 'Palacagüina',
        2 => 'San José de Cusmapa',
        3 => 'San Juan de Río Coco',
        4 => 'San Lucas',
        5 => 'Somoto',
        6 => 'Telpaneca',
        7 => 'Totogalpa',
        8 => 'Yalagüina',
      ),
    ),
    'SJ' => 
    array (
      'name' => 'Río San Juan Department',
      'cities' => 
      array (
        0 => 'El Almendro',
        1 => 'Greytown',
        2 => 'Morrito',
        3 => 'San Carlos',
        4 => 'San Miguelito',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Carazo Department',
      'cities' => 
      array (
        0 => 'Diriamba',
        1 => 'Dolores',
        2 => 'El Rosario',
        3 => 'Jinotepe',
        4 => 'La Conquista',
        5 => 'La Paz de Carazo',
        6 => 'Municipio de San Marcos',
        7 => 'San Marcos',
        8 => 'Santa Teresa',
      ),
    ),
    'AN' => 
    array (
      'name' => 'North Caribbean Coast Autonomous Region',
      'cities' => 
      array (
        0 => 'Bonanza',
        1 => 'Prinzapolka',
        2 => 'Puerto Cabezas',
        3 => 'Siuna',
        4 => 'Waslala',
        5 => 'Waspán',
      ),
    ),
    'AS' => 
    array (
      'name' => 'South Caribbean Coast Autonomous Region',
      'cities' => 
      array (
        0 => 'Bluefields',
        1 => 'Bocana de Paiwas',
        2 => 'Corn Island',
        3 => 'El Rama',
        4 => 'El Tortuguero',
        5 => 'Kukrahill',
        6 => 'La Cruz de Río Grande',
        7 => 'Laguna de Perlas',
        8 => 'Muelle de los Bueyes',
        9 => 'Nueva Guinea',
      ),
    ),
    'MS' => 
    array (
      'name' => 'Masaya Department',
      'cities' => 
      array (
        0 => 'Catarina',
        1 => 'La Concepción',
        2 => 'Masatepe',
        3 => 'Masaya',
        4 => 'Municipio de Masatepe',
        5 => 'Municipio de Nandasmo',
        6 => 'Municipio de Niquinohomo',
        7 => 'Municipio de San Juan de Oriente',
        8 => 'Nandasmo',
        9 => 'Nindirí',
        10 => 'Niquinohomo',
        11 => 'San Juan de Oriente',
        12 => 'Tisma',
      ),
    ),
    'CI' => 
    array (
      'name' => 'Chinandega Department',
      'cities' => 
      array (
        0 => 'Chichigalpa',
        1 => 'Chinandega',
        2 => 'Cinco Pinos',
        3 => 'Corinto',
        4 => 'El Realejo',
        5 => 'El Viejo',
        6 => 'Jiquilillo',
        7 => 'Municipio de San Francisco del Norte',
        8 => 'Posoltega',
        9 => 'Puerto Morazán',
        10 => 'Santo Tomás del Norte',
        11 => 'Somotillo',
      ),
    ),
    'JI' => 
    array (
      'name' => 'Jinotega Department',
      'cities' => 
      array (
        0 => 'El Cuá',
        1 => 'Jinotega',
        2 => 'LLano de La Cruz',
        3 => 'La Concordia',
        4 => 'Las Praderas',
        5 => 'San José de Bocay',
        6 => 'San Rafael del Norte',
        7 => 'San Sebastián de Yalí',
      ),
    ),
  ),
  'JO' => 
  array (
    'KA' => 
    array (
      'name' => 'Karak Governorate',
      'cities' => 
      array (
        0 => 'Adir',
        1 => 'Al Khinzīrah',
        2 => 'Al Mazār al Janūbī',
        3 => 'Al Qaşr',
        4 => 'Ar Rabbah',
        5 => 'Karak City',
        6 => 'Safi',
        7 => '&#039;Ayy',
        8 => '&#039;Izrā',
      ),
    ),
    'AT' => 
    array (
      'name' => 'Tafilah Governorate',
      'cities' => 
      array (
        0 => 'Aţ Ţafīlah',
        1 => 'Buşayrā',
      ),
    ),
    'MD' => 
    array (
      'name' => 'Madaba Governorate',
      'cities' => 
      array (
        0 => 'Mādabā',
      ),
    ),
    'AQ' => 
    array (
      'name' => 'Aqaba Governorate',
      'cities' => 
      array (
        0 => 'Aqaba',
        1 => 'Tala Bay',
      ),
    ),
    'IR' => 
    array (
      'name' => 'Irbid Governorate',
      'cities' => 
      array (
        0 => 'Ar Ramthā',
        1 => 'Ash Shajarah',
        2 => 'Aydūn',
        3 => 'Aţ Ţayyibah',
        4 => 'Aţ Ţurrah',
        5 => 'Bayt Yāfā',
        6 => 'Bayt Īdis',
        7 => 'Dayr Yūsuf',
        8 => 'Irbid',
        9 => 'Judita',
        10 => 'Kafr Abīl',
        11 => 'Kafr Asad',
        12 => 'Kafr Sawm',
        13 => 'Kharjā',
        14 => 'Kitim',
        15 => 'Kurayyimah',
        16 => 'Malkā',
        17 => 'Qumaym',
        18 => 'Saḩam al Kaffārāt',
        19 => 'Sāl',
        20 => 'Tibnah',
        21 => 'Umm Qays',
        22 => 'Waqqāş',
        23 => 'Zaḩar',
        24 => 'Şammā',
        25 => 'Ḩakamā',
        26 => 'Ḩātim',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Balqa Governorate',
      'cities' => 
      array (
        0 => 'Al Karāmah',
        1 => 'As Salţ',
        2 => 'Yarqā',
      ),
    ),
    'MA' => 
    array (
      'name' => 'Mafraq Governorate',
      'cities' => 
      array (
        0 => 'Al Ḩamrā&#039;',
        1 => 'Mafraq',
        2 => 'Rehab',
        3 => 'Rukban',
        4 => 'Umm al Qiţţayn',
        5 => 'Şabḩā',
      ),
    ),
    'AJ' => 
    array (
      'name' => 'Ajloun Governorate',
      'cities' => 
      array (
        0 => 'Şakhrah',
        1 => 'Ḩalāwah',
        2 => '&#039;Ajlūn',
        3 => '&#039;Anjarah',
        4 => '&#039;Ayn Jannah',
      ),
    ),
    'MN' => 
    array (
      'name' => 'Ma&#039;an Governorate',
      'cities' => 
      array (
        0 => 'Al Jafr',
        1 => 'Al Quwayrah',
        2 => 'Ash Shawbak',
        3 => 'Aţ Ţayyibah',
        4 => 'Ma&#039;an',
        5 => 'Petra',
        6 => 'Qīr Moāv',
      ),
    ),
    'AM' => 
    array (
      'name' => 'Amman Governorate',
      'cities' => 
      array (
        0 => 'Al Jubayhah',
        1 => 'Al Jīzah',
        2 => 'Amman',
        3 => 'Jāwā',
        4 => 'Saḩāb',
        5 => 'Umm as Summāq',
        6 => 'Wādī as Sīr',
        7 => 'Ḩayy al Bunayyāt',
        8 => 'Ḩayy al Quwaysimah',
      ),
    ),
    'JA' => 
    array (
      'name' => 'Jerash Governorate',
      'cities' => 
      array (
        0 => 'Al Kittah',
        1 => 'Balīlā',
        2 => 'Burmā',
        3 => 'Jarash',
        4 => 'Qafqafā',
        5 => 'Raymūn',
        6 => 'Sakib',
        7 => 'Sūf',
      ),
    ),
    'AZ' => 
    array (
      'name' => 'Zarqa Governorate',
      'cities' => 
      array (
        0 => 'Al Azraq ash Shamālī',
        1 => 'Russeifa',
        2 => 'Zarqa',
      ),
    ),
  ),
  'SZ' => 
  array (
    'MA' => 
    array (
      'name' => 'Manzini District',
      'cities' => 
      array (
        0 => 'Bhunya',
        1 => 'Ekukhanyeni',
        2 => 'Kwaluseni',
        3 => 'Malkerns',
        4 => 'Manzini',
        5 => 'Manzini South',
        6 => 'Mhlambanyatsi',
        7 => 'Ngwempisi',
        8 => 'Ntondozi',
        9 => 'Sidvokodvo',
      ),
    ),
    'HH' => 
    array (
      'name' => 'Hhohho District',
      'cities' => 
      array (
        0 => 'Bulembu',
        1 => 'Hhukwini',
        2 => 'Lobamba',
        3 => 'Mbabane',
        4 => 'Nkhaba',
        5 => 'Piggs Peak',
      ),
    ),
    'LU' => 
    array (
      'name' => 'Lubombo District',
      'cities' => 
      array (
        0 => 'Big Bend',
        1 => 'Dvokodvweni Inkhundla',
        2 => 'Lomashasha',
        3 => 'Mhlume',
        4 => 'Nsoko',
        5 => 'Siteki',
        6 => 'Tshaneni',
        7 => 'Vuvulane',
      ),
    ),
    'SH' => 
    array (
      'name' => 'Shiselweni District',
      'cities' => 
      array (
        0 => 'Hlatikulu',
        1 => 'Hluti',
        2 => 'Kubuta',
        3 => 'Lavumisa',
        4 => 'Matsanjeni',
        5 => 'Ngudzeni',
        6 => 'Nhlangano',
        7 => 'Nkwene',
        8 => 'Sigwe Inkhundla',
        9 => 'Zombodze Ikhundla',
      ),
    ),
  ),
  'KW' => 
  array (
    'JA' => 
    array (
      'name' => 'Al Jahra Governorate',
      'cities' => 
      array (
        0 => 'Al Jahrā&#039;',
      ),
    ),
    'HA' => 
    array (
      'name' => 'Hawalli Governorate',
      'cities' => 
      array (
        0 => 'Ar Rumaythīyah',
        1 => 'As Sālimīyah',
        2 => 'Bayān',
        3 => 'Salwá',
        4 => 'Ḩawallī',
      ),
    ),
    'MU' => 
    array (
      'name' => 'Mubarak Al-Kabeer Governorate',
      'cities' => 
      array (
        0 => 'Abu Al Hasaniya',
        1 => 'Abu Fatira',
        2 => 'Al Funayţīs',
        3 => 'Al-Masayel',
        4 => 'Şabāḩ as Sālim',
      ),
    ),
    'FA' => 
    array (
      'name' => 'Al Farwaniyah Governorate',
      'cities' => 
      array (
        0 => 'Al Farwānīyah',
        1 => 'Janūb as Surrah',
      ),
    ),
    'KU' => 
    array (
      'name' => 'Capital Governorate',
      'cities' => 
      array (
        0 => 'Ad Dasmah',
        1 => 'Ar Rābiyah',
        2 => 'Ash Shāmīyah',
        3 => 'Az Zawr',
        4 => 'Kuwait City',
      ),
    ),
    'AH' => 
    array (
      'name' => 'Al Ahmadi Governorate',
      'cities' => 
      array (
        0 => 'Al Aḩmadī',
        1 => 'Al Faḩāḩīl',
        2 => 'Al Finţās',
        3 => 'Al Mahbūlah',
        4 => 'Al Manqaf',
        5 => 'Al Wafrah',
        6 => 'Ar Riqqah',
      ),
    ),
  ),
  'LA' => 
  array (
    'LP' => 
    array (
      'name' => 'Luang Prabang Province',
      'cities' => 
      array (
        0 => 'Luang Prabang',
      ),
    ),
    'VT' => 
    array (
      'name' => 'Vientiane Prefecture',
      'cities' => 
      array (
        0 => 'Vientiane',
      ),
    ),
    'VI' => 
    array (
      'name' => 'Vientiane Province',
      'cities' => 
      array (
        0 => 'Muang Phôn-Hông',
        1 => 'Vangviang',
      ),
    ),
    'SL' => 
    array (
      'name' => 'Salavan Province',
      'cities' => 
      array (
        0 => 'Muang Khôngxédôn',
        1 => 'Muang Lakhonphéng',
        2 => 'Muang Laongam',
        3 => 'Muang Samouay',
        4 => 'Muang Saravan',
        5 => 'Muang Ta-Ôy',
        6 => 'Muang Toumlan',
        7 => 'Muang Vapi',
        8 => 'Salavan',
      ),
    ),
    'AT' => 
    array (
      'name' => 'Attapeu Province',
      'cities' => 
      array (
        0 => 'Attapeu',
        1 => 'Muang Phouvong',
        2 => 'Muang Samakhixai',
        3 => 'Muang Sanamxai',
        4 => 'Muang Sanxai',
        5 => 'Muang Xaiséttha',
      ),
    ),
    'XS' => 
    array (
      'name' => 'Xaisomboun Province',
      'cities' => 
      array (
        0 => 'Anouvong district',
        1 => 'Longchaeng',
        2 => 'Muang Longxan',
        3 => 'Muang Thathôm',
      ),
    ),
    'XE' => 
    array (
      'name' => 'Sekong Province',
      'cities' => 
      array (
        0 => 'Ban Thatèng',
        1 => 'Lamam',
        2 => 'Muang Dakchung',
        3 => 'Muang Khaleum',
        4 => 'Muang Laman',
        5 => 'Muang Thatèng',
      ),
    ),
    'BL' => 
    array (
      'name' => 'Bolikhamsai Province',
      'cities' => 
      array (
        0 => 'Ban Nahin',
        1 => 'Pakxan',
      ),
    ),
    'KH' => 
    array (
      'name' => 'Khammouane Province',
      'cities' => 
      array (
        0 => 'Muang Thakhèk',
        1 => 'Thakhèk',
      ),
    ),
    'PH' => 
    array (
      'name' => 'Phongsaly Province',
      'cities' => 
      array (
        0 => 'Phôngsali',
      ),
    ),
    'OU' => 
    array (
      'name' => 'Oudomxay Province',
      'cities' => 
      array (
        0 => 'Muang Xay',
      ),
    ),
    'HO' => 
    array (
      'name' => 'Houaphanh Province',
      'cities' => 
      array (
        0 => 'Xam Neua',
        1 => 'Xam Nua',
      ),
    ),
    'SV' => 
    array (
      'name' => 'Savannakhet Province',
      'cities' => 
      array (
        0 => 'Kaysone Phomvihane',
        1 => 'Muang Alsaphangthong',
        2 => 'Muang Atsaphan',
        3 => 'Muang Champhon',
        4 => 'Muang Nong',
        5 => 'Muang Outhoumphon',
        6 => 'Muang Phin',
        7 => 'Muang Songkhon',
        8 => 'Muang Thapangthong',
        9 => 'Muang Vilabouli',
        10 => 'Muang Xaibouli',
        11 => 'Muang Xayphoothong',
        12 => 'Muang Xônbouli',
        13 => 'Savannakhet',
        14 => 'Thaphalanxay',
      ),
    ),
    'BK' => 
    array (
      'name' => 'Bokeo Province',
      'cities' => 
      array (
        0 => 'Ban Houakhoua',
        1 => 'Ban Houayxay',
        2 => 'Muang Houayxay',
        3 => 'Muang Meung',
        4 => 'Muang Paktha',
        5 => 'Muang Pha Oudôm',
        6 => 'Muang Tônpheung',
      ),
    ),
    'LM' => 
    array (
      'name' => 'Luang Namtha Province',
      'cities' => 
      array (
        0 => 'Luang Namtha',
        1 => 'Muang Louang Namtha',
      ),
    ),
    'XA' => 
    array (
      'name' => 'Sainyabuli Province',
      'cities' => 
      array (
        0 => 'Sainyabuli',
      ),
    ),
    'XI' => 
    array (
      'name' => 'Xiangkhouang Province',
      'cities' => 
      array (
        0 => 'Muang Phônsavan',
      ),
    ),
    'CH' => 
    array (
      'name' => 'Champasak Province',
      'cities' => 
      array (
        0 => 'Champasak',
        1 => 'Muang Bachiangchaleunsook',
        2 => 'Muang Champasak',
        3 => 'Muang Không',
        4 => 'Muang Mounlapamôk',
        5 => 'Muang Pakxong',
        6 => 'Muang Pakxé',
        7 => 'Muang Pathoumphon',
        8 => 'Muang Phônthong',
        9 => 'Muang Soukhouma',
        10 => 'Muang Xanasômboun',
        11 => 'Pakse',
        12 => 'Pakxong',
      ),
    ),
  ),
  'KG' => 
  array (
    'T' => 
    array (
      'name' => 'Talas Region',
      'cities' => 
      array (
        0 => 'Kara-Buurinskiy Rayon',
        1 => 'Talas',
        2 => 'Talasskiy Rayon',
      ),
    ),
    'B' => 
    array (
      'name' => 'Batken Region',
      'cities' => 
      array (
        0 => 'Aydarken',
        1 => 'Batken',
        2 => 'Iradan',
        3 => 'Isfana',
        4 => 'Karavan',
        5 => 'Kyzyl-Kyya',
        6 => 'Suluktu',
      ),
    ),
    'N' => 
    array (
      'name' => 'Naryn Region',
      'cities' => 
      array (
        0 => 'At-Bashi',
        1 => 'Jumgal',
        2 => 'Naryn',
      ),
    ),
    'J' => 
    array (
      'name' => 'Jalal-Abad Region',
      'cities' => 
      array (
        0 => 'Ala-Buka',
        1 => 'Bazar-Korgon',
        2 => 'Jalal-Abad',
        3 => 'Kazarman',
        4 => 'Kerben',
        5 => 'Kochkor-Ata',
        6 => 'Suzak',
        7 => 'Tash-Kumyr',
        8 => 'Toktogul',
        9 => 'Toktogul District',
      ),
    ),
    'GB' => 
    array (
      'name' => 'Bishkek',
      'cities' => 
      array (
        0 => 'Bishkek',
      ),
    ),
    'Y' => 
    array (
      'name' => 'Issyk-Kul Region',
      'cities' => 
      array (
        0 => 'Ak-Suu',
        1 => 'Balykchy',
        2 => 'Cholpon-Ata',
        3 => 'Kadzhi-Say',
        4 => 'Karakol',
        5 => 'Kyzyl-Suu',
        6 => 'Tyup',
      ),
    ),
    'C' => 
    array (
      'name' => 'Chuy Region',
      'cities' => 
      array (
        0 => 'Alamudunskiy Rayon',
        1 => 'Belovodskoye',
        2 => 'Chuyskiy Rayon',
        3 => 'Ivanovka',
        4 => 'Kaindy',
        5 => 'Kant',
        6 => 'Kara-Balta',
        7 => 'Kemin',
        8 => 'Lebedinovka',
        9 => 'Sokulukskiy Rayon',
        10 => 'Sosnovka',
        11 => 'Tokmok',
        12 => 'Ysyk-Ata',
      ),
    ),
    'O' => 
    array (
      'name' => 'Osh Region',
      'cities' => 
      array (
        0 => 'Chong-Alay District',
        1 => 'Daroot-Korgon',
        2 => 'Kara Kulja',
        3 => 'Kara Suu',
        4 => 'Kyzyl-Eshme',
        5 => 'Nookat',
        6 => 'Osh',
        7 => 'Uzgen',
        8 => 'Uzgen District',
      ),
    ),
  ),
  'NO' => 
  array (
    '03' => 
    array (
      'name' => 'Oslo',
      'cities' => 
      array (
        0 => 'Oslo',
        1 => 'Sjølyststranda',
      ),
    ),
    '07' => 
    array (
      'name' => 'Vestfold',
      'cities' => 
      array (
        0 => 'Barkåker',
        1 => 'Berger',
        2 => 'Færder',
        3 => 'Gullhaug',
        4 => 'Holmestrand',
        5 => 'Horten',
        6 => 'Larvik',
        7 => 'Melsomvik',
        8 => 'Re',
        9 => 'Sande',
        10 => 'Sandefjord',
        11 => 'Selvik',
        12 => 'Sem',
        13 => 'Skoppum',
        14 => 'Stavern',
        15 => 'Stokke',
        16 => 'Svelvik',
        17 => 'Tjøme',
        18 => 'Tønsberg',
        19 => 'Årøysund',
        20 => 'Åsgårdstrand',
      ),
    ),
    '05' => 
    array (
      'name' => 'Oppland',
      'cities' => 
      array (
        0 => 'Bagn',
        1 => 'Dokka',
        2 => 'Dombås',
        3 => 'Dovre',
        4 => 'Etnedal',
        5 => 'Fagernes',
        6 => 'Fossbergom',
        7 => 'Gausdal',
        8 => 'Gjøvik',
        9 => 'Gran',
        10 => 'Grua',
        11 => 'Hov',
        12 => 'Hundorp',
        13 => 'Jevnaker',
        14 => 'Lena',
        15 => 'Lesja',
        16 => 'Lillehammer',
        17 => 'Lom',
        18 => 'Lunner',
        19 => 'Nord-Aurdal',
        20 => 'Nord-Fron',
        21 => 'Nordre Land',
        22 => 'Otta',
        23 => 'Raufoss',
        24 => 'Reinsvoll',
        25 => 'Ringebu',
        26 => 'Sel',
        27 => 'Skjåk',
        28 => 'Skreia',
        29 => 'Søndre Land',
        30 => 'Sør-Aurdal',
        31 => 'Sør-Fron',
        32 => 'Tretten',
        33 => 'Vang',
        34 => 'Vestre Slidre',
        35 => 'Vestre Toten',
        36 => 'Vinstra',
        37 => 'Vågå',
        38 => 'Vågåmo',
        39 => 'Østre Toten',
        40 => 'Øyer',
        41 => 'Øystre Slidre',
      ),
    ),
    '06' => 
    array (
      'name' => 'Buskerud',
      'cities' => 
      array (
        0 => 'Drammen',
        1 => 'Flesberg',
        2 => 'Flå',
        3 => 'Geilo',
        4 => 'Gol',
        5 => 'Hemsedal',
        6 => 'Hol',
        7 => 'Hole',
        8 => 'Hurum',
        9 => 'Hvittingfoss',
        10 => 'Hønefoss',
        11 => 'Kongsberg',
        12 => 'Krødsherad',
        13 => 'Lier',
        14 => 'Modum',
        15 => 'Nedre Eiker',
        16 => 'Nes',
        17 => 'Nesbyen',
        18 => 'Nore og Uvdal',
        19 => 'Noresund',
        20 => 'Prestfoss',
        21 => 'Ringerike',
        22 => 'Rollag',
        23 => 'Røyken',
        24 => 'Sigdal',
        25 => 'Skoger',
        26 => 'Sætre',
        27 => 'Tofte',
        28 => 'Tranby',
        29 => 'Vikersund',
        30 => 'Ål',
        31 => 'Åros',
        32 => 'Øvre Eiker',
      ),
    ),
    '02' => 
    array (
      'name' => 'Akershus',
      'cities' => 
      array (
        0 => 'Ask',
        1 => 'Asker',
        2 => 'Auli',
        3 => 'Aurskog-Høland',
        4 => 'Aursmoen',
        5 => 'Billingstad',
        6 => 'Bjørkelangen',
        7 => 'Blakstad',
        8 => 'Bærum',
        9 => 'Drøbak',
        10 => 'Eidsvoll',
        11 => 'Enebakk',
        12 => 'Fagerstrand',
        13 => 'Fet',
        14 => 'Fetsund',
        15 => 'Fjellfoten',
        16 => 'Flateby',
        17 => 'Frogn',
        18 => 'Frogner',
        19 => 'Gjerdrum',
        20 => 'Hurdal',
        21 => 'Jessheim',
        22 => 'Kløfta',
        23 => 'Leirsund',
        24 => 'Lillestrøm',
        25 => 'Lysaker',
        26 => 'Lørenskog',
        27 => 'Maura',
        28 => 'Nannestad',
        29 => 'Nes',
        30 => 'Neskollen',
        31 => 'Nesodden',
        32 => 'Nesoddtangen',
        33 => 'Nittedal',
        34 => 'Oppegård',
        35 => 'Rotnes',
        36 => 'Råholt',
        37 => 'Rælingen',
        38 => 'Skedsmo',
        39 => 'Ski',
        40 => 'Skui',
        41 => 'Sørum',
        42 => 'Sørumsand',
        43 => 'Ullensaker',
        44 => 'Vestby',
        45 => 'Åneby',
        46 => 'Årnes',
        47 => 'Ås',
      ),
    ),
    '04' => 
    array (
      'name' => 'Hedmark',
      'cities' => 
      array (
        0 => 'Alvdal',
        1 => 'Brumunddal',
        2 => 'Eidskog',
        3 => 'Elverum',
        4 => 'Engerdal',
        5 => 'Folldal',
        6 => 'Grue',
        7 => 'Hamar',
        8 => 'Innbygda',
        9 => 'Kirkenær',
        10 => 'Kongsvinger',
        11 => 'Koppang',
        12 => 'Løten',
        13 => 'Moelv',
        14 => 'Nord-Odal',
        15 => 'Os',
        16 => 'Rena',
        17 => 'Rendalen',
        18 => 'Ringsaker',
        19 => 'Sand',
        20 => 'Skarnes',
        21 => 'Skotterud',
        22 => 'Spetalen',
        23 => 'Stange',
        24 => 'Stor-Elvdal',
        25 => 'Sør-Odal',
        26 => 'Tolga',
        27 => 'Trysil',
        28 => 'Tynset',
        29 => 'Våler',
        30 => 'Åmot',
        31 => 'Åsnes',
      ),
    ),
    '01' => 
    array (
      'name' => 'Østfold',
      'cities' => 
      array (
        0 => 'Aremark',
        1 => 'Askim',
        2 => 'Eidsberg',
        3 => 'Fossby',
        4 => 'Fredrikstad',
        5 => 'Halden',
        6 => 'Hobøl',
        7 => 'Hvaler',
        8 => 'Karlshus',
        9 => 'Knappstad',
        10 => 'Larkollen',
        11 => 'Lervik',
        12 => 'Marker',
        13 => 'Moss',
        14 => 'Mysen',
        15 => 'Rakkestad',
        16 => 'Rygge',
        17 => 'Ryggebyen',
        18 => 'Råde',
        19 => 'Rømskog',
        20 => 'Sarpsborg',
        21 => 'Skiptvet',
        22 => 'Skjeberg',
        23 => 'Skjærhalden',
        24 => 'Spydeberg',
        25 => 'Tomter',
        26 => 'Trøgstad',
        27 => 'Våler',
        28 => 'Ørje',
      ),
    ),
    '08' => 
    array (
      'name' => 'Telemark',
      'cities' => 
      array (
        0 => 'Bamble',
        1 => 'Bø',
        2 => 'Dalen',
        3 => 'Drangedal',
        4 => 'Fyresdal',
        5 => 'Gvarv',
        6 => 'Herre',
        7 => 'Hjartdal',
        8 => 'Kragerø',
        9 => 'Kviteseid',
        10 => 'Lunde',
        11 => 'Nissedal',
        12 => 'Nome',
        13 => 'Notodden',
        14 => 'Porsgrunn',
        15 => 'Prestestranda',
        16 => 'Rjukan',
        17 => 'Sauherad',
        18 => 'Seljord',
        19 => 'Siljan',
        20 => 'Skien',
        21 => 'Tinn',
        22 => 'Tokke',
        23 => 'Ulefoss',
        24 => 'Vinje',
      ),
    ),
  ),
  'HU' => 
  array (
    'CS' => 
    array (
      'name' => 'Csongrád County',
      'cities' => 
      array (
        0 => 'Algyő',
        1 => 'Apátfalva',
        2 => 'Baks',
        3 => 'Balástya',
        4 => 'Bordány',
        5 => 'Csanytelek',
        6 => 'Csanádpalota',
        7 => 'Csengele',
        8 => 'Csongrád',
        9 => 'Csongrádi Járás',
        10 => 'Deszk',
        11 => 'Domaszék',
        12 => 'Forráskút',
        13 => 'Fábiánsebestyén',
        14 => 'Földeák',
        15 => 'Hódmezővásárhely',
        16 => 'Hódmezővásárhelyi Járás',
        17 => 'Kistelek',
        18 => 'Kisteleki Járás',
        19 => 'Kiszombor',
        20 => 'Makó',
        21 => 'Makói Járás',
        22 => 'Maroslele',
        23 => 'Mindszent',
        24 => 'Mórahalmi Járás',
        25 => 'Mórahalom',
        26 => 'Pusztaszer',
        27 => 'Ruzsa',
        28 => 'Röszke',
        29 => 'Szatymaz',
        30 => 'Szeged',
        31 => 'Szegedi Járás',
        32 => 'Szegvár',
        33 => 'Szentes',
        34 => 'Szentesi Járás',
        35 => 'Székkutas',
        36 => 'Sándorfalva',
        37 => 'Tömörkény',
        38 => 'Zsombó',
        39 => 'Zákányszék',
        40 => 'Ásotthalom',
        41 => 'Ópusztaszer',
        42 => 'Üllés',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Somogy County',
      'cities' => 
      array (
        0 => 'Babócsa',
        1 => 'Balatonberény',
        2 => 'Balatonboglár',
        3 => 'Balatonfenyves',
        4 => 'Balatonföldvár',
        5 => 'Balatonlelle',
        6 => 'Balatonszabadi',
        7 => 'Balatonszárszó',
        8 => 'Barcs',
        9 => 'Barcsi Járás',
        10 => 'Berzence',
        11 => 'Böhönye',
        12 => 'Csurgó',
        13 => 'Csurgói Járás',
        14 => 'Fonyód',
        15 => 'Fonyódi Járás',
        16 => 'Kadarkút',
        17 => 'Kaposmérő',
        18 => 'Kaposvár',
        19 => 'Kaposvári Járás',
        20 => 'Karád',
        21 => 'Kéthely',
        22 => 'Lengyeltóti',
        23 => 'Lábod',
        24 => 'Marcali',
        25 => 'Marcali Járás',
        26 => 'Nagyatád',
        27 => 'Nagyatádi Járás',
        28 => 'Nagybajom',
        29 => 'Segesd',
        30 => 'Siófok',
        31 => 'Siófoki Járás',
        32 => 'Somogyvár',
        33 => 'Tab',
        34 => 'Tabi Járás',
        35 => 'Taszár',
        36 => 'Zamárdi',
        37 => 'Ádánd',
      ),
    ),
    'TO' => 
    array (
      'name' => 'Tolna County',
      'cities' => 
      array (
        0 => 'Bogyiszló',
        1 => 'Bonyhád',
        2 => 'Bonyhádi Járás',
        3 => 'Báta',
        4 => 'Bátaszék',
        5 => 'Bölcske',
        6 => 'Decs',
        7 => 'Dombóvár',
        8 => 'Dombóvári Járás',
        9 => 'Dunaföldvár',
        10 => 'Dunaszentgyörgy',
        11 => 'Döbrököz',
        12 => 'Fadd',
        13 => 'Gyönk',
        14 => 'Hőgyész',
        15 => 'Iregszemcse',
        16 => 'Madocsa',
        17 => 'Nagydorog',
        18 => 'Nagymányok',
        19 => 'Németkér',
        20 => 'Ozora',
        21 => 'Paks',
        22 => 'Paksi Járás',
        23 => 'Pincehely',
        24 => 'Simontornya',
        25 => 'Szedres',
        26 => 'Szekszárd',
        27 => 'Szekszárdi Járás',
        28 => 'Szentgálpuszta',
        29 => 'Tamási',
        30 => 'Tamási Járás',
        31 => 'Tengelic',
        32 => 'Tolna',
        33 => 'Tolnai Járás',
        34 => 'Zomba',
        35 => 'Őcsény',
      ),
    ),
    'VA' => 
    array (
      'name' => 'Vas County',
      'cities' => 
      array (
        0 => 'Bük',
        1 => 'Celldömölk',
        2 => 'Celldömölki Járás',
        3 => 'Csepreg',
        4 => 'Gencsapáti',
        5 => 'Ják',
        6 => 'Jánosháza',
        7 => 'Körmend',
        8 => 'Körmendi Járás',
        9 => 'Kőszeg',
        10 => 'Kőszegi Járás',
        11 => 'Répcelak',
        12 => 'Szentgotthárd',
        13 => 'Szentgotthárdi Járás',
        14 => 'Szombathely',
        15 => 'Szombathelyi Járás',
        16 => 'Sárvár',
        17 => 'Sárvári Járás',
        18 => 'Táplánszentkereszt',
        19 => 'Vasvár',
        20 => 'Vasvári Járás',
        21 => 'Vép',
      ),
    ),
    'HE' => 
    array (
      'name' => 'Heves County',
      'cities' => 
      array (
        0 => 'Abasár',
        1 => 'Adács',
        2 => 'Andornaktálya',
        3 => 'Apc',
        4 => 'Besenyőtelek',
        5 => 'Boldog',
        6 => 'Bélapátfalva',
        7 => 'Bélapátfalvai Járás',
        8 => 'Csány',
        9 => 'Domoszló',
        10 => 'Ecséd',
        11 => 'Eger',
        12 => 'Egerszalók',
        13 => 'Egri Járás',
        14 => 'Erdőtelek',
        15 => 'Felsőtárkány',
        16 => 'Füzesabony',
        17 => 'Füzesabonyi Járás',
        18 => 'Gyöngyös',
        19 => 'Gyöngyöshalász',
        20 => 'Gyöngyösi Járás',
        21 => 'Gyöngyöspata',
        22 => 'Gyöngyössolymos',
        23 => 'Gyöngyöstarján',
        24 => 'Hatvan',
        25 => 'Hatvani Járás',
        26 => 'Heréd',
        27 => 'Heves',
        28 => 'Hevesi Járás',
        29 => 'Hort',
        30 => 'Karácsond',
        31 => 'Kerecsend',
        32 => 'Kisköre',
        33 => 'Kompolt',
        34 => 'Kál',
        35 => 'Lőrinci',
        36 => 'Maklár',
        37 => 'Mátraderecske',
        38 => 'Nagyréde',
        39 => 'Ostoros',
        40 => 'Parád',
        41 => 'Parádsasvár',
        42 => 'Petőfibánya',
        43 => 'Poroszló',
        44 => 'Pétervására',
        45 => 'Pétervásárai Járás',
        46 => 'Recsk',
        47 => 'Rózsaszentmárton',
        48 => 'Sirok',
        49 => 'Szihalom',
        50 => 'Szilvásvárad',
        51 => 'Tarnalelesz',
        52 => 'Tarnaörs',
        53 => 'Tiszanána',
        54 => 'Verpelét',
        55 => 'Vámosgyörk',
        56 => 'Zagyvaszántó',
      ),
    ),
    'GS' => 
    array (
      'name' => 'Győr-Moson-Sopron County',
      'cities' => 
      array (
        0 => 'Abda',
        1 => 'Bakonyszentlászló',
        2 => 'Beled',
        3 => 'Bőny',
        4 => 'Bősárkány',
        5 => 'Csorna',
        6 => 'Csornai Járás',
        7 => 'Farád',
        8 => 'Fertőd',
        9 => 'Fertőrákos',
        10 => 'Fertőszentmiklós',
        11 => 'Győr',
        12 => 'Győri Járás',
        13 => 'Győrszemere',
        14 => 'Győrújbarát',
        15 => 'Halászi',
        16 => 'Jánossomorja',
        17 => 'Kapuvár',
        18 => 'Kapuvári Járás',
        19 => 'Kimle',
        20 => 'Kóny',
        21 => 'Lébény',
        22 => 'Mihályi',
        23 => 'Mosonmagyaróvár',
        24 => 'Mosonmagyaróvári Járás',
        25 => 'Mosonszentmiklós',
        26 => 'Nagycenk',
        27 => 'Nyúl',
        28 => 'Pannonhalma',
        29 => 'Pannonhalmi Járás',
        30 => 'Pér',
        31 => 'Rajka',
        32 => 'Rábapatona',
        33 => 'Sopron',
        34 => 'Soproni Járás',
        35 => 'Szany',
        36 => 'Tét',
        37 => 'Téti Járás',
        38 => 'Töltéstava',
        39 => 'Ágfalva',
        40 => 'Ásványráró',
        41 => 'Öttevény',
      ),
    ),
    'JN' => 
    array (
      'name' => 'Jász-Nagykun-Szolnok County',
      'cities' => 
      array (
        0 => 'Abádszalók',
        1 => 'Alattyán',
        2 => 'Besenyszög',
        3 => 'Cibakháza',
        4 => 'Cserkeszőlő',
        5 => 'Fegyvernek',
        6 => 'Jánoshida',
        7 => 'Jászalsószentgyörgy',
        8 => 'Jászapáti',
        9 => 'Jászapáti Járás',
        10 => 'Jászberény',
        11 => 'Jászberényi Járás',
        12 => 'Jászdózsa',
        13 => 'Jászjákóhalma',
        14 => 'Jászkisér',
        15 => 'Jászladány',
        16 => 'Jászszentandrás',
        17 => 'Jászárokszállás',
        18 => 'Karcag',
        19 => 'Karcagi Járás',
        20 => 'Kenderes',
        21 => 'Kengyel',
        22 => 'Kisújszállás',
        23 => 'Kunhegyes',
        24 => 'Kunhegyesi Járás',
        25 => 'Kunmadaras',
        26 => 'Kunszentmárton',
        27 => 'Kunszentmártoni Járás',
        28 => 'Mezőtúr',
        29 => 'Mezőtúri Járás',
        30 => 'Rákóczifalva',
        31 => 'Rákócziújfalu',
        32 => 'Szajol',
        33 => 'Szelevény',
        34 => 'Szolnok',
        35 => 'Szolnoki Járás',
        36 => 'Tiszabura',
        37 => 'Tiszabő',
        38 => 'Tiszaföldvár',
        39 => 'Tiszafüred',
        40 => 'Tiszafüredi Járás',
        41 => 'Tiszapüspöki',
        42 => 'Tiszaroff',
        43 => 'Tiszaszentimre',
        44 => 'Tiszaszőlős',
        45 => 'Tiszasüly',
        46 => 'Tószeg',
        47 => 'Törökszentmiklós',
        48 => 'Törökszentmiklósi Járás',
        49 => 'Túrkeve',
        50 => 'Zagyvarékas',
        51 => 'Öcsöd',
        52 => 'Újszász',
      ),
    ),
    'FE' => 
    array (
      'name' => 'Fejér County',
      'cities' => 
      array (
        0 => 'Aba',
        1 => 'Adony',
        2 => 'Alap',
        3 => 'Bakonycsernye',
        4 => 'Baracs',
        5 => 'Baracska',
        6 => 'Bicske',
        7 => 'Bicskei Járás',
        8 => 'Bodajk',
        9 => 'Cece',
        10 => 'Csákvár',
        11 => 'Dunaújvárosi Járás',
        12 => 'Dég',
        13 => 'Előszállás',
        14 => 'Enying',
        15 => 'Enyingi Járás',
        16 => 'Ercsi',
        17 => 'Etyek',
        18 => 'Fehérvárcsurgó',
        19 => 'Gárdony',
        20 => 'Gárdonyi Járás',
        21 => 'Iváncsa',
        22 => 'Kincsesbánya',
        23 => 'Kisláng',
        24 => 'Káloz',
        25 => 'Kápolnásnyék',
        26 => 'Lajoskomárom',
        27 => 'Lepsény',
        28 => 'Lovasberény',
        29 => 'Martonvásár',
        30 => 'Martonvásári Járás',
        31 => 'Mezőfalva',
        32 => 'Mezőszilas',
        33 => 'Mány',
        34 => 'Mór',
        35 => 'Móri Járás',
        36 => 'Perkáta',
        37 => 'Polgárdi',
        38 => 'Pusztaszabolcs',
        39 => 'Pusztavám',
        40 => 'Pákozd',
        41 => 'Pázmánd',
        42 => 'Rácalmás',
        43 => 'Ráckeresztúr',
        44 => 'Seregélyes',
        45 => 'Soponya',
        46 => 'Szabadbattyán',
        47 => 'Szárliget',
        48 => 'Székesfehérvár',
        49 => 'Székesfehérvári Járás',
        50 => 'Sárbogárd',
        51 => 'Sárbogárdi Járás',
        52 => 'Sárkeresztúr',
        53 => 'Sárosd',
        54 => 'Sárszentmihály',
        55 => 'Velence',
        56 => 'Vál',
        57 => 'Zámoly',
        58 => 'dunaújváros',
      ),
    ),
    'SZ' => 
    array (
      'name' => 'Szabolcs-Szatmár-Bereg County',
      'cities' => 
      array (
        0 => 'Ajak',
        1 => 'Anarcs',
        2 => 'Apagy',
        3 => 'Aranyosapáti',
        4 => 'Baktalórántháza',
        5 => 'Baktalórántházai Járás',
        6 => 'Balkány',
        7 => 'Buj',
        8 => 'Bököny',
        9 => 'Csenger',
        10 => 'Csengeri Járás',
        11 => 'Demecser',
        12 => 'Dombrád',
        13 => 'Döge',
        14 => 'Encsencs',
        15 => 'Fehérgyarmat',
        16 => 'Fehérgyarmati Járás',
        17 => 'Fényeslitke',
        18 => 'Gyulaháza',
        19 => 'Gégény',
        20 => 'Hodász',
        21 => 'Ibrány',
        22 => 'Ibrányi Járás',
        23 => 'Kemecse',
        24 => 'Kemecsei Járás',
        25 => 'Kisléta',
        26 => 'Kisvárda',
        27 => 'Kisvárdai Járás',
        28 => 'Kocsord',
        29 => 'Kállósemjén',
        30 => 'Kálmánháza',
        31 => 'Kántorjánosi',
        32 => 'Kék',
        33 => 'Kótaj',
        34 => 'Levelek',
        35 => 'Mándok',
        36 => 'Máriapócs',
        37 => 'Mátészalka',
        38 => 'Mátészalkai Járás',
        39 => 'Mérk',
        40 => 'Nagycserkesz',
        41 => 'Nagydobos',
        42 => 'Nagyecsed',
        43 => 'Nagyhalász',
        44 => 'Nagykálló',
        45 => 'Nagykállói Járás',
        46 => 'Napkor',
        47 => 'Nyírbogdány',
        48 => 'Nyírbogát',
        49 => 'Nyírbátor',
        50 => 'Nyírbátori Járás',
        51 => 'Nyírbéltek',
        52 => 'Nyírcsaholy',
        53 => 'Nyíregyháza',
        54 => 'Nyíregyházi Járás',
        55 => 'Nyírgyulaj',
        56 => 'Nyírkarász',
        57 => 'Nyírlugos',
        58 => 'Nyírmada',
        59 => 'Nyírmeggyes',
        60 => 'Nyírmihálydi',
        61 => 'Nyírpazony',
        62 => 'Nyírtass',
        63 => 'Nyírtelek',
        64 => 'Nyírvasvári',
        65 => 'Petneháza',
        66 => 'Porcsalma',
        67 => 'Pátroha',
        68 => 'Rakamaz',
        69 => 'Szakoly',
        70 => 'Szamosszeg',
        71 => 'Tarpa',
        72 => 'Tiszabercel',
        73 => 'Tiszabezdéd',
        74 => 'Tiszadada',
        75 => 'Tiszadob',
        76 => 'Tiszaeszlár',
        77 => 'Tiszalök',
        78 => 'Tiszanagyfalu',
        79 => 'Tiszavasvári',
        80 => 'Tiszavasvári Járás',
        81 => 'Tornyospálca',
        82 => 'Tunyogmatolcs',
        83 => 'Tuzsér',
        84 => 'Tyukod',
        85 => 'Vaja',
        86 => 'Vásárosnamény',
        87 => 'Vásárosnaményi Járás',
        88 => 'Záhony',
        89 => 'Záhonyi Járás',
        90 => 'Ófehértó',
        91 => 'Ópályi',
        92 => 'Ököritófülpös',
        93 => 'Újfehértó',
      ),
    ),
    'ZA' => 
    array (
      'name' => 'Zala County',
      'cities' => 
      array (
        0 => 'Becsehely',
        1 => 'Cserszegtomaj',
        2 => 'Gyenesdiás',
        3 => 'Hévíz',
        4 => 'Keszthely',
        5 => 'Keszthelyi Járás',
        6 => 'Lenti',
        7 => 'Lenti Járás',
        8 => 'Letenye',
        9 => 'Letenyei Járás',
        10 => 'Murakeresztúr',
        11 => 'Nagykanizsa',
        12 => 'Nagykanizsai Járás',
        13 => 'Pacsa',
        14 => 'Sármellék',
        15 => 'Türje',
        16 => 'Vonyarcvashegy',
        17 => 'Zalaegerszeg',
        18 => 'Zalaegerszegi Járás',
        19 => 'Zalakomár',
        20 => 'Zalalövő',
        21 => 'Zalaszentgrót',
        22 => 'Zalaszentgróti Járás',
      ),
    ),
    'BK' => 
    array (
      'name' => 'Bács-Kiskun County',
      'cities' => 
      array (
        0 => 'Akasztó',
        1 => 'Apostag',
        2 => 'Baja',
        3 => 'Bajai Járás',
        4 => 'Ballószög',
        5 => 'Bugac',
        6 => 'Bácsalmás',
        7 => 'Bácsalmási Járás',
        8 => 'Bácsbokod',
        9 => 'Bátya',
        10 => 'Csengőd',
        11 => 'Császártöltés',
        12 => 'Csávoly',
        13 => 'Dunapataj',
        14 => 'Dunavecse',
        15 => 'Dusnok',
        16 => 'Dávod',
        17 => 'Felsőszentiván',
        18 => 'Fülöpjakab',
        19 => 'Fülöpszállás',
        20 => 'Gara',
        21 => 'Hajós',
        22 => 'Harta',
        23 => 'Helvécia',
        24 => 'Hercegszántó',
        25 => 'Izsák',
        26 => 'Jánoshalma',
        27 => 'Jánoshalmai Járás',
        28 => 'Jászszentlászló',
        29 => 'Kalocsa',
        30 => 'Kalocsai Járás',
        31 => 'Katymár',
        32 => 'Kecel',
        33 => 'Kecskemét',
        34 => 'Kecskeméti Járás',
        35 => 'Kelebia',
        36 => 'Kerekegyháza',
        37 => 'Kiskunfélegyháza',
        38 => 'Kiskunfélegyházi Járás',
        39 => 'Kiskunhalas',
        40 => 'Kiskunhalasi Járás',
        41 => 'Kiskunmajsa',
        42 => 'Kiskunmajsai Járás',
        43 => 'Kiskőrös',
        44 => 'Kiskőrösi Járás',
        45 => 'Kisszállás',
        46 => 'Kunfehértó',
        47 => 'Kunszentmiklós',
        48 => 'Kunszentmiklósi Járás',
        49 => 'Lajosmizse',
        50 => 'Lakitelek',
        51 => 'Madaras',
        52 => 'Mélykút',
        53 => 'Nagybaracska',
        54 => 'Nemesnádudvar',
        55 => 'Nyárlőrinc',
        56 => 'Orgovány',
        57 => 'Pálmonostora',
        58 => 'Solt',
        59 => 'Soltvadkert',
        60 => 'Szabadszállás',
        61 => 'Szalkszentmárton',
        62 => 'Szank',
        63 => 'Szentkirály',
        64 => 'Sükösd',
        65 => 'Tass',
        66 => 'Tiszaalpár',
        67 => 'Tiszakécske',
        68 => 'Tiszakécskei Járás',
        69 => 'Tompa',
        70 => 'Tázlár',
        71 => 'Vaskút',
        72 => 'Városföld',
        73 => 'Ágasegyháza',
        74 => 'Érsekcsanád',
      ),
    ),
    'NO' => 
    array (
      'name' => 'Nógrád County',
      'cities' => 
      array (
        0 => 'Balassagyarmat',
        1 => 'Balassagyarmati Járás',
        2 => 'Bercel',
        3 => 'Buják',
        4 => 'Bátonyterenye',
        5 => 'Bátonyterenyei Járás',
        6 => 'Diósjenő',
        7 => 'Héhalom',
        8 => 'Jobbágyi',
        9 => 'Karancskeszi',
        10 => 'Karancslapujtő',
        11 => 'Kazár',
        12 => 'Mátranovák',
        13 => 'Mátraterenye',
        14 => 'Mátraverebély',
        15 => 'Nagyoroszi',
        16 => 'Palotás',
        17 => 'Pásztó',
        18 => 'Pásztói Járás',
        19 => 'Rimóc',
        20 => 'Romhány',
        21 => 'Rétság',
        22 => 'Rétsági Járás',
        23 => 'Salgótarján',
        24 => 'Salgótarjáni Járás',
        25 => 'Somoskőújfalu',
        26 => 'Szurdokpüspöki',
        27 => 'Szécsény',
        28 => 'Szécsényi Járás',
        29 => 'Tar',
        30 => 'Érsekvadkert',
      ),
    ),
    'VE' => 
    array (
      'name' => 'Veszprém County',
      'cities' => 
      array (
        0 => 'Ajka',
        1 => 'Ajkai Járás',
        2 => 'Badacsonytomaj',
        3 => 'Balatonalmádi',
        4 => 'Balatonalmádi Járás',
        5 => 'Balatonfüred',
        6 => 'Balatonfüredi Járás',
        7 => 'Balatonkenese',
        8 => 'Berhida',
        9 => 'Csabrendek',
        10 => 'Csetény',
        11 => 'Csopak',
        12 => 'Devecser',
        13 => 'Devecseri Járás',
        14 => 'Hajmáskér',
        15 => 'Herend',
        16 => 'Litér',
        17 => 'Nemesvámos',
        18 => 'Pápa',
        19 => 'Pápai Járás',
        20 => 'Pétfürdő',
        21 => 'Révfülöp',
        22 => 'Szentkirályszabadja',
        23 => 'Sümeg',
        24 => 'Sümegi Járás',
        25 => 'Tapolca',
        26 => 'Tapolcai Járás',
        27 => 'Tihany',
        28 => 'Veszprém',
        29 => 'Veszprémi Járás',
        30 => 'Várpalota',
        31 => 'Várpalotai Járás',
        32 => 'Zirc',
        33 => 'Zirci Járás',
        34 => 'Zánka',
        35 => 'Úrkút',
        36 => 'Ősi',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Baranya County',
      'cities' => 
      array (
        0 => 'Beremend',
        1 => 'Bóly',
        2 => 'Bólyi Járás',
        3 => 'Bükkösd',
        4 => 'Dunaszekcső',
        5 => 'Harkány',
        6 => 'Hegyháti Járás',
        7 => 'Hidas',
        8 => 'Hosszúhetény',
        9 => 'Komló',
        10 => 'Komlói Járás',
        11 => 'Kozármisleny',
        12 => 'Lánycsók',
        13 => 'Mecseknádasd',
        14 => 'Mohács',
        15 => 'Mohácsi Járás',
        16 => 'Mágocs',
        17 => 'Pellérd',
        18 => 'Pécs',
        19 => 'Pécsi Járás',
        20 => 'Pécsvárad',
        21 => 'Pécsváradi Járás',
        22 => 'Sellye',
        23 => 'Sellyei Járás',
        24 => 'Siklós',
        25 => 'Siklósi Járás',
        26 => 'Szentlőrinc',
        27 => 'Szentlőrinci Járás',
        28 => 'Szigetvár',
        29 => 'Szigetvári Járás',
        30 => 'Szászvár',
        31 => 'Sásd',
        32 => 'Vajszló',
        33 => 'Villány',
      ),
    ),
    'BZ' => 
    array (
      'name' => 'Borsod-Abaúj-Zemplén County',
      'cities' => 
      array (
        0 => 'Abaújszántó',
        1 => 'Alsózsolca',
        2 => 'Arló',
        3 => 'Arnót',
        4 => 'Aszaló',
        5 => 'Bekecs',
        6 => 'Bogács',
        7 => 'Boldva',
        8 => 'Borsodnádasd',
        9 => 'Bőcs',
        10 => 'Cigánd',
        11 => 'Cigándi Járás',
        12 => 'Edelény',
        13 => 'Edelényi Járás',
        14 => 'Emőd',
        15 => 'Encs',
        16 => 'Encsi Járás',
        17 => 'Farkaslyuk',
        18 => 'Felsőzsolca',
        19 => 'Gesztely',
        20 => 'Gönc',
        21 => 'Gönci Járás',
        22 => 'Halmaj',
        23 => 'Harsány',
        24 => 'Hejőbába',
        25 => 'Hernádnémeti',
        26 => 'Izsófalva',
        27 => 'Járdánháza',
        28 => 'Karcsa',
        29 => 'Kazincbarcika',
        30 => 'Kazincbarcikai Járás',
        31 => 'Megyaszó',
        32 => 'Mezőcsát',
        33 => 'Mezőcsáti Járás',
        34 => 'Mezőkeresztes',
        35 => 'Mezőkövesd',
        36 => 'Mezőkövesdi Járás',
        37 => 'Mezőzombor',
        38 => 'Miskolc',
        39 => 'Miskolci Járás',
        40 => 'Monok',
        41 => 'Mád',
        42 => 'Mályi',
        43 => 'Múcsony',
        44 => 'Nyékládháza',
        45 => 'Olaszliszka',
        46 => 'Onga',
        47 => 'Prügy',
        48 => 'Putnok',
        49 => 'Putnoki Járás',
        50 => 'Ricse',
        51 => 'Rudabánya',
        52 => 'Sajóbábony',
        53 => 'Sajókaza',
        54 => 'Sajólád',
        55 => 'Sajószentpéter',
        56 => 'Sajószöged',
        57 => 'Sajóvámos',
        58 => 'Sajóörös',
        59 => 'Szendrő',
        60 => 'Szentistván',
        61 => 'Szerencs',
        62 => 'Szerencsi Járás',
        63 => 'Szikszó',
        64 => 'Szikszói Járás',
        65 => 'Szirmabesenyő',
        66 => 'Sály',
        67 => 'Sárospatak',
        68 => 'Sárospataki Járás',
        69 => 'Sátoraljaújhely',
        70 => 'Sátoraljaújhelyi Járás',
        71 => 'Taktaharkány',
        72 => 'Taktaszada',
        73 => 'Tarcal',
        74 => 'Tiszakarád',
        75 => 'Tiszakeszi',
        76 => 'Tiszalúc',
        77 => 'Tiszaújváros',
        78 => 'Tiszaújvárosi Járás',
        79 => 'Tokaj',
        80 => 'Tokaji Járás',
        81 => 'Tolcsva',
        82 => 'Tállya',
        83 => 'Ónod',
        84 => 'Ózd',
        85 => 'Ózdi Járás',
      ),
    ),
    'PE' => 
    array (
      'name' => 'Pest County',
      'cities' => 
      array (
        0 => 'Abony',
        1 => 'Acsa',
        2 => 'Albertirsa',
        3 => 'Alsónémedi',
        4 => 'Aszód',
        5 => 'Aszódi Járás',
        6 => 'Bag',
        7 => 'Biatorbágy',
        8 => 'Budakalász',
        9 => 'Budakeszi',
        10 => 'Budakeszi Járás',
        11 => 'Budaörs',
        12 => 'Bugyi',
        13 => 'Cegléd',
        14 => 'Ceglédbercel',
        15 => 'Ceglédi Járás',
        16 => 'Csemő',
        17 => 'Csobánka',
        18 => 'Csömör',
        19 => 'Dabas',
        20 => 'Dabasi Járás',
        21 => 'Diósd',
        22 => 'Domony',
        23 => 'Dunabogdány',
        24 => 'Dunaharaszti',
        25 => 'Dunakeszi',
        26 => 'Dunakeszi Járás',
        27 => 'Dunavarsány',
        28 => 'Dánszentmiklós',
        29 => 'Dány',
        30 => 'Délegyháza',
        31 => 'Dömsöd',
        32 => 'Ecser',
        33 => 'Erdőkertes',
        34 => 'Farmos',
        35 => 'Felsőpakony',
        36 => 'Forrópuszta',
        37 => 'Fót',
        38 => 'Galgahévíz',
        39 => 'Galgamácsa',
        40 => 'Gomba',
        41 => 'Gyál',
        42 => 'Gyáli Járás',
        43 => 'Gyömrő',
        44 => 'Göd',
        45 => 'Gödöllő',
        46 => 'Gödöllői Járás',
        47 => 'Halásztelek',
        48 => 'Hernád',
        49 => 'Hévízgyörk',
        50 => 'Iklad',
        51 => 'Inárcs',
        52 => 'Isaszeg',
        53 => 'Jászkarajenő',
        54 => 'Kakucs',
        55 => 'Kartal',
        56 => 'Kerepes',
        57 => 'Kiskunlacháza',
        58 => 'Kismaros',
        59 => 'Kistarcsa',
        60 => 'Kocsér',
        61 => 'Kosd',
        62 => 'Kóka',
        63 => 'Leányfalu',
        64 => 'Maglód',
        65 => 'Mende',
        66 => 'Mogyoród',
        67 => 'Monor',
        68 => 'Monori Járás',
        69 => 'Nagykovácsi',
        70 => 'Nagykáta',
        71 => 'Nagykátai Járás',
        72 => 'Nagykőrös',
        73 => 'Nagykőrösi Járás',
        74 => 'Nagymaros',
        75 => 'Nagytarcsa',
        76 => 'Nyáregyháza',
        77 => 'Perbál',
        78 => 'Pilis',
        79 => 'Pilisborosjenő',
        80 => 'Piliscsaba',
        81 => 'Pilisszentiván',
        82 => 'Pilisszentkereszt',
        83 => 'Pilisszántó',
        84 => 'Pilisvörösvár',
        85 => 'Pilisvörösvári Járás',
        86 => 'Pomáz',
        87 => 'Pánd',
        88 => 'Páty',
        89 => 'Pécel',
        90 => 'Péteri',
        91 => 'Ráckeve',
        92 => 'Ráckevei Járás',
        93 => 'Solymár',
        94 => 'Szada',
        95 => 'Szentendre',
        96 => 'Szentendrei Járás',
        97 => 'Szentlőrinckáta',
        98 => 'Szentmártonkáta',
        99 => 'Szigetcsép',
        100 => 'Szigethalom',
        101 => 'Szigetszentmiklós',
        102 => 'Szigetszentmiklósi Járás',
        103 => 'Szigetújfalu',
        104 => 'Szob',
        105 => 'Szobi Járás',
        106 => 'Százhalombatta',
        107 => 'Sződ',
        108 => 'Sződliget',
        109 => 'Sóskút',
        110 => 'Sülysáp',
        111 => 'Tahitótfalu',
        112 => 'Taksony',
        113 => 'Telki',
        114 => 'Tura',
        115 => 'Táborfalva',
        116 => 'Tápióbicske',
        117 => 'Tápiógyörgye',
        118 => 'Tápiószecső',
        119 => 'Tápiószele',
        120 => 'Tápiószentmárton',
        121 => 'Tápiószőlős',
        122 => 'Tápióság',
        123 => 'Tárnok',
        124 => 'Tóalmás',
        125 => 'Tököl',
        126 => 'Törtel',
        127 => 'Törökbálint',
        128 => 'Valkó',
        129 => 'Vecsés',
        130 => 'Vecsési Járás',
        131 => 'Veresegyház',
        132 => 'Verőce',
        133 => 'Visegrád',
        134 => 'Vác',
        135 => 'Váci Járás',
        136 => 'Vácszentlászló',
        137 => 'Zsámbok',
        138 => 'Zsámbék',
        139 => 'Érd',
        140 => 'Érdi Járás',
        141 => 'Ócsa',
        142 => 'Örkény',
        143 => 'Újhartyán',
        144 => 'Újszilvás',
        145 => 'Úri',
        146 => 'Üllő',
        147 => 'Üröm',
        148 => 'Őrbottyán',
      ),
    ),
    'BE' => 
    array (
      'name' => 'Békés County',
      'cities' => 
      array (
        0 => 'Battonya',
        1 => 'Bucsa',
        2 => 'Békés',
        3 => 'Békéscsaba',
        4 => 'Békéscsabai Járás',
        5 => 'Békési Járás',
        6 => 'Békésszentandrás',
        7 => 'Békéssámson',
        8 => 'Csanádapáca',
        9 => 'Csorvás',
        10 => 'Doboz',
        11 => 'Dombegyház',
        12 => 'Dévaványa',
        13 => 'Elek',
        14 => 'Füzesgyarmat',
        15 => 'Gyomaendrőd',
        16 => 'Gyomaendrődi Járás',
        17 => 'Gyula',
        18 => 'Gyulai Járás',
        19 => 'Gádoros',
        20 => 'Kaszaper',
        21 => 'Kevermes',
        22 => 'Kondoros',
        23 => 'Kunágota',
        24 => 'Kétegyháza',
        25 => 'Körösladány',
        26 => 'Köröstarcsa',
        27 => 'Lőkösháza',
        28 => 'Magyarbánhegyes',
        29 => 'Medgyesegyháza',
        30 => 'Mezőberény',
        31 => 'Mezőhegyes',
        32 => 'Mezőkovácsháza',
        33 => 'Mezőkovácsházai Járás',
        34 => 'Méhkerék',
        35 => 'Nagyszénás',
        36 => 'Okány',
        37 => 'Orosháza',
        38 => 'Orosházi Járás',
        39 => 'Pusztaföldvár',
        40 => 'Sarkad',
        41 => 'Sarkadi Járás',
        42 => 'Szabadkígyós',
        43 => 'Szarvas',
        44 => 'Szarvasi Járás',
        45 => 'Szeghalmi Járás',
        46 => 'Szeghalom',
        47 => 'Tótkomlós',
        48 => 'Vésztő',
        49 => 'Újkígyós',
      ),
    ),
    'HB' => 
    array (
      'name' => 'Hajdú-Bihar County',
      'cities' => 
      array (
        0 => 'Bagamér',
        1 => 'Balmazújváros',
        2 => 'Balmazújvárosi Járás',
        3 => 'Berettyóújfalu',
        4 => 'Berettyóújfalui Járás',
        5 => 'Biharkeresztes',
        6 => 'Biharnagybajom',
        7 => 'Báránd',
        8 => 'Csökmő',
        9 => 'Debrecen',
        10 => 'Debreceni Járás',
        11 => 'Derecske',
        12 => 'Derecskei Járás',
        13 => 'Ebes',
        14 => 'Egyek',
        15 => 'Földes',
        16 => 'Görbeháza',
        17 => 'Hadjúszoboszlói Járás',
        18 => 'Hajdúbagos',
        19 => 'Hajdúböszörmény',
        20 => 'Hajdúböszörményi Járás',
        21 => 'Hajdúdorog',
        22 => 'Hajdúhadház',
        23 => 'Hajdúhadházi Járás',
        24 => 'Hajdúnánás',
        25 => 'Hajdúnánási Járás',
        26 => 'Hajdúszoboszló',
        27 => 'Hajdúszovát',
        28 => 'Hajdúsámson',
        29 => 'Hortobágy',
        30 => 'Hosszúpályi',
        31 => 'Kaba',
        32 => 'Komádi',
        33 => 'Konyár',
        34 => 'Létavértes',
        35 => 'Mikepércs',
        36 => 'Monostorpályi',
        37 => 'Nagyrábé',
        38 => 'Nyíracsád',
        39 => 'Nyíradony',
        40 => 'Nyíradonyi Járás',
        41 => 'Nyírmártonfalva',
        42 => 'Nyírábrány',
        43 => 'Nádudvar',
        44 => 'Pocsaj',
        45 => 'Polgár',
        46 => 'Püspökladány',
        47 => 'Püspökladányi Járás',
        48 => 'Sárrétudvari',
        49 => 'Sáránd',
        50 => 'Tiszacsege',
        51 => 'Téglás',
        52 => 'Vámospércs',
      ),
    ),
    'BU' => 
    array (
      'name' => 'Budapest',
      'cities' => 
      array (
        0 => 'Budapest',
        1 => 'Budapest I. kerület',
        2 => 'Budapest II. kerület',
        3 => 'Budapest III. kerület',
        4 => 'Budapest IV. kerület',
        5 => 'Budapest VI. kerület',
        6 => 'Budapest VIII. kerület',
        7 => 'Budapest X. kerület',
        8 => 'Budapest XI. kerület',
        9 => 'Budapest XII. kerület',
        10 => 'Budapest XIII. kerület',
        11 => 'Budapest XV. kerület',
        12 => 'Budapest XVI. kerület',
        13 => 'Budapest XVII. kerület',
        14 => 'Budapest XVIII. kerület',
        15 => 'Budapest XX. kerület',
        16 => 'Budapest XXI. kerület',
        17 => 'Budapest XXII. kerület',
        18 => 'Budapest XXIII. kerület',
        19 => 'Erzsébetváros',
        20 => 'Józsefváros',
        21 => 'Kispest',
        22 => 'Zugló',
      ),
    ),
  ),
  'IE' => 
  array (
    'L' => 
    array (
      'name' => 'Leinster',
      'cities' => 
      array (
        0 => 'Abbeyleix',
        1 => 'An Iarmhí',
        2 => 'An Longfort',
        3 => 'An Mhí',
        4 => 'An Muileann gCearr',
        5 => 'An Ros',
        6 => 'Ardee',
        7 => 'Arklow',
        8 => 'Artane',
        9 => 'Ashbourne',
        10 => 'Ashford',
        11 => 'Athboy',
        12 => 'Athgarvan',
        13 => 'Athlone',
        14 => 'Athy',
        15 => 'Aughrim',
        16 => 'Bagenalstown',
        17 => 'Balally',
        18 => 'Balbriggan',
        19 => 'Baldoyle',
        20 => 'Ballinroad',
        21 => 'Ballinteer',
        22 => 'Ballivor',
        23 => 'Ballyboden',
        24 => 'Ballyfermot',
        25 => 'Ballygerry',
        26 => 'Ballylinan',
        27 => 'Ballymahon',
        28 => 'Ballymun',
        29 => 'Ballyragget',
        30 => 'Balrothery',
        31 => 'Baltinglass',
        32 => 'Banagher',
        33 => 'Bayside',
        34 => 'Beaumont',
        35 => 'Birr',
        36 => 'Blackrock',
        37 => 'Blanchardstown',
        38 => 'Blessington',
        39 => 'Bonnybrook',
        40 => 'Booterstown',
        41 => 'Bray',
        42 => 'Bunclody',
        43 => 'Cabinteely',
        44 => 'Cabra',
        45 => 'Callan',
        46 => 'Carlingford',
        47 => 'Carlow',
        48 => 'Carnew',
        49 => 'Castlebellingham',
        50 => 'Castlebridge',
        51 => 'Castlecomer',
        52 => 'Castledermot',
        53 => 'Castleknock',
        54 => 'Castlepollard',
        55 => 'Castletown',
        56 => 'Celbridge',
        57 => 'Chapelizod',
        58 => 'Charlesland',
        59 => 'Cherry Orchard',
        60 => 'Cherryville',
        61 => 'Clane',
        62 => 'Clara',
        63 => 'Clogherhead',
        64 => 'Clondalkin',
        65 => 'Clonskeagh',
        66 => 'Confey',
        67 => 'Coolock',
        68 => 'County Carlow',
        69 => 'Courtown',
        70 => 'Crumlin',
        71 => 'Daingean',
        72 => 'Dalkey',
        73 => 'Darndale',
        74 => 'Derrinturn',
        75 => 'Dollymount',
        76 => 'Donabate',
        77 => 'Donaghmede',
        78 => 'Donnybrook',
        79 => 'Donnycarney',
        80 => 'Drogheda',
        81 => 'Droichead Nua',
        82 => 'Dromiskin',
        83 => 'Drumcondra',
        84 => 'Dublin',
        85 => 'Dublin City',
        86 => 'Duleek',
        87 => 'Dunboyne',
        88 => 'Dundalk',
        89 => 'Dundrum',
        90 => 'Dunleer',
        91 => 'Dunshaughlin',
        92 => 'Dún Laoghaire',
        93 => 'Dún Laoghaire-Rathdown',
        94 => 'Eadestown',
        95 => 'Edenderry',
        96 => 'Edgeworthstown',
        97 => 'Enfield',
        98 => 'Enniscorthy',
        99 => 'Enniskerry',
        100 => 'Fairview',
        101 => 'Ferbane',
        102 => 'Ferns',
        103 => 'Fingal County',
        104 => 'Finglas',
        105 => 'Firhouse',
        106 => 'Foxrock',
        107 => 'Glasnevin',
        108 => 'Gorey',
        109 => 'Graiguenamanagh',
        110 => 'Granard',
        111 => 'Greenhills',
        112 => 'Greystones',
        113 => 'Hartstown',
        114 => 'Howth',
        115 => 'Jobstown',
        116 => 'Johnstown',
        117 => 'Kells',
        118 => 'Kentstown',
        119 => 'Kilbeggan',
        120 => 'Kilcock',
        121 => 'Kilcoole',
        122 => 'Kilcullen',
        123 => 'Kildare',
        124 => 'Kilkenny',
        125 => 'Kill',
        126 => 'Killester',
        127 => 'Kilmacanoge',
        128 => 'Kilpedder',
        129 => 'Kilquade',
        130 => 'Kinnegad',
        131 => 'Kinsealy-Drinan',
        132 => 'Knocklyon',
        133 => 'Lanesborough',
        134 => 'Laois',
        135 => 'Laytown',
        136 => 'Leixlip',
        137 => 'Little Bray',
        138 => 'Loch Garman',
        139 => 'Longford',
        140 => 'Longwood',
        141 => 'Loughlinstown',
        142 => 'Lucan',
        143 => 'Lusk',
        144 => 'Lú',
        145 => 'Malahide',
        146 => 'Marino',
        147 => 'Maynooth',
        148 => 'Milltown',
        149 => 'Moate',
        150 => 'Monasterevin',
        151 => 'Monkstown',
        152 => 'Mooncoin',
        153 => 'Moone',
        154 => 'Mount Merrion',
        155 => 'Mountmellick',
        156 => 'Mountrath',
        157 => 'Naas',
        158 => 'Navan',
        159 => 'New Ross',
        160 => 'Newcastle',
        161 => 'Newtown Trim',
        162 => 'Newtownmountkennedy',
        163 => 'Old Kilcullen',
        164 => 'Oldbawn',
        165 => 'Oldcastle',
        166 => 'Palmerstown',
        167 => 'Piltown',
        168 => 'Portarlington',
        169 => 'Portlaoise',
        170 => 'Portmarnock',
        171 => 'Portraine',
        172 => 'Prosperous',
        173 => 'Raheny',
        174 => 'Rathangan',
        175 => 'Rathcoole',
        176 => 'Rathdowney',
        177 => 'Rathdrum',
        178 => 'Rathgar',
        179 => 'Rathmines',
        180 => 'Rathnew',
        181 => 'Rathwire',
        182 => 'Ratoath',
        183 => 'Rialto',
        184 => 'Ringsend',
        185 => 'Rochfortbridge',
        186 => 'Rosslare',
        187 => 'Saggart',
        188 => 'Sallins',
        189 => 'Sallynoggin',
        190 => 'Sandyford',
        191 => 'Sandymount',
        192 => 'Shankill',
        193 => 'Skerries',
        194 => 'Slane',
        195 => 'South Dublin',
        196 => 'Stamullin',
        197 => 'Stradbally',
        198 => 'Sutton',
        199 => 'Swords',
        200 => 'Tallaght',
        201 => 'Templeogue',
        202 => 'Terenure',
        203 => 'Termonfeckin',
        204 => 'Thomastown',
        205 => 'Trim',
        206 => 'Tullamore',
        207 => 'Tullow',
        208 => 'Tullyallen',
        209 => 'Uíbh Fhailí',
        210 => 'Valleymount',
        211 => 'Wicklow',
      ),
    ),
    'M' => 
    array (
      'name' => 'Munster',
      'cities' => 
      array (
        0 => 'Abbeyfeale',
        1 => 'Adare',
        2 => 'Aghada',
        3 => 'An Clár',
        4 => 'Annacotty',
        5 => 'Ardnacrusha',
        6 => 'Askeaton',
        7 => 'Ballina',
        8 => 'Ballybunnion',
        9 => 'Bandon',
        10 => 'Bantry',
        11 => 'Blarney',
        12 => 'Caherconlish',
        13 => 'Cahersiveen',
        14 => 'Cahir',
        15 => 'Carrick-on-Suir',
        16 => 'Carrigaline',
        17 => 'Carrigtwohill',
        18 => 'Cashel',
        19 => 'Castleconnell',
        20 => 'Castleisland',
        21 => 'Castlemartyr',
        22 => 'Ciarraí',
        23 => 'Cill Airne',
        24 => 'Clonakilty',
        25 => 'Cloyne',
        26 => 'Cluain Meala',
        27 => 'Cobh',
        28 => 'Cork',
        29 => 'Cork City',
        30 => 'County Cork',
        31 => 'County Tipperary',
        32 => 'Croom',
        33 => 'Crosshaven',
        34 => 'Derry',
        35 => 'Dingle',
        36 => 'Dungarvan',
        37 => 'Dunmanway',
        38 => 'Dunmore East',
        39 => 'Ennis',
        40 => 'Fermoy',
        41 => 'Fethard',
        42 => 'Kanturk',
        43 => 'Kenmare',
        44 => 'Killaloe',
        45 => 'Killorglin',
        46 => 'Killumney',
        47 => 'Kilmallock',
        48 => 'Kilrush',
        49 => 'Kinsale',
        50 => 'Listowel',
        51 => 'Luimneach',
        52 => 'Macroom',
        53 => 'Mallow',
        54 => 'Midleton',
        55 => 'Millstreet',
        56 => 'Mitchelstown',
        57 => 'Moroe',
        58 => 'Moyross',
        59 => 'Nenagh',
        60 => 'Nenagh Bridge',
        61 => 'Newcastle West',
        62 => 'Newmarket on Fergus',
        63 => 'Newport',
        64 => 'Passage West',
        65 => 'Portlaw',
        66 => 'Rathcormac',
        67 => 'Rathkeale',
        68 => 'Roscrea',
        69 => 'Ráth Luirc',
        70 => 'Shannon',
        71 => 'Sixmilebridge',
        72 => 'Skibbereen',
        73 => 'Templemore',
        74 => 'Thurles',
        75 => 'Tipperary',
        76 => 'Tower',
        77 => 'Tralee',
        78 => 'Trá Mhór',
        79 => 'Waterford',
        80 => 'Watergrasshill',
        81 => 'Whitegate',
        82 => 'Youghal',
      ),
    ),
    'U' => 
    array (
      'name' => 'Ulster',
      'cities' => 
      array (
        0 => 'An Cabhán',
        1 => 'Bailieborough',
        2 => 'Ballybofey',
        3 => 'Ballyconnell',
        4 => 'Ballyjamesduff',
        5 => 'Ballyshannon',
        6 => 'Belturbet',
        7 => 'Buncrana',
        8 => 'Bundoran',
        9 => 'Carndonagh',
        10 => 'Carrickmacross',
        11 => 'Castleblayney',
        12 => 'Cavan',
        13 => 'Clones',
        14 => 'Convoy',
        15 => 'Cootehill',
        16 => 'County Donegal',
        17 => 'County Monaghan',
        18 => 'Derrybeg',
        19 => 'Donegal',
        20 => 'Dungloe',
        21 => 'Dunlewy',
        22 => 'Gweedore',
        23 => 'Killybegs',
        24 => 'Kingscourt',
        25 => 'Leifear',
        26 => 'Letterkenny',
        27 => 'Monaghan',
        28 => 'Moville',
        29 => 'Muff',
        30 => 'Mullagh',
        31 => 'Newtown Cunningham',
        32 => 'Ramelton',
        33 => 'Raphoe',
        34 => 'Virginia',
      ),
    ),
    'C' => 
    array (
      'name' => 'Connacht',
      'cities' => 
      array (
        0 => 'Athenry',
        1 => 'Ballaghaderreen',
        2 => 'Ballina',
        3 => 'Ballinasloe',
        4 => 'Ballinrobe',
        5 => 'Ballisodare',
        6 => 'Ballyhaunis',
        7 => 'Ballymote',
        8 => 'Bearna',
        9 => 'Belmullet',
        10 => 'Boyle',
        11 => 'Carrick-on-Shannon',
        12 => 'Castlebar',
        13 => 'Castlerea',
        14 => 'Claregalway',
        15 => 'Claremorris',
        16 => 'Clifden',
        17 => 'Collooney',
        18 => 'County Galway',
        19 => 'County Leitrim',
        20 => 'Crossmolina',
        21 => 'Foxford',
        22 => 'Gaillimh',
        23 => 'Galway City',
        24 => 'Gort',
        25 => 'Inishcrone',
        26 => 'Kiltamagh',
        27 => 'Kinlough',
        28 => 'Loughrea',
        29 => 'Manorhamilton',
        30 => 'Mayo County',
        31 => 'Moycullen',
        32 => 'Oranmore',
        33 => 'Oughterard',
        34 => 'Portumna',
        35 => 'Roscommon',
        36 => 'Sligo',
        37 => 'Strandhill',
        38 => 'Swinford',
        39 => 'Tobercurry',
        40 => 'Tuam',
        41 => 'Westport',
      ),
    ),
  ),
  'DZ' => 
  array (
    '02' => 
    array (
      'name' => 'Chlef Province',
      'cities' => 
      array (
        0 => 'Abou el Hassan',
        1 => 'Boukadir',
        2 => 'Chlef',
        3 => 'Ech Chettia',
        4 => 'Oued Fodda',
        5 => 'Oued Sly',
        6 => 'Sidi Akkacha',
      ),
    ),
    '08' => 
    array (
      'name' => 'Béchar Province',
      'cities' => 
      array (
        0 => 'Béchar',
      ),
    ),
    '09' => 
    array (
      'name' => 'Blida Province',
      'cities' => 
      array (
        0 => 'Beni Mered',
        1 => 'Blida',
        2 => 'Boufarik',
        3 => 'Bougara',
        4 => 'Bouinan',
        5 => 'Boû Arfa',
        6 => 'Chebli',
        7 => 'Chiffa',
        8 => 'Larbaâ',
        9 => 'Meftah',
        10 => 'Sidi Moussa',
        11 => 'Souma',
      ),
    ),
    '07' => 
    array (
      'name' => 'Biskra',
      'cities' => 
      array (
        0 => 'Biskra',
        1 => 'Oumache',
        2 => 'Sidi Khaled',
        3 => 'Sidi Okba',
        4 => 'Tolga',
        5 => 'Zeribet el Oued',
      ),
    ),
    '01' => 
    array (
      'name' => 'Adrar Province',
      'cities' => 
      array (
        0 => 'Adrar',
        1 => 'Aoulef',
        2 => 'Reggane',
        3 => 'Timimoun',
      ),
    ),
    '06' => 
    array (
      'name' => 'Béjaïa Province',
      'cities' => 
      array (
        0 => 'Akbou',
        1 => 'Amizour',
        2 => 'Barbacha',
        3 => 'Bejaïa',
        4 => 'El Kseur',
        5 => 'Feraoun',
        6 => 'Seddouk',
        7 => 'el hed',
      ),
    ),
    '04' => 
    array (
      'name' => 'Oum El Bouaghi Province',
      'cities' => 
      array (
        0 => 'Aïn Beïda',
        1 => 'Aïn Fakroun',
        2 => 'Aïn Kercha',
        3 => 'El Aouinet',
        4 => 'Meskiana',
        5 => 'Oum el Bouaghi',
      ),
    ),
    '03' => 
    array (
      'name' => 'Laghouat Province',
      'cities' => 
      array (
        0 => 'Aflou',
        1 => 'Laghouat',
      ),
    ),
    '05' => 
    array (
      'name' => 'Batna Province',
      'cities' => 
      array (
        0 => 'Arris',
        1 => 'Aïn Touta',
        2 => 'Barika',
        3 => 'Batna',
        4 => 'Boumagueur',
        5 => 'Merouana',
        6 => 'Râs el Aïoun',
        7 => 'Tazoult-Lambese',
      ),
    ),
  ),
);