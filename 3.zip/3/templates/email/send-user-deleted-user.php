<?php
/**
 * Template for the "User Deleted Email".
 * 
 * Whether to send the user an email when a user is deleted.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-deleted-user.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: User's display name.*/
		__( 'Hello %s,', 'describr' ),
		$args['user']->display_name
		)) . "\r\n\r\n"?>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		###HTMLDELETE_ACCOUNT_NOTICE:
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post( $this->make_clickable(sprintf(
			/*translators: %s: Registration URL.*/
			__( 'Your account has been deleted. If you did not intend to delete your account and wish to sign up again, you may do so <a href="%s">here</a>.', 'describr' ), 
			$args['url'] ),  $slug, $args ) );
		?></p>
	    ###HTMLDELETE_ACCOUNT_NOTICE
	    ###TEXTDELETE_ACCOUNT_NOTICE:
	    <?php
	    echo esc_html( sprintf(
	    	/*translators: %s: Registration URL.*/
	    	__( 'Your account has been deleted. If you did not intend to delete your account and wish to sign up again, you may do so by visiting the following address: %s.', 'describr' ),
	    	$args['url']
	    )) . "\r\n";
	    ?>
	    ###TEXTDELETE_ACCOUNT_NOTICE
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );



