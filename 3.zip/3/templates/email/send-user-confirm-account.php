<?php
/**
 * Template for the "Confirm Account Email".
 * 
 * Whether to send the user an email to confirm account.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-confirm-account.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Username.*/
		__( '<strong>Username:</strong> %s', 'describr' ),
		$args['user']->user_login
		)) . "\r\n\r\n"; ?>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		###HTMLCONFIRM_ACCOUNT:
		<div style="padding: 20px 0; margin: 0;"><?php echo wp_kses_post( $this->btn( $args['url'], _x( 'Confirm Account', 'user', 'describr' ), 'confirm_account' ) ); ?></div>
        ###HTMLCONFIRM_ACCOUNT
        ###TEXTCONFIRM_ACCOUNT:
        <?php
        echo esc_html(
            sprintf(
            	/*translators: %s: User's confirmation URL.*/
        	    _x( 'To confirm your account, visit the following address: %s.', 'user', 'describr' ),
        	    $args['url']
        	)) . "\r\n";
	    ?>
        ###TEXTCONFIRM_ACCOUNT
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );