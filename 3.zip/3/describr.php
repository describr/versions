<?php
/**
 * Plugin Name: Describr
 * Description: The best plugin to show user profiles on the front end.
 * Version: 3.0
 * Requires at least: 4.7
 * Requires PHP: 8.4.0
 * Author: profiletoggler
 * Author URI: https://facebook.com/plzr17/
 * Update URI: https://raw.githubusercontent.com/
 * Plugin URI:https://github.com/describr/versions/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: describr
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DESCRIBR', 'Describr' );
define( 'DESCRIBR_VERSION', '3.0' );
define( 'DESCRIBR_DIR', plugin_dir_path( __FILE__ ) );
define( 'DESCRIBR_URL', plugin_dir_url( __FILE__ ) );
define( 'DESCRIBR_FILE', plugin_basename( __FILE__ ) );
define( 'DESCRIBR_TEMPLATE', DESCRIBR_DIR . 'templates' . DIRECTORY_SEPARATOR );

require_once DESCRIBR_DIR . 'includes' . DIRECTORY_SEPARATOR . 'class-config.php';
require_once DESCRIBR_DIR . 'includes' . DIRECTORY_SEPARATOR . 'class-init.php';

