<?php
/**
 * An array of translated states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'PG' => 
  array (
    'WBK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'West New Britain Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kandrian', 'describr' ),
        1 => /*translators: City.*/ __( 'Kandrian Gloucester', 'describr' ),
        2 => /*translators: City.*/ __( 'Kimbe', 'describr' ),
        3 => /*translators: City.*/ __( 'Talasea', 'describr' ),
      ),
    ),
    'NSB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bougainville', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arawa', 'describr' ),
        1 => /*translators: City.*/ __( 'Central Bougainville', 'describr' ),
        2 => /*translators: City.*/ __( 'Kieta', 'describr' ),
        3 => /*translators: City.*/ __( 'North Bougainville', 'describr' ),
        4 => /*translators: City.*/ __( 'Panguna', 'describr' ),
        5 => /*translators: City.*/ __( 'South Bougainville', 'describr' ),
      ),
    ),
    'JWK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jiwaka Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Angalimp South Wahgi', 'describr' ),
        1 => /*translators: City.*/ __( 'Jimi', 'describr' ),
        2 => /*translators: City.*/ __( 'North Wahgi', 'describr' ),
      ),
    ),
    'HLA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hela', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Komo Margarima', 'describr' ),
        1 => /*translators: City.*/ __( 'Koroba-Lake Kopiago', 'describr' ),
        2 => /*translators: City.*/ __( 'Tari', 'describr' ),
        3 => /*translators: City.*/ __( 'Tari Pori', 'describr' ),
      ),
    ),
    'EBR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'East New Britain', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gazelle', 'describr' ),
        1 => /*translators: City.*/ __( 'Kokopo', 'describr' ),
        2 => /*translators: City.*/ __( 'Pomio', 'describr' ),
        3 => /*translators: City.*/ __( 'Rabaul', 'describr' ),
      ),
    ),
    'MPL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Morobe Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bulolo', 'describr' ),
        1 => /*translators: City.*/ __( 'Finschhafen', 'describr' ),
        2 => /*translators: City.*/ __( 'Huon Gulf', 'describr' ),
        3 => /*translators: City.*/ __( 'Kabwum', 'describr' ),
        4 => /*translators: City.*/ __( 'Lae', 'describr' ),
        5 => /*translators: City.*/ __( 'Markham', 'describr' ),
        6 => /*translators: City.*/ __( 'Menyamya', 'describr' ),
        7 => /*translators: City.*/ __( 'Nawae', 'describr' ),
        8 => /*translators: City.*/ __( 'Tewai Siassi', 'describr' ),
        9 => /*translators: City.*/ __( 'Wau', 'describr' ),
      ),
    ),
    'SAN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sandaun Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aitape', 'describr' ),
        1 => /*translators: City.*/ __( 'Aitape Lumi', 'describr' ),
        2 => /*translators: City.*/ __( 'Nuku', 'describr' ),
        3 => /*translators: City.*/ __( 'Telefomin', 'describr' ),
        4 => /*translators: City.*/ __( 'Vanimo', 'describr' ),
        5 => /*translators: City.*/ __( 'Vanimo Green', 'describr' ),
      ),
    ),
    'NCD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Port Moresby', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'National Capital District', 'describr' ),
        1 => /*translators: City.*/ __( 'Port Moresby', 'describr' ),
      ),
    ),
    'NPP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oro Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ijivitari', 'describr' ),
        1 => /*translators: City.*/ __( 'Kokoda', 'describr' ),
        2 => /*translators: City.*/ __( 'Popondetta', 'describr' ),
        3 => /*translators: City.*/ __( 'Sohe', 'describr' ),
      ),
    ),
    'GPK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gulf', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kerema', 'describr' ),
        1 => /*translators: City.*/ __( 'Kikori', 'describr' ),
      ),
    ),
    'WHM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Highlands Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baiyer Mul', 'describr' ),
        1 => /*translators: City.*/ __( 'Dei', 'describr' ),
        2 => /*translators: City.*/ __( 'Hagen', 'describr' ),
        3 => /*translators: City.*/ __( 'Mount Hagen', 'describr' ),
        4 => /*translators: City.*/ __( 'Tambul Nebilyer', 'describr' ),
      ),
    ),
    'NIK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'New Ireland Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kavieng', 'describr' ),
        1 => /*translators: City.*/ __( 'Namatanai', 'describr' ),
      ),
    ),
    'MRL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manus Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lorengau', 'describr' ),
        1 => /*translators: City.*/ __( 'Manus', 'describr' ),
      ),
    ),
    'MPM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Madang Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bogia', 'describr' ),
        1 => /*translators: City.*/ __( 'Madang', 'describr' ),
        2 => /*translators: City.*/ __( 'Middle Ramu', 'describr' ),
        3 => /*translators: City.*/ __( 'Rai Coast', 'describr' ),
        4 => /*translators: City.*/ __( 'Sumkar', 'describr' ),
        5 => /*translators: City.*/ __( 'Usino Bundi', 'describr' ),
      ),
    ),
    'SHM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Highlands Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ialibu', 'describr' ),
        1 => /*translators: City.*/ __( 'Ialibu Pangia', 'describr' ),
        2 => /*translators: City.*/ __( 'Imbonggu', 'describr' ),
        3 => /*translators: City.*/ __( 'Kagua Erave', 'describr' ),
        4 => /*translators: City.*/ __( 'Mendi', 'describr' ),
        5 => /*translators: City.*/ __( 'Nipa Kutubu', 'describr' ),
      ),
    ),
    'EHG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Highlands Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Daulo', 'describr' ),
        1 => /*translators: City.*/ __( 'Goroka', 'describr' ),
        2 => /*translators: City.*/ __( 'Henganofi', 'describr' ),
        3 => /*translators: City.*/ __( 'Kainantu', 'describr' ),
        4 => /*translators: City.*/ __( 'Lufa', 'describr' ),
        5 => /*translators: City.*/ __( 'Obura Wonenara', 'describr' ),
        6 => /*translators: City.*/ __( 'Okapa', 'describr' ),
        7 => /*translators: City.*/ __( 'Unggai Bena', 'describr' ),
      ),
    ),
    'CPK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chimbu Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chuave', 'describr' ),
        1 => /*translators: City.*/ __( 'Gumine', 'describr' ),
        2 => /*translators: City.*/ __( 'Karimui Nomane', 'describr' ),
        3 => /*translators: City.*/ __( 'Kerowagi', 'describr' ),
        4 => /*translators: City.*/ __( 'Kundiawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Sinasina Yonggamugl', 'describr' ),
      ),
    ),
    'CPM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abau', 'describr' ),
        1 => /*translators: City.*/ __( 'Goilala', 'describr' ),
        2 => /*translators: City.*/ __( 'Kairuku-Hiri', 'describr' ),
        3 => /*translators: City.*/ __( 'Rigo', 'describr' ),
      ),
    ),
    'EPW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Enga Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kandep', 'describr' ),
        1 => /*translators: City.*/ __( 'Kompiam Ambum', 'describr' ),
        2 => /*translators: City.*/ __( 'Lagaip Porgera', 'describr' ),
        3 => /*translators: City.*/ __( 'Porgera', 'describr' ),
        4 => /*translators: City.*/ __( 'Wabag', 'describr' ),
        5 => /*translators: City.*/ __( 'Wapenamanda', 'describr' ),
      ),
    ),
    'MBA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Milne Bay Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alotau', 'describr' ),
        1 => /*translators: City.*/ __( 'Esa&#039;ala', 'describr' ),
        2 => /*translators: City.*/ __( 'Kiriwina Goodenough', 'describr' ),
        3 => /*translators: City.*/ __( 'Samarai', 'describr' ),
        4 => /*translators: City.*/ __( 'Samarai Murua', 'describr' ),
      ),
    ),
    'WPD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Daru', 'describr' ),
        1 => /*translators: City.*/ __( 'Kiunga', 'describr' ),
        2 => /*translators: City.*/ __( 'Middle Fly', 'describr' ),
        3 => /*translators: City.*/ __( 'Morehead', 'describr' ),
        4 => /*translators: City.*/ __( 'North Fly', 'describr' ),
        5 => /*translators: City.*/ __( 'South Fly', 'describr' ),
      ),
    ),
  ),
);