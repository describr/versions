=== Describr - Membership, User Profile, Content Restriction & Role Editor Plugin ===
Contributors: profiletoggler
Tags: user profile, users, membership, member, user registration
Requires at least: 4.7
Tested up to: 6.8
Requires PHP: 8.4
Stable tag: 3.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Membership plugin including front-end user profiles, user registration, content restriction, user account restriction, user roles, and more.

== Description == 

Describr is the best user profile and membership plugin for WordPress. Describr makes it easy to create beautiful user profiles on the front end. Describr makes it easy for users to manage their profiles and accounts on the front end. Describr is extensible and makes it easy for you to create websites where users can become members. 

Major features in Describr include:

* Front-end user profiles.
* User account on the front end.
* Content restriction.
* User account restriction.
* Password field can be added to WordPress registration form (single site only).
* Password complexity.
* Conditional profile fields.
* Conditional nav menus.
* Make user an important person.
* Custom capabilities. 
* Delete user from the front end.
* Show author posts & comments on user profiles.
* Extensible with many filters and actions.
* Multisite support.
* Fully translatable.

== Installation ==

Upload the Describr plugin to your blog and activate it.

...You're done!

= Plugin Support =

Like This Plugin? You can show your support by [rating the plugin](https://wordpress.org/support/plugin/describr/reviews/?filter=5#new-post).

== Links to Noncompressed Source Code for JavaScript Files ==

1. [jquery-ui](https://github.com/jquery/jquery-ui)
2. [libphonenumber-js](https://github.com/catamphetamine/libphonenumber-js) 

== Changelog ==

= 3.0.1 =
*Release Date - 15 October 2025*

###Changed

* User is valid if no status exists.
* Replaced single quotes with double quotes in JavaScript files.
* Changed the name of the JavaScript property to delete the profile picture from "delete" to "deletePicture".
* Changed the name of the JavaScript property to assign the profile picture from "assign" to "assignPicture".
* Removed the `describr.events` method in `assets/js/main.js`.
* Checked if the post exists when retrieving the attachment ID for a profile photo in `includes/class-avatar.php`.
* Restored the current blog before any returning in `includes/class-upload-photo.php`.
* Uncommented `describr_messages_keys` user meta in `includes/class-user.php` so that users can reply to messages.

###Added

* Front-end profile photo is audited if it is deleted by a user.
* Function `describr_avatar_rating` to retrieve the avatar's rating.
* Function `describr_print_profile_picture_rating_modal` to print profile picture rating modal.
* `Popper.js` to display popups in the admin interface.
* The ability to rate avatar on the front end.
* Additional placeholders in email templates.


