<?php
/**
 * Template for the "Pending Review Email".
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-review-pending.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var array $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(sprintf(
            /*translators: 1: Site's title. 2: Email address.*/
            __( 'Thanks for signing up to %1$s. Your membership is awaiting review. We will notify you at %2$s as soon as a decision is made.', 'describr' ),
            "<strong>{$args['blogname']}</strong>",
            "<strong>{$args['user']->user_email}</strong>"
        )) . "\r\n\r\n";
	    ?>
    </td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="padding: 0; margin: 1em 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Username.*/
		__( '<strong>Username:</strong> %s', 'describr' ),
		$args['user']->user_login
		)) . "\r\n"; ?>
	    </p>
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );