=== Describr - Membership, User Profile, Content Restriction & Role Editor Plugin ===
Contributors: profiletoggler
Tags: community, membership, member, user-profile, user-registration
Requires at least: 4.7
Tested up to: 6.9
Requires PHP: 8.4
Stable tag: 3.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The best membership plugin including front-end user profiles, user registration, content restriction, user roles, and more.

== Description == 

Describr is the best membership and user profile plugin for WordPress. Describr makes it easy to create beautiful user profiles on the front end. Describr is extensible and makes it easy for you to create websites where users can become members. Describr gives you powerful tools to add capabilities to roles and restrict content.

Major features in Describr include:

* Add password to registration form.
* Delete user from the front end.
* Show author posts & comments on user profiles.
* Extensible with many filters and actions.

== Installation ==

Upload the Describr plugin to your blog and activate it.

...You're done!

== Frequently Asked Questions ==

### Is Describr 100% free?

Yes. There are no fees to use any feature offered by Describr.

### Do you need coding skills to use Describr?

No. You do not need coding skills to use Describr. All features are accessible and can be managed in the browser.

### Can Describr delete a role?

Yes. Describr can delete all roles except WordPress' defined roles, which are **Administrator**, **Editor**, **Author**, **Contributor**, and **Subscriber**.

### Can Describr delete capabilities from any role?

Yes. Describr deletes capabilities from any role. However, The **Administrator** role must have at least one capability. 

### Is Describr mobile responsive?

Yes. Describr is designed to adapt nicely to any screen resolution. It includes specific designs for phones, tablets, and desktops.

### Is Describr multisite compatible?

Yes. Describr works great on both single site and multisite WordPress installations.

### Does Describr work with any WordPress theme?

Yes. Describr will work with any properly coded theme. However, some themes may cause conflicts with the plugin. If you find a styling issue with your theme please create a post in the community forum.

### Why the User and Account pages show on the Administration panel's Pages Screen but not on the front end?

This could occur if the rewrite rules are not flushed after the pages are created. To flush the rewrite rules, go to settings>permalinks, scroll to the bottom, and click the **Save Changes** button.

### Is special permission needed to edit Describr settings?

Yes. Users must have the **manage_options** capability to access and edit Describr settings.

== Links to Noncompressed Source Code for JavaScript Files ==

1. [jquery-ui](https://github.com/jquery/jquery-ui)
2. [libphonenumber-js](https://github.com/catamphetamine/libphonenumber-js) 

== Changelog ==

= 3.0.2 =
*Release Date - 2 December 2025*

###Changed

* Cities suggested to users as they type are no longer translatable.
* Bumped "Tested up to" to 6.9

= 3.0.1 =
*Release Date - 15 October 2025*

###Changed

* User is valid if no status exists.
* Replaced single quotes with double quotes in JavaScript files.
* Changed the name of the JavaScript property to delete the profile picture from "delete" to "deletePicture".
* Changed the name of the JavaScript property to assign the profile picture from "assign" to "assignPicture".
* Removed the `describr.events` method in `assets/js/main.js`.
* Checked if the post exists when retrieving the attachment ID for a profile photo in `includes/class-avatar.php`.
* Restored the current blog before any returning in `includes/class-upload-photo.php`.
* Uncommented `describr_messages_keys` user meta in `includes/class-user.php` so that users can reply to messages.

###Added

* Front-end profile photo is audited if it is deleted by a user.
* Function `describr_avatar_rating` to retrieve the avatar's rating.
* Function `describr_print_profile_picture_rating_modal` to print profile picture rating modal.
* `Popper.js` to display popups in the admin interface.
* The ability to rate avatar on the front end.
* Additional placeholders in email templates.


