<?php 
/**
 * An array of translated states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array (
  'ET' => 
  array (
    'SN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Nations, Nationalities, and Peoples&#039; Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alaba Special Wereda', 'describr' ),
        1 => /*translators: City.*/ __( 'Arba Minch', 'describr' ),
        2 => /*translators: City.*/ __( 'Bako', 'describr' ),
        3 => /*translators: City.*/ __( 'Bench Maji Zone', 'describr' ),
        4 => /*translators: City.*/ __( 'Bodītī', 'describr' ),
        5 => /*translators: City.*/ __( 'Bonga', 'describr' ),
        6 => /*translators: City.*/ __( 'Butajīra', 'describr' ),
        7 => /*translators: City.*/ __( 'Dīla', 'describr' ),
        8 => /*translators: City.*/ __( 'Felege Neway', 'describr' ),
        9 => /*translators: City.*/ __( 'Gedeo Zone', 'describr' ),
        10 => /*translators: City.*/ __( 'Guraghe Zone', 'describr' ),
        11 => /*translators: City.*/ __( 'Gīdolē', 'describr' ),
        12 => /*translators: City.*/ __( 'Hadiya Zone', 'describr' ),
        13 => /*translators: City.*/ __( 'Hawassa', 'describr' ),
        14 => /*translators: City.*/ __( 'Hosa&#039;ina', 'describr' ),
        15 => /*translators: City.*/ __( 'Hāgere Selam', 'describr' ),
        16 => /*translators: City.*/ __( 'Jinka', 'describr' ),
        17 => /*translators: City.*/ __( 'Kembata Alaba Tembaro Zone', 'describr' ),
        18 => /*translators: City.*/ __( 'Konso', 'describr' ),
        19 => /*translators: City.*/ __( 'K&#039;olīto', 'describr' ),
        20 => /*translators: City.*/ __( 'Leku', 'describr' ),
        21 => /*translators: City.*/ __( 'Lobuni', 'describr' ),
        22 => /*translators: City.*/ __( 'Mīzan Teferī', 'describr' ),
        23 => /*translators: City.*/ __( 'Sheka Zone', 'describr' ),
        24 => /*translators: City.*/ __( 'Sidama Zone', 'describr' ),
        25 => /*translators: City.*/ __( 'Sodo', 'describr' ),
        26 => /*translators: City.*/ __( 'Tippi', 'describr' ),
        27 => /*translators: City.*/ __( 'Turmi', 'describr' ),
        28 => /*translators: City.*/ __( 'Wendo', 'describr' ),
        29 => /*translators: City.*/ __( 'Wolayita Zone', 'describr' ),
        30 => /*translators: City.*/ __( 'Yem', 'describr' ),
        31 => /*translators: City.*/ __( 'Yirga &#039;Alem', 'describr' ),
        32 => /*translators: City.*/ __( 'Āreka', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Somali Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Afder Zone', 'describr' ),
        1 => /*translators: City.*/ __( 'Degehabur Zone', 'describr' ),
        2 => /*translators: City.*/ __( 'Gode Zone', 'describr' ),
        3 => /*translators: City.*/ __( 'Jijiga', 'describr' ),
        4 => /*translators: City.*/ __( 'Liben zone', 'describr' ),
        5 => /*translators: City.*/ __( 'Shinile Zone', 'describr' ),
      ),
    ),
    'AM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Amhara Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abomsa', 'describr' ),
        1 => /*translators: City.*/ __( 'Addiet Canna', 'describr' ),
        2 => /*translators: City.*/ __( 'Bahir Dar', 'describr' ),
        3 => /*translators: City.*/ __( 'Batī', 'describr' ),
        4 => /*translators: City.*/ __( 'Bichena', 'describr' ),
        5 => /*translators: City.*/ __( 'Burē', 'describr' ),
        6 => /*translators: City.*/ __( 'Dabat', 'describr' ),
        7 => /*translators: City.*/ __( 'Debark&#039;', 'describr' ),
        8 => /*translators: City.*/ __( 'Debre Birhan', 'describr' ),
        9 => /*translators: City.*/ __( 'Debre Mark&#039;os', 'describr' ),
        10 => /*translators: City.*/ __( 'Debre Sīna', 'describr' ),
        11 => /*translators: City.*/ __( 'Debre Tabor', 'describr' ),
        12 => /*translators: City.*/ __( 'Debre Werk&#039;', 'describr' ),
        13 => /*translators: City.*/ __( 'Dejen', 'describr' ),
        14 => /*translators: City.*/ __( 'Desē', 'describr' ),
        15 => /*translators: City.*/ __( 'Finote Selam', 'describr' ),
        16 => /*translators: City.*/ __( 'Gondar', 'describr' ),
        17 => /*translators: City.*/ __( 'Kemisē', 'describr' ),
        18 => /*translators: City.*/ __( 'Kombolcha', 'describr' ),
        19 => /*translators: City.*/ __( 'Lalībela', 'describr' ),
        20 => /*translators: City.*/ __( 'North Shewa Zone', 'describr' ),
        21 => /*translators: City.*/ __( 'North Wollo Zone', 'describr' ),
        22 => /*translators: City.*/ __( 'Robīt', 'describr' ),
        23 => /*translators: City.*/ __( 'South Gondar Zone', 'describr' ),
        24 => /*translators: City.*/ __( 'South Wollo Zone', 'describr' ),
        25 => /*translators: City.*/ __( 'Wag Hemra Zone', 'describr' ),
        26 => /*translators: City.*/ __( 'Were Īlu', 'describr' ),
        27 => /*translators: City.*/ __( 'Werota', 'describr' ),
        28 => /*translators: City.*/ __( 'Ādīs Zemen', 'describr' ),
      ),
    ),
    'TI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tigray Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Axum', 'describr' ),
        1 => /*translators: City.*/ __( 'Inda Silasē', 'describr' ),
        2 => /*translators: City.*/ __( 'Korem', 'describr' ),
        3 => /*translators: City.*/ __( 'Maych&#039;ew', 'describr' ),
        4 => /*translators: City.*/ __( 'Mek&#039;ele', 'describr' ),
        5 => /*translators: City.*/ __( 'Southeastern Tigray Zone', 'describr' ),
        6 => /*translators: City.*/ __( 'Southern Tigray Zone', 'describr' ),
        7 => /*translators: City.*/ __( 'Ādīgrat', 'describr' ),
      ),
    ),
    'OR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oromia Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arsi Zone', 'describr' ),
        1 => /*translators: City.*/ __( 'Bedelē', 'describr' ),
        2 => /*translators: City.*/ __( 'Bedēsa', 'describr' ),
        3 => /*translators: City.*/ __( 'Bishoftu', 'describr' ),
        4 => /*translators: City.*/ __( 'Deder', 'describr' ),
        5 => /*translators: City.*/ __( 'Dembī Dolo', 'describr' ),
        6 => /*translators: City.*/ __( 'Dodola', 'describr' ),
        7 => /*translators: City.*/ __( 'East Harerghe Zone', 'describr' ),
        8 => /*translators: City.*/ __( 'East Shewa Zone', 'describr' ),
        9 => /*translators: City.*/ __( 'East Wellega Zone', 'describr' ),
        10 => /*translators: City.*/ __( 'Fichē', 'describr' ),
        11 => /*translators: City.*/ __( 'Gebre Guracha', 'describr' ),
        12 => /*translators: City.*/ __( 'Gelemso', 'describr' ),
        13 => /*translators: City.*/ __( 'Genet', 'describr' ),
        14 => /*translators: City.*/ __( 'Gimbi', 'describr' ),
        15 => /*translators: City.*/ __( 'Ginir', 'describr' ),
        16 => /*translators: City.*/ __( 'Goba', 'describr' ),
        17 => /*translators: City.*/ __( 'Gorē', 'describr' ),
        18 => /*translators: City.*/ __( 'Guji Zone', 'describr' ),
        19 => /*translators: City.*/ __( 'Gēdo', 'describr' ),
        20 => /*translators: City.*/ __( 'Hagere Maryam', 'describr' ),
        21 => /*translators: City.*/ __( 'Huruta', 'describr' ),
        22 => /*translators: City.*/ __( 'Hāgere Hiywet', 'describr' ),
        23 => /*translators: City.*/ __( 'Hīrna', 'describr' ),
        24 => /*translators: City.*/ __( 'Illubabor Zone', 'describr' ),
        25 => /*translators: City.*/ __( 'Jimma', 'describr' ),
        26 => /*translators: City.*/ __( 'Jimma Zone', 'describr' ),
        27 => /*translators: City.*/ __( 'Kibre Mengist', 'describr' ),
        28 => /*translators: City.*/ __( 'Kofelē', 'describr' ),
        29 => /*translators: City.*/ __( 'Mendī', 'describr' ),
        30 => /*translators: City.*/ __( 'Metahāra', 'describr' ),
        31 => /*translators: City.*/ __( 'Metu', 'describr' ),
        32 => /*translators: City.*/ __( 'Mojo', 'describr' ),
        33 => /*translators: City.*/ __( 'Mēga', 'describr' ),
        34 => /*translators: City.*/ __( 'Nazrēt', 'describr' ),
        35 => /*translators: City.*/ __( 'Nejo', 'describr' ),
        36 => /*translators: City.*/ __( 'North Shewa Zone', 'describr' ),
        37 => /*translators: City.*/ __( 'Sebeta', 'describr' ),
        38 => /*translators: City.*/ __( 'Sendafa', 'describr' ),
        39 => /*translators: City.*/ __( 'Shakiso', 'describr' ),
        40 => /*translators: City.*/ __( 'Shambu', 'describr' ),
        41 => /*translators: City.*/ __( 'Shashemenē', 'describr' ),
        42 => /*translators: City.*/ __( 'Sirre', 'describr' ),
        43 => /*translators: City.*/ __( 'Tulu Bolo', 'describr' ),
        44 => /*translators: City.*/ __( 'Waliso', 'describr' ),
        45 => /*translators: City.*/ __( 'Wenjī', 'describr' ),
        46 => /*translators: City.*/ __( 'West Harerghe Zone', 'describr' ),
        47 => /*translators: City.*/ __( 'West Wellega Zone', 'describr' ),
        48 => /*translators: City.*/ __( 'Yabēlo', 'describr' ),
        49 => /*translators: City.*/ __( 'Ziway', 'describr' ),
        50 => /*translators: City.*/ __( 'Ādīs &#039;Alem', 'describr' ),
        51 => /*translators: City.*/ __( 'Āgaro', 'describr' ),
        52 => /*translators: City.*/ __( 'Āsasa', 'describr' ),
        53 => /*translators: City.*/ __( 'Āsbe Teferī', 'describr' ),
      ),
    ),
    'AF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Afar Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Administrative Zone 2', 'describr' ),
        1 => /*translators: City.*/ __( 'Administrative Zone 3', 'describr' ),
        2 => /*translators: City.*/ __( 'Asaita', 'describr' ),
        3 => /*translators: City.*/ __( 'Dubti', 'describr' ),
        4 => /*translators: City.*/ __( 'Gewanē', 'describr' ),
        5 => /*translators: City.*/ __( 'Semera', 'describr' ),
        6 => /*translators: City.*/ __( 'Āwash', 'describr' ),
      ),
    ),
    'HA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Harari Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Harar', 'describr' ),
      ),
    ),
    'DD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dire Dawa', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dire Dawa', 'describr' ),
      ),
    ),
    'BE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Benishangul-Gumuz Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Asosa', 'describr' ),
        1 => /*translators: City.*/ __( 'Metekel', 'describr' ),
        2 => /*translators: City.*/ __( 'Āsosa', 'describr' ),
      ),
    ),
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gambela Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Administrative Zone 1', 'describr' ),
        1 => /*translators: City.*/ __( 'Gambēla', 'describr' ),
      ),
    ),
    'AA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Addis Ababa', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Addis Ababa', 'describr' ),
      ),
    ),
  ),
  'ME' => 
  array (
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bar Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bar', 'describr' ),
        1 => /*translators: City.*/ __( 'Stari Bar', 'describr' ),
        2 => /*translators: City.*/ __( 'Sutomore', 'describr' ),
        3 => /*translators: City.*/ __( 'Šušanj', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Danilovgrad Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Danilovgrad', 'describr' ),
        1 => /*translators: City.*/ __( 'Spuž', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Berane Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Berane', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Andrijevica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Andrijevica', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bijelo Polje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bijelo Polje', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Old Royal Capital Cetinje', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cetinje', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Budva Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Budva', 'describr' ),
        1 => /*translators: City.*/ __( 'Petrovac na Moru', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kolašin Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kolašin', 'describr' ),
      ),
    ),
  ),
  'NA' => 
  array (
    'KU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kunene Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Epupa Constituency', 'describr' ),
        1 => /*translators: City.*/ __( 'Khorixas', 'describr' ),
        2 => /*translators: City.*/ __( 'Khorixas Constituency', 'describr' ),
        3 => /*translators: City.*/ __( 'Opuwo', 'describr' ),
        4 => /*translators: City.*/ __( 'Opuwo Constituency', 'describr' ),
        5 => /*translators: City.*/ __( 'Outjo', 'describr' ),
        6 => /*translators: City.*/ __( 'Sesfontein Constituency', 'describr' ),
      ),
    ),
    'KE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kavango East Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rundu', 'describr' ),
      ),
    ),
    'ON' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oshana Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ondangwa', 'describr' ),
        1 => /*translators: City.*/ __( 'Ongwediva', 'describr' ),
        2 => /*translators: City.*/ __( 'Oshakati', 'describr' ),
      ),
    ),
    'HA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hardap Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aranos', 'describr' ),
        1 => /*translators: City.*/ __( 'Hoachanas', 'describr' ),
        2 => /*translators: City.*/ __( 'Maltahöhe', 'describr' ),
        3 => /*translators: City.*/ __( 'Mariental', 'describr' ),
        4 => /*translators: City.*/ __( 'Rehoboth', 'describr' ),
      ),
    ),
    'OS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Omusati Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Okahao', 'describr' ),
        1 => /*translators: City.*/ __( 'Ongandjera', 'describr' ),
        2 => /*translators: City.*/ __( 'Outapi', 'describr' ),
      ),
    ),
    'OW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ohangwena Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Oshikango', 'describr' ),
      ),
    ),
    'OH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Omaheke Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gobabis', 'describr' ),
      ),
    ),
    'OT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oshikoto Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Omuthiya', 'describr' ),
        1 => /*translators: City.*/ __( 'Tsumeb', 'describr' ),
      ),
    ),
    'ER' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Erongo Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arandis', 'describr' ),
        1 => /*translators: City.*/ __( 'Hentiesbaai', 'describr' ),
        2 => /*translators: City.*/ __( 'Karibib', 'describr' ),
        3 => /*translators: City.*/ __( 'Omaruru', 'describr' ),
        4 => /*translators: City.*/ __( 'Otjimbingwe', 'describr' ),
        5 => /*translators: City.*/ __( 'Swakopmund', 'describr' ),
        6 => /*translators: City.*/ __( 'Swakopmund Constituency', 'describr' ),
        7 => /*translators: City.*/ __( 'Usakos', 'describr' ),
        8 => /*translators: City.*/ __( 'Walvis Bay', 'describr' ),
      ),
    ),
    'KH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khomas Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Katutura', 'describr' ),
        1 => /*translators: City.*/ __( 'Windhoek', 'describr' ),
      ),
    ),
    'KA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Karas Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bethanie', 'describr' ),
        1 => /*translators: City.*/ __( 'Karasburg', 'describr' ),
        2 => /*translators: City.*/ __( 'Keetmanshoop', 'describr' ),
        3 => /*translators: City.*/ __( 'Lüderitz', 'describr' ),
        4 => /*translators: City.*/ __( 'Oranjemund', 'describr' ),
        5 => /*translators: City.*/ __( 'Tses', 'describr' ),
        6 => /*translators: City.*/ __( 'Warmbad', 'describr' ),
      ),
    ),
    'OD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Otjozondjupa Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Grootfontein', 'describr' ),
        1 => /*translators: City.*/ __( 'Okahandja', 'describr' ),
        2 => /*translators: City.*/ __( 'Okakarara', 'describr' ),
        3 => /*translators: City.*/ __( 'Otavi', 'describr' ),
        4 => /*translators: City.*/ __( 'Otjiwarongo', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zambezi Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bagani', 'describr' ),
        1 => /*translators: City.*/ __( 'Katima Mulilo', 'describr' ),
      ),
    ),
  ),
  'GH' => 
  array (
    'AH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ashanti Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agogo', 'describr' ),
        1 => /*translators: City.*/ __( 'Bekwai', 'describr' ),
        2 => /*translators: City.*/ __( 'Ejura', 'describr' ),
        3 => /*translators: City.*/ __( 'Konongo', 'describr' ),
        4 => /*translators: City.*/ __( 'Kumasi', 'describr' ),
        5 => /*translators: City.*/ __( 'Mampong', 'describr' ),
        6 => /*translators: City.*/ __( 'Obuase', 'describr' ),
        7 => /*translators: City.*/ __( 'Tafo', 'describr' ),
      ),
    ),
    'WP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aboso', 'describr' ),
        1 => /*translators: City.*/ __( 'Axim', 'describr' ),
        2 => /*translators: City.*/ __( 'Bibiani', 'describr' ),
        3 => /*translators: City.*/ __( 'Prestea', 'describr' ),
        4 => /*translators: City.*/ __( 'Sekondi-Takoradi', 'describr' ),
        5 => /*translators: City.*/ __( 'Shama Junction', 'describr' ),
        6 => /*translators: City.*/ __( 'Takoradi', 'describr' ),
        7 => /*translators: City.*/ __( 'Tarkwa', 'describr' ),
      ),
    ),
    'EP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aburi', 'describr' ),
        1 => /*translators: City.*/ __( 'Akim Oda', 'describr' ),
        2 => /*translators: City.*/ __( 'Akim Swedru', 'describr' ),
        3 => /*translators: City.*/ __( 'Akropong', 'describr' ),
        4 => /*translators: City.*/ __( 'Akwatia', 'describr' ),
        5 => /*translators: City.*/ __( 'Asamankese', 'describr' ),
        6 => /*translators: City.*/ __( 'Begoro', 'describr' ),
        7 => /*translators: City.*/ __( 'Kibi', 'describr' ),
        8 => /*translators: City.*/ __( 'Koforidua', 'describr' ),
        9 => /*translators: City.*/ __( 'Mpraeso', 'describr' ),
        10 => /*translators: City.*/ __( 'Nsawam', 'describr' ),
        11 => /*translators: City.*/ __( 'Suhum', 'describr' ),
      ),
    ),
    'NP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kpandae', 'describr' ),
        1 => /*translators: City.*/ __( 'Salaga', 'describr' ),
        2 => /*translators: City.*/ __( 'Savelugu', 'describr' ),
        3 => /*translators: City.*/ __( 'Tamale', 'describr' ),
        4 => /*translators: City.*/ __( 'Yendi', 'describr' ),
      ),
    ),
    'CP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Apam', 'describr' ),
        1 => /*translators: City.*/ __( 'Cape Coast', 'describr' ),
        2 => /*translators: City.*/ __( 'Dunkwa', 'describr' ),
        3 => /*translators: City.*/ __( 'Elmina', 'describr' ),
        4 => /*translators: City.*/ __( 'Foso', 'describr' ),
        5 => /*translators: City.*/ __( 'Kasoa', 'describr' ),
        6 => /*translators: City.*/ __( 'Mumford', 'describr' ),
        7 => /*translators: City.*/ __( 'Saltpond', 'describr' ),
        8 => /*translators: City.*/ __( 'Swedru', 'describr' ),
        9 => /*translators: City.*/ __( 'Winneba', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brong-Ahafo Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bechem', 'describr' ),
        1 => /*translators: City.*/ __( 'Berekum', 'describr' ),
        2 => /*translators: City.*/ __( 'Duayaw-Nkwanta', 'describr' ),
        3 => /*translators: City.*/ __( 'Japekrom', 'describr' ),
        4 => /*translators: City.*/ __( 'Kintampo', 'describr' ),
        5 => /*translators: City.*/ __( 'Sunyani', 'describr' ),
        6 => /*translators: City.*/ __( 'Techiman', 'describr' ),
        7 => /*translators: City.*/ __( 'Wenchi', 'describr' ),
      ),
    ),
    'AA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Greater Accra Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Accra', 'describr' ),
        1 => /*translators: City.*/ __( 'Atsiaman', 'describr' ),
        2 => /*translators: City.*/ __( 'Dome', 'describr' ),
        3 => /*translators: City.*/ __( 'Gbawe', 'describr' ),
        4 => /*translators: City.*/ __( 'Medina Estates', 'describr' ),
        5 => /*translators: City.*/ __( 'Nungua', 'describr' ),
        6 => /*translators: City.*/ __( 'Tema', 'describr' ),
        7 => /*translators: City.*/ __( 'Teshi Old Town', 'describr' ),
      ),
    ),
    'UE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Upper East Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bawku', 'describr' ),
        1 => /*translators: City.*/ __( 'Bolgatanga', 'describr' ),
        2 => /*translators: City.*/ __( 'Navrongo', 'describr' ),
      ),
    ),
    'TV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Volta Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aflao', 'describr' ),
        1 => /*translators: City.*/ __( 'Anloga', 'describr' ),
        2 => /*translators: City.*/ __( 'Ho', 'describr' ),
        3 => /*translators: City.*/ __( 'Hohoe', 'describr' ),
        4 => /*translators: City.*/ __( 'Keta', 'describr' ),
        5 => /*translators: City.*/ __( 'Kete Krachi', 'describr' ),
        6 => /*translators: City.*/ __( 'Kpandu', 'describr' ),
      ),
    ),
    'UW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Upper West Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Wa', 'describr' ),
      ),
    ),
  ),
  'SM' => 
  array (
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Marino', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'San Marino', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Acquaviva', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acquaviva', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chiesanuova', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Poggio di Chiesanuova', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Borgo Maggiore', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Borgo Maggiore', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Faetano', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Faetano', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Montegiardino', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Monte Giardino', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Domagnano', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Domagnano', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Serravalle', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Serravalle', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fiorentino', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fiorentino', 'describr' ),
      ),
    ),
  ),
  'MT' => 
  array (
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Floriana', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Floriana', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Birżebbuġa', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Birżebbuġa', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Birkirkara', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Birkirkara', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Birgu', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Vittoriosa', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balzan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balzan', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Attard', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Attard', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dingli', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dingli', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fgura', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fgura', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cospicua', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cospicua', 'describr' ),
      ),
    ),
  ),
  'KZ' => 
  array (
    'MAN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mangystau Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aktau', 'describr' ),
        1 => /*translators: City.*/ __( 'Baūtīno', 'describr' ),
        2 => /*translators: City.*/ __( 'Beyneu', 'describr' ),
        3 => /*translators: City.*/ __( 'Fort-Shevchenko', 'describr' ),
        4 => /*translators: City.*/ __( 'Munayshy', 'describr' ),
        5 => /*translators: City.*/ __( 'Sayötesh', 'describr' ),
        6 => /*translators: City.*/ __( 'Shetpe', 'describr' ),
        7 => /*translators: City.*/ __( 'Taūshyq', 'describr' ),
        8 => /*translators: City.*/ __( 'Yeraliyev', 'describr' ),
        9 => /*translators: City.*/ __( 'Zhanaozen', 'describr' ),
        10 => /*translators: City.*/ __( 'Zhetibay', 'describr' ),
        11 => /*translators: City.*/ __( 'Ömirzaq', 'describr' ),
      ),
    ),
    'KZY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kyzylorda Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aral', 'describr' ),
        1 => /*translators: City.*/ __( 'Ayteke Bi', 'describr' ),
        2 => /*translators: City.*/ __( 'Belköl', 'describr' ),
        3 => /*translators: City.*/ __( 'Dzhalagash', 'describr' ),
        4 => /*translators: City.*/ __( 'Kyzylorda', 'describr' ),
        5 => /*translators: City.*/ __( 'Qazaly', 'describr' ),
        6 => /*translators: City.*/ __( 'Sekseūil', 'describr' ),
        7 => /*translators: City.*/ __( 'Shalqīya', 'describr' ),
        8 => /*translators: City.*/ __( 'Shīeli', 'describr' ),
        9 => /*translators: City.*/ __( 'Tasböget', 'describr' ),
        10 => /*translators: City.*/ __( 'Terenozek', 'describr' ),
        11 => /*translators: City.*/ __( 'Yanykurgan', 'describr' ),
        12 => /*translators: City.*/ __( 'Zhosaly', 'describr' ),
      ),
    ),
    'ALM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Almaty Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bakanas', 'describr' ),
        1 => /*translators: City.*/ __( 'Balpyk Bī', 'describr' ),
        2 => /*translators: City.*/ __( 'Burunday', 'describr' ),
        3 => /*translators: City.*/ __( 'Chemolgan', 'describr' ),
        4 => /*translators: City.*/ __( 'Druzhba', 'describr' ),
        5 => /*translators: City.*/ __( 'Esik', 'describr' ),
        6 => /*translators: City.*/ __( 'Kapshagay', 'describr' ),
        7 => /*translators: City.*/ __( 'Kegen', 'describr' ),
        8 => /*translators: City.*/ __( 'Lepsy', 'describr' ),
        9 => /*translators: City.*/ __( 'Matay', 'describr' ),
        10 => /*translators: City.*/ __( 'Otegen Batyra', 'describr' ),
        11 => /*translators: City.*/ __( 'Pervomayka', 'describr' ),
        12 => /*translators: City.*/ __( 'Sarkand', 'describr' ),
        13 => /*translators: City.*/ __( 'Saryozek', 'describr' ),
        14 => /*translators: City.*/ __( 'Taldykorgan', 'describr' ),
        15 => /*translators: City.*/ __( 'Talghar', 'describr' ),
        16 => /*translators: City.*/ __( 'Tekeli', 'describr' ),
        17 => /*translators: City.*/ __( 'Turgen', 'describr' ),
        18 => /*translators: City.*/ __( 'Ush-Tyube', 'describr' ),
        19 => /*translators: City.*/ __( 'Zharkent', 'describr' ),
        20 => /*translators: City.*/ __( 'Ülken', 'describr' ),
      ),
    ),
    'SEV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North Kazakhstan Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Birlestik', 'describr' ),
        1 => /*translators: City.*/ __( 'Bishkul', 'describr' ),
        2 => /*translators: City.*/ __( 'Bulayevo', 'describr' ),
        3 => /*translators: City.*/ __( 'Būrabay', 'describr' ),
        4 => /*translators: City.*/ __( 'Kzyltu', 'describr' ),
        5 => /*translators: City.*/ __( 'Novoishimskiy', 'describr' ),
        6 => /*translators: City.*/ __( 'Petropavl', 'describr' ),
        7 => /*translators: City.*/ __( 'Sergeyevka', 'describr' ),
        8 => /*translators: City.*/ __( 'Smirnovo', 'describr' ),
        9 => /*translators: City.*/ __( 'Taiynsha', 'describr' ),
        10 => /*translators: City.*/ __( 'Talshik', 'describr' ),
        11 => /*translators: City.*/ __( 'Timiryazevo', 'describr' ),
        12 => /*translators: City.*/ __( 'Volodarskoye', 'describr' ),
        13 => /*translators: City.*/ __( 'Yavlenka', 'describr' ),
      ),
    ),
    'AKM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Akmola Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akkol', 'describr' ),
        1 => /*translators: City.*/ __( 'Akkol&#039;', 'describr' ),
        2 => /*translators: City.*/ __( 'Aksu', 'describr' ),
        3 => /*translators: City.*/ __( 'Astrakhan', 'describr' ),
        4 => /*translators: City.*/ __( 'Atbasar', 'describr' ),
        5 => /*translators: City.*/ __( 'Balkashino', 'describr' ),
        6 => /*translators: City.*/ __( 'Bestobe', 'describr' ),
        7 => /*translators: City.*/ __( 'Derzhavīnsk', 'describr' ),
        8 => /*translators: City.*/ __( 'Egindiköl', 'describr' ),
        9 => /*translators: City.*/ __( 'Esil', 'describr' ),
        10 => /*translators: City.*/ __( 'Kokshetau', 'describr' ),
        11 => /*translators: City.*/ __( 'Krasnogorskiy', 'describr' ),
        12 => /*translators: City.*/ __( 'Makinsk', 'describr' ),
        13 => /*translators: City.*/ __( 'Shantobe', 'describr' ),
        14 => /*translators: City.*/ __( 'Shchuchinsk', 'describr' ),
        15 => /*translators: City.*/ __( 'Shortandy', 'describr' ),
        16 => /*translators: City.*/ __( 'Stepnogorsk', 'describr' ),
        17 => /*translators: City.*/ __( 'Stepnyak', 'describr' ),
        18 => /*translators: City.*/ __( 'Yermentau', 'describr' ),
        19 => /*translators: City.*/ __( 'Zavodskoy', 'describr' ),
        20 => /*translators: City.*/ __( 'Zhaqsy', 'describr' ),
        21 => /*translators: City.*/ __( 'Zholymbet', 'describr' ),
      ),
    ),
    'PAV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pavlodar Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aksu', 'describr' ),
        1 => /*translators: City.*/ __( 'Bayanaul', 'describr' ),
        2 => /*translators: City.*/ __( 'Belogor&#039;ye', 'describr' ),
        3 => /*translators: City.*/ __( 'Ekibastuz', 'describr' ),
        4 => /*translators: City.*/ __( 'Irtyshsk', 'describr' ),
        5 => /*translators: City.*/ __( 'Kalkaman', 'describr' ),
        6 => /*translators: City.*/ __( 'Leninskiy', 'describr' ),
        7 => /*translators: City.*/ __( 'Mayqayyng', 'describr' ),
        8 => /*translators: City.*/ __( 'Pavlodar', 'describr' ),
        9 => /*translators: City.*/ __( 'Qashyr', 'describr' ),
        10 => /*translators: City.*/ __( 'Zhelezinka', 'describr' ),
      ),
    ),
    'ZHA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jambyl Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aqbaqay', 'describr' ),
        1 => /*translators: City.*/ __( 'Chu', 'describr' ),
        2 => /*translators: City.*/ __( 'Georgiyevka', 'describr' ),
        3 => /*translators: City.*/ __( 'Granitogorsk', 'describr' ),
        4 => /*translators: City.*/ __( 'Karatau', 'describr' ),
        5 => /*translators: City.*/ __( 'Khantaū', 'describr' ),
        6 => /*translators: City.*/ __( 'Lugovoy', 'describr' ),
        7 => /*translators: City.*/ __( 'Lugovoye', 'describr' ),
        8 => /*translators: City.*/ __( 'Merke', 'describr' ),
        9 => /*translators: City.*/ __( 'Moyynkum', 'describr' ),
        10 => /*translators: City.*/ __( 'Mynaral', 'describr' ),
        11 => /*translators: City.*/ __( 'Oytal', 'describr' ),
        12 => /*translators: City.*/ __( 'Sarykemer', 'describr' ),
        13 => /*translators: City.*/ __( 'Shyghanaq', 'describr' ),
        14 => /*translators: City.*/ __( 'Taraz', 'describr' ),
        15 => /*translators: City.*/ __( 'Zhangatas', 'describr' ),
      ),
    ),
    'ZAP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'West Kazakhstan Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aqsay', 'describr' ),
        1 => /*translators: City.*/ __( 'Burlin', 'describr' ),
        2 => /*translators: City.*/ __( 'Chapaev', 'describr' ),
        3 => /*translators: City.*/ __( 'Chingirlau', 'describr' ),
        4 => /*translators: City.*/ __( 'Dzhambeyty', 'describr' ),
        5 => /*translators: City.*/ __( 'Fedorovka', 'describr' ),
        6 => /*translators: City.*/ __( 'Kaztalovka', 'describr' ),
        7 => /*translators: City.*/ __( 'Krūgloozernoe', 'describr' ),
        8 => /*translators: City.*/ __( 'Oral', 'describr' ),
        9 => /*translators: City.*/ __( 'Peremetnoe', 'describr' ),
        10 => /*translators: City.*/ __( 'Saykhin', 'describr' ),
        11 => /*translators: City.*/ __( 'Tasqala', 'describr' ),
        12 => /*translators: City.*/ __( 'Zhänibek', 'describr' ),
      ),
    ),
    'YUZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Turkestan Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arys', 'describr' ),
        1 => /*translators: City.*/ __( 'Ashchysay', 'describr' ),
        2 => /*translators: City.*/ __( 'Asyqata', 'describr' ),
        3 => /*translators: City.*/ __( 'Atakent', 'describr' ),
        4 => /*translators: City.*/ __( 'Bayzhansay', 'describr' ),
        5 => /*translators: City.*/ __( 'Belyye Vody', 'describr' ),
        6 => /*translators: City.*/ __( 'Chardara', 'describr' ),
        7 => /*translators: City.*/ __( 'Chayan', 'describr' ),
        8 => /*translators: City.*/ __( 'Chulakkurgan', 'describr' ),
        9 => /*translators: City.*/ __( 'Kantagi', 'describr' ),
        10 => /*translators: City.*/ __( 'Kentau', 'describr' ),
        11 => /*translators: City.*/ __( 'Kokterek', 'describr' ),
        12 => /*translators: City.*/ __( 'Lenger', 'describr' ),
        13 => /*translators: City.*/ __( 'Leninskoye', 'describr' ),
        14 => /*translators: City.*/ __( 'Maqtaaral Aūdany', 'describr' ),
        15 => /*translators: City.*/ __( 'Myrzakent', 'describr' ),
        16 => /*translators: City.*/ __( 'Qogham', 'describr' ),
        17 => /*translators: City.*/ __( 'Saryaghash', 'describr' ),
        18 => /*translators: City.*/ __( 'Saryaghash Aūdany', 'describr' ),
        19 => /*translators: City.*/ __( 'Sastobe', 'describr' ),
        20 => /*translators: City.*/ __( 'Sozaq Aūdany', 'describr' ),
        21 => /*translators: City.*/ __( 'Temirlanovka', 'describr' ),
        22 => /*translators: City.*/ __( 'Turar Ryskulov', 'describr' ),
        23 => /*translators: City.*/ __( 'Turkestan', 'describr' ),
        24 => /*translators: City.*/ __( 'Tyul&#039;kubas', 'describr' ),
        25 => /*translators: City.*/ __( 'Zhabagly', 'describr' ),
      ),
    ),
    'KAR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Karaganda Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abay', 'describr' ),
        1 => /*translators: City.*/ __( 'Abay Qalasy', 'describr' ),
        2 => /*translators: City.*/ __( 'Aksu-Ayuly', 'describr' ),
        3 => /*translators: City.*/ __( 'Aktas', 'describr' ),
        4 => /*translators: City.*/ __( 'Aktau', 'describr' ),
        5 => /*translators: City.*/ __( 'Aktogay', 'describr' ),
        6 => /*translators: City.*/ __( 'Aqadyr', 'describr' ),
        7 => /*translators: City.*/ __( 'Aqshataū', 'describr' ),
        8 => /*translators: City.*/ __( 'Aqtoghay Aūdany', 'describr' ),
        9 => /*translators: City.*/ __( 'Atasū', 'describr' ),
        10 => /*translators: City.*/ __( 'Balqash', 'describr' ),
        11 => /*translators: City.*/ __( 'Bukhar-Zhyrau', 'describr' ),
        12 => /*translators: City.*/ __( 'Dolinka', 'describr' ),
        13 => /*translators: City.*/ __( 'Karagandy', 'describr' ),
        14 => /*translators: City.*/ __( 'Koktal', 'describr' ),
        15 => /*translators: City.*/ __( 'Kushoky', 'describr' ),
        16 => /*translators: City.*/ __( 'Kyzylzhar', 'describr' ),
        17 => /*translators: City.*/ __( 'Kīevka', 'describr' ),
        18 => /*translators: City.*/ __( 'Moyynty', 'describr' ),
        19 => /*translators: City.*/ __( 'Novodolinskiy', 'describr' ),
        20 => /*translators: City.*/ __( 'Osakarovka', 'describr' ),
        21 => /*translators: City.*/ __( 'Prigorodnoye', 'describr' ),
        22 => /*translators: City.*/ __( 'Priozersk', 'describr' ),
        23 => /*translators: City.*/ __( 'Qarazhal', 'describr' ),
        24 => /*translators: City.*/ __( 'Qarqaraly', 'describr' ),
        25 => /*translators: City.*/ __( 'Saryshaghan', 'describr' ),
        26 => /*translators: City.*/ __( 'Sayaq', 'describr' ),
        27 => /*translators: City.*/ __( 'Shakhan', 'describr' ),
        28 => /*translators: City.*/ __( 'Shakhtinsk', 'describr' ),
        29 => /*translators: City.*/ __( 'Shashūbay', 'describr' ),
        30 => /*translators: City.*/ __( 'Shubarköl', 'describr' ),
        31 => /*translators: City.*/ __( 'Soran', 'describr' ),
        32 => /*translators: City.*/ __( 'Temirtau', 'describr' ),
        33 => /*translators: City.*/ __( 'Tokarevka', 'describr' ),
        34 => /*translators: City.*/ __( 'Verkhniye Kayrakty', 'describr' ),
        35 => /*translators: City.*/ __( 'Zhambyl', 'describr' ),
        36 => /*translators: City.*/ __( 'Zharyk', 'describr' ),
        37 => /*translators: City.*/ __( 'Zhezqazghan', 'describr' ),
      ),
    ),
    'AKT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aktobe Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aktobe', 'describr' ),
        1 => /*translators: City.*/ __( 'Batamshinskiy', 'describr' ),
        2 => /*translators: City.*/ __( 'Bayganin', 'describr' ),
        3 => /*translators: City.*/ __( 'Embi', 'describr' ),
        4 => /*translators: City.*/ __( 'Kandyagash', 'describr' ),
        5 => /*translators: City.*/ __( 'Khromtau', 'describr' ),
        6 => /*translators: City.*/ __( 'Martuk', 'describr' ),
        7 => /*translators: City.*/ __( 'Shalqar', 'describr' ),
        8 => /*translators: City.*/ __( 'Shubarkuduk', 'describr' ),
        9 => /*translators: City.*/ __( 'Shubarshi', 'describr' ),
        10 => /*translators: City.*/ __( 'Temir', 'describr' ),
        11 => /*translators: City.*/ __( 'Yrghyz', 'describr' ),
      ),
    ),
    'ALA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Almaty', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Almaty', 'describr' ),
      ),
    ),
    'ATY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Atyrau Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akkol&#039;', 'describr' ),
        1 => /*translators: City.*/ __( 'Atyrau', 'describr' ),
        2 => /*translators: City.*/ __( 'Balykshi', 'describr' ),
        3 => /*translators: City.*/ __( 'Bayshonas', 'describr' ),
        4 => /*translators: City.*/ __( 'Dossor', 'describr' ),
        5 => /*translators: City.*/ __( 'Inderbor', 'describr' ),
        6 => /*translators: City.*/ __( 'Makhambet', 'describr' ),
        7 => /*translators: City.*/ __( 'Maloye Ganyushkino', 'describr' ),
        8 => /*translators: City.*/ __( 'Maqat', 'describr' ),
        9 => /*translators: City.*/ __( 'Miyaly', 'describr' ),
        10 => /*translators: City.*/ __( 'Qaraton', 'describr' ),
        11 => /*translators: City.*/ __( 'Qulsary', 'describr' ),
        12 => /*translators: City.*/ __( 'Shalkar', 'describr' ),
      ),
    ),
    'VOS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'East Kazakhstan Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Altayskiy', 'describr' ),
        1 => /*translators: City.*/ __( 'Aqtoghay', 'describr' ),
        2 => /*translators: City.*/ __( 'Asūbulaq', 'describr' ),
        3 => /*translators: City.*/ __( 'Auezov', 'describr' ),
        4 => /*translators: City.*/ __( 'Ayagoz', 'describr' ),
        5 => /*translators: City.*/ __( 'Belogorskīy', 'describr' ),
        6 => /*translators: City.*/ __( 'Belousovka', 'describr' ),
        7 => /*translators: City.*/ __( 'Borodulikha', 'describr' ),
        8 => /*translators: City.*/ __( 'Georgīevka', 'describr' ),
        9 => /*translators: City.*/ __( 'Glubokoye', 'describr' ),
        10 => /*translators: City.*/ __( 'Kurchatov', 'describr' ),
        11 => /*translators: City.*/ __( 'Kurchum', 'describr' ),
        12 => /*translators: City.*/ __( 'Maleyevsk', 'describr' ),
        13 => /*translators: City.*/ __( 'Ognevka', 'describr' ),
        14 => /*translators: City.*/ __( 'Priisk Boko', 'describr' ),
        15 => /*translators: City.*/ __( 'Qaraūyl', 'describr' ),
        16 => /*translators: City.*/ __( 'Ridder', 'describr' ),
        17 => /*translators: City.*/ __( 'Semey', 'describr' ),
        18 => /*translators: City.*/ __( 'Shar', 'describr' ),
        19 => /*translators: City.*/ __( 'Shemonaīkha', 'describr' ),
        20 => /*translators: City.*/ __( 'Suykbulak', 'describr' ),
        21 => /*translators: City.*/ __( 'Tūghyl', 'describr' ),
        22 => /*translators: City.*/ __( 'Urzhar', 'describr' ),
        23 => /*translators: City.*/ __( 'Ust-Kamenogorsk', 'describr' ),
        24 => /*translators: City.*/ __( 'Zaysan', 'describr' ),
        25 => /*translators: City.*/ __( 'Zhalghyztobe', 'describr' ),
        26 => /*translators: City.*/ __( 'Zhanga Buqtyrma', 'describr' ),
        27 => /*translators: City.*/ __( 'Zhezkent', 'describr' ),
        28 => /*translators: City.*/ __( 'Zyryanovsk', 'describr' ),
        29 => /*translators: City.*/ __( 'Ūst&#039;-Talovka', 'describr' ),
      ),
    ),
    'BAY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baikonur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baikonur', 'describr' ),
      ),
    ),
    'AST' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nur-Sultan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nur-Sultan', 'describr' ),
      ),
    ),
    'KUS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kostanay Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arkalyk', 'describr' ),
        1 => /*translators: City.*/ __( 'Ayat', 'describr' ),
        2 => /*translators: City.*/ __( 'Borovskoy', 'describr' ),
        3 => /*translators: City.*/ __( 'Dzhetygara', 'describr' ),
        4 => /*translators: City.*/ __( 'Fyodorovka', 'describr' ),
        5 => /*translators: City.*/ __( 'Karasu', 'describr' ),
        6 => /*translators: City.*/ __( 'Komsomolets', 'describr' ),
        7 => /*translators: City.*/ __( 'Kostanay', 'describr' ),
        8 => /*translators: City.*/ __( 'Lisakovsk', 'describr' ),
        9 => /*translators: City.*/ __( 'Ordzhonikidze', 'describr' ),
        10 => /*translators: City.*/ __( 'Qashar', 'describr' ),
        11 => /*translators: City.*/ __( 'Qusmuryn', 'describr' ),
        12 => /*translators: City.*/ __( 'Rudnyy', 'describr' ),
        13 => /*translators: City.*/ __( 'Tobol', 'describr' ),
        14 => /*translators: City.*/ __( 'Torghay', 'describr' ),
        15 => /*translators: City.*/ __( 'Troyebratskiy', 'describr' ),
      ),
    ),
  ),
  'KE' => 
  array (
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Busia County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Busia', 'describr' ),
        1 => /*translators: City.*/ __( 'Luanda', 'describr' ),
        2 => /*translators: City.*/ __( 'Lugulu', 'describr' ),
        3 => /*translators: City.*/ __( 'Malaba', 'describr' ),
        4 => /*translators: City.*/ __( 'Nambare', 'describr' ),
        5 => /*translators: City.*/ __( 'Port Victoria', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Embu County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Embu', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bungoma County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bungoma', 'describr' ),
        1 => /*translators: City.*/ __( 'Malikisi', 'describr' ),
        2 => /*translators: City.*/ __( 'Webuye', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Isiolo County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Isiolo', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baringo County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baringo', 'describr' ),
        1 => /*translators: City.*/ __( 'Eldama Ravine', 'describr' ),
        2 => /*translators: City.*/ __( 'Kabarnet', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Homa Bay County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Homa Bay', 'describr' ),
        1 => /*translators: City.*/ __( 'Oyugis', 'describr' ),
        2 => /*translators: City.*/ __( 'Rachuonyo District', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Garissa County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Garissa', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bomet County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sotik', 'describr' ),
        1 => /*translators: City.*/ __( 'Sotik Post', 'describr' ),
      ),
    ),
  ),
  'AO' => 
  array (
    'BIE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bié Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camacupa', 'describr' ),
        1 => /*translators: City.*/ __( 'Catabola', 'describr' ),
        2 => /*translators: City.*/ __( 'Chissamba', 'describr' ),
        3 => /*translators: City.*/ __( 'Cuito', 'describr' ),
      ),
    ),
    'HUA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Huambo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Caála', 'describr' ),
        1 => /*translators: City.*/ __( 'Chela', 'describr' ),
        2 => /*translators: City.*/ __( 'Huambo', 'describr' ),
        3 => /*translators: City.*/ __( 'Longonjo', 'describr' ),
      ),
    ),
    'ZAI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zaire Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mbanza Congo', 'describr' ),
        1 => /*translators: City.*/ __( 'N&#039;zeto', 'describr' ),
        2 => /*translators: City.*/ __( 'Soio', 'describr' ),
      ),
    ),
    'CNN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cunene Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ondjiva', 'describr' ),
      ),
    ),
    'CUS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cuanza Sul', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Quibala', 'describr' ),
        1 => /*translators: City.*/ __( 'Sumbe', 'describr' ),
        2 => /*translators: City.*/ __( 'Uacu Cungo', 'describr' ),
      ),
    ),
    'CNO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cuanza Norte Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camabatela', 'describr' ),
        1 => /*translators: City.*/ __( 'N&#039;dalatando', 'describr' ),
      ),
    ),
    'BGU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Benguela Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Benguela', 'describr' ),
        1 => /*translators: City.*/ __( 'Catumbela', 'describr' ),
        2 => /*translators: City.*/ __( 'Lobito', 'describr' ),
      ),
    ),
    'MOX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Moxico Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luau', 'describr' ),
        1 => /*translators: City.*/ __( 'Luena', 'describr' ),
        2 => /*translators: City.*/ __( 'Lumeje', 'describr' ),
        3 => /*translators: City.*/ __( 'Léua', 'describr' ),
      ),
    ),
    'LSU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lunda Sul Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cazaji', 'describr' ),
        1 => /*translators: City.*/ __( 'Saurimo', 'describr' ),
      ),
    ),
    'BGO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bengo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Caxito', 'describr' ),
      ),
    ),
    'LUA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luanda Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belas', 'describr' ),
        1 => /*translators: City.*/ __( 'Icolo e Bengo', 'describr' ),
        2 => /*translators: City.*/ __( 'Luanda', 'describr' ),
      ),
    ),
    'LNO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lunda Norte Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lucapa', 'describr' ),
      ),
    ),
    'UIG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Uíge Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Uíge', 'describr' ),
      ),
    ),
    'HUI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Huíla Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Caconda', 'describr' ),
        1 => /*translators: City.*/ __( 'Caluquembe', 'describr' ),
        2 => /*translators: City.*/ __( 'Chibia', 'describr' ),
        3 => /*translators: City.*/ __( 'Chicomba', 'describr' ),
        4 => /*translators: City.*/ __( 'Chipindo', 'describr' ),
        5 => /*translators: City.*/ __( 'Cuvango', 'describr' ),
        6 => /*translators: City.*/ __( 'Gambos', 'describr' ),
        7 => /*translators: City.*/ __( 'Humpata', 'describr' ),
        8 => /*translators: City.*/ __( 'Jamba', 'describr' ),
        9 => /*translators: City.*/ __( 'Lubango', 'describr' ),
        10 => /*translators: City.*/ __( 'Matala', 'describr' ),
        11 => /*translators: City.*/ __( 'Quilengues', 'describr' ),
        12 => /*translators: City.*/ __( 'Quipungo', 'describr' ),
      ),
    ),
    'CCU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cuando Cubango Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Menongue', 'describr' ),
      ),
    ),
    'MAL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Malanje Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Malanje', 'describr' ),
      ),
    ),
    'CAB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cabinda Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cabinda', 'describr' ),
      ),
    ),
  ),
  'BT' => 
  array (
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gasa District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gasa', 'describr' ),
      ),
    ),
  ),
  'ML' => 
  array (
    'BKO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bamako', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bamako', 'describr' ),
      ),
    ),
  ),
  'RW' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Butare', 'describr' ),
        1 => /*translators: City.*/ __( 'Eglise Catholique, Centrale GIKO', 'describr' ),
        2 => /*translators: City.*/ __( 'Gitarama', 'describr' ),
        3 => /*translators: City.*/ __( 'Nzega', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cyangugu', 'describr' ),
        1 => /*translators: City.*/ __( 'Gisenyi', 'describr' ),
        2 => /*translators: City.*/ __( 'Kibuye', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kibungo', 'describr' ),
        1 => /*translators: City.*/ __( 'Rwamagana', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kigali district', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kigali', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Byumba', 'describr' ),
        1 => /*translators: City.*/ __( 'Musanze', 'describr' ),
      ),
    ),
  ),
  'BZ' => 
  array (
    'BZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Belize District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belize City', 'describr' ),
        1 => /*translators: City.*/ __( 'San Pedro', 'describr' ),
      ),
    ),
    'SC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Stann Creek District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dangriga', 'describr' ),
        1 => /*translators: City.*/ __( 'Placencia', 'describr' ),
      ),
    ),
    'CZL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Corozal District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Corozal', 'describr' ),
      ),
    ),
    'TOL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Toledo District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Punta Gorda', 'describr' ),
      ),
    ),
    'OW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Orange Walk District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hopelchén', 'describr' ),
        1 => /*translators: City.*/ __( 'Orange Walk', 'describr' ),
        2 => /*translators: City.*/ __( 'Shipyard', 'describr' ),
      ),
    ),
    'CY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cayo District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belmopan', 'describr' ),
        1 => /*translators: City.*/ __( 'Benque Viejo el Carmen', 'describr' ),
        2 => /*translators: City.*/ __( 'San Ignacio', 'describr' ),
        3 => /*translators: City.*/ __( 'Valley of Peace', 'describr' ),
      ),
    ),
  ),
  'ST' => 
  array (
    'P' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Príncipe Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Santo António', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'São Tomé Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cantagalo District', 'describr' ),
        1 => /*translators: City.*/ __( 'Caué District', 'describr' ),
        2 => /*translators: City.*/ __( 'São Tomé', 'describr' ),
        3 => /*translators: City.*/ __( 'Trindade', 'describr' ),
      ),
    ),
  ),
  'CU' => 
  array (
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Havana Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alamar', 'describr' ),
        1 => /*translators: City.*/ __( 'Arroyo Naranjo', 'describr' ),
        2 => /*translators: City.*/ __( 'Boyeros', 'describr' ),
        3 => /*translators: City.*/ __( 'Centro Habana', 'describr' ),
        4 => /*translators: City.*/ __( 'Cerro', 'describr' ),
        5 => /*translators: City.*/ __( 'Diez de Octubre', 'describr' ),
        6 => /*translators: City.*/ __( 'Guanabacoa', 'describr' ),
        7 => /*translators: City.*/ __( 'Habana del Este', 'describr' ),
        8 => /*translators: City.*/ __( 'Havana', 'describr' ),
        9 => /*translators: City.*/ __( 'La Habana Vieja', 'describr' ),
        10 => /*translators: City.*/ __( 'Regla', 'describr' ),
        11 => /*translators: City.*/ __( 'San Miguel del Padrón', 'describr' ),
        12 => /*translators: City.*/ __( 'Santiago de las Vegas', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sancti Spíritus Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cabaiguán', 'describr' ),
        1 => /*translators: City.*/ __( 'Condado', 'describr' ),
        2 => /*translators: City.*/ __( 'Fomento', 'describr' ),
        3 => /*translators: City.*/ __( 'Guayos', 'describr' ),
        4 => /*translators: City.*/ __( 'Jatibonico', 'describr' ),
        5 => /*translators: City.*/ __( 'La Sierpe', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Cabaiguán', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de Jatibonico', 'describr' ),
        8 => /*translators: City.*/ __( 'Municipio de Sancti Spíritus', 'describr' ),
        9 => /*translators: City.*/ __( 'Municipio de Trinidad', 'describr' ),
        10 => /*translators: City.*/ __( 'Sancti Spíritus', 'describr' ),
        11 => /*translators: City.*/ __( 'Topes de Collantes', 'describr' ),
        12 => /*translators: City.*/ __( 'Trinidad', 'describr' ),
        13 => /*translators: City.*/ __( 'Yaguajay', 'describr' ),
        14 => /*translators: City.*/ __( 'Zaza del Medio', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pinar del Río Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Consolación del Sur', 'describr' ),
        1 => /*translators: City.*/ __( 'Guane', 'describr' ),
        2 => /*translators: City.*/ __( 'Los Palacios', 'describr' ),
        3 => /*translators: City.*/ __( 'Mantua', 'describr' ),
        4 => /*translators: City.*/ __( 'Minas de Matahambre', 'describr' ),
        5 => /*translators: City.*/ __( 'Municipio de Consolación del Sur', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Guane', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de La Palma', 'describr' ),
        8 => /*translators: City.*/ __( 'Municipio de Los Palacios', 'describr' ),
        9 => /*translators: City.*/ __( 'Pinar del Río', 'describr' ),
        10 => /*translators: City.*/ __( 'Puerto Esperanza', 'describr' ),
        11 => /*translators: City.*/ __( 'San Diego de Los Baños', 'describr' ),
        12 => /*translators: City.*/ __( 'San Luis', 'describr' ),
        13 => /*translators: City.*/ __( 'Viñales', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Villa Clara Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Caibarién', 'describr' ),
        1 => /*translators: City.*/ __( 'Calabazar de Sagua', 'describr' ),
        2 => /*translators: City.*/ __( 'Camajuaní', 'describr' ),
        3 => /*translators: City.*/ __( 'Cifuentes', 'describr' ),
        4 => /*translators: City.*/ __( 'Corralillo', 'describr' ),
        5 => /*translators: City.*/ __( 'Encrucijada', 'describr' ),
        6 => /*translators: City.*/ __( 'Esperanza', 'describr' ),
        7 => /*translators: City.*/ __( 'Isabela de Sagua', 'describr' ),
        8 => /*translators: City.*/ __( 'Manicaragua', 'describr' ),
        9 => /*translators: City.*/ __( 'Municipio de Placetas', 'describr' ),
        10 => /*translators: City.*/ __( 'Municipio de Santa Clara', 'describr' ),
        11 => /*translators: City.*/ __( 'Placetas', 'describr' ),
        12 => /*translators: City.*/ __( 'Quemado de Güines', 'describr' ),
        13 => /*translators: City.*/ __( 'Rancho Veloz', 'describr' ),
        14 => /*translators: City.*/ __( 'Ranchuelo', 'describr' ),
        15 => /*translators: City.*/ __( 'Sagua la Grande', 'describr' ),
        16 => /*translators: City.*/ __( 'Santa Clara', 'describr' ),
        17 => /*translators: City.*/ __( 'Santo Domingo', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ciego de Ávila Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baraguá', 'describr' ),
        1 => /*translators: City.*/ __( 'Chambas', 'describr' ),
        2 => /*translators: City.*/ __( 'Ciego de Ávila', 'describr' ),
        3 => /*translators: City.*/ __( 'Ciro Redondo', 'describr' ),
        4 => /*translators: City.*/ __( 'Florencia', 'describr' ),
        5 => /*translators: City.*/ __( 'Morón', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Ciego de Ávila', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de Morón', 'describr' ),
        8 => /*translators: City.*/ __( 'Primero de Enero', 'describr' ),
        9 => /*translators: City.*/ __( 'Venezuela', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Matanzas Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alacranes', 'describr' ),
        1 => /*translators: City.*/ __( 'Bolondrón', 'describr' ),
        2 => /*translators: City.*/ __( 'Calimete', 'describr' ),
        3 => /*translators: City.*/ __( 'Colón', 'describr' ),
        4 => /*translators: City.*/ __( 'Cárdenas', 'describr' ),
        5 => /*translators: City.*/ __( 'Jagüey Grande', 'describr' ),
        6 => /*translators: City.*/ __( 'Jovellanos', 'describr' ),
        7 => /*translators: City.*/ __( 'Limonar', 'describr' ),
        8 => /*translators: City.*/ __( 'Los Arabos', 'describr' ),
        9 => /*translators: City.*/ __( 'Manguito', 'describr' ),
        10 => /*translators: City.*/ __( 'Martí', 'describr' ),
        11 => /*translators: City.*/ __( 'Matanzas', 'describr' ),
        12 => /*translators: City.*/ __( 'Municipio de Cárdenas', 'describr' ),
        13 => /*translators: City.*/ __( 'Municipio de Matanzas', 'describr' ),
        14 => /*translators: City.*/ __( 'Pedro Betancourt', 'describr' ),
        15 => /*translators: City.*/ __( 'Perico', 'describr' ),
        16 => /*translators: City.*/ __( 'Unión de Reyes', 'describr' ),
        17 => /*translators: City.*/ __( 'Varadero', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Camagüey Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camagüey', 'describr' ),
        1 => /*translators: City.*/ __( 'El Caney', 'describr' ),
        2 => /*translators: City.*/ __( 'Esmeralda', 'describr' ),
        3 => /*translators: City.*/ __( 'Florida', 'describr' ),
        4 => /*translators: City.*/ __( 'Guáimaro', 'describr' ),
        5 => /*translators: City.*/ __( 'Jimaguayú', 'describr' ),
        6 => /*translators: City.*/ __( 'Minas', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de Florida', 'describr' ),
        8 => /*translators: City.*/ __( 'Municipio de Nuevitas', 'describr' ),
        9 => /*translators: City.*/ __( 'Nuevitas', 'describr' ),
        10 => /*translators: City.*/ __( 'Santa Cruz del Sur', 'describr' ),
        11 => /*translators: City.*/ __( 'Sibanicú', 'describr' ),
        12 => /*translators: City.*/ __( 'Vertientes', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cienfuegos Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abreus', 'describr' ),
        1 => /*translators: City.*/ __( 'Aguada de Pasajeros', 'describr' ),
        2 => /*translators: City.*/ __( 'Cienfuegos', 'describr' ),
        3 => /*translators: City.*/ __( 'Cruces', 'describr' ),
        4 => /*translators: City.*/ __( 'Cumanayagua', 'describr' ),
        5 => /*translators: City.*/ __( 'Lajas', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Abreus', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de Cienfuegos', 'describr' ),
        8 => /*translators: City.*/ __( 'Palmira', 'describr' ),
        9 => /*translators: City.*/ __( 'Rodas', 'describr' ),
      ),
    ),
  ),
  'NG' => 
  array (
    'JI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jigawa State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Babura', 'describr' ),
        1 => /*translators: City.*/ __( 'Birnin Kudu', 'describr' ),
        2 => /*translators: City.*/ __( 'Birniwa', 'describr' ),
        3 => /*translators: City.*/ __( 'Dutse', 'describr' ),
        4 => /*translators: City.*/ __( 'Gagarawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Gumel', 'describr' ),
        6 => /*translators: City.*/ __( 'Gwaram', 'describr' ),
        7 => /*translators: City.*/ __( 'Hadejia', 'describr' ),
        8 => /*translators: City.*/ __( 'Kafin Hausa', 'describr' ),
        9 => /*translators: City.*/ __( 'Kazaure', 'describr' ),
        10 => /*translators: City.*/ __( 'Kiyawa', 'describr' ),
        11 => /*translators: City.*/ __( 'Mallammaduri', 'describr' ),
        12 => /*translators: City.*/ __( 'Ringim', 'describr' ),
        13 => /*translators: City.*/ __( 'Samamiya', 'describr' ),
      ),
    ),
    'EN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Enugu State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adani', 'describr' ),
        1 => /*translators: City.*/ __( 'Ake-Eze', 'describr' ),
        2 => /*translators: City.*/ __( 'Aku', 'describr' ),
        3 => /*translators: City.*/ __( 'Amagunze', 'describr' ),
        4 => /*translators: City.*/ __( 'Awgu', 'describr' ),
        5 => /*translators: City.*/ __( 'Eha Amufu', 'describr' ),
        6 => /*translators: City.*/ __( 'Enugu', 'describr' ),
        7 => /*translators: City.*/ __( 'Enugu-Ezike', 'describr' ),
        8 => /*translators: City.*/ __( 'Ete', 'describr' ),
        9 => /*translators: City.*/ __( 'Ikem', 'describr' ),
        10 => /*translators: City.*/ __( 'Mberubu', 'describr' ),
        11 => /*translators: City.*/ __( 'Nsukka', 'describr' ),
        12 => /*translators: City.*/ __( 'Obolo-Eke (1)', 'describr' ),
        13 => /*translators: City.*/ __( 'Opi', 'describr' ),
        14 => /*translators: City.*/ __( 'Udi', 'describr' ),
      ),
    ),
    'KE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kebbi State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Argungu', 'describr' ),
        1 => /*translators: City.*/ __( 'Bagudo', 'describr' ),
        2 => /*translators: City.*/ __( 'Bena', 'describr' ),
        3 => /*translators: City.*/ __( 'Bin Yauri', 'describr' ),
        4 => /*translators: City.*/ __( 'Birnin Kebbi', 'describr' ),
        5 => /*translators: City.*/ __( 'Dabai', 'describr' ),
        6 => /*translators: City.*/ __( 'Dakingari', 'describr' ),
        7 => /*translators: City.*/ __( 'Gulma', 'describr' ),
        8 => /*translators: City.*/ __( 'Gwandu', 'describr' ),
        9 => /*translators: City.*/ __( 'Jega', 'describr' ),
        10 => /*translators: City.*/ __( 'Kamba', 'describr' ),
        11 => /*translators: City.*/ __( 'Kangiwa', 'describr' ),
        12 => /*translators: City.*/ __( 'Kende', 'describr' ),
        13 => /*translators: City.*/ __( 'Mahuta', 'describr' ),
        14 => /*translators: City.*/ __( 'Maiyama', 'describr' ),
        15 => /*translators: City.*/ __( 'Shanga', 'describr' ),
        16 => /*translators: City.*/ __( 'Wasagu', 'describr' ),
        17 => /*translators: City.*/ __( 'Zuru', 'describr' ),
      ),
    ),
    'BE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Benue State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aliade', 'describr' ),
        1 => /*translators: City.*/ __( 'Boju', 'describr' ),
        2 => /*translators: City.*/ __( 'Igbor', 'describr' ),
        3 => /*translators: City.*/ __( 'Makurdi', 'describr' ),
        4 => /*translators: City.*/ __( 'Ochobo', 'describr' ),
        5 => /*translators: City.*/ __( 'Otukpa', 'describr' ),
        6 => /*translators: City.*/ __( 'Takum', 'describr' ),
        7 => /*translators: City.*/ __( 'Ugbokpo', 'describr' ),
        8 => /*translators: City.*/ __( 'Yandev', 'describr' ),
        9 => /*translators: City.*/ __( 'Zaki Biam', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sokoto State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Binji', 'describr' ),
        1 => /*translators: City.*/ __( 'Dange', 'describr' ),
        2 => /*translators: City.*/ __( 'Gandi', 'describr' ),
        3 => /*translators: City.*/ __( 'Goronyo', 'describr' ),
        4 => /*translators: City.*/ __( 'Gwadabawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Illela', 'describr' ),
        6 => /*translators: City.*/ __( 'Rabah', 'describr' ),
        7 => /*translators: City.*/ __( 'Sokoto', 'describr' ),
        8 => /*translators: City.*/ __( 'Tambuwal', 'describr' ),
        9 => /*translators: City.*/ __( 'Wurno', 'describr' ),
      ),
    ),
    'FC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Federal Capital Territory', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abuja', 'describr' ),
        1 => /*translators: City.*/ __( 'Kuje', 'describr' ),
        2 => /*translators: City.*/ __( 'Kwali', 'describr' ),
        3 => /*translators: City.*/ __( 'Madala', 'describr' ),
      ),
    ),
    'KD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kaduna State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anchau', 'describr' ),
        1 => /*translators: City.*/ __( 'Burumburum', 'describr' ),
        2 => /*translators: City.*/ __( 'Dutsen Wai', 'describr' ),
        3 => /*translators: City.*/ __( 'Hunkuyi', 'describr' ),
        4 => /*translators: City.*/ __( 'Kachia', 'describr' ),
        5 => /*translators: City.*/ __( 'Kaduna', 'describr' ),
        6 => /*translators: City.*/ __( 'Kafanchan', 'describr' ),
        7 => /*translators: City.*/ __( 'Kagoro', 'describr' ),
        8 => /*translators: City.*/ __( 'Kajuru', 'describr' ),
        9 => /*translators: City.*/ __( 'Kujama', 'describr' ),
        10 => /*translators: City.*/ __( 'Lere', 'describr' ),
        11 => /*translators: City.*/ __( 'Mando', 'describr' ),
        12 => /*translators: City.*/ __( 'Saminaka', 'describr' ),
        13 => /*translators: City.*/ __( 'Soba', 'describr' ),
        14 => /*translators: City.*/ __( 'Sofo-Birnin-Gwari', 'describr' ),
        15 => /*translators: City.*/ __( 'Zaria', 'describr' ),
      ),
    ),
    'KW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kwara State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajasse Ipo', 'describr' ),
        1 => /*translators: City.*/ __( 'Bode Saadu', 'describr' ),
        2 => /*translators: City.*/ __( 'Gwasero', 'describr' ),
        3 => /*translators: City.*/ __( 'Ilorin', 'describr' ),
        4 => /*translators: City.*/ __( 'Jebba', 'describr' ),
        5 => /*translators: City.*/ __( 'Kaiama', 'describr' ),
        6 => /*translators: City.*/ __( 'Lafiagi', 'describr' ),
        7 => /*translators: City.*/ __( 'Offa', 'describr' ),
        8 => /*translators: City.*/ __( 'Okuta', 'describr' ),
        9 => /*translators: City.*/ __( 'Omu-Aran', 'describr' ),
        10 => /*translators: City.*/ __( 'Patigi', 'describr' ),
        11 => /*translators: City.*/ __( 'Suya', 'describr' ),
        12 => /*translators: City.*/ __( 'Yashikera', 'describr' ),
      ),
    ),
    'OY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oyo State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ago Are', 'describr' ),
        1 => /*translators: City.*/ __( 'Alapa', 'describr' ),
        2 => /*translators: City.*/ __( 'Fiditi', 'describr' ),
        3 => /*translators: City.*/ __( 'Ibadan', 'describr' ),
        4 => /*translators: City.*/ __( 'Igbeti', 'describr' ),
        5 => /*translators: City.*/ __( 'Igbo-Ora', 'describr' ),
        6 => /*translators: City.*/ __( 'Igboho', 'describr' ),
        7 => /*translators: City.*/ __( 'Kisi', 'describr' ),
        8 => /*translators: City.*/ __( 'Lalupon', 'describr' ),
        9 => /*translators: City.*/ __( 'Ogbomoso', 'describr' ),
        10 => /*translators: City.*/ __( 'Okeho', 'describr' ),
        11 => /*translators: City.*/ __( 'Orita Eruwa', 'describr' ),
        12 => /*translators: City.*/ __( 'Oyo', 'describr' ),
        13 => /*translators: City.*/ __( 'Saki', 'describr' ),
      ),
    ),
    'YO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yobe State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Damaturu', 'describr' ),
        1 => /*translators: City.*/ __( 'Dankalwa', 'describr' ),
        2 => /*translators: City.*/ __( 'Dapchi', 'describr' ),
        3 => /*translators: City.*/ __( 'Daura', 'describr' ),
        4 => /*translators: City.*/ __( 'Fika', 'describr' ),
        5 => /*translators: City.*/ __( 'Gashua', 'describr' ),
        6 => /*translators: City.*/ __( 'Geidam', 'describr' ),
        7 => /*translators: City.*/ __( 'Goniri', 'describr' ),
        8 => /*translators: City.*/ __( 'Gorgoram', 'describr' ),
        9 => /*translators: City.*/ __( 'Gujba', 'describr' ),
        10 => /*translators: City.*/ __( 'Gwio Kura', 'describr' ),
        11 => /*translators: City.*/ __( 'Kumagunnam', 'describr' ),
        12 => /*translators: City.*/ __( 'Lajere', 'describr' ),
        13 => /*translators: City.*/ __( 'Machina', 'describr' ),
        14 => /*translators: City.*/ __( 'Nguru', 'describr' ),
        15 => /*translators: City.*/ __( 'Potiskum', 'describr' ),
      ),
    ),
    'KO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kogi State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abocho', 'describr' ),
        1 => /*translators: City.*/ __( 'Adoru', 'describr' ),
        2 => /*translators: City.*/ __( 'Ankpa', 'describr' ),
        3 => /*translators: City.*/ __( 'Bugana', 'describr' ),
        4 => /*translators: City.*/ __( 'Dekina', 'describr' ),
        5 => /*translators: City.*/ __( 'Egbe', 'describr' ),
        6 => /*translators: City.*/ __( 'Icheu', 'describr' ),
        7 => /*translators: City.*/ __( 'Idah', 'describr' ),
        8 => /*translators: City.*/ __( 'Isanlu-Itedoijowa', 'describr' ),
        9 => /*translators: City.*/ __( 'Kabba', 'describr' ),
        10 => /*translators: City.*/ __( 'Koton-Karfe', 'describr' ),
        11 => /*translators: City.*/ __( 'Lokoja', 'describr' ),
        12 => /*translators: City.*/ __( 'Ogaminana', 'describr' ),
        13 => /*translators: City.*/ __( 'Ogurugu', 'describr' ),
        14 => /*translators: City.*/ __( 'Okene', 'describr' ),
      ),
    ),
    'ZA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zamfara State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anka', 'describr' ),
        1 => /*translators: City.*/ __( 'Dan Sadau', 'describr' ),
        2 => /*translators: City.*/ __( 'Gummi', 'describr' ),
        3 => /*translators: City.*/ __( 'Gusau', 'describr' ),
        4 => /*translators: City.*/ __( 'Kaura Namoda', 'describr' ),
        5 => /*translators: City.*/ __( 'Kwatarkwashi', 'describr' ),
        6 => /*translators: City.*/ __( 'Maru', 'describr' ),
        7 => /*translators: City.*/ __( 'Moriki', 'describr' ),
        8 => /*translators: City.*/ __( 'Sauri', 'describr' ),
        9 => /*translators: City.*/ __( 'Tsafe', 'describr' ),
      ),
    ),
    'KN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kano State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dan Gora', 'describr' ),
        1 => /*translators: City.*/ __( 'Gaya', 'describr' ),
        2 => /*translators: City.*/ __( 'Kano', 'describr' ),
      ),
    ),
    'NA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nasarawa State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Buga', 'describr' ),
        1 => /*translators: City.*/ __( 'Doma', 'describr' ),
        2 => /*translators: City.*/ __( 'Keffi', 'describr' ),
        3 => /*translators: City.*/ __( 'Lafia', 'describr' ),
        4 => /*translators: City.*/ __( 'Nasarawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Wamba', 'describr' ),
      ),
    ),
    'PL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Plateau State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amper', 'describr' ),
        1 => /*translators: City.*/ __( 'Bukuru', 'describr' ),
        2 => /*translators: City.*/ __( 'Dengi', 'describr' ),
        3 => /*translators: City.*/ __( 'Jos', 'describr' ),
        4 => /*translators: City.*/ __( 'Kwolla', 'describr' ),
        5 => /*translators: City.*/ __( 'Langtang', 'describr' ),
        6 => /*translators: City.*/ __( 'Pankshin', 'describr' ),
        7 => /*translators: City.*/ __( 'Panyam', 'describr' ),
        8 => /*translators: City.*/ __( 'Vom', 'describr' ),
        9 => /*translators: City.*/ __( 'Yelwa', 'describr' ),
      ),
    ),
    'AB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Abia State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aba', 'describr' ),
        1 => /*translators: City.*/ __( 'Amaigbo', 'describr' ),
        2 => /*translators: City.*/ __( 'Arochukwu', 'describr' ),
        3 => /*translators: City.*/ __( 'Bende', 'describr' ),
        4 => /*translators: City.*/ __( 'Ohafia-Ifigh', 'describr' ),
        5 => /*translators: City.*/ __( 'Umuahia', 'describr' ),
      ),
    ),
    'AK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Akwa Ibom State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Eket', 'describr' ),
        1 => /*translators: City.*/ __( 'Esuk Oron', 'describr' ),
        2 => /*translators: City.*/ __( 'Ikot Ekpene', 'describr' ),
        3 => /*translators: City.*/ __( 'Itu', 'describr' ),
        4 => /*translators: City.*/ __( 'Uyo', 'describr' ),
      ),
    ),
    'BY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bayelsa State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amassoma', 'describr' ),
        1 => /*translators: City.*/ __( 'Twon-Brass', 'describr' ),
        2 => /*translators: City.*/ __( 'Yenagoa', 'describr' ),
      ),
    ),
    'LA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lagos', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Apapa', 'describr' ),
        1 => /*translators: City.*/ __( 'Badagry', 'describr' ),
        2 => /*translators: City.*/ __( 'Ebute Ikorodu', 'describr' ),
        3 => /*translators: City.*/ __( 'Ejirin', 'describr' ),
        4 => /*translators: City.*/ __( 'Epe', 'describr' ),
        5 => /*translators: City.*/ __( 'Ikeja', 'describr' ),
        6 => /*translators: City.*/ __( 'Lagos', 'describr' ),
        7 => /*translators: City.*/ __( 'Makoko', 'describr' ),
      ),
    ),
    'BO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Borno State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bama', 'describr' ),
        1 => /*translators: City.*/ __( 'Benisheikh', 'describr' ),
        2 => /*translators: City.*/ __( 'Biu', 'describr' ),
        3 => /*translators: City.*/ __( 'Bornu Yassu', 'describr' ),
        4 => /*translators: City.*/ __( 'Damasak', 'describr' ),
        5 => /*translators: City.*/ __( 'Damboa', 'describr' ),
        6 => /*translators: City.*/ __( 'Dikwa', 'describr' ),
        7 => /*translators: City.*/ __( 'Gamboru', 'describr' ),
        8 => /*translators: City.*/ __( 'Gwoza', 'describr' ),
        9 => /*translators: City.*/ __( 'Kukawa', 'describr' ),
        10 => /*translators: City.*/ __( 'Magumeri', 'describr' ),
        11 => /*translators: City.*/ __( 'Maiduguri', 'describr' ),
        12 => /*translators: City.*/ __( 'Marte', 'describr' ),
        13 => /*translators: City.*/ __( 'Miringa', 'describr' ),
        14 => /*translators: City.*/ __( 'Monguno', 'describr' ),
        15 => /*translators: City.*/ __( 'Ngala', 'describr' ),
        16 => /*translators: City.*/ __( 'Shaffa', 'describr' ),
        17 => /*translators: City.*/ __( 'Shani', 'describr' ),
        18 => /*translators: City.*/ __( 'Tokombere', 'describr' ),
        19 => /*translators: City.*/ __( 'Uba', 'describr' ),
        20 => /*translators: City.*/ __( 'Wuyo', 'describr' ),
        21 => /*translators: City.*/ __( 'Yajiwa', 'describr' ),
      ),
    ),
    'IM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Imo State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Iho', 'describr' ),
        1 => /*translators: City.*/ __( 'Oguta', 'describr' ),
        2 => /*translators: City.*/ __( 'Okigwe', 'describr' ),
        3 => /*translators: City.*/ __( 'Orlu', 'describr' ),
        4 => /*translators: City.*/ __( 'Orodo', 'describr' ),
        5 => /*translators: City.*/ __( 'Owerri', 'describr' ),
      ),
    ),
    'EK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ekiti State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ado-Ekiti', 'describr' ),
        1 => /*translators: City.*/ __( 'Aramoko-Ekiti', 'describr' ),
        2 => /*translators: City.*/ __( 'Efon-Alaaye', 'describr' ),
        3 => /*translators: City.*/ __( 'Emure-Ekiti', 'describr' ),
        4 => /*translators: City.*/ __( 'Ifaki', 'describr' ),
        5 => /*translators: City.*/ __( 'Igbara-Odo', 'describr' ),
        6 => /*translators: City.*/ __( 'Igede-Ekiti', 'describr' ),
        7 => /*translators: City.*/ __( 'Ijero-Ekiti', 'describr' ),
        8 => /*translators: City.*/ __( 'Ikere-Ekiti', 'describr' ),
        9 => /*translators: City.*/ __( 'Ipoti', 'describr' ),
        10 => /*translators: City.*/ __( 'Ise-Ekiti', 'describr' ),
        11 => /*translators: City.*/ __( 'Oke Ila', 'describr' ),
        12 => /*translators: City.*/ __( 'Omuo-Ekiti', 'describr' ),
      ),
    ),
    'GO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gombe State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akko', 'describr' ),
        1 => /*translators: City.*/ __( 'Bara', 'describr' ),
        2 => /*translators: City.*/ __( 'Billiri', 'describr' ),
        3 => /*translators: City.*/ __( 'Dadiya', 'describr' ),
        4 => /*translators: City.*/ __( 'Deba', 'describr' ),
        5 => /*translators: City.*/ __( 'Dukku', 'describr' ),
        6 => /*translators: City.*/ __( 'Garko', 'describr' ),
        7 => /*translators: City.*/ __( 'Gombe', 'describr' ),
        8 => /*translators: City.*/ __( 'Hinna', 'describr' ),
        9 => /*translators: City.*/ __( 'Kafarati', 'describr' ),
        10 => /*translators: City.*/ __( 'Kaltungo', 'describr' ),
        11 => /*translators: City.*/ __( 'Kumo', 'describr' ),
        12 => /*translators: City.*/ __( 'Nafada', 'describr' ),
        13 => /*translators: City.*/ __( 'Pindiga', 'describr' ),
      ),
    ),
    'EB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ebonyi State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abakaliki', 'describr' ),
        1 => /*translators: City.*/ __( 'Afikpo', 'describr' ),
        2 => /*translators: City.*/ __( 'Effium', 'describr' ),
        3 => /*translators: City.*/ __( 'Ezza-Ohu', 'describr' ),
        4 => /*translators: City.*/ __( 'Isieke', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bauchi State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Azare', 'describr' ),
        1 => /*translators: City.*/ __( 'Bauchi', 'describr' ),
        2 => /*translators: City.*/ __( 'Boi', 'describr' ),
        3 => /*translators: City.*/ __( 'Bununu', 'describr' ),
        4 => /*translators: City.*/ __( 'Darazo', 'describr' ),
        5 => /*translators: City.*/ __( 'Dass', 'describr' ),
        6 => /*translators: City.*/ __( 'Dindima', 'describr' ),
        7 => /*translators: City.*/ __( 'Disina', 'describr' ),
        8 => /*translators: City.*/ __( 'Gabarin', 'describr' ),
        9 => /*translators: City.*/ __( 'Gwaram', 'describr' ),
        10 => /*translators: City.*/ __( 'Kari', 'describr' ),
        11 => /*translators: City.*/ __( 'Lame', 'describr' ),
        12 => /*translators: City.*/ __( 'Lere', 'describr' ),
        13 => /*translators: City.*/ __( 'Madara', 'describr' ),
        14 => /*translators: City.*/ __( 'Misau', 'describr' ),
        15 => /*translators: City.*/ __( 'Sade', 'describr' ),
        16 => /*translators: City.*/ __( 'Yamrat', 'describr' ),
        17 => /*translators: City.*/ __( 'Yanda Bayo', 'describr' ),
        18 => /*translators: City.*/ __( 'Yuli', 'describr' ),
        19 => /*translators: City.*/ __( 'Zadawa', 'describr' ),
        20 => /*translators: City.*/ __( 'Zalanga', 'describr' ),
      ),
    ),
    'KT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Katsina State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Danja', 'describr' ),
        1 => /*translators: City.*/ __( 'Dankama', 'describr' ),
        2 => /*translators: City.*/ __( 'Daura', 'describr' ),
        3 => /*translators: City.*/ __( 'Dutsin-Ma', 'describr' ),
        4 => /*translators: City.*/ __( 'Funtua', 'describr' ),
        5 => /*translators: City.*/ __( 'Gora', 'describr' ),
        6 => /*translators: City.*/ __( 'Jibia', 'describr' ),
        7 => /*translators: City.*/ __( 'Jikamshi', 'describr' ),
        8 => /*translators: City.*/ __( 'Kankara', 'describr' ),
        9 => /*translators: City.*/ __( 'Katsina', 'describr' ),
        10 => /*translators: City.*/ __( 'Mashi', 'describr' ),
        11 => /*translators: City.*/ __( 'Ruma', 'describr' ),
        12 => /*translators: City.*/ __( 'Runka', 'describr' ),
        13 => /*translators: City.*/ __( 'Wagini', 'describr' ),
      ),
    ),
    'CR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cross River State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akankpa', 'describr' ),
        1 => /*translators: City.*/ __( 'Calabar', 'describr' ),
        2 => /*translators: City.*/ __( 'Gakem', 'describr' ),
        3 => /*translators: City.*/ __( 'Ikang', 'describr' ),
        4 => /*translators: City.*/ __( 'Ugep', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anambra State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agulu', 'describr' ),
        1 => /*translators: City.*/ __( 'Atani', 'describr' ),
        2 => /*translators: City.*/ __( 'Awka', 'describr' ),
        3 => /*translators: City.*/ __( 'Enugu-Ukwu', 'describr' ),
        4 => /*translators: City.*/ __( 'Igbo-Ukwu', 'describr' ),
        5 => /*translators: City.*/ __( 'Ihiala', 'describr' ),
        6 => /*translators: City.*/ __( 'Nkpor', 'describr' ),
        7 => /*translators: City.*/ __( 'Nnewi', 'describr' ),
        8 => /*translators: City.*/ __( 'Onitsha', 'describr' ),
        9 => /*translators: City.*/ __( 'Ozubulu', 'describr' ),
        10 => /*translators: City.*/ __( 'Uga', 'describr' ),
        11 => /*translators: City.*/ __( 'Uruobo-Okija', 'describr' ),
      ),
    ),
    'DE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Delta State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abraka', 'describr' ),
        1 => /*translators: City.*/ __( 'Agbor', 'describr' ),
        2 => /*translators: City.*/ __( 'Asaba', 'describr' ),
        3 => /*translators: City.*/ __( 'Bomadi', 'describr' ),
        4 => /*translators: City.*/ __( 'Burutu', 'describr' ),
        5 => /*translators: City.*/ __( 'Kwale', 'describr' ),
        6 => /*translators: City.*/ __( 'Obiaruku', 'describr' ),
        7 => /*translators: City.*/ __( 'Ogwashi-Uku', 'describr' ),
        8 => /*translators: City.*/ __( 'Orerokpe', 'describr' ),
        9 => /*translators: City.*/ __( 'Patani', 'describr' ),
        10 => /*translators: City.*/ __( 'Sapele', 'describr' ),
        11 => /*translators: City.*/ __( 'Ughelli', 'describr' ),
        12 => /*translators: City.*/ __( 'Umunede', 'describr' ),
        13 => /*translators: City.*/ __( 'Warri', 'describr' ),
      ),
    ),
    'NI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Niger State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Auna', 'describr' ),
        1 => /*translators: City.*/ __( 'Babana', 'describr' ),
        2 => /*translators: City.*/ __( 'Badeggi', 'describr' ),
        3 => /*translators: City.*/ __( 'Baro', 'describr' ),
        4 => /*translators: City.*/ __( 'Bokani', 'describr' ),
        5 => /*translators: City.*/ __( 'Duku', 'describr' ),
        6 => /*translators: City.*/ __( 'Ibeto', 'describr' ),
        7 => /*translators: City.*/ __( 'Konkwesso', 'describr' ),
        8 => /*translators: City.*/ __( 'Kontagora', 'describr' ),
        9 => /*translators: City.*/ __( 'Kusheriki', 'describr' ),
        10 => /*translators: City.*/ __( 'Kuta', 'describr' ),
        11 => /*translators: City.*/ __( 'Lapai', 'describr' ),
        12 => /*translators: City.*/ __( 'Minna', 'describr' ),
        13 => /*translators: City.*/ __( 'New Shagunnu', 'describr' ),
        14 => /*translators: City.*/ __( 'Suleja', 'describr' ),
        15 => /*translators: City.*/ __( 'Tegina', 'describr' ),
        16 => /*translators: City.*/ __( 'Ukata', 'describr' ),
        17 => /*translators: City.*/ __( 'Wawa', 'describr' ),
        18 => /*translators: City.*/ __( 'Zungeru', 'describr' ),
      ),
    ),
    'ED' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Edo State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agenebode', 'describr' ),
        1 => /*translators: City.*/ __( 'Auchi', 'describr' ),
        2 => /*translators: City.*/ __( 'Benin City', 'describr' ),
        3 => /*translators: City.*/ __( 'Ekpoma', 'describr' ),
        4 => /*translators: City.*/ __( 'Igarra', 'describr' ),
        5 => /*translators: City.*/ __( 'Illushi', 'describr' ),
        6 => /*translators: City.*/ __( 'Siluko', 'describr' ),
        7 => /*translators: City.*/ __( 'Ubiaja', 'describr' ),
        8 => /*translators: City.*/ __( 'Uromi', 'describr' ),
      ),
    ),
    'TA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taraba State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baissa', 'describr' ),
        1 => /*translators: City.*/ __( 'Beli', 'describr' ),
        2 => /*translators: City.*/ __( 'Gassol', 'describr' ),
        3 => /*translators: City.*/ __( 'Gembu', 'describr' ),
        4 => /*translators: City.*/ __( 'Ibi', 'describr' ),
        5 => /*translators: City.*/ __( 'Jalingo', 'describr' ),
        6 => /*translators: City.*/ __( 'Lau', 'describr' ),
        7 => /*translators: City.*/ __( 'Mutum Biyu', 'describr' ),
        8 => /*translators: City.*/ __( 'Riti', 'describr' ),
        9 => /*translators: City.*/ __( 'Wukari', 'describr' ),
      ),
    ),
    'AD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Adamawa State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ganye', 'describr' ),
        1 => /*translators: City.*/ __( 'Gombi', 'describr' ),
        2 => /*translators: City.*/ __( 'Holma', 'describr' ),
        3 => /*translators: City.*/ __( 'Jimeta', 'describr' ),
        4 => /*translators: City.*/ __( 'Madagali', 'describr' ),
        5 => /*translators: City.*/ __( 'Mayo-Belwa', 'describr' ),
        6 => /*translators: City.*/ __( 'Mubi', 'describr' ),
        7 => /*translators: City.*/ __( 'Ngurore', 'describr' ),
        8 => /*translators: City.*/ __( 'Numan', 'describr' ),
        9 => /*translators: City.*/ __( 'Toungo', 'describr' ),
        10 => /*translators: City.*/ __( 'Yola', 'describr' ),
      ),
    ),
    'ON' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ondo State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agbabu', 'describr' ),
        1 => /*translators: City.*/ __( 'Akure', 'describr' ),
        2 => /*translators: City.*/ __( 'Idanre', 'describr' ),
        3 => /*translators: City.*/ __( 'Ifon', 'describr' ),
        4 => /*translators: City.*/ __( 'Ilare', 'describr' ),
        5 => /*translators: City.*/ __( 'Ode', 'describr' ),
        6 => /*translators: City.*/ __( 'Ondo', 'describr' ),
        7 => /*translators: City.*/ __( 'Ore', 'describr' ),
        8 => /*translators: City.*/ __( 'Owo', 'describr' ),
      ),
    ),
    'OS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Osun State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Apomu', 'describr' ),
        1 => /*translators: City.*/ __( 'Ejigbo', 'describr' ),
        2 => /*translators: City.*/ __( 'Gbongan', 'describr' ),
        3 => /*translators: City.*/ __( 'Ijebu-Jesa', 'describr' ),
        4 => /*translators: City.*/ __( 'Ikire', 'describr' ),
        5 => /*translators: City.*/ __( 'Ikirun', 'describr' ),
        6 => /*translators: City.*/ __( 'Ila Orangun', 'describr' ),
        7 => /*translators: City.*/ __( 'Ile-Ife', 'describr' ),
        8 => /*translators: City.*/ __( 'Ilesa', 'describr' ),
        9 => /*translators: City.*/ __( 'Ilobu', 'describr' ),
        10 => /*translators: City.*/ __( 'Inisa', 'describr' ),
        11 => /*translators: City.*/ __( 'Iwo', 'describr' ),
        12 => /*translators: City.*/ __( 'Modakeke', 'describr' ),
        13 => /*translators: City.*/ __( 'Oke Mesi', 'describr' ),
        14 => /*translators: City.*/ __( 'Olupona', 'describr' ),
        15 => /*translators: City.*/ __( 'Osogbo', 'describr' ),
        16 => /*translators: City.*/ __( 'Otan Ayegbaju', 'describr' ),
        17 => /*translators: City.*/ __( 'Oyan', 'describr' ),
      ),
    ),
    'OG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ogun State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abeokuta', 'describr' ),
        1 => /*translators: City.*/ __( 'Ado Odo', 'describr' ),
        2 => /*translators: City.*/ __( 'Idi Iroko', 'describr' ),
        3 => /*translators: City.*/ __( 'Ifo', 'describr' ),
        4 => /*translators: City.*/ __( 'Ijebu-Ife', 'describr' ),
        5 => /*translators: City.*/ __( 'Ijebu-Igbo', 'describr' ),
        6 => /*translators: City.*/ __( 'Ijebu-Ode', 'describr' ),
        7 => /*translators: City.*/ __( 'Ilaro', 'describr' ),
        8 => /*translators: City.*/ __( 'Imeko', 'describr' ),
        9 => /*translators: City.*/ __( 'Iperu', 'describr' ),
        10 => /*translators: City.*/ __( 'Isara', 'describr' ),
        11 => /*translators: City.*/ __( 'Owode', 'describr' ),
      ),
    ),
  ),
  'UG' => 
  array (
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adjumani', 'describr' ),
        1 => /*translators: City.*/ __( 'Amudat', 'describr' ),
        2 => /*translators: City.*/ __( 'Apac', 'describr' ),
        3 => /*translators: City.*/ __( 'Arua', 'describr' ),
        4 => /*translators: City.*/ __( 'Gulu', 'describr' ),
        5 => /*translators: City.*/ __( 'Kitgum', 'describr' ),
        6 => /*translators: City.*/ __( 'Kotido', 'describr' ),
        7 => /*translators: City.*/ __( 'Lira', 'describr' ),
        8 => /*translators: City.*/ __( 'Moroto', 'describr' ),
        9 => /*translators: City.*/ __( 'Moyo', 'describr' ),
        10 => /*translators: City.*/ __( 'Nebbi', 'describr' ),
        11 => /*translators: City.*/ __( 'Otuke District', 'describr' ),
        12 => /*translators: City.*/ __( 'Oyam District', 'describr' ),
        13 => /*translators: City.*/ __( 'Pader', 'describr' ),
        14 => /*translators: City.*/ __( 'Pader Palwo', 'describr' ),
        15 => /*translators: City.*/ __( 'Paidha', 'describr' ),
        16 => /*translators: City.*/ __( 'Yumbe', 'describr' ),
      ),
    ),
    'W' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bundibugyo', 'describr' ),
        1 => /*translators: City.*/ __( 'Bwizibwera', 'describr' ),
        2 => /*translators: City.*/ __( 'Fort Portal', 'describr' ),
        3 => /*translators: City.*/ __( 'Hoima', 'describr' ),
        4 => /*translators: City.*/ __( 'Ibanda', 'describr' ),
        5 => /*translators: City.*/ __( 'Ibanda District', 'describr' ),
        6 => /*translators: City.*/ __( 'Kabale', 'describr' ),
        7 => /*translators: City.*/ __( 'Kagadi', 'describr' ),
        8 => /*translators: City.*/ __( 'Kamwenge', 'describr' ),
        9 => /*translators: City.*/ __( 'Kanungu', 'describr' ),
        10 => /*translators: City.*/ __( 'Kasese', 'describr' ),
        11 => /*translators: City.*/ __( 'Kibale', 'describr' ),
        12 => /*translators: City.*/ __( 'Kigorobya', 'describr' ),
        13 => /*translators: City.*/ __( 'Kilembe', 'describr' ),
        14 => /*translators: City.*/ __( 'Kiruhura', 'describr' ),
        15 => /*translators: City.*/ __( 'Kisoro', 'describr' ),
        16 => /*translators: City.*/ __( 'Kyenjojo', 'describr' ),
        17 => /*translators: City.*/ __( 'Margherita', 'describr' ),
        18 => /*translators: City.*/ __( 'Masindi', 'describr' ),
        19 => /*translators: City.*/ __( 'Masindi Port', 'describr' ),
        20 => /*translators: City.*/ __( 'Mbarara', 'describr' ),
        21 => /*translators: City.*/ __( 'Muhororo', 'describr' ),
        22 => /*translators: City.*/ __( 'Ntungamo', 'describr' ),
        23 => /*translators: City.*/ __( 'Nyachera', 'describr' ),
        24 => /*translators: City.*/ __( 'Rukungiri', 'describr' ),
      ),
    ),
    'E' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bugembe', 'describr' ),
        1 => /*translators: City.*/ __( 'Bugiri', 'describr' ),
        2 => /*translators: City.*/ __( 'Bukwa District', 'describr' ),
        3 => /*translators: City.*/ __( 'Bulambuli District', 'describr' ),
        4 => /*translators: City.*/ __( 'Busembatia', 'describr' ),
        5 => /*translators: City.*/ __( 'Busia', 'describr' ),
        6 => /*translators: City.*/ __( 'Buwenge', 'describr' ),
        7 => /*translators: City.*/ __( 'Iganga', 'describr' ),
        8 => /*translators: City.*/ __( 'Jinja', 'describr' ),
        9 => /*translators: City.*/ __( 'Kamuli', 'describr' ),
        10 => /*translators: City.*/ __( 'Kapchorwa', 'describr' ),
        11 => /*translators: City.*/ __( 'Kibuku District', 'describr' ),
        12 => /*translators: City.*/ __( 'Kumi', 'describr' ),
        13 => /*translators: City.*/ __( 'Mayuge', 'describr' ),
        14 => /*translators: City.*/ __( 'Mbale', 'describr' ),
        15 => /*translators: City.*/ __( 'Pallisa', 'describr' ),
        16 => /*translators: City.*/ __( 'Sironko', 'describr' ),
        17 => /*translators: City.*/ __( 'Soroti', 'describr' ),
        18 => /*translators: City.*/ __( 'Tororo', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bukomansimbi District', 'describr' ),
        1 => /*translators: City.*/ __( 'Buvuma District', 'describr' ),
        2 => /*translators: City.*/ __( 'Bweyogerere', 'describr' ),
        3 => /*translators: City.*/ __( 'Byakabanda', 'describr' ),
        4 => /*translators: City.*/ __( 'Entebbe', 'describr' ),
        5 => /*translators: City.*/ __( 'Gomba District', 'describr' ),
        6 => /*translators: City.*/ __( 'Kajansi', 'describr' ),
        7 => /*translators: City.*/ __( 'Kampala', 'describr' ),
        8 => /*translators: City.*/ __( 'Kampala District', 'describr' ),
        9 => /*translators: City.*/ __( 'Kanoni', 'describr' ),
        10 => /*translators: City.*/ __( 'Kayunga', 'describr' ),
        11 => /*translators: City.*/ __( 'Kiboga', 'describr' ),
        12 => /*translators: City.*/ __( 'Kireka', 'describr' ),
        13 => /*translators: City.*/ __( 'Kyotera', 'describr' ),
        14 => /*translators: City.*/ __( 'Lugazi', 'describr' ),
        15 => /*translators: City.*/ __( 'Luwero', 'describr' ),
        16 => /*translators: City.*/ __( 'Lyantonde', 'describr' ),
        17 => /*translators: City.*/ __( 'Masaka', 'describr' ),
        18 => /*translators: City.*/ __( 'Mityana', 'describr' ),
        19 => /*translators: City.*/ __( 'Mpigi', 'describr' ),
        20 => /*translators: City.*/ __( 'Mubende', 'describr' ),
        21 => /*translators: City.*/ __( 'Mubende District', 'describr' ),
        22 => /*translators: City.*/ __( 'Mukono', 'describr' ),
        23 => /*translators: City.*/ __( 'Nakasongola', 'describr' ),
        24 => /*translators: City.*/ __( 'Namasuba', 'describr' ),
        25 => /*translators: City.*/ __( 'Njeru', 'describr' ),
        26 => /*translators: City.*/ __( 'Sembabule', 'describr' ),
        27 => /*translators: City.*/ __( 'Wakiso', 'describr' ),
        28 => /*translators: City.*/ __( 'Wakiso District', 'describr' ),
        29 => /*translators: City.*/ __( 'Wobulenzi', 'describr' ),
      ),
    ),
  ),
  'LI' => 
  array (
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Schellenberg', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Schellenberg', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Schaan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Schaan', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eschen', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Eschen', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ruggell', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ruggell', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Planken', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Planken', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mauren', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mauren', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gamprin', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gamprin', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balzers', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balzers', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Triesen', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Triesen', 'describr' ),
      ),
    ),
  ),
  'BA' => 
  array (
    'BRC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brčko District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brka', 'describr' ),
        1 => /*translators: City.*/ __( 'Brčko', 'describr' ),
      ),
    ),
    'BIH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Federation of Bosnia and Herzegovina', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banovići', 'describr' ),
        1 => /*translators: City.*/ __( 'Barice', 'describr' ),
        2 => /*translators: City.*/ __( 'Bihać', 'describr' ),
        3 => /*translators: City.*/ __( 'Bijela', 'describr' ),
        4 => /*translators: City.*/ __( 'Bila', 'describr' ),
        5 => /*translators: City.*/ __( 'Blagaj', 'describr' ),
        6 => /*translators: City.*/ __( 'Bosanska Krupa', 'describr' ),
        7 => /*translators: City.*/ __( 'Bosanski Petrovac', 'describr' ),
        8 => /*translators: City.*/ __( 'Bosansko Grahovo', 'describr' ),
        9 => /*translators: City.*/ __( 'Breza', 'describr' ),
        10 => /*translators: City.*/ __( 'Bugojno', 'describr' ),
        11 => /*translators: City.*/ __( 'Busovača', 'describr' ),
        12 => /*translators: City.*/ __( 'Bužim', 'describr' ),
        13 => /*translators: City.*/ __( 'Cazin', 'describr' ),
        14 => /*translators: City.*/ __( 'Cim', 'describr' ),
        15 => /*translators: City.*/ __( 'Crnići', 'describr' ),
        16 => /*translators: City.*/ __( 'Divičani', 'describr' ),
        17 => /*translators: City.*/ __( 'Dobrinje', 'describr' ),
        18 => /*translators: City.*/ __( 'Domaljevac', 'describr' ),
        19 => /*translators: City.*/ __( 'Donja Dubica', 'describr' ),
        20 => /*translators: City.*/ __( 'Donja Mahala', 'describr' ),
        21 => /*translators: City.*/ __( 'Donja Međiđa', 'describr' ),
        22 => /*translators: City.*/ __( 'Donji Vakuf', 'describr' ),
        23 => /*translators: City.*/ __( 'Drežnica', 'describr' ),
        24 => /*translators: City.*/ __( 'Drinovci', 'describr' ),
        25 => /*translators: City.*/ __( 'Drvar', 'describr' ),
        26 => /*translators: City.*/ __( 'Dubrave Donje', 'describr' ),
        27 => /*translators: City.*/ __( 'Dubrave Gornje', 'describr' ),
        28 => /*translators: City.*/ __( 'Dubravica', 'describr' ),
        29 => /*translators: City.*/ __( 'Fojnica', 'describr' ),
        30 => /*translators: City.*/ __( 'Glamoč', 'describr' ),
        31 => /*translators: City.*/ __( 'Gnojnica', 'describr' ),
        32 => /*translators: City.*/ __( 'Goražde', 'describr' ),
        33 => /*translators: City.*/ __( 'Gorica', 'describr' ),
        34 => /*translators: City.*/ __( 'Gornja Breza', 'describr' ),
        35 => /*translators: City.*/ __( 'Gornja Koprivna', 'describr' ),
        36 => /*translators: City.*/ __( 'Gornja Tuzla', 'describr' ),
        37 => /*translators: City.*/ __( 'Gornje Moštre', 'describr' ),
        38 => /*translators: City.*/ __( 'Gornje Živinice', 'describr' ),
        39 => /*translators: City.*/ __( 'Gornji Vakuf', 'describr' ),
        40 => /*translators: City.*/ __( 'Gostovići', 'describr' ),
        41 => /*translators: City.*/ __( 'Gradačac', 'describr' ),
        42 => /*translators: City.*/ __( 'Gračanica', 'describr' ),
        43 => /*translators: City.*/ __( 'Gromiljak', 'describr' ),
        44 => /*translators: City.*/ __( 'Grude', 'describr' ),
        45 => /*translators: City.*/ __( 'Hadžići', 'describr' ),
        46 => /*translators: City.*/ __( 'Hercegovačko-Neretvanski Kanton', 'describr' ),
        47 => /*translators: City.*/ __( 'Hotonj', 'describr' ),
        48 => /*translators: City.*/ __( 'Ilijaš', 'describr' ),
        49 => /*translators: City.*/ __( 'Ilići', 'describr' ),
        50 => /*translators: City.*/ __( 'Izačić', 'describr' ),
        51 => /*translators: City.*/ __( 'Jablanica', 'describr' ),
        52 => /*translators: City.*/ __( 'Jajce', 'describr' ),
        53 => /*translators: City.*/ __( 'Jelah', 'describr' ),
        54 => /*translators: City.*/ __( 'Jezerski', 'describr' ),
        55 => /*translators: City.*/ __( 'Kakanj', 'describr' ),
        56 => /*translators: City.*/ __( 'Kanton Sarajevo', 'describr' ),
        57 => /*translators: City.*/ __( 'Karadaglije', 'describr' ),
        58 => /*translators: City.*/ __( 'Kačuni', 'describr' ),
        59 => /*translators: City.*/ __( 'Kiseljak', 'describr' ),
        60 => /*translators: City.*/ __( 'Kladanj', 'describr' ),
        61 => /*translators: City.*/ __( 'Ključ', 'describr' ),
        62 => /*translators: City.*/ __( 'Kobilja Glava', 'describr' ),
        63 => /*translators: City.*/ __( 'Konjic', 'describr' ),
        64 => /*translators: City.*/ __( 'Kovači', 'describr' ),
        65 => /*translators: City.*/ __( 'Kočerin', 'describr' ),
        66 => /*translators: City.*/ __( 'Liješnica', 'describr' ),
        67 => /*translators: City.*/ __( 'Livno', 'describr' ),
        68 => /*translators: City.*/ __( 'Ljubuški', 'describr' ),
        69 => /*translators: City.*/ __( 'Lokvine', 'describr' ),
        70 => /*translators: City.*/ __( 'Lukavac', 'describr' ),
        71 => /*translators: City.*/ __( 'Lukavica', 'describr' ),
        72 => /*translators: City.*/ __( 'Maglaj', 'describr' ),
        73 => /*translators: City.*/ __( 'Mahala', 'describr' ),
        74 => /*translators: City.*/ __( 'Mala Kladuša', 'describr' ),
        75 => /*translators: City.*/ __( 'Malešići', 'describr' ),
        76 => /*translators: City.*/ __( 'Mionica', 'describr' ),
        77 => /*translators: City.*/ __( 'Mostar', 'describr' ),
        78 => /*translators: City.*/ __( 'Mramor', 'describr' ),
        79 => /*translators: City.*/ __( 'Neum', 'describr' ),
        80 => /*translators: City.*/ __( 'Novi Travnik', 'describr' ),
        81 => /*translators: City.*/ __( 'Novi Šeher', 'describr' ),
        82 => /*translators: City.*/ __( 'Odžak', 'describr' ),
        83 => /*translators: City.*/ __( 'Olovo', 'describr' ),
        84 => /*translators: City.*/ __( 'Omanjska', 'describr' ),
        85 => /*translators: City.*/ __( 'Orahovica Donja', 'describr' ),
        86 => /*translators: City.*/ __( 'Orašac', 'describr' ),
        87 => /*translators: City.*/ __( 'Orašje', 'describr' ),
        88 => /*translators: City.*/ __( 'Orguz', 'describr' ),
        89 => /*translators: City.*/ __( 'Ostrožac', 'describr' ),
        90 => /*translators: City.*/ __( 'Otoka', 'describr' ),
        91 => /*translators: City.*/ __( 'Pajić Polje', 'describr' ),
        92 => /*translators: City.*/ __( 'Pazarić', 'describr' ),
        93 => /*translators: City.*/ __( 'Peći', 'describr' ),
        94 => /*translators: City.*/ __( 'Pećigrad', 'describr' ),
        95 => /*translators: City.*/ __( 'Pjanići', 'describr' ),
        96 => /*translators: City.*/ __( 'Podhum', 'describr' ),
        97 => /*translators: City.*/ __( 'Podzvizd', 'describr' ),
        98 => /*translators: City.*/ __( 'Polje', 'describr' ),
        99 => /*translators: City.*/ __( 'Polje-Bijela', 'describr' ),
        100 => /*translators: City.*/ __( 'Potoci', 'describr' ),
        101 => /*translators: City.*/ __( 'Prozor', 'describr' ),
        102 => /*translators: City.*/ __( 'Puračić', 'describr' ),
        103 => /*translators: City.*/ __( 'Radišići', 'describr' ),
        104 => /*translators: City.*/ __( 'Rodoč', 'describr' ),
        105 => /*translators: City.*/ __( 'Rumboci', 'describr' ),
        106 => /*translators: City.*/ __( 'Sanica', 'describr' ),
        107 => /*translators: City.*/ __( 'Sanski Most', 'describr' ),
        108 => /*translators: City.*/ __( 'Sapna', 'describr' ),
        109 => /*translators: City.*/ __( 'Sarajevo', 'describr' ),
        110 => /*translators: City.*/ __( 'Skokovi', 'describr' ),
        111 => /*translators: City.*/ __( 'Sladna', 'describr' ),
        112 => /*translators: City.*/ __( 'Solina', 'describr' ),
        113 => /*translators: City.*/ __( 'Srebrenik', 'describr' ),
        114 => /*translators: City.*/ __( 'Stijena', 'describr' ),
        115 => /*translators: City.*/ __( 'Stjepan-Polje', 'describr' ),
        116 => /*translators: City.*/ __( 'Stolac', 'describr' ),
        117 => /*translators: City.*/ __( 'Tasovčići', 'describr' ),
        118 => /*translators: City.*/ __( 'Tešanj', 'describr' ),
        119 => /*translators: City.*/ __( 'Tešanjka', 'describr' ),
        120 => /*translators: City.*/ __( 'Todorovo', 'describr' ),
        121 => /*translators: City.*/ __( 'Tojšići', 'describr' ),
        122 => /*translators: City.*/ __( 'Tomislavgrad', 'describr' ),
        123 => /*translators: City.*/ __( 'Travnik', 'describr' ),
        124 => /*translators: City.*/ __( 'Tržačka Raštela', 'describr' ),
        125 => /*translators: City.*/ __( 'Turbe', 'describr' ),
        126 => /*translators: City.*/ __( 'Tuzla', 'describr' ),
        127 => /*translators: City.*/ __( 'Ustikolina', 'describr' ),
        128 => /*translators: City.*/ __( 'Vareš', 'describr' ),
        129 => /*translators: City.*/ __( 'Varoška Rijeka', 'describr' ),
        130 => /*translators: City.*/ __( 'Velagići', 'describr' ),
        131 => /*translators: City.*/ __( 'Velika Kladuša', 'describr' ),
        132 => /*translators: City.*/ __( 'Vidoši', 'describr' ),
        133 => /*translators: City.*/ __( 'Visoko', 'describr' ),
        134 => /*translators: City.*/ __( 'Vitez', 'describr' ),
        135 => /*translators: City.*/ __( 'Vitina', 'describr' ),
        136 => /*translators: City.*/ __( 'Vogošća', 'describr' ),
        137 => /*translators: City.*/ __( 'Voljevac', 'describr' ),
        138 => /*translators: City.*/ __( 'Vrnograč', 'describr' ),
        139 => /*translators: City.*/ __( 'Vukovije Donje', 'describr' ),
        140 => /*translators: City.*/ __( 'Zabrišće', 'describr' ),
        141 => /*translators: City.*/ __( 'Zavidovići', 'describr' ),
        142 => /*translators: City.*/ __( 'Zborište', 'describr' ),
        143 => /*translators: City.*/ __( 'Zenica', 'describr' ),
        144 => /*translators: City.*/ __( 'Ćoralići', 'describr' ),
        145 => /*translators: City.*/ __( 'Čapljina', 'describr' ),
        146 => /*translators: City.*/ __( 'Čelić', 'describr' ),
        147 => /*translators: City.*/ __( 'Čitluk', 'describr' ),
        148 => /*translators: City.*/ __( 'Šerići', 'describr' ),
        149 => /*translators: City.*/ __( 'Široki Brijeg', 'describr' ),
        150 => /*translators: City.*/ __( 'Šturlić', 'describr' ),
        151 => /*translators: City.*/ __( 'Šumatac', 'describr' ),
        152 => /*translators: City.*/ __( 'Željezno Polje', 'describr' ),
        153 => /*translators: City.*/ __( 'Žepče', 'describr' ),
        154 => /*translators: City.*/ __( 'Živinice', 'describr' ),
      ),
    ),
    'SRP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Republika Srpska', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balatun', 'describr' ),
        1 => /*translators: City.*/ __( 'Banja Luka', 'describr' ),
        2 => /*translators: City.*/ __( 'Bijeljina', 'describr' ),
        3 => /*translators: City.*/ __( 'Bileća', 'describr' ),
        4 => /*translators: City.*/ __( 'Blatnica', 'describr' ),
        5 => /*translators: City.*/ __( 'Brod', 'describr' ),
        6 => /*translators: City.*/ __( 'Bronzani Majdan', 'describr' ),
        7 => /*translators: City.*/ __( 'Derventa', 'describr' ),
        8 => /*translators: City.*/ __( 'Doboj', 'describr' ),
        9 => /*translators: City.*/ __( 'Dobrljin', 'describr' ),
        10 => /*translators: City.*/ __( 'Dvorovi', 'describr' ),
        11 => /*translators: City.*/ __( 'Foča', 'describr' ),
        12 => /*translators: City.*/ __( 'Gacko', 'describr' ),
        13 => /*translators: City.*/ __( 'Gradiška', 'describr' ),
        14 => /*translators: City.*/ __( 'Hiseti', 'describr' ),
        15 => /*translators: City.*/ __( 'Istočni Mostar', 'describr' ),
        16 => /*translators: City.*/ __( 'Janja', 'describr' ),
        17 => /*translators: City.*/ __( 'Kalenderovci Donji', 'describr' ),
        18 => /*translators: City.*/ __( 'Kneževo', 'describr' ),
        19 => /*translators: City.*/ __( 'Knežica', 'describr' ),
        20 => /*translators: City.*/ __( 'Koran', 'describr' ),
        21 => /*translators: City.*/ __( 'Kostajnica', 'describr' ),
        22 => /*translators: City.*/ __( 'Kotor Varoš', 'describr' ),
        23 => /*translators: City.*/ __( 'Kozarska Dubica', 'describr' ),
        24 => /*translators: City.*/ __( 'Krupa na Vrbasu', 'describr' ),
        25 => /*translators: City.*/ __( 'Laktaši', 'describr' ),
        26 => /*translators: City.*/ __( 'Lamovita', 'describr' ),
        27 => /*translators: City.*/ __( 'Ljubinje', 'describr' ),
        28 => /*translators: City.*/ __( 'Lopare', 'describr' ),
        29 => /*translators: City.*/ __( 'Maglajani', 'describr' ),
        30 => /*translators: City.*/ __( 'Marićka', 'describr' ),
        31 => /*translators: City.*/ __( 'Maslovare', 'describr' ),
        32 => /*translators: City.*/ __( 'Mejdan - Obilićevo', 'describr' ),
        33 => /*translators: City.*/ __( 'Milići', 'describr' ),
        34 => /*translators: City.*/ __( 'Modriča', 'describr' ),
        35 => /*translators: City.*/ __( 'Mrkonjić Grad', 'describr' ),
        36 => /*translators: City.*/ __( 'Nevesinje', 'describr' ),
        37 => /*translators: City.*/ __( 'Novi Grad', 'describr' ),
        38 => /*translators: City.*/ __( 'Obudovac', 'describr' ),
        39 => /*translators: City.*/ __( 'Omarska', 'describr' ),
        40 => /*translators: City.*/ __( 'Opština Oštra Luka', 'describr' ),
        41 => /*translators: City.*/ __( 'Opština Višegrad', 'describr' ),
        42 => /*translators: City.*/ __( 'Oštra Luka', 'describr' ),
        43 => /*translators: City.*/ __( 'Pale', 'describr' ),
        44 => /*translators: City.*/ __( 'Pelagićevo', 'describr' ),
        45 => /*translators: City.*/ __( 'Petkovci', 'describr' ),
        46 => /*translators: City.*/ __( 'Piskavica', 'describr' ),
        47 => /*translators: City.*/ __( 'Podbrdo', 'describr' ),
        48 => /*translators: City.*/ __( 'Popovi', 'describr' ),
        49 => /*translators: City.*/ __( 'Pribinić', 'describr' ),
        50 => /*translators: City.*/ __( 'Priboj', 'describr' ),
        51 => /*translators: City.*/ __( 'Prijedor', 'describr' ),
        52 => /*translators: City.*/ __( 'Rogatica', 'describr' ),
        53 => /*translators: City.*/ __( 'Rudo', 'describr' ),
        54 => /*translators: City.*/ __( 'Sokolac', 'describr' ),
        55 => /*translators: City.*/ __( 'Srbac', 'describr' ),
        56 => /*translators: City.*/ __( 'Srebrenica', 'describr' ),
        57 => /*translators: City.*/ __( 'Stanari', 'describr' ),
        58 => /*translators: City.*/ __( 'Starcevica', 'describr' ),
        59 => /*translators: City.*/ __( 'Svodna', 'describr' ),
        60 => /*translators: City.*/ __( 'Teslić', 'describr' ),
        61 => /*translators: City.*/ __( 'Trebinje', 'describr' ),
        62 => /*translators: City.*/ __( 'Trn', 'describr' ),
        63 => /*translators: City.*/ __( 'Ugljevik', 'describr' ),
        64 => /*translators: City.*/ __( 'Velika Obarska', 'describr' ),
        65 => /*translators: City.*/ __( 'Višegrad', 'describr' ),
        66 => /*translators: City.*/ __( 'Vlasenica', 'describr' ),
        67 => /*translators: City.*/ __( 'Zvornik', 'describr' ),
        68 => /*translators: City.*/ __( 'Čajniče', 'describr' ),
        69 => /*translators: City.*/ __( 'Čelinac', 'describr' ),
        70 => /*translators: City.*/ __( 'Čečava', 'describr' ),
        71 => /*translators: City.*/ __( 'Šamac', 'describr' ),
        72 => /*translators: City.*/ __( 'Šekovići', 'describr' ),
        73 => /*translators: City.*/ __( 'Šipovo', 'describr' ),
        74 => /*translators: City.*/ __( 'Živinice', 'describr' ),
      ),
    ),
  ),
  'SN' => 
  array (
    'DK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dakar', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dakar', 'describr' ),
        1 => /*translators: City.*/ __( 'Dakar Department', 'describr' ),
        2 => /*translators: City.*/ __( 'Guédiawaye Department', 'describr' ),
        3 => /*translators: City.*/ __( 'Mermoz Boabab', 'describr' ),
        4 => /*translators: City.*/ __( 'N&#039;diareme limamoulaye', 'describr' ),
        5 => /*translators: City.*/ __( 'Pikine', 'describr' ),
        6 => /*translators: City.*/ __( 'Pikine Department', 'describr' ),
        7 => /*translators: City.*/ __( 'Rufisque Department', 'describr' ),
      ),
    ),
    'KD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kolda', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kolda', 'describr' ),
        1 => /*translators: City.*/ __( 'Kolda Department', 'describr' ),
        2 => /*translators: City.*/ __( 'Marsassoum', 'describr' ),
        3 => /*translators: City.*/ __( 'Vélingara', 'describr' ),
      ),
    ),
    'KA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kaffrine', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kaffrine', 'describr' ),
        1 => /*translators: City.*/ __( 'Koungheul', 'describr' ),
      ),
    ),
    'MT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Matam', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Diawara', 'describr' ),
        1 => /*translators: City.*/ __( 'Kanel', 'describr' ),
        2 => /*translators: City.*/ __( 'Matam', 'describr' ),
        3 => /*translators: City.*/ __( 'Matam Department', 'describr' ),
        4 => /*translators: City.*/ __( 'Ouro Sogui', 'describr' ),
        5 => /*translators: City.*/ __( 'Ranérou', 'describr' ),
        6 => /*translators: City.*/ __( 'Sémé', 'describr' ),
        7 => /*translators: City.*/ __( 'Waoundé', 'describr' ),
      ),
    ),
    'SL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint-Louis', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Goléré', 'describr' ),
        1 => /*translators: City.*/ __( 'Ndioum', 'describr' ),
        2 => /*translators: City.*/ __( 'Polel Diaoubé', 'describr' ),
        3 => /*translators: City.*/ __( 'Richard-Toll', 'describr' ),
        4 => /*translators: City.*/ __( 'Rosso', 'describr' ),
        5 => /*translators: City.*/ __( 'Saint-Louis', 'describr' ),
      ),
    ),
    'ZG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ziguinchor', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adéane', 'describr' ),
        1 => /*translators: City.*/ __( 'Bignona', 'describr' ),
        2 => /*translators: City.*/ __( 'Oussouye', 'describr' ),
        3 => /*translators: City.*/ __( 'Tionk Essil', 'describr' ),
        4 => /*translators: City.*/ __( 'Ziguinchor', 'describr' ),
      ),
    ),
    'FK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fatick', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Diofior', 'describr' ),
        1 => /*translators: City.*/ __( 'Fatick Department', 'describr' ),
        2 => /*translators: City.*/ __( 'Foundiougne', 'describr' ),
        3 => /*translators: City.*/ __( 'Guinguinéo', 'describr' ),
        4 => /*translators: City.*/ __( 'Passi', 'describr' ),
        5 => /*translators: City.*/ __( 'Pourham', 'describr' ),
        6 => /*translators: City.*/ __( 'Sokone', 'describr' ),
      ),
    ),
    'DB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Diourbel Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mbacké', 'describr' ),
        1 => /*translators: City.*/ __( 'Mbaké', 'describr' ),
        2 => /*translators: City.*/ __( 'Tiébo', 'describr' ),
        3 => /*translators: City.*/ __( 'Touba', 'describr' ),
      ),
    ),
    'KE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kédougou', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Département de Salémata', 'describr' ),
        1 => /*translators: City.*/ __( 'Kédougou', 'describr' ),
        2 => /*translators: City.*/ __( 'Kédougou Department', 'describr' ),
        3 => /*translators: City.*/ __( 'Saraya', 'describr' ),
      ),
    ),
    'SE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sédhiou', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Goudomp Department', 'describr' ),
        1 => /*translators: City.*/ __( 'Sédhiou', 'describr' ),
      ),
    ),
    'KL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kaolack', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gandiaye', 'describr' ),
        1 => /*translators: City.*/ __( 'Kaolack', 'describr' ),
        2 => /*translators: City.*/ __( 'Ndofane', 'describr' ),
        3 => /*translators: City.*/ __( 'Nioro du Rip', 'describr' ),
      ),
    ),
    'TH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Thiès Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Joal-Fadiout', 'describr' ),
        1 => /*translators: City.*/ __( 'Kayar', 'describr' ),
        2 => /*translators: City.*/ __( 'Khombole', 'describr' ),
        3 => /*translators: City.*/ __( 'Mbour', 'describr' ),
        4 => /*translators: City.*/ __( 'Mékhé', 'describr' ),
        5 => /*translators: City.*/ __( 'Nguékhokh', 'describr' ),
        6 => /*translators: City.*/ __( 'Pout', 'describr' ),
        7 => /*translators: City.*/ __( 'Thiès', 'describr' ),
        8 => /*translators: City.*/ __( 'Thiès Nones', 'describr' ),
        9 => /*translators: City.*/ __( 'Tiadiaye', 'describr' ),
        10 => /*translators: City.*/ __( 'Tivaouane', 'describr' ),
        11 => /*translators: City.*/ __( 'Warang', 'describr' ),
      ),
    ),
    'LG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Louga', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dara', 'describr' ),
        1 => /*translators: City.*/ __( 'Guéoul', 'describr' ),
        2 => /*translators: City.*/ __( 'Linguere Department', 'describr' ),
        3 => /*translators: City.*/ __( 'Louga', 'describr' ),
        4 => /*translators: City.*/ __( 'Ndibène Dahra', 'describr' ),
      ),
    ),
    'TC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tambacounda Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tambacounda', 'describr' ),
        1 => /*translators: City.*/ __( 'Tambacounda Department', 'describr' ),
      ),
    ),
  ),
  'AD' => 
  array (
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Encamp', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Encamp', 'describr' ),
        1 => /*translators: City.*/ __( 'Pas de la Casa', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Andorra la Vella', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Andorra la Vella', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Canillo', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Canillo', 'describr' ),
        1 => /*translators: City.*/ __( 'El Tarter', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sant Julià de Lòria', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sant Julià de Lòria', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ordino', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ordino', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Escaldes-Engordany', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'les Escaldes', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Massana', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arinsal', 'describr' ),
        1 => /*translators: City.*/ __( 'la Massana', 'describr' ),
      ),
    ),
  ),
  'SC' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anse Royale', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse Royale', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beau Vallon', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beau Vallon', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anse Boileau', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse Boileau', 'describr' ),
      ),
    ),
  ),
  'AZ' => 
  array (
    'SA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shaki', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sheki', 'describr' ),
      ),
    ),
    'TAR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tartar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Martakert', 'describr' ),
        1 => /*translators: City.*/ __( 'Terter', 'describr' ),
      ),
    ),
    'SR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shirvan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Şirvan', 'describr' ),
      ),
    ),
    'QAZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qazakh District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qazax', 'describr' ),
      ),
    ),
    'YEV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yevlakh District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aran', 'describr' ),
        1 => /*translators: City.*/ __( 'Qaramanlı', 'describr' ),
      ),
    ),
    'XCI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khojali District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Askyaran', 'describr' ),
        1 => /*translators: City.*/ __( 'Xocalı', 'describr' ),
      ),
    ),
    'KAL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kalbajar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kerbakhiar', 'describr' ),
        1 => /*translators: City.*/ __( 'Vank', 'describr' ),
      ),
    ),
    'QAX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qakh District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qax', 'describr' ),
        1 => /*translators: City.*/ __( 'Qax İngiloy', 'describr' ),
        2 => /*translators: City.*/ __( 'Qaxbaş', 'describr' ),
        3 => /*translators: City.*/ __( 'Çinarlı', 'describr' ),
      ),
    ),
    'FUZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fizuli District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fizuli', 'describr' ),
        1 => /*translators: City.*/ __( 'Horadiz', 'describr' ),
      ),
    ),
    'AST' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Astara District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Astara', 'describr' ),
        1 => /*translators: City.*/ __( 'Kizhaba', 'describr' ),
      ),
    ),
    'SMI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shamakhi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Shamakhi', 'describr' ),
      ),
    ),
    'NEF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Neftchala District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Neftçala', 'describr' ),
        1 => /*translators: City.*/ __( 'Severo-Vostotchnyi Bank', 'describr' ),
        2 => /*translators: City.*/ __( 'Sovetabad', 'describr' ),
        3 => /*translators: City.*/ __( 'Xıllı', 'describr' ),
      ),
    ),
    'GOY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Goychay', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Geoktschai', 'describr' ),
      ),
    ),
    'BIL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bilasuvar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pushkino', 'describr' ),
      ),
    ),
    'TOV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tovuz District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dondar Quşçu', 'describr' ),
        1 => /*translators: City.*/ __( 'Qaraxanlı', 'describr' ),
        2 => /*translators: City.*/ __( 'Tovuz', 'describr' ),
        3 => /*translators: City.*/ __( 'Yanıqlı', 'describr' ),
        4 => /*translators: City.*/ __( 'Çatax', 'describr' ),
        5 => /*translators: City.*/ __( 'Çobansığnaq', 'describr' ),
      ),
    ),
    'SMX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Samukh District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qarayeri', 'describr' ),
        1 => /*translators: City.*/ __( 'Qırmızı Samux', 'describr' ),
        2 => /*translators: City.*/ __( 'Samux', 'describr' ),
      ),
    ),
    'XIZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khizi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Altıağac', 'describr' ),
        1 => /*translators: City.*/ __( 'Khyzy', 'describr' ),
        2 => /*translators: City.*/ __( 'Kilyazi', 'describr' ),
        3 => /*translators: City.*/ __( 'Şuraabad', 'describr' ),
      ),
    ),
    'YE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yevlakh', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Yevlakh', 'describr' ),
      ),
    ),
    'UCA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ujar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ujar', 'describr' ),
      ),
    ),
    'ABS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Absheron District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ceyranbatan', 'describr' ),
        1 => /*translators: City.*/ __( 'Digah', 'describr' ),
        2 => /*translators: City.*/ __( 'Gyuzdek', 'describr' ),
        3 => /*translators: City.*/ __( 'Khirdalan', 'describr' ),
        4 => /*translators: City.*/ __( 'Qobu', 'describr' ),
        5 => /*translators: City.*/ __( 'Saray', 'describr' ),
      ),
    ),
    'LAC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lachin District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Laçın', 'describr' ),
      ),
    ),
    'QAB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qabala District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qutqashen', 'describr' ),
      ),
    ),
    'AGA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Agstafa District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aghstafa', 'describr' ),
        1 => /*translators: City.*/ __( 'Saloğlu', 'describr' ),
        2 => /*translators: City.*/ __( 'Vurğun', 'describr' ),
      ),
    ),
    'IMI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Imishli District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Imishli', 'describr' ),
      ),
    ),
    'SAL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Salyan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qaraçala', 'describr' ),
        1 => /*translators: City.*/ __( 'Salyan', 'describr' ),
      ),
    ),
    'LER' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lerik District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lerik', 'describr' ),
      ),
    ),
    'AGU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Agsu District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aghsu', 'describr' ),
      ),
    ),
    'QBI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qubadli District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qubadlı', 'describr' ),
      ),
    ),
    'KUR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kurdamir District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kyurdarmir', 'describr' ),
      ),
    ),
    'YAR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yardymli District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Yardımlı', 'describr' ),
      ),
    ),
    'GOR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Goranboy District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Goranboy', 'describr' ),
        1 => /*translators: City.*/ __( 'Qızılhacılı', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baku', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amirdzhan', 'describr' ),
        1 => /*translators: City.*/ __( 'Badamdar', 'describr' ),
        2 => /*translators: City.*/ __( 'Baku', 'describr' ),
        3 => /*translators: City.*/ __( 'Bakıxanov', 'describr' ),
        4 => /*translators: City.*/ __( 'Balakhani', 'describr' ),
        5 => /*translators: City.*/ __( 'Bilajari', 'describr' ),
        6 => /*translators: City.*/ __( 'Bilajer', 'describr' ),
        7 => /*translators: City.*/ __( 'Binagadi', 'describr' ),
        8 => /*translators: City.*/ __( 'Biny Selo', 'describr' ),
        9 => /*translators: City.*/ __( 'Buzovna', 'describr' ),
        10 => /*translators: City.*/ __( 'Hövsan', 'describr' ),
        11 => /*translators: City.*/ __( 'Khodzhi-Gasan', 'describr' ),
        12 => /*translators: City.*/ __( 'Korgöz', 'describr' ),
        13 => /*translators: City.*/ __( 'Lökbatan', 'describr' ),
        14 => /*translators: City.*/ __( 'Mardakan', 'describr' ),
        15 => /*translators: City.*/ __( 'Maştağa', 'describr' ),
        16 => /*translators: City.*/ __( 'Nardaran', 'describr' ),
        17 => /*translators: City.*/ __( 'Nizami Rayonu', 'describr' ),
        18 => /*translators: City.*/ __( 'Pirallahı', 'describr' ),
        19 => /*translators: City.*/ __( 'Puta', 'describr' ),
        20 => /*translators: City.*/ __( 'Qala', 'describr' ),
        21 => /*translators: City.*/ __( 'Qaraçuxur', 'describr' ),
        22 => /*translators: City.*/ __( 'Qobustan', 'describr' ),
        23 => /*translators: City.*/ __( 'Ramana', 'describr' ),
        24 => /*translators: City.*/ __( 'Sabunçu', 'describr' ),
        25 => /*translators: City.*/ __( 'Sanqaçal', 'describr' ),
        26 => /*translators: City.*/ __( 'Türkan', 'describr' ),
        27 => /*translators: City.*/ __( 'Yeni Suraxanı', 'describr' ),
        28 => /*translators: City.*/ __( 'Zabrat', 'describr' ),
        29 => /*translators: City.*/ __( 'Zyrya', 'describr' ),
      ),
    ),
    'AGS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Agdash District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ağdaş', 'describr' ),
      ),
    ),
    'BEY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beylagan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beylagan', 'describr' ),
        1 => /*translators: City.*/ __( 'Birinci Aşıqlı', 'describr' ),
        2 => /*translators: City.*/ __( 'Dünyamalılar', 'describr' ),
        3 => /*translators: City.*/ __( 'Orjonikidze', 'describr' ),
        4 => /*translators: City.*/ __( 'Yuxarı Aran', 'describr' ),
      ),
    ),
    'MAS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Masally District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Boradigah', 'describr' ),
        1 => /*translators: City.*/ __( 'Masally', 'describr' ),
      ),
    ),
    'OGU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oghuz District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Oğuz', 'describr' ),
      ),
    ),
    'SAT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saatly District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Saatlı', 'describr' ),
        1 => /*translators: City.*/ __( 'Əhmədbəyli', 'describr' ),
      ),
    ),
    'LA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lankaran District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Haftoni', 'describr' ),
        1 => /*translators: City.*/ __( 'Lankaran', 'describr' ),
      ),
    ),
    'AGM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Agdam District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ağdam', 'describr' ),
      ),
    ),
    'BAL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balakan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belokany', 'describr' ),
        1 => /*translators: City.*/ __( 'Qabaqçöl', 'describr' ),
      ),
    ),
    'DAS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dashkasan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Verkhniy Dashkesan', 'describr' ),
        1 => /*translators: City.*/ __( 'Yukhary-Dashkesan', 'describr' ),
      ),
    ),
    'NX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nakhchivan Autonomous Republic', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cahri', 'describr' ),
        1 => /*translators: City.*/ __( 'Culfa', 'describr' ),
        2 => /*translators: City.*/ __( 'Deste', 'describr' ),
        3 => /*translators: City.*/ __( 'Heydarabad', 'describr' ),
        4 => /*translators: City.*/ __( 'Julfa Rayon', 'describr' ),
        5 => /*translators: City.*/ __( 'Nakhchivan', 'describr' ),
        6 => /*translators: City.*/ __( 'Ordubad', 'describr' ),
        7 => /*translators: City.*/ __( 'Ordubad Rayon', 'describr' ),
        8 => /*translators: City.*/ __( 'Oğlanqala', 'describr' ),
        9 => /*translators: City.*/ __( 'Qıvraq', 'describr' ),
        10 => /*translators: City.*/ __( 'Sedarak', 'describr' ),
        11 => /*translators: City.*/ __( 'Shahbuz Rayon', 'describr' ),
        12 => /*translators: City.*/ __( 'Sharur City', 'describr' ),
        13 => /*translators: City.*/ __( 'Sumbatan-diza', 'describr' ),
        14 => /*translators: City.*/ __( 'Tazakend', 'describr' ),
        15 => /*translators: City.*/ __( 'Yaycı', 'describr' ),
        16 => /*translators: City.*/ __( 'Çalxanqala', 'describr' ),
        17 => /*translators: City.*/ __( 'Şahbuz', 'describr' ),
      ),
    ),
    'QBA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Quba District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hacıhüseynli', 'describr' ),
        1 => /*translators: City.*/ __( 'Quba', 'describr' ),
      ),
    ),
    'ISM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ismailli District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Basqal', 'describr' ),
        1 => /*translators: City.*/ __( 'İsmayıllı', 'describr' ),
      ),
    ),
    'SAB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sabirabad District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sabirabad', 'describr' ),
      ),
    ),
    'ZAQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zaqatala District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aliabad', 'describr' ),
        1 => /*translators: City.*/ __( 'Faldarlı', 'describr' ),
        2 => /*translators: City.*/ __( 'Mamrux', 'describr' ),
        3 => /*translators: City.*/ __( 'Qandax', 'describr' ),
        4 => /*translators: City.*/ __( 'Zaqatala', 'describr' ),
      ),
    ),
    'XVD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Martuni', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hadrut', 'describr' ),
        1 => /*translators: City.*/ __( 'Novyy Karanlug', 'describr' ),
        2 => /*translators: City.*/ __( 'Qırmızı Bazar', 'describr' ),
      ),
    ),
    'BAR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Barda District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barda', 'describr' ),
        1 => /*translators: City.*/ __( 'Samuxlu', 'describr' ),
      ),
    ),
    'CAB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jabrayil District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jebrail', 'describr' ),
      ),
    ),
    'HAC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hajigabul District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hacıqabul', 'describr' ),
        1 => /*translators: City.*/ __( 'Mughan', 'describr' ),
      ),
    ),
    'QOB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gobustan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qobustan', 'describr' ),
      ),
    ),
    'GYG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Goygol District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Yelenendorf', 'describr' ),
      ),
    ),
    'ZAR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zardab District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Zardob', 'describr' ),
      ),
    ),
    'AGC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aghjabadi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agdzhabedy', 'describr' ),
        1 => /*translators: City.*/ __( 'Avşar', 'describr' ),
      ),
    ),
    'CAL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jalilabad District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jalilabad', 'describr' ),
        1 => /*translators: City.*/ __( 'Prishibinskoye', 'describr' ),
      ),
    ),
    'MI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mingachevir', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mingelchaur', 'describr' ),
      ),
    ),
    'ZAN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zangilan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mincivan', 'describr' ),
        1 => /*translators: City.*/ __( 'Zangilan', 'describr' ),
      ),
    ),
    'SM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sumqayit', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Corat', 'describr' ),
        1 => /*translators: City.*/ __( 'Hacı Zeynalabdin', 'describr' ),
        2 => /*translators: City.*/ __( 'Sumqayıt', 'describr' ),
      ),
    ),
    'SKR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shamkir District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dolyar', 'describr' ),
        1 => /*translators: City.*/ __( 'Dzagam', 'describr' ),
        2 => /*translators: City.*/ __( 'Qasım İsmayılov', 'describr' ),
        3 => /*translators: City.*/ __( 'Shamkhor', 'describr' ),
      ),
    ),
    'SIY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Siazan District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gilgilçay', 'describr' ),
        1 => /*translators: City.*/ __( 'Kyzyl-Burun', 'describr' ),
      ),
    ),
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ganja', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ganja', 'describr' ),
      ),
    ),
    'SAK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shaki District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baş Göynük', 'describr' ),
      ),
    ),
    'QUS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qusar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qusar', 'describr' ),
        1 => /*translators: City.*/ __( 'Samur', 'describr' ),
      ),
    ),
    'GAD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gədəbəy', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arıqdam', 'describr' ),
        1 => /*translators: City.*/ __( 'Arıqıran', 'describr' ),
        2 => /*translators: City.*/ __( 'Böyük Qaramurad', 'describr' ),
        3 => /*translators: City.*/ __( 'Kyadabek', 'describr' ),
        4 => /*translators: City.*/ __( 'Novosaratovka', 'describr' ),
      ),
    ),
    'XAC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khachmaz District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Xaçmaz', 'describr' ),
        1 => /*translators: City.*/ __( 'Xudat', 'describr' ),
      ),
    ),
    'SBN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shabran District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Divichibazar', 'describr' ),
      ),
    ),
    'SUS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shusha District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Shushi', 'describr' ),
      ),
    ),
  ),
  'AL' => 
  array (
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lezhë County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Kurbin', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Lezhë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Mirditë', 'describr' ),
        3 => /*translators: City.*/ __( 'Kurbnesh', 'describr' ),
        4 => /*translators: City.*/ __( 'Laç', 'describr' ),
        5 => /*translators: City.*/ __( 'Lezhë', 'describr' ),
        6 => /*translators: City.*/ __( 'Mamurras', 'describr' ),
        7 => /*translators: City.*/ __( 'Milot', 'describr' ),
        8 => /*translators: City.*/ __( 'Rrethi i Kurbinit', 'describr' ),
        9 => /*translators: City.*/ __( 'Rrëshen', 'describr' ),
        10 => /*translators: City.*/ __( 'Rubik', 'describr' ),
        11 => /*translators: City.*/ __( 'Shëngjin', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dibër County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Bulqizë', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Klos', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Mat', 'describr' ),
        3 => /*translators: City.*/ __( 'Bulqizë', 'describr' ),
        4 => /*translators: City.*/ __( 'Burrel', 'describr' ),
        5 => /*translators: City.*/ __( 'Klos', 'describr' ),
        6 => /*translators: City.*/ __( 'Peshkopi', 'describr' ),
        7 => /*translators: City.*/ __( 'Rrethi i Bulqizës', 'describr' ),
        8 => /*translators: City.*/ __( 'Rrethi i Dibrës', 'describr' ),
        9 => /*translators: City.*/ __( 'Rrethi i Matit', 'describr' ),
        10 => /*translators: City.*/ __( 'Ulëz', 'describr' ),
      ),
    ),
    'GJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gjirokastër District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Dropull', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Kelcyrë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Libohovë', 'describr' ),
        3 => /*translators: City.*/ __( 'Bashkia Memaliaj', 'describr' ),
        4 => /*translators: City.*/ __( 'Bashkia Përmet', 'describr' ),
        5 => /*translators: City.*/ __( 'Bashkia Tepelenë', 'describr' ),
        6 => /*translators: City.*/ __( 'Gjinkar', 'describr' ),
        7 => /*translators: City.*/ __( 'Gjirokastër', 'describr' ),
        8 => /*translators: City.*/ __( 'Këlcyrë', 'describr' ),
        9 => /*translators: City.*/ __( 'Lazarat', 'describr' ),
        10 => /*translators: City.*/ __( 'Libohovë', 'describr' ),
        11 => /*translators: City.*/ __( 'Memaliaj', 'describr' ),
        12 => /*translators: City.*/ __( 'Përmet', 'describr' ),
        13 => /*translators: City.*/ __( 'Tepelenë', 'describr' ),
      ),
    ),
    'KU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kukës District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bajram Curri', 'describr' ),
        1 => /*translators: City.*/ __( 'Krumë', 'describr' ),
        2 => /*translators: City.*/ __( 'Kukës', 'describr' ),
        3 => /*translators: City.*/ __( 'Rrethi i Hasit', 'describr' ),
        4 => /*translators: City.*/ __( 'Rrethi i Kukësit', 'describr' ),
      ),
    ),
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shkodër District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Malësi e Madhe', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Pukë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Vau i Dejës', 'describr' ),
        3 => /*translators: City.*/ __( 'Fushë-Arrëz', 'describr' ),
        4 => /*translators: City.*/ __( 'Koplik', 'describr' ),
        5 => /*translators: City.*/ __( 'Pukë', 'describr' ),
        6 => /*translators: City.*/ __( 'Rrethi i Malësia e Madhe', 'describr' ),
        7 => /*translators: City.*/ __( 'Rrethi i Shkodrës', 'describr' ),
        8 => /*translators: City.*/ __( 'Shkodër', 'describr' ),
        9 => /*translators: City.*/ __( 'Vau i Dejës', 'describr' ),
        10 => /*translators: City.*/ __( 'Vukatanë', 'describr' ),
      ),
    ),
    'BR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Berat District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banaj', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Berat', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Kuçovë', 'describr' ),
        3 => /*translators: City.*/ __( 'Bashkia Poliçan', 'describr' ),
        4 => /*translators: City.*/ __( 'Bashkia Skrapar', 'describr' ),
        5 => /*translators: City.*/ __( 'Berat', 'describr' ),
        6 => /*translators: City.*/ __( 'Kuçovë', 'describr' ),
        7 => /*translators: City.*/ __( 'Poliçan', 'describr' ),
        8 => /*translators: City.*/ __( 'Rrethi i Beratit', 'describr' ),
        9 => /*translators: City.*/ __( 'Rrethi i Kuçovës', 'describr' ),
        10 => /*translators: City.*/ __( 'Rrethi i Skraparit', 'describr' ),
        11 => /*translators: City.*/ __( 'Ura Vajgurore', 'describr' ),
        12 => /*translators: City.*/ __( 'Çorovodë', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Korçë County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Devoll', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Kolonjë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Maliq', 'describr' ),
        3 => /*translators: City.*/ __( 'Bashkia Pustec', 'describr' ),
        4 => /*translators: City.*/ __( 'Bilisht', 'describr' ),
        5 => /*translators: City.*/ __( 'Ersekë', 'describr' ),
        6 => /*translators: City.*/ __( 'Korçë', 'describr' ),
        7 => /*translators: City.*/ __( 'Leskovik', 'describr' ),
        8 => /*translators: City.*/ __( 'Libonik', 'describr' ),
        9 => /*translators: City.*/ __( 'Maliq', 'describr' ),
        10 => /*translators: City.*/ __( 'Mborje', 'describr' ),
        11 => /*translators: City.*/ __( 'Pogradec', 'describr' ),
        12 => /*translators: City.*/ __( 'Rrethi i Devollit', 'describr' ),
        13 => /*translators: City.*/ __( 'Rrethi i Kolonjës', 'describr' ),
        14 => /*translators: City.*/ __( 'Velçan', 'describr' ),
        15 => /*translators: City.*/ __( 'Voskopojë', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fier County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ballsh', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Divjakë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Fier', 'describr' ),
        3 => /*translators: City.*/ __( 'Bashkia Mallakastër', 'describr' ),
        4 => /*translators: City.*/ __( 'Bashkia Patos', 'describr' ),
        5 => /*translators: City.*/ __( 'Divjakë', 'describr' ),
        6 => /*translators: City.*/ __( 'Fier', 'describr' ),
        7 => /*translators: City.*/ __( 'Fier-Çifçi', 'describr' ),
        8 => /*translators: City.*/ __( 'Lushnjë', 'describr' ),
        9 => /*translators: City.*/ __( 'Patos', 'describr' ),
        10 => /*translators: City.*/ __( 'Patos Fshat', 'describr' ),
        11 => /*translators: City.*/ __( 'Roskovec', 'describr' ),
        12 => /*translators: City.*/ __( 'Rrethi i Mallakastrës', 'describr' ),
      ),
    ),
    'TR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tirana District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Kavajë', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Vorë', 'describr' ),
        2 => /*translators: City.*/ __( 'Kamëz', 'describr' ),
        3 => /*translators: City.*/ __( 'Kavajë', 'describr' ),
        4 => /*translators: City.*/ __( 'Krrabë', 'describr' ),
        5 => /*translators: City.*/ __( 'Rrethi i Kavajës', 'describr' ),
        6 => /*translators: City.*/ __( 'Rrethi i Tiranës', 'describr' ),
        7 => /*translators: City.*/ __( 'Rrogozhinë', 'describr' ),
        8 => /*translators: City.*/ __( 'Sinaballaj', 'describr' ),
        9 => /*translators: City.*/ __( 'Tirana', 'describr' ),
        10 => /*translators: City.*/ __( 'Vorë', 'describr' ),
      ),
    ),
    'DR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Durrës District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bashkia Durrës', 'describr' ),
        1 => /*translators: City.*/ __( 'Bashkia Krujë', 'describr' ),
        2 => /*translators: City.*/ __( 'Bashkia Shijak', 'describr' ),
        3 => /*translators: City.*/ __( 'Durrës', 'describr' ),
        4 => /*translators: City.*/ __( 'Durrës District', 'describr' ),
        5 => /*translators: City.*/ __( 'Fushë-Krujë', 'describr' ),
        6 => /*translators: City.*/ __( 'Krujë', 'describr' ),
        7 => /*translators: City.*/ __( 'Rrethi i Krujës', 'describr' ),
        8 => /*translators: City.*/ __( 'Shijak', 'describr' ),
        9 => /*translators: City.*/ __( 'Sukth', 'describr' ),
      ),
    ),
  ),
  'MK' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bogdanci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bogdanci', 'describr' ),
        1 => /*translators: City.*/ __( 'Stojakovo', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bosilovo Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bosilovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Ilovica', 'describr' ),
        2 => /*translators: City.*/ __( 'Sekirnik', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aračinovo Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Арачиново', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brvenica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brvenica', 'describr' ),
        1 => /*translators: City.*/ __( 'Gurgurnica', 'describr' ),
        2 => /*translators: City.*/ __( 'Miletino', 'describr' ),
        3 => /*translators: City.*/ __( 'Čelopek', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bitola Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bistrica', 'describr' ),
        1 => /*translators: City.*/ __( 'Bitola', 'describr' ),
        2 => /*translators: City.*/ __( 'Capari', 'describr' ),
        3 => /*translators: City.*/ __( 'Dolno Orizari', 'describr' ),
        4 => /*translators: City.*/ __( 'Gorno Orizari', 'describr' ),
        5 => /*translators: City.*/ __( 'Kukurečani', 'describr' ),
        6 => /*translators: City.*/ __( 'Logovardi', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Butel Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Butel', 'describr' ),
        1 => /*translators: City.*/ __( 'Radishani', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Berovo Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Berovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Rusinovo', 'describr' ),
        2 => /*translators: City.*/ __( 'Vladimirovo', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bogovinje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bogovinje', 'describr' ),
        1 => /*translators: City.*/ __( 'Dolno Palčište', 'describr' ),
        2 => /*translators: City.*/ __( 'Gradec', 'describr' ),
        3 => /*translators: City.*/ __( 'Kamenjane', 'describr' ),
      ),
    ),
  ),
  'HR' => 
  array (
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Krapina-Zagorje County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bedekovčina', 'describr' ),
        1 => /*translators: City.*/ __( 'Budinščina', 'describr' ),
        2 => /*translators: City.*/ __( 'Grad Donja Stubica', 'describr' ),
        3 => /*translators: City.*/ __( 'Grad Klanjec', 'describr' ),
        4 => /*translators: City.*/ __( 'Grad Krapina', 'describr' ),
        5 => /*translators: City.*/ __( 'Grad Zabok', 'describr' ),
        6 => /*translators: City.*/ __( 'Grad Zlatar', 'describr' ),
        7 => /*translators: City.*/ __( 'Jesenje', 'describr' ),
        8 => /*translators: City.*/ __( 'Klanjec', 'describr' ),
        9 => /*translators: City.*/ __( 'Konjščina', 'describr' ),
        10 => /*translators: City.*/ __( 'Krapina', 'describr' ),
        11 => /*translators: City.*/ __( 'Kumrovec', 'describr' ),
        12 => /*translators: City.*/ __( 'Marija Bistrica', 'describr' ),
        13 => /*translators: City.*/ __( 'Mače', 'describr' ),
        14 => /*translators: City.*/ __( 'Mihovljan', 'describr' ),
        15 => /*translators: City.*/ __( 'Oroslavje', 'describr' ),
        16 => /*translators: City.*/ __( 'Pregrada', 'describr' ),
        17 => /*translators: City.*/ __( 'Radoboj', 'describr' ),
        18 => /*translators: City.*/ __( 'Stubičke Toplice', 'describr' ),
        19 => /*translators: City.*/ __( 'Sveti Križ Začretje', 'describr' ),
        20 => /*translators: City.*/ __( 'Zabok', 'describr' ),
        21 => /*translators: City.*/ __( 'Zlatar', 'describr' ),
        22 => /*translators: City.*/ __( 'Zlatar Bistrica', 'describr' ),
        23 => /*translators: City.*/ __( 'Đurmanec', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lika-Senj County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brinje', 'describr' ),
        1 => /*translators: City.*/ __( 'Gospić', 'describr' ),
        2 => /*translators: City.*/ __( 'Karlobag', 'describr' ),
        3 => /*translators: City.*/ __( 'Lički Osik', 'describr' ),
        4 => /*translators: City.*/ __( 'Novalja', 'describr' ),
        5 => /*translators: City.*/ __( 'Otočac', 'describr' ),
        6 => /*translators: City.*/ __( 'Perušić', 'describr' ),
        7 => /*translators: City.*/ __( 'Plitvička Jezera', 'describr' ),
        8 => /*translators: City.*/ __( 'Popovača', 'describr' ),
        9 => /*translators: City.*/ __( 'Senj', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sisak-Moslavina County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Budaševo', 'describr' ),
        1 => /*translators: City.*/ __( 'Dvor', 'describr' ),
        2 => /*translators: City.*/ __( 'Glina', 'describr' ),
        3 => /*translators: City.*/ __( 'Grad Glina', 'describr' ),
        4 => /*translators: City.*/ __( 'Grad Hrvatska Kostajnica', 'describr' ),
        5 => /*translators: City.*/ __( 'Grad Kutina', 'describr' ),
        6 => /*translators: City.*/ __( 'Grad Novska', 'describr' ),
        7 => /*translators: City.*/ __( 'Grad Petrinja', 'describr' ),
        8 => /*translators: City.*/ __( 'Grad Sisak', 'describr' ),
        9 => /*translators: City.*/ __( 'Gvozd', 'describr' ),
        10 => /*translators: City.*/ __( 'Hrvatska Kostajnica', 'describr' ),
        11 => /*translators: City.*/ __( 'Kutina', 'describr' ),
        12 => /*translators: City.*/ __( 'Lekenik', 'describr' ),
        13 => /*translators: City.*/ __( 'Lipovljani', 'describr' ),
        14 => /*translators: City.*/ __( 'Martinska Ves', 'describr' ),
        15 => /*translators: City.*/ __( 'Novska', 'describr' ),
        16 => /*translators: City.*/ __( 'Općina Dvor', 'describr' ),
        17 => /*translators: City.*/ __( 'Općina Gvozd', 'describr' ),
        18 => /*translators: City.*/ __( 'Petrinja', 'describr' ),
        19 => /*translators: City.*/ __( 'Popovača', 'describr' ),
        20 => /*translators: City.*/ __( 'Repušnica', 'describr' ),
        21 => /*translators: City.*/ __( 'Sisak', 'describr' ),
        22 => /*translators: City.*/ __( 'Sunja', 'describr' ),
        23 => /*translators: City.*/ __( 'Voloder', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bjelovar-Bilogora County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bjelovar', 'describr' ),
        1 => /*translators: City.*/ __( 'Brezovac', 'describr' ),
        2 => /*translators: City.*/ __( 'Daruvar', 'describr' ),
        3 => /*translators: City.*/ __( 'Dežanovac', 'describr' ),
        4 => /*translators: City.*/ __( 'Garešnica', 'describr' ),
        5 => /*translators: City.*/ __( 'Grad Bjelovar', 'describr' ),
        6 => /*translators: City.*/ __( 'Grad Daruvar', 'describr' ),
        7 => /*translators: City.*/ __( 'Grad Garešnica', 'describr' ),
        8 => /*translators: City.*/ __( 'Grad Grubišno Polje', 'describr' ),
        9 => /*translators: City.*/ __( 'Grad Čazma', 'describr' ),
        10 => /*translators: City.*/ __( 'Grubišno Polje', 'describr' ),
        11 => /*translators: City.*/ __( 'Gudovac', 'describr' ),
        12 => /*translators: City.*/ __( 'Hercegovac', 'describr' ),
        13 => /*translators: City.*/ __( 'Ivanska', 'describr' ),
        14 => /*translators: City.*/ __( 'Kapela', 'describr' ),
        15 => /*translators: City.*/ __( 'Končanica', 'describr' ),
        16 => /*translators: City.*/ __( 'Predavac', 'describr' ),
        17 => /*translators: City.*/ __( 'Rovišće', 'describr' ),
        18 => /*translators: City.*/ __( 'Severin', 'describr' ),
        19 => /*translators: City.*/ __( 'Sirač', 'describr' ),
        20 => /*translators: City.*/ __( 'Velika Pisanica', 'describr' ),
        21 => /*translators: City.*/ __( 'Veliki Grđevac', 'describr' ),
        22 => /*translators: City.*/ __( 'Zrinski Topolovac', 'describr' ),
        23 => /*translators: City.*/ __( 'Čazma', 'describr' ),
        24 => /*translators: City.*/ __( 'Đulovac', 'describr' ),
        25 => /*translators: City.*/ __( 'Šandrovac', 'describr' ),
        26 => /*translators: City.*/ __( 'Ždralovi', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Primorje-Gorski Kotar County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bakar', 'describr' ),
        1 => /*translators: City.*/ __( 'Banjol', 'describr' ),
        2 => /*translators: City.*/ __( 'Baška', 'describr' ),
        3 => /*translators: City.*/ __( 'Bribir', 'describr' ),
        4 => /*translators: City.*/ __( 'Buzdohanj', 'describr' ),
        5 => /*translators: City.*/ __( 'Cernik', 'describr' ),
        6 => /*translators: City.*/ __( 'Cres', 'describr' ),
        7 => /*translators: City.*/ __( 'Crikvenica', 'describr' ),
        8 => /*translators: City.*/ __( 'Delnice', 'describr' ),
        9 => /*translators: City.*/ __( 'Dražice', 'describr' ),
        10 => /*translators: City.*/ __( 'Drenova', 'describr' ),
        11 => /*translators: City.*/ __( 'Fužine', 'describr' ),
        12 => /*translators: City.*/ __( 'Grad Crikvenica', 'describr' ),
        13 => /*translators: City.*/ __( 'Grad Delnice', 'describr' ),
        14 => /*translators: City.*/ __( 'Grad Krk', 'describr' ),
        15 => /*translators: City.*/ __( 'Grad Opatija', 'describr' ),
        16 => /*translators: City.*/ __( 'Grad Rijeka', 'describr' ),
        17 => /*translators: City.*/ __( 'Grad Vrbovsko', 'describr' ),
        18 => /*translators: City.*/ __( 'Grad Čabar', 'describr' ),
        19 => /*translators: City.*/ __( 'Hreljin', 'describr' ),
        20 => /*translators: City.*/ __( 'Jadranovo', 'describr' ),
        21 => /*translators: City.*/ __( 'Kampor', 'describr' ),
        22 => /*translators: City.*/ __( 'Kastav', 'describr' ),
        23 => /*translators: City.*/ __( 'Klana', 'describr' ),
        24 => /*translators: City.*/ __( 'Kraljevica', 'describr' ),
        25 => /*translators: City.*/ __( 'Krasica', 'describr' ),
        26 => /*translators: City.*/ __( 'Krk', 'describr' ),
        27 => /*translators: City.*/ __( 'Lopar', 'describr' ),
        28 => /*translators: City.*/ __( 'Lovran', 'describr' ),
        29 => /*translators: City.*/ __( 'Mali Lošinj', 'describr' ),
        30 => /*translators: City.*/ __( 'Malinska-Dubašnica', 'describr' ),
        31 => /*translators: City.*/ __( 'Marinići', 'describr' ),
        32 => /*translators: City.*/ __( 'Marčelji', 'describr' ),
        33 => /*translators: City.*/ __( 'Matulji', 'describr' ),
        34 => /*translators: City.*/ __( 'Mihotići', 'describr' ),
        35 => /*translators: City.*/ __( 'Mrkopalj', 'describr' ),
        36 => /*translators: City.*/ __( 'Njivice', 'describr' ),
        37 => /*translators: City.*/ __( 'Novi Vinodolski', 'describr' ),
        38 => /*translators: City.*/ __( 'Omišalj', 'describr' ),
        39 => /*translators: City.*/ __( 'Opatija', 'describr' ),
        40 => /*translators: City.*/ __( 'Podhum', 'describr' ),
        41 => /*translators: City.*/ __( 'Punat', 'describr' ),
        42 => /*translators: City.*/ __( 'Rab', 'describr' ),
        43 => /*translators: City.*/ __( 'Rijeka', 'describr' ),
        44 => /*translators: City.*/ __( 'Rubeši', 'describr' ),
        45 => /*translators: City.*/ __( 'Selce', 'describr' ),
        46 => /*translators: City.*/ __( 'Skrad', 'describr' ),
        47 => /*translators: City.*/ __( 'Supetarska Draga', 'describr' ),
        48 => /*translators: City.*/ __( 'Vinodolska općina', 'describr' ),
        49 => /*translators: City.*/ __( 'Viškovo', 'describr' ),
        50 => /*translators: City.*/ __( 'Vrbnik', 'describr' ),
        51 => /*translators: City.*/ __( 'Vrbovsko', 'describr' ),
        52 => /*translators: City.*/ __( 'Čavle', 'describr' ),
        53 => /*translators: City.*/ __( 'Škrljevo', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zagreb County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bestovje', 'describr' ),
        1 => /*translators: City.*/ __( 'Bistra', 'describr' ),
        2 => /*translators: City.*/ __( 'Brckovljani', 'describr' ),
        3 => /*translators: City.*/ __( 'Brdovec', 'describr' ),
        4 => /*translators: City.*/ __( 'Bregana', 'describr' ),
        5 => /*translators: City.*/ __( 'Donja Bistra', 'describr' ),
        6 => /*translators: City.*/ __( 'Donja Lomnica', 'describr' ),
        7 => /*translators: City.*/ __( 'Donja Zdenčina', 'describr' ),
        8 => /*translators: City.*/ __( 'Donji Stupnik', 'describr' ),
        9 => /*translators: City.*/ __( 'Farkaševac', 'describr' ),
        10 => /*translators: City.*/ __( 'Gornja Bistra', 'describr' ),
        11 => /*translators: City.*/ __( 'Grad Dugo Selo', 'describr' ),
        12 => /*translators: City.*/ __( 'Grad Jastrebarsko', 'describr' ),
        13 => /*translators: City.*/ __( 'Grad Samobor', 'describr' ),
        14 => /*translators: City.*/ __( 'Grad Sveti Ivan Zelina', 'describr' ),
        15 => /*translators: City.*/ __( 'Grad Velika Gorica', 'describr' ),
        16 => /*translators: City.*/ __( 'Grad Vrbovec', 'describr' ),
        17 => /*translators: City.*/ __( 'Grad Zaprešić', 'describr' ),
        18 => /*translators: City.*/ __( 'Gradec', 'describr' ),
        19 => /*translators: City.*/ __( 'Gradići', 'describr' ),
        20 => /*translators: City.*/ __( 'Gračec', 'describr' ),
        21 => /*translators: City.*/ __( 'Jablanovec', 'describr' ),
        22 => /*translators: City.*/ __( 'Jakovlje', 'describr' ),
        23 => /*translators: City.*/ __( 'Jastrebarsko', 'describr' ),
        24 => /*translators: City.*/ __( 'Kerestinec', 'describr' ),
        25 => /*translators: City.*/ __( 'Križ', 'describr' ),
        26 => /*translators: City.*/ __( 'Kuče', 'describr' ),
        27 => /*translators: City.*/ __( 'Lonjica', 'describr' ),
        28 => /*translators: City.*/ __( 'Luka', 'describr' ),
        29 => /*translators: City.*/ __( 'Lukavec', 'describr' ),
        30 => /*translators: City.*/ __( 'Lupoglav', 'describr' ),
        31 => /*translators: City.*/ __( 'Mičevec', 'describr' ),
        32 => /*translators: City.*/ __( 'Mraclin', 'describr' ),
        33 => /*translators: City.*/ __( 'Novo Čiče', 'describr' ),
        34 => /*translators: City.*/ __( 'Novoselec', 'describr' ),
        35 => /*translators: City.*/ __( 'Općina Dubrava', 'describr' ),
        36 => /*translators: City.*/ __( 'Orešje', 'describr' ),
        37 => /*translators: City.*/ __( 'Pojatno', 'describr' ),
        38 => /*translators: City.*/ __( 'Preseka', 'describr' ),
        39 => /*translators: City.*/ __( 'Prigorje Brdovečko', 'describr' ),
        40 => /*translators: City.*/ __( 'Pušća', 'describr' ),
        41 => /*translators: City.*/ __( 'Rakitje', 'describr' ),
        42 => /*translators: City.*/ __( 'Rakov Potok', 'describr' ),
        43 => /*translators: City.*/ __( 'Rude', 'describr' ),
        44 => /*translators: City.*/ __( 'Samobor', 'describr' ),
        45 => /*translators: City.*/ __( 'Stupnik', 'describr' ),
        46 => /*translators: City.*/ __( 'Sveta Nedelja', 'describr' ),
        47 => /*translators: City.*/ __( 'Sveta Nedjelja', 'describr' ),
        48 => /*translators: City.*/ __( 'Velika Gorica', 'describr' ),
        49 => /*translators: City.*/ __( 'Velika Mlaka', 'describr' ),
        50 => /*translators: City.*/ __( 'Velika Ostrna', 'describr' ),
        51 => /*translators: City.*/ __( 'Vrbovec', 'describr' ),
        52 => /*translators: City.*/ __( 'Zaprešić', 'describr' ),
        53 => /*translators: City.*/ __( 'Zdenci Brdovečki', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Varaždin County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beretinec', 'describr' ),
        1 => /*translators: City.*/ __( 'Breznica', 'describr' ),
        2 => /*translators: City.*/ __( 'Breznički Hum', 'describr' ),
        3 => /*translators: City.*/ __( 'Cestica', 'describr' ),
        4 => /*translators: City.*/ __( 'Donje Ladanje', 'describr' ),
        5 => /*translators: City.*/ __( 'Gornje Vratno', 'describr' ),
        6 => /*translators: City.*/ __( 'Gornji Kneginec', 'describr' ),
        7 => /*translators: City.*/ __( 'Grad Ivanec', 'describr' ),
        8 => /*translators: City.*/ __( 'Grad Ludbreg', 'describr' ),
        9 => /*translators: City.*/ __( 'Grad Novi Marof', 'describr' ),
        10 => /*translators: City.*/ __( 'Grad Varaždin', 'describr' ),
        11 => /*translators: City.*/ __( 'Hrašćica', 'describr' ),
        12 => /*translators: City.*/ __( 'Ivanec', 'describr' ),
        13 => /*translators: City.*/ __( 'Jalkovec', 'describr' ),
        14 => /*translators: City.*/ __( 'Jalžabet', 'describr' ),
        15 => /*translators: City.*/ __( 'Klenovnik', 'describr' ),
        16 => /*translators: City.*/ __( 'Kućan Marof', 'describr' ),
        17 => /*translators: City.*/ __( 'Lepoglava', 'describr' ),
        18 => /*translators: City.*/ __( 'Ljubešćica', 'describr' ),
        19 => /*translators: City.*/ __( 'Ludbreg', 'describr' ),
        20 => /*translators: City.*/ __( 'Nedeljanec', 'describr' ),
        21 => /*translators: City.*/ __( 'Petrijanec', 'describr' ),
        22 => /*translators: City.*/ __( 'Remetinec', 'describr' ),
        23 => /*translators: City.*/ __( 'Sračinec', 'describr' ),
        24 => /*translators: City.*/ __( 'Sveti Đurđ', 'describr' ),
        25 => /*translators: City.*/ __( 'Tužno', 'describr' ),
        26 => /*translators: City.*/ __( 'Varaždin', 'describr' ),
        27 => /*translators: City.*/ __( 'Vidovec', 'describr' ),
        28 => /*translators: City.*/ __( 'Vinica', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Koprivnica-Križevci County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Drnje', 'describr' ),
        1 => /*translators: City.*/ __( 'Ferdinandovac', 'describr' ),
        2 => /*translators: City.*/ __( 'Gola', 'describr' ),
        3 => /*translators: City.*/ __( 'Gornja Rijeka', 'describr' ),
        4 => /*translators: City.*/ __( 'Grad Koprivnica', 'describr' ),
        5 => /*translators: City.*/ __( 'Grad Križevci', 'describr' ),
        6 => /*translators: City.*/ __( 'Hlebine', 'describr' ),
        7 => /*translators: City.*/ __( 'Kalinovac', 'describr' ),
        8 => /*translators: City.*/ __( 'Koprivnica', 'describr' ),
        9 => /*translators: City.*/ __( 'Koprivnički Ivanec', 'describr' ),
        10 => /*translators: City.*/ __( 'Križevci', 'describr' ),
        11 => /*translators: City.*/ __( 'Legrad', 'describr' ),
        12 => /*translators: City.*/ __( 'Molve', 'describr' ),
        13 => /*translators: City.*/ __( 'Novo Virje', 'describr' ),
        14 => /*translators: City.*/ __( 'Peteranec', 'describr' ),
        15 => /*translators: City.*/ __( 'Rasinja', 'describr' ),
        16 => /*translators: City.*/ __( 'Reka', 'describr' ),
        17 => /*translators: City.*/ __( 'Sigetec', 'describr' ),
        18 => /*translators: City.*/ __( 'Virje', 'describr' ),
        19 => /*translators: City.*/ __( 'Đelekovec', 'describr' ),
        20 => /*translators: City.*/ __( 'Đurđevac', 'describr' ),
      ),
    ),
  ),
  'CY' => 
  array (
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kyrenia District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kyrenia', 'describr' ),
        1 => /*translators: City.*/ __( 'Kyrenia Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Lápithos', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nicosia District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akáki', 'describr' ),
        1 => /*translators: City.*/ __( 'Alámpra', 'describr' ),
        2 => /*translators: City.*/ __( 'Aredioú', 'describr' ),
        3 => /*translators: City.*/ __( 'Astromerítis', 'describr' ),
        4 => /*translators: City.*/ __( 'Dáli', 'describr' ),
        5 => /*translators: City.*/ __( 'Ergátes', 'describr' ),
        6 => /*translators: City.*/ __( 'Géri', 'describr' ),
        7 => /*translators: City.*/ __( 'Kakopetriá', 'describr' ),
        8 => /*translators: City.*/ __( 'Klírou', 'describr' ),
        9 => /*translators: City.*/ __( 'Kokkinotrimithiá', 'describr' ),
        10 => /*translators: City.*/ __( 'Káto Defterá', 'describr' ),
        11 => /*translators: City.*/ __( 'Káto Pýrgos', 'describr' ),
        12 => /*translators: City.*/ __( 'Lythrodóntas', 'describr' ),
        13 => /*translators: City.*/ __( 'Léfka', 'describr' ),
        14 => /*translators: City.*/ __( 'Lýmpia', 'describr' ),
        15 => /*translators: City.*/ __( 'Mámmari', 'describr' ),
        16 => /*translators: City.*/ __( 'Méniko', 'describr' ),
        17 => /*translators: City.*/ __( 'Mórfou', 'describr' ),
        18 => /*translators: City.*/ __( 'Nicosia', 'describr' ),
        19 => /*translators: City.*/ __( 'Nicosia Municipality', 'describr' ),
        20 => /*translators: City.*/ __( 'Peristeróna', 'describr' ),
        21 => /*translators: City.*/ __( 'Psimolofou', 'describr' ),
        22 => /*translators: City.*/ __( 'Páno Defterá', 'describr' ),
        23 => /*translators: City.*/ __( 'Péra', 'describr' ),
        24 => /*translators: City.*/ __( 'Tséri', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Paphos District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Argáka', 'describr' ),
        1 => /*translators: City.*/ __( 'Chlórakas', 'describr' ),
        2 => /*translators: City.*/ __( 'Emba', 'describr' ),
        3 => /*translators: City.*/ __( 'Geroskipou', 'describr' ),
        4 => /*translators: City.*/ __( 'Geroskípou (quarter)', 'describr' ),
        5 => /*translators: City.*/ __( 'Geroskípou Municipality', 'describr' ),
        6 => /*translators: City.*/ __( 'Kissonerga', 'describr' ),
        7 => /*translators: City.*/ __( 'Koloni', 'describr' ),
        8 => /*translators: City.*/ __( 'Konia', 'describr' ),
        9 => /*translators: City.*/ __( 'Mesógi', 'describr' ),
        10 => /*translators: City.*/ __( 'Paphos', 'describr' ),
        11 => /*translators: City.*/ __( 'Pégeia', 'describr' ),
        12 => /*translators: City.*/ __( 'Pólis', 'describr' ),
        13 => /*translators: City.*/ __( 'Tsáda', 'describr' ),
        14 => /*translators: City.*/ __( 'Tála', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Larnaca District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aradíppou', 'describr' ),
        1 => /*translators: City.*/ __( 'Athíenou', 'describr' ),
        2 => /*translators: City.*/ __( 'Dhromolaxia', 'describr' ),
        3 => /*translators: City.*/ __( 'Kofínou', 'describr' ),
        4 => /*translators: City.*/ __( 'Kolossi', 'describr' ),
        5 => /*translators: City.*/ __( 'Kíti', 'describr' ),
        6 => /*translators: City.*/ __( 'Kórnos', 'describr' ),
        7 => /*translators: City.*/ __( 'Larnaca', 'describr' ),
        8 => /*translators: City.*/ __( 'Livádia', 'describr' ),
        9 => /*translators: City.*/ __( 'Meneou', 'describr' ),
        10 => /*translators: City.*/ __( 'Mosfilotí', 'describr' ),
        11 => /*translators: City.*/ __( 'Perivólia', 'describr' ),
        12 => /*translators: City.*/ __( 'Psevdás', 'describr' ),
        13 => /*translators: City.*/ __( 'Pérgamos', 'describr' ),
        14 => /*translators: City.*/ __( 'Pýla', 'describr' ),
        15 => /*translators: City.*/ __( 'Tersefánou', 'describr' ),
        16 => /*translators: City.*/ __( 'Troúlloi', 'describr' ),
        17 => /*translators: City.*/ __( 'Voróklini', 'describr' ),
        18 => /*translators: City.*/ __( 'Xylofágou', 'describr' ),
        19 => /*translators: City.*/ __( 'Xylotymbou', 'describr' ),
        20 => /*translators: City.*/ __( 'Ágios Týchon', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Limassol District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Erími', 'describr' ),
        1 => /*translators: City.*/ __( 'Germasógeia', 'describr' ),
        2 => /*translators: City.*/ __( 'Kyperoúnta', 'describr' ),
        3 => /*translators: City.*/ __( 'Lemesós', 'describr' ),
        4 => /*translators: City.*/ __( 'Limassol', 'describr' ),
        5 => /*translators: City.*/ __( 'Mouttagiáka', 'describr' ),
        6 => /*translators: City.*/ __( 'Parekklisha', 'describr' ),
        7 => /*translators: City.*/ __( 'Peléndri', 'describr' ),
        8 => /*translators: City.*/ __( 'Pissoúri', 'describr' ),
        9 => /*translators: City.*/ __( 'Pyrgos', 'describr' ),
        10 => /*translators: City.*/ __( 'Páchna', 'describr' ),
        11 => /*translators: City.*/ __( 'Páno Polemídia', 'describr' ),
        12 => /*translators: City.*/ __( 'Sotíra', 'describr' ),
        13 => /*translators: City.*/ __( 'Soúni-Zanakiá', 'describr' ),
        14 => /*translators: City.*/ __( 'Ágios Tomás', 'describr' ),
        15 => /*translators: City.*/ __( 'Ýpsonas', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Famagusta District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acherítou', 'describr' ),
        1 => /*translators: City.*/ __( 'Ammochostos Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Avgórou', 'describr' ),
        3 => /*translators: City.*/ __( 'Ayia Napa', 'describr' ),
        4 => /*translators: City.*/ __( 'Derýneia', 'describr' ),
        5 => /*translators: City.*/ __( 'Famagusta', 'describr' ),
        6 => /*translators: City.*/ __( 'Frénaros', 'describr' ),
        7 => /*translators: City.*/ __( 'Lefkónoiko', 'describr' ),
        8 => /*translators: City.*/ __( 'Leonárisso', 'describr' ),
        9 => /*translators: City.*/ __( 'Liopétri', 'describr' ),
        10 => /*translators: City.*/ __( 'Paralímni', 'describr' ),
        11 => /*translators: City.*/ __( 'Protaras', 'describr' ),
        12 => /*translators: City.*/ __( 'Rizokárpaso', 'describr' ),
        13 => /*translators: City.*/ __( 'Tríkomo', 'describr' ),
        14 => /*translators: City.*/ __( 'Áchna', 'describr' ),
      ),
    ),
  ),
  'BD' => 
  array (
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chittagong Division', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bandarban', 'describr' ),
        1 => /*translators: City.*/ __( 'Bibir Hat', 'describr' ),
        2 => /*translators: City.*/ __( 'Brahmanbaria', 'describr' ),
        3 => /*translators: City.*/ __( 'Bāndarban', 'describr' ),
        4 => /*translators: City.*/ __( 'Chandpur', 'describr' ),
        5 => /*translators: City.*/ __( 'Chhāgalnāiya', 'describr' ),
        6 => /*translators: City.*/ __( 'Chittagong', 'describr' ),
        7 => /*translators: City.*/ __( 'Comilla', 'describr' ),
        8 => /*translators: City.*/ __( 'Cox&#039;s Bazar', 'describr' ),
        9 => /*translators: City.*/ __( 'Cox&#039;s Bāzār', 'describr' ),
        10 => /*translators: City.*/ __( 'Feni', 'describr' ),
        11 => /*translators: City.*/ __( 'Hājīganj', 'describr' ),
        12 => /*translators: City.*/ __( 'Khagrachhari', 'describr' ),
        13 => /*translators: City.*/ __( 'Lakshmipur', 'describr' ),
        14 => /*translators: City.*/ __( 'Lakshmīpur', 'describr' ),
        15 => /*translators: City.*/ __( 'Lākshām', 'describr' ),
        16 => /*translators: City.*/ __( 'Manikchari', 'describr' ),
        17 => /*translators: City.*/ __( 'Nabīnagar', 'describr' ),
        18 => /*translators: City.*/ __( 'Noakhali', 'describr' ),
        19 => /*translators: City.*/ __( 'Patiya', 'describr' ),
        20 => /*translators: City.*/ __( 'Rangamati', 'describr' ),
        21 => /*translators: City.*/ __( 'Raojān', 'describr' ),
        22 => /*translators: City.*/ __( 'Rāipur', 'describr' ),
        23 => /*translators: City.*/ __( 'Rāmganj', 'describr' ),
        24 => /*translators: City.*/ __( 'Sandwīp', 'describr' ),
        25 => /*translators: City.*/ __( 'Sātkania', 'describr' ),
        26 => /*translators: City.*/ __( 'Teknāf', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Barisal District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barguna', 'describr' ),
        1 => /*translators: City.*/ __( 'Barisal', 'describr' ),
        2 => /*translators: City.*/ __( 'Barisāl', 'describr' ),
        3 => /*translators: City.*/ __( 'Bhola', 'describr' ),
        4 => /*translators: City.*/ __( 'Bhāndāria', 'describr' ),
        5 => /*translators: City.*/ __( 'Burhānuddin', 'describr' ),
        6 => /*translators: City.*/ __( 'Gaurnadi', 'describr' ),
        7 => /*translators: City.*/ __( 'Jhalokati', 'describr' ),
        8 => /*translators: City.*/ __( 'Lālmohan', 'describr' ),
        9 => /*translators: City.*/ __( 'Mathba', 'describr' ),
        10 => /*translators: City.*/ __( 'Mehendiganj', 'describr' ),
        11 => /*translators: City.*/ __( 'Nālchiti', 'describr' ),
        12 => /*translators: City.*/ __( 'Patuakhali', 'describr' ),
        13 => /*translators: City.*/ __( 'Pirojpur', 'describr' ),
      ),
    ),
  ),
  'JP' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Akita Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akita', 'describr' ),
        1 => /*translators: City.*/ __( 'Akita Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Daisen', 'describr' ),
        3 => /*translators: City.*/ __( 'Daisen-shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Hanawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Kakunodatemachi', 'describr' ),
        6 => /*translators: City.*/ __( 'Katagami', 'describr' ),
        7 => /*translators: City.*/ __( 'Katagami-shi', 'describr' ),
        8 => /*translators: City.*/ __( 'Kazuno Shi', 'describr' ),
        9 => /*translators: City.*/ __( 'Kitaakita-shi', 'describr' ),
        10 => /*translators: City.*/ __( 'Nikaho-shi', 'describr' ),
        11 => /*translators: City.*/ __( 'Noshiro', 'describr' ),
        12 => /*translators: City.*/ __( 'Noshiro Shi', 'describr' ),
        13 => /*translators: City.*/ __( 'Oga', 'describr' ),
        14 => /*translators: City.*/ __( 'Oga-shi', 'describr' ),
        15 => /*translators: City.*/ __( 'Semboku-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Takanosu', 'describr' ),
        17 => /*translators: City.*/ __( 'Tennō', 'describr' ),
        18 => /*translators: City.*/ __( 'Yokote', 'describr' ),
        19 => /*translators: City.*/ __( 'Yokote-shi', 'describr' ),
        20 => /*translators: City.*/ __( 'Yurihonjō', 'describr' ),
        21 => /*translators: City.*/ __( 'Yurihonjō-shi', 'describr' ),
        22 => /*translators: City.*/ __( 'Yuzawa', 'describr' ),
        23 => /*translators: City.*/ __( 'Yuzawa-shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Ōdate', 'describr' ),
        25 => /*translators: City.*/ __( 'Ōdate-shi', 'describr' ),
        26 => /*translators: City.*/ __( 'Ōmagari', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hokkaidō Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abashiri', 'describr' ),
        1 => /*translators: City.*/ __( 'Abashiri Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Akabira', 'describr' ),
        3 => /*translators: City.*/ __( 'Akabira-shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Asahikawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Ashibetsu', 'describr' ),
        6 => /*translators: City.*/ __( 'Ashibetsu-shi', 'describr' ),
        7 => /*translators: City.*/ __( 'Bibai', 'describr' ),
        8 => /*translators: City.*/ __( 'Chitose', 'describr' ),
        9 => /*translators: City.*/ __( 'Chitose Shi', 'describr' ),
        10 => /*translators: City.*/ __( 'Date', 'describr' ),
        11 => /*translators: City.*/ __( 'Date-shi', 'describr' ),
        12 => /*translators: City.*/ __( 'Ebetsu', 'describr' ),
        13 => /*translators: City.*/ __( 'Eniwa-shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Fukagawa', 'describr' ),
        15 => /*translators: City.*/ __( 'Fukagawa-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Furano-shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Hakodate', 'describr' ),
        18 => /*translators: City.*/ __( 'Hakodate Shi', 'describr' ),
        19 => /*translators: City.*/ __( 'Hokuto', 'describr' ),
        20 => /*translators: City.*/ __( 'Hokuto-shi', 'describr' ),
        21 => /*translators: City.*/ __( 'Honchō', 'describr' ),
        22 => /*translators: City.*/ __( 'Ishikari', 'describr' ),
        23 => /*translators: City.*/ __( 'Ishikari-shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Iwamizawa', 'describr' ),
        25 => /*translators: City.*/ __( 'Iwamizawa-shi', 'describr' ),
        26 => /*translators: City.*/ __( 'Iwanai', 'describr' ),
        27 => /*translators: City.*/ __( 'Kamiiso', 'describr' ),
        28 => /*translators: City.*/ __( 'Kamikawa', 'describr' ),
        29 => /*translators: City.*/ __( 'Kitahiroshima', 'describr' ),
        30 => /*translators: City.*/ __( 'Kitahiroshima-shi', 'describr' ),
        31 => /*translators: City.*/ __( 'Kitami', 'describr' ),
        32 => /*translators: City.*/ __( 'Ktiami Shi', 'describr' ),
        33 => /*translators: City.*/ __( 'Kushiro', 'describr' ),
        34 => /*translators: City.*/ __( 'Kushiro Shi', 'describr' ),
        35 => /*translators: City.*/ __( 'Makubetsu', 'describr' ),
        36 => /*translators: City.*/ __( 'Mikasa', 'describr' ),
        37 => /*translators: City.*/ __( 'Mikasa-shi', 'describr' ),
        38 => /*translators: City.*/ __( 'Mombetsu', 'describr' ),
        39 => /*translators: City.*/ __( 'Monbetsu Shi', 'describr' ),
        40 => /*translators: City.*/ __( 'Motomachi', 'describr' ),
        41 => /*translators: City.*/ __( 'Muroran', 'describr' ),
        42 => /*translators: City.*/ __( 'Muroran-shi', 'describr' ),
        43 => /*translators: City.*/ __( 'Nayoro', 'describr' ),
        44 => /*translators: City.*/ __( 'Nayoro Shi', 'describr' ),
        45 => /*translators: City.*/ __( 'Nemuro', 'describr' ),
        46 => /*translators: City.*/ __( 'Nemuro-shi', 'describr' ),
        47 => /*translators: City.*/ __( 'Niseko Town', 'describr' ),
        48 => /*translators: City.*/ __( 'Noboribetsu', 'describr' ),
        49 => /*translators: City.*/ __( 'Noboribetsu-shi', 'describr' ),
        50 => /*translators: City.*/ __( 'Obihiro', 'describr' ),
        51 => /*translators: City.*/ __( 'Obihiro Shi', 'describr' ),
        52 => /*translators: City.*/ __( 'Otaru', 'describr' ),
        53 => /*translators: City.*/ __( 'Otaru-shi', 'describr' ),
        54 => /*translators: City.*/ __( 'Otofuke', 'describr' ),
        55 => /*translators: City.*/ __( 'Rebun Gun', 'describr' ),
        56 => /*translators: City.*/ __( 'Rishiri Gun', 'describr' ),
        57 => /*translators: City.*/ __( 'Rishiri Town', 'describr' ),
        58 => /*translators: City.*/ __( 'Rumoi', 'describr' ),
        59 => /*translators: City.*/ __( 'Rumoi-shi', 'describr' ),
        60 => /*translators: City.*/ __( 'Sapporo', 'describr' ),
        61 => /*translators: City.*/ __( 'Sapporo-shi', 'describr' ),
        62 => /*translators: City.*/ __( 'Shibetsu', 'describr' ),
        63 => /*translators: City.*/ __( 'Shibetsu Shi', 'describr' ),
        64 => /*translators: City.*/ __( 'Shimo-furano', 'describr' ),
        65 => /*translators: City.*/ __( 'Shiraoi', 'describr' ),
        66 => /*translators: City.*/ __( 'Shizunai-furukawachō', 'describr' ),
        67 => /*translators: City.*/ __( 'Sunagawa', 'describr' ),
        68 => /*translators: City.*/ __( 'Sunagawa-shi', 'describr' ),
        69 => /*translators: City.*/ __( 'Takikawa', 'describr' ),
        70 => /*translators: City.*/ __( 'Takikawa-shi', 'describr' ),
        71 => /*translators: City.*/ __( 'Tomakomai', 'describr' ),
        72 => /*translators: City.*/ __( 'Tomakomai Shi', 'describr' ),
        73 => /*translators: City.*/ __( 'Tōbetsu', 'describr' ),
        74 => /*translators: City.*/ __( 'Utashinai', 'describr' ),
        75 => /*translators: City.*/ __( 'Utashinai-shi', 'describr' ),
        76 => /*translators: City.*/ __( 'Wakkanai', 'describr' ),
        77 => /*translators: City.*/ __( 'Wakkanai Shi', 'describr' ),
        78 => /*translators: City.*/ __( 'Yoichi', 'describr' ),
        79 => /*translators: City.*/ __( 'Yūbari', 'describr' ),
        80 => /*translators: City.*/ __( 'Yūbari-shi', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yamagata Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Higashine', 'describr' ),
        1 => /*translators: City.*/ __( 'Higashine Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Kaminoyama', 'describr' ),
        3 => /*translators: City.*/ __( 'Kaminoyama-shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Murayama', 'describr' ),
        5 => /*translators: City.*/ __( 'Murayama Shi', 'describr' ),
        6 => /*translators: City.*/ __( 'Nagai', 'describr' ),
        7 => /*translators: City.*/ __( 'Nagai-shi', 'describr' ),
        8 => /*translators: City.*/ __( 'Nanyō Shi', 'describr' ),
        9 => /*translators: City.*/ __( 'Obanazawa', 'describr' ),
        10 => /*translators: City.*/ __( 'Obanazawa Shi', 'describr' ),
        11 => /*translators: City.*/ __( 'Sagae', 'describr' ),
        12 => /*translators: City.*/ __( 'Sagae-shi', 'describr' ),
        13 => /*translators: City.*/ __( 'Sakata', 'describr' ),
        14 => /*translators: City.*/ __( 'Sakata Shi', 'describr' ),
        15 => /*translators: City.*/ __( 'Shinjō', 'describr' ),
        16 => /*translators: City.*/ __( 'Shinjō Shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Takahata', 'describr' ),
        18 => /*translators: City.*/ __( 'Tendō', 'describr' ),
        19 => /*translators: City.*/ __( 'Tendō Shi', 'describr' ),
        20 => /*translators: City.*/ __( 'Tsuruoka', 'describr' ),
        21 => /*translators: City.*/ __( 'Tsuruoka Shi', 'describr' ),
        22 => /*translators: City.*/ __( 'Yamagata', 'describr' ),
        23 => /*translators: City.*/ __( 'Yamagata Shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Yonezawa', 'describr' ),
        25 => /*translators: City.*/ __( 'Yonezawa Shi', 'describr' ),
        26 => /*translators: City.*/ __( 'Yuza', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aomori Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aomori', 'describr' ),
        1 => /*translators: City.*/ __( 'Aomori Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Goshogawara', 'describr' ),
        3 => /*translators: City.*/ __( 'Goshogawara Shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Hachinohe', 'describr' ),
        5 => /*translators: City.*/ __( 'Hachinohe Shi', 'describr' ),
        6 => /*translators: City.*/ __( 'Hirakawa', 'describr' ),
        7 => /*translators: City.*/ __( 'Hirakawa Shi', 'describr' ),
        8 => /*translators: City.*/ __( 'Hirosaki', 'describr' ),
        9 => /*translators: City.*/ __( 'Hirosaki Shi', 'describr' ),
        10 => /*translators: City.*/ __( 'Kuroishi', 'describr' ),
        11 => /*translators: City.*/ __( 'Kuroishi Shi', 'describr' ),
        12 => /*translators: City.*/ __( 'Misawa', 'describr' ),
        13 => /*translators: City.*/ __( 'Misawa Shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Mutsu', 'describr' ),
        15 => /*translators: City.*/ __( 'Mutsu-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Namioka', 'describr' ),
        17 => /*translators: City.*/ __( 'Shimokizukuri', 'describr' ),
        18 => /*translators: City.*/ __( 'Towada Shi', 'describr' ),
        19 => /*translators: City.*/ __( 'Tsugaru', 'describr' ),
        20 => /*translators: City.*/ __( 'Tsugaru Shi', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fukushima Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aizu-wakamatsu Shi', 'describr' ),
        1 => /*translators: City.*/ __( 'Date-shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Fukushima', 'describr' ),
        3 => /*translators: City.*/ __( 'Fukushima Shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Funehikimachi-funehiki', 'describr' ),
        5 => /*translators: City.*/ __( 'Hobaramachi', 'describr' ),
        6 => /*translators: City.*/ __( 'Inawashiro', 'describr' ),
        7 => /*translators: City.*/ __( 'Ishikawa', 'describr' ),
        8 => /*translators: City.*/ __( 'Iwaki', 'describr' ),
        9 => /*translators: City.*/ __( 'Iwaki-shi', 'describr' ),
        10 => /*translators: City.*/ __( 'Kitakata', 'describr' ),
        11 => /*translators: City.*/ __( 'Kitakata-shi', 'describr' ),
        12 => /*translators: City.*/ __( 'Kōriyama', 'describr' ),
        13 => /*translators: City.*/ __( 'Kōriyama Shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Miharu', 'describr' ),
        15 => /*translators: City.*/ __( 'Minami-Sōma', 'describr' ),
        16 => /*translators: City.*/ __( 'Minamisōma Shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Motomiya', 'describr' ),
        18 => /*translators: City.*/ __( 'Motomiya-shi', 'describr' ),
        19 => /*translators: City.*/ __( 'Namie', 'describr' ),
        20 => /*translators: City.*/ __( 'Nihommatsu', 'describr' ),
        21 => /*translators: City.*/ __( 'Nihonmatsu Shi', 'describr' ),
        22 => /*translators: City.*/ __( 'Shirakawa Shi', 'describr' ),
        23 => /*translators: City.*/ __( 'Sukagawa', 'describr' ),
        24 => /*translators: City.*/ __( 'Sukagawa Shi', 'describr' ),
        25 => /*translators: City.*/ __( 'Sōma', 'describr' ),
        26 => /*translators: City.*/ __( 'Sōma Shi', 'describr' ),
        27 => /*translators: City.*/ __( 'Tamura', 'describr' ),
        28 => /*translators: City.*/ __( 'Tamura-shi', 'describr' ),
        29 => /*translators: City.*/ __( 'Yanagawamachi-saiwaichō', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ibaraki Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ami', 'describr' ),
        1 => /*translators: City.*/ __( 'Bandō', 'describr' ),
        2 => /*translators: City.*/ __( 'Bandō-shi', 'describr' ),
        3 => /*translators: City.*/ __( 'Chikusei', 'describr' ),
        4 => /*translators: City.*/ __( 'Chikusei-shi', 'describr' ),
        5 => /*translators: City.*/ __( 'Daigo', 'describr' ),
        6 => /*translators: City.*/ __( 'Edosaki', 'describr' ),
        7 => /*translators: City.*/ __( 'Fujishiro', 'describr' ),
        8 => /*translators: City.*/ __( 'Funaishikawa', 'describr' ),
        9 => /*translators: City.*/ __( 'Hitachi', 'describr' ),
        10 => /*translators: City.*/ __( 'Hitachi-Naka', 'describr' ),
        11 => /*translators: City.*/ __( 'Hitachi-ota', 'describr' ),
        12 => /*translators: City.*/ __( 'Hitachi-shi', 'describr' ),
        13 => /*translators: City.*/ __( 'Hitachinaka-shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Hitachiōmiya-shi', 'describr' ),
        15 => /*translators: City.*/ __( 'Hitachiōta-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Hokota-shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Inashiki', 'describr' ),
        18 => /*translators: City.*/ __( 'Inashiki-shi', 'describr' ),
        19 => /*translators: City.*/ __( 'Ishige', 'describr' ),
        20 => /*translators: City.*/ __( 'Ishioka', 'describr' ),
        21 => /*translators: City.*/ __( 'Ishioka-shi', 'describr' ),
        22 => /*translators: City.*/ __( 'Itako', 'describr' ),
        23 => /*translators: City.*/ __( 'Itako-shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Iwai', 'describr' ),
        25 => /*translators: City.*/ __( 'Iwase', 'describr' ),
        26 => /*translators: City.*/ __( 'Jōsō-shi', 'describr' ),
        27 => /*translators: City.*/ __( 'Kamisu-shi', 'describr' ),
        28 => /*translators: City.*/ __( 'Kasama', 'describr' ),
        29 => /*translators: City.*/ __( 'Kasama-shi', 'describr' ),
        30 => /*translators: City.*/ __( 'Kashima-shi', 'describr' ),
        31 => /*translators: City.*/ __( 'Kasumigaura', 'describr' ),
        32 => /*translators: City.*/ __( 'Kasumigaura-shi', 'describr' ),
        33 => /*translators: City.*/ __( 'Katsuta', 'describr' ),
        34 => /*translators: City.*/ __( 'Kitaibaraki', 'describr' ),
        35 => /*translators: City.*/ __( 'Kitaibaraki-shi', 'describr' ),
        36 => /*translators: City.*/ __( 'Koga', 'describr' ),
        37 => /*translators: City.*/ __( 'Koga-shi', 'describr' ),
        38 => /*translators: City.*/ __( 'Makabe', 'describr' ),
        39 => /*translators: City.*/ __( 'Mito', 'describr' ),
        40 => /*translators: City.*/ __( 'Mito-shi', 'describr' ),
        41 => /*translators: City.*/ __( 'Mitsukaidō', 'describr' ),
        42 => /*translators: City.*/ __( 'Moriya', 'describr' ),
        43 => /*translators: City.*/ __( 'Moriya-shi', 'describr' ),
        44 => /*translators: City.*/ __( 'Naka', 'describr' ),
        45 => /*translators: City.*/ __( 'Naka-gun', 'describr' ),
        46 => /*translators: City.*/ __( 'Namegata', 'describr' ),
        47 => /*translators: City.*/ __( 'Namegata-shi', 'describr' ),
        48 => /*translators: City.*/ __( 'Okunoya', 'describr' ),
        49 => /*translators: City.*/ __( 'Omitama-shi', 'describr' ),
        50 => /*translators: City.*/ __( 'Ryūgasaki', 'describr' ),
        51 => /*translators: City.*/ __( 'Ryūgasaki-shi', 'describr' ),
        52 => /*translators: City.*/ __( 'Sakai', 'describr' ),
        53 => /*translators: City.*/ __( 'Sakuragawa', 'describr' ),
        54 => /*translators: City.*/ __( 'Sakuragawa-shi', 'describr' ),
        55 => /*translators: City.*/ __( 'Shimodate', 'describr' ),
        56 => /*translators: City.*/ __( 'Shimotsuma-shi', 'describr' ),
        57 => /*translators: City.*/ __( 'Takahagi', 'describr' ),
        58 => /*translators: City.*/ __( 'Tomobe', 'describr' ),
        59 => /*translators: City.*/ __( 'Toride', 'describr' ),
        60 => /*translators: City.*/ __( 'Toride-shi', 'describr' ),
        61 => /*translators: City.*/ __( 'Tsuchiura-shi', 'describr' ),
        62 => /*translators: City.*/ __( 'Tsukuba', 'describr' ),
        63 => /*translators: City.*/ __( 'Tsukuba-shi', 'describr' ),
        64 => /*translators: City.*/ __( 'Tsukubamirai', 'describr' ),
        65 => /*translators: City.*/ __( 'Tsukubamirai-shi', 'describr' ),
        66 => /*translators: City.*/ __( 'Ushiku', 'describr' ),
        67 => /*translators: City.*/ __( 'Ushiku-shi', 'describr' ),
        68 => /*translators: City.*/ __( 'Yūki', 'describr' ),
        69 => /*translators: City.*/ __( 'Yūki-shi', 'describr' ),
        70 => /*translators: City.*/ __( 'Ōarai', 'describr' ),
        71 => /*translators: City.*/ __( 'Ōmiya', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tochigi Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ashikaga', 'describr' ),
        1 => /*translators: City.*/ __( 'Fujioka', 'describr' ),
        2 => /*translators: City.*/ __( 'Imaichi', 'describr' ),
        3 => /*translators: City.*/ __( 'Kaminokawa', 'describr' ),
        4 => /*translators: City.*/ __( 'Kanuma', 'describr' ),
        5 => /*translators: City.*/ __( 'Kanuma-shi', 'describr' ),
        6 => /*translators: City.*/ __( 'Karasuyama', 'describr' ),
        7 => /*translators: City.*/ __( 'Kuroiso', 'describr' ),
        8 => /*translators: City.*/ __( 'Mashiko', 'describr' ),
        9 => /*translators: City.*/ __( 'Mibu', 'describr' ),
        10 => /*translators: City.*/ __( 'Mooka', 'describr' ),
        11 => /*translators: City.*/ __( 'Mooka-shi', 'describr' ),
        12 => /*translators: City.*/ __( 'Motegi', 'describr' ),
        13 => /*translators: City.*/ __( 'Nasukarasuyama', 'describr' ),
        14 => /*translators: City.*/ __( 'Nasukarasuyama-shi', 'describr' ),
        15 => /*translators: City.*/ __( 'Nasushiobara-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Nikko-shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Nikkō', 'describr' ),
        18 => /*translators: City.*/ __( 'Oyama', 'describr' ),
        19 => /*translators: City.*/ __( 'Oyama-shi', 'describr' ),
        20 => /*translators: City.*/ __( 'Sakura-shi', 'describr' ),
        21 => /*translators: City.*/ __( 'Sano', 'describr' ),
        22 => /*translators: City.*/ __( 'Sano-shi', 'describr' ),
        23 => /*translators: City.*/ __( 'Shimotsuke-shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Tanuma', 'describr' ),
        25 => /*translators: City.*/ __( 'Tochigi-shi', 'describr' ),
        26 => /*translators: City.*/ __( 'Ujiie', 'describr' ),
        27 => /*translators: City.*/ __( 'Utsunomiya', 'describr' ),
        28 => /*translators: City.*/ __( 'Utsunomiya-shi', 'describr' ),
        29 => /*translators: City.*/ __( 'Yaita', 'describr' ),
        30 => /*translators: City.*/ __( 'Yaita-shi', 'describr' ),
        31 => /*translators: City.*/ __( 'Ōtawara', 'describr' ),
        32 => /*translators: City.*/ __( 'Ōtawara-shi', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Iwate Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hachimantai', 'describr' ),
        1 => /*translators: City.*/ __( 'Hachimantai Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Hanamaki', 'describr' ),
        3 => /*translators: City.*/ __( 'Hanamaki Shi', 'describr' ),
        4 => /*translators: City.*/ __( 'Ichinohe', 'describr' ),
        5 => /*translators: City.*/ __( 'Ichinoseki', 'describr' ),
        6 => /*translators: City.*/ __( 'Ichinoseki-shi', 'describr' ),
        7 => /*translators: City.*/ __( 'Iwate-gun', 'describr' ),
        8 => /*translators: City.*/ __( 'Kamaishi', 'describr' ),
        9 => /*translators: City.*/ __( 'Kamaishi-shi', 'describr' ),
        10 => /*translators: City.*/ __( 'Kitakami', 'describr' ),
        11 => /*translators: City.*/ __( 'Kitakami-shi', 'describr' ),
        12 => /*translators: City.*/ __( 'Kuji', 'describr' ),
        13 => /*translators: City.*/ __( 'Kuji-shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Miyako', 'describr' ),
        15 => /*translators: City.*/ __( 'Miyako-shi', 'describr' ),
        16 => /*translators: City.*/ __( 'Mizusawa', 'describr' ),
        17 => /*translators: City.*/ __( 'Morioka', 'describr' ),
        18 => /*translators: City.*/ __( 'Morioka-shi', 'describr' ),
        19 => /*translators: City.*/ __( 'Ninohe', 'describr' ),
        20 => /*translators: City.*/ __( 'Ninohe Shi', 'describr' ),
        21 => /*translators: City.*/ __( 'Rikuzentakata-shi', 'describr' ),
        22 => /*translators: City.*/ __( 'Shizukuishi', 'describr' ),
        23 => /*translators: City.*/ __( 'Takizawa-shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Tōno', 'describr' ),
        25 => /*translators: City.*/ __( 'Tōno-shi', 'describr' ),
        26 => /*translators: City.*/ __( 'Yamada', 'describr' ),
        27 => /*translators: City.*/ __( 'Ōfunato', 'describr' ),
        28 => /*translators: City.*/ __( 'Ōfunato-shi', 'describr' ),
        29 => /*translators: City.*/ __( 'Ōshū', 'describr' ),
        30 => /*translators: City.*/ __( 'Ōshū-shi', 'describr' ),
        31 => /*translators: City.*/ __( 'Ōtsuchi', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Miyagi Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Furukawa', 'describr' ),
        1 => /*translators: City.*/ __( 'Higashimatshushima Shi', 'describr' ),
        2 => /*translators: City.*/ __( 'Higashimatsushima', 'describr' ),
        3 => /*translators: City.*/ __( 'Ishinomaki', 'describr' ),
        4 => /*translators: City.*/ __( 'Ishinomaki Shi', 'describr' ),
        5 => /*translators: City.*/ __( 'Iwanuma', 'describr' ),
        6 => /*translators: City.*/ __( 'Iwanuma-shi', 'describr' ),
        7 => /*translators: City.*/ __( 'Kakuda', 'describr' ),
        8 => /*translators: City.*/ __( 'Kakuda Shi', 'describr' ),
        9 => /*translators: City.*/ __( 'Kesennuma', 'describr' ),
        10 => /*translators: City.*/ __( 'Kesennuma Shi', 'describr' ),
        11 => /*translators: City.*/ __( 'Kogota', 'describr' ),
        12 => /*translators: City.*/ __( 'Kurihara', 'describr' ),
        13 => /*translators: City.*/ __( 'Kurihara Shi', 'describr' ),
        14 => /*translators: City.*/ __( 'Marumori', 'describr' ),
        15 => /*translators: City.*/ __( 'Matsushima', 'describr' ),
        16 => /*translators: City.*/ __( 'Natori Shi', 'describr' ),
        17 => /*translators: City.*/ __( 'Onagawa Chō', 'describr' ),
        18 => /*translators: City.*/ __( 'Rifu', 'describr' ),
        19 => /*translators: City.*/ __( 'Sendai', 'describr' ),
        20 => /*translators: City.*/ __( 'Shiogama', 'describr' ),
        21 => /*translators: City.*/ __( 'Shiroishi', 'describr' ),
        22 => /*translators: City.*/ __( 'Shiroishi Shi', 'describr' ),
        23 => /*translators: City.*/ __( 'Tagajō Shi', 'describr' ),
        24 => /*translators: City.*/ __( 'Tome Shi', 'describr' ),
        25 => /*translators: City.*/ __( 'Tomiya', 'describr' ),
        26 => /*translators: City.*/ __( 'Wakuya', 'describr' ),
        27 => /*translators: City.*/ __( 'Watari', 'describr' ),
        28 => /*translators: City.*/ __( 'Watari-gun', 'describr' ),
        29 => /*translators: City.*/ __( 'Yamoto', 'describr' ),
        30 => /*translators: City.*/ __( 'Ōkawara', 'describr' ),
        31 => /*translators: City.*/ __( 'Ōsaki', 'describr' ),
        32 => /*translators: City.*/ __( 'Ōsaki Shi', 'describr' ),
      ),
    ),
  ),
  'CA' => 
  array (
    'ON' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ontario', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajax', 'describr' ),
        1 => /*translators: City.*/ __( 'Algoma', 'describr' ),
        2 => /*translators: City.*/ __( 'Alliston', 'describr' ),
        3 => /*translators: City.*/ __( 'Amherstburg', 'describr' ),
        4 => /*translators: City.*/ __( 'Amigo Beach', 'describr' ),
        5 => /*translators: City.*/ __( 'Ancaster', 'describr' ),
        6 => /*translators: City.*/ __( 'Angus', 'describr' ),
        7 => /*translators: City.*/ __( 'Arnprior', 'describr' ),
        8 => /*translators: City.*/ __( 'Atikokan', 'describr' ),
        9 => /*translators: City.*/ __( 'Attawapiskat', 'describr' ),
        10 => /*translators: City.*/ __( 'Aurora', 'describr' ),
        11 => /*translators: City.*/ __( 'Aylmer', 'describr' ),
        12 => /*translators: City.*/ __( 'Azilda', 'describr' ),
        13 => /*translators: City.*/ __( 'Ballantrae', 'describr' ),
        14 => /*translators: City.*/ __( 'Bancroft', 'describr' ),
        15 => /*translators: City.*/ __( 'Barrie', 'describr' ),
        16 => /*translators: City.*/ __( 'Bath', 'describr' ),
        17 => /*translators: City.*/ __( 'Belleville', 'describr' ),
        18 => /*translators: City.*/ __( 'Bells Corners', 'describr' ),
        19 => /*translators: City.*/ __( 'Belmont', 'describr' ),
        20 => /*translators: City.*/ __( 'Binbrook', 'describr' ),
        21 => /*translators: City.*/ __( 'Bluewater', 'describr' ),
        22 => /*translators: City.*/ __( 'Bourget', 'describr' ),
        23 => /*translators: City.*/ __( 'Bracebridge', 'describr' ),
        24 => /*translators: City.*/ __( 'Brampton', 'describr' ),
        25 => /*translators: City.*/ __( 'Brant', 'describr' ),
        26 => /*translators: City.*/ __( 'Brantford', 'describr' ),
        27 => /*translators: City.*/ __( 'Brockville', 'describr' ),
        28 => /*translators: City.*/ __( 'Brussels', 'describr' ),
        29 => /*translators: City.*/ __( 'Burford', 'describr' ),
        30 => /*translators: City.*/ __( 'Burlington', 'describr' ),
        31 => /*translators: City.*/ __( 'Cambridge', 'describr' ),
        32 => /*translators: City.*/ __( 'Camlachie', 'describr' ),
        33 => /*translators: City.*/ __( 'Capreol', 'describr' ),
        34 => /*translators: City.*/ __( 'Carleton Place', 'describr' ),
        35 => /*translators: City.*/ __( 'Casselman', 'describr' ),
        36 => /*translators: City.*/ __( 'Chatham', 'describr' ),
        37 => /*translators: City.*/ __( 'Chatham-Kent', 'describr' ),
        38 => /*translators: City.*/ __( 'Clarence-Rockland', 'describr' ),
        39 => /*translators: City.*/ __( 'Cobourg', 'describr' ),
        40 => /*translators: City.*/ __( 'Cochrane District', 'describr' ),
        41 => /*translators: City.*/ __( 'Collingwood', 'describr' ),
        42 => /*translators: City.*/ __( 'Concord', 'describr' ),
        43 => /*translators: City.*/ __( 'Constance Bay', 'describr' ),
        44 => /*translators: City.*/ __( 'Cookstown', 'describr' ),
        45 => /*translators: City.*/ __( 'Cornwall', 'describr' ),
        46 => /*translators: City.*/ __( 'Corunna', 'describr' ),
        47 => /*translators: City.*/ __( 'Deep River', 'describr' ),
        48 => /*translators: City.*/ __( 'Delaware', 'describr' ),
        49 => /*translators: City.*/ __( 'Deseronto', 'describr' ),
        50 => /*translators: City.*/ __( 'Dorchester', 'describr' ),
        51 => /*translators: City.*/ __( 'Dowling', 'describr' ),
        52 => /*translators: City.*/ __( 'Dryden', 'describr' ),
        53 => /*translators: City.*/ __( 'Durham', 'describr' ),
        54 => /*translators: City.*/ __( 'Ear Falls', 'describr' ),
        55 => /*translators: City.*/ __( 'East Gwillimbury', 'describr' ),
        56 => /*translators: City.*/ __( 'East York', 'describr' ),
        57 => /*translators: City.*/ __( 'Elliot Lake', 'describr' ),
        58 => /*translators: City.*/ __( 'Elmvale', 'describr' ),
        59 => /*translators: City.*/ __( 'Englehart', 'describr' ),
        60 => /*translators: City.*/ __( 'Espanola', 'describr' ),
        61 => /*translators: City.*/ __( 'Essex', 'describr' ),
        62 => /*translators: City.*/ __( 'Etobicoke', 'describr' ),
        63 => /*translators: City.*/ __( 'Fort Erie', 'describr' ),
        64 => /*translators: City.*/ __( 'Fort Frances', 'describr' ),
        65 => /*translators: City.*/ __( 'Gananoque', 'describr' ),
        66 => /*translators: City.*/ __( 'Glencoe', 'describr' ),
        67 => /*translators: City.*/ __( 'Goderich', 'describr' ),
        68 => /*translators: City.*/ __( 'Golden', 'describr' ),
        69 => /*translators: City.*/ __( 'Gravenhurst', 'describr' ),
        70 => /*translators: City.*/ __( 'Greater Napanee', 'describr' ),
        71 => /*translators: City.*/ __( 'Greater Sudbury', 'describr' ),
        72 => /*translators: City.*/ __( 'Greenstone', 'describr' ),
        73 => /*translators: City.*/ __( 'Guelph', 'describr' ),
        74 => /*translators: City.*/ __( 'Haldimand County', 'describr' ),
        75 => /*translators: City.*/ __( 'Haliburton Village', 'describr' ),
        76 => /*translators: City.*/ __( 'Halton', 'describr' ),
        77 => /*translators: City.*/ __( 'Hamilton', 'describr' ),
        78 => /*translators: City.*/ __( 'Hanover', 'describr' ),
        79 => /*translators: City.*/ __( 'Harriston', 'describr' ),
        80 => /*translators: City.*/ __( 'Hawkesbury', 'describr' ),
        81 => /*translators: City.*/ __( 'Hearst', 'describr' ),
        82 => /*translators: City.*/ __( 'Hornepayne', 'describr' ),
        83 => /*translators: City.*/ __( 'Huntsville', 'describr' ),
        84 => /*translators: City.*/ __( 'Huron East', 'describr' ),
        85 => /*translators: City.*/ __( 'Ingersoll', 'describr' ),
        86 => /*translators: City.*/ __( 'Innisfil', 'describr' ),
        87 => /*translators: City.*/ __( 'Iroquois Falls', 'describr' ),
        88 => /*translators: City.*/ __( 'Jarvis', 'describr' ),
        89 => /*translators: City.*/ __( 'Kanata', 'describr' ),
        90 => /*translators: City.*/ __( 'Kapuskasing', 'describr' ),
        91 => /*translators: City.*/ __( 'Kawartha Lakes', 'describr' ),
        92 => /*translators: City.*/ __( 'Kenora', 'describr' ),
        93 => /*translators: City.*/ __( 'Keswick', 'describr' ),
        94 => /*translators: City.*/ __( 'Kincardine', 'describr' ),
        95 => /*translators: City.*/ __( 'King', 'describr' ),
        96 => /*translators: City.*/ __( 'Kingston', 'describr' ),
        97 => /*translators: City.*/ __( 'Kirkland Lake', 'describr' ),
        98 => /*translators: City.*/ __( 'Kitchener', 'describr' ),
        99 => /*translators: City.*/ __( 'L&#039;Orignal', 'describr' ),
        100 => /*translators: City.*/ __( 'Lakefield', 'describr' ),
        101 => /*translators: City.*/ __( 'Lambton Shores', 'describr' ),
        102 => /*translators: City.*/ __( 'Lappe', 'describr' ),
        103 => /*translators: City.*/ __( 'Leamington', 'describr' ),
        104 => /*translators: City.*/ __( 'Limoges', 'describr' ),
        105 => /*translators: City.*/ __( 'Lindsay', 'describr' ),
        106 => /*translators: City.*/ __( 'Listowel', 'describr' ),
        107 => /*translators: City.*/ __( 'Little Current', 'describr' ),
        108 => /*translators: City.*/ __( 'Lively', 'describr' ),
        109 => /*translators: City.*/ __( 'London', 'describr' ),
        110 => /*translators: City.*/ __( 'Lucan', 'describr' ),
        111 => /*translators: City.*/ __( 'Madoc', 'describr' ),
        112 => /*translators: City.*/ __( 'Manitoulin District', 'describr' ),
        113 => /*translators: City.*/ __( 'Manitouwadge', 'describr' ),
        114 => /*translators: City.*/ __( 'Marathon', 'describr' ),
        115 => /*translators: City.*/ __( 'Markdale', 'describr' ),
        116 => /*translators: City.*/ __( 'Markham', 'describr' ),
        117 => /*translators: City.*/ __( 'Mattawa', 'describr' ),
        118 => /*translators: City.*/ __( 'Meaford', 'describr' ),
        119 => /*translators: City.*/ __( 'Metcalfe', 'describr' ),
        120 => /*translators: City.*/ __( 'Midland', 'describr' ),
        121 => /*translators: City.*/ __( 'Mildmay', 'describr' ),
        122 => /*translators: City.*/ __( 'Millbrook', 'describr' ),
        123 => /*translators: City.*/ __( 'Milton', 'describr' ),
        124 => /*translators: City.*/ __( 'Mississauga', 'describr' ),
        125 => /*translators: City.*/ __( 'Mississauga Beach', 'describr' ),
        126 => /*translators: City.*/ __( 'Moose Factory', 'describr' ),
        127 => /*translators: City.*/ __( 'Moosonee', 'describr' ),
        128 => /*translators: City.*/ __( 'Morrisburg', 'describr' ),
        129 => /*translators: City.*/ __( 'Mount Albert', 'describr' ),
        130 => /*translators: City.*/ __( 'Mount Brydges', 'describr' ),
        131 => /*translators: City.*/ __( 'Napanee', 'describr' ),
        132 => /*translators: City.*/ __( 'Napanee Downtown', 'describr' ),
        133 => /*translators: City.*/ __( 'Neebing', 'describr' ),
        134 => /*translators: City.*/ __( 'Nepean', 'describr' ),
        135 => /*translators: City.*/ __( 'New Hamburg', 'describr' ),
        136 => /*translators: City.*/ __( 'Newmarket', 'describr' ),
        137 => /*translators: City.*/ __( 'Niagara Falls', 'describr' ),
        138 => /*translators: City.*/ __( 'Nipissing District', 'describr' ),
        139 => /*translators: City.*/ __( 'Norfolk County', 'describr' ),
        140 => /*translators: City.*/ __( 'North Bay', 'describr' ),
        141 => /*translators: City.*/ __( 'North Perth', 'describr' ),
        142 => /*translators: City.*/ __( 'North York', 'describr' ),
        143 => /*translators: City.*/ __( 'Norwood', 'describr' ),
        144 => /*translators: City.*/ __( 'Oakville', 'describr' ),
        145 => /*translators: City.*/ __( 'Omemee', 'describr' ),
        146 => /*translators: City.*/ __( 'Orangeville', 'describr' ),
        147 => /*translators: City.*/ __( 'Orillia', 'describr' ),
        148 => /*translators: City.*/ __( 'Osgoode', 'describr' ),
        149 => /*translators: City.*/ __( 'Oshawa', 'describr' ),
        150 => /*translators: City.*/ __( 'Ottawa', 'describr' ),
        151 => /*translators: City.*/ __( 'Owen Sound', 'describr' ),
        152 => /*translators: City.*/ __( 'Paisley', 'describr' ),
        153 => /*translators: City.*/ __( 'Paris', 'describr' ),
        154 => /*translators: City.*/ __( 'Parkhill', 'describr' ),
        155 => /*translators: City.*/ __( 'Parry Sound', 'describr' ),
        156 => /*translators: City.*/ __( 'Parry Sound District', 'describr' ),
        157 => /*translators: City.*/ __( 'Peel', 'describr' ),
        158 => /*translators: City.*/ __( 'Pembroke', 'describr' ),
        159 => /*translators: City.*/ __( 'Perth', 'describr' ),
        160 => /*translators: City.*/ __( 'Petawawa', 'describr' ),
        161 => /*translators: City.*/ __( 'Peterborough', 'describr' ),
        162 => /*translators: City.*/ __( 'Petrolia', 'describr' ),
        163 => /*translators: City.*/ __( 'Pickering', 'describr' ),
        164 => /*translators: City.*/ __( 'Picton', 'describr' ),
        165 => /*translators: City.*/ __( 'Plantagenet', 'describr' ),
        166 => /*translators: City.*/ __( 'Plattsville', 'describr' ),
        167 => /*translators: City.*/ __( 'Port Colborne', 'describr' ),
        168 => /*translators: City.*/ __( 'Port Hope', 'describr' ),
        169 => /*translators: City.*/ __( 'Port Rowan', 'describr' ),
        170 => /*translators: City.*/ __( 'Port Stanley', 'describr' ),
        171 => /*translators: City.*/ __( 'Powassan', 'describr' ),
        172 => /*translators: City.*/ __( 'Prescott', 'describr' ),
        173 => /*translators: City.*/ __( 'Prince Edward', 'describr' ),
        174 => /*translators: City.*/ __( 'Queenswood Heights', 'describr' ),
        175 => /*translators: City.*/ __( 'Quinte West', 'describr' ),
        176 => /*translators: City.*/ __( 'Rainy River District', 'describr' ),
        177 => /*translators: City.*/ __( 'Rayside-Balfour', 'describr' ),
        178 => /*translators: City.*/ __( 'Red Lake', 'describr' ),
        179 => /*translators: City.*/ __( 'Regional Municipality of Waterloo', 'describr' ),
        180 => /*translators: City.*/ __( 'Renfrew', 'describr' ),
        181 => /*translators: City.*/ __( 'Richmond', 'describr' ),
        182 => /*translators: City.*/ __( 'Richmond Hill', 'describr' ),
        183 => /*translators: City.*/ __( 'Ridgetown', 'describr' ),
        184 => /*translators: City.*/ __( 'Rockwood', 'describr' ),
        185 => /*translators: City.*/ __( 'Russell', 'describr' ),
        186 => /*translators: City.*/ __( 'Sarnia', 'describr' ),
        187 => /*translators: City.*/ __( 'Sault Ste. Marie', 'describr' ),
        188 => /*translators: City.*/ __( 'Scarborough', 'describr' ),
        189 => /*translators: City.*/ __( 'Seaforth', 'describr' ),
        190 => /*translators: City.*/ __( 'Shelburne', 'describr' ),
        191 => /*translators: City.*/ __( 'Simcoe', 'describr' ),
        192 => /*translators: City.*/ __( 'Sioux Lookout', 'describr' ),
        193 => /*translators: City.*/ __( 'Skatepark', 'describr' ),
        194 => /*translators: City.*/ __( 'Smiths Falls', 'describr' ),
        195 => /*translators: City.*/ __( 'South Huron', 'describr' ),
        196 => /*translators: City.*/ __( 'South River', 'describr' ),
        197 => /*translators: City.*/ __( 'St. Catharines', 'describr' ),
        198 => /*translators: City.*/ __( 'St. George', 'describr' ),
        199 => /*translators: City.*/ __( 'St. Thomas', 'describr' ),
        200 => /*translators: City.*/ __( 'Stirling', 'describr' ),
        201 => /*translators: City.*/ __( 'Stoney Point', 'describr' ),
        202 => /*translators: City.*/ __( 'Stratford', 'describr' ),
        203 => /*translators: City.*/ __( 'Sudbury', 'describr' ),
        204 => /*translators: City.*/ __( 'Tavistock', 'describr' ),
        205 => /*translators: City.*/ __( 'Temiskaming Shores', 'describr' ),
        206 => /*translators: City.*/ __( 'Thessalon', 'describr' ),
        207 => /*translators: City.*/ __( 'Thorold', 'describr' ),
        208 => /*translators: City.*/ __( 'Thunder Bay', 'describr' ),
        209 => /*translators: City.*/ __( 'Thunder Bay District', 'describr' ),
        210 => /*translators: City.*/ __( 'Timiskaming District', 'describr' ),
        211 => /*translators: City.*/ __( 'Timmins', 'describr' ),
        212 => /*translators: City.*/ __( 'Tobermory', 'describr' ),
        213 => /*translators: City.*/ __( 'Toronto', 'describr' ),
        214 => /*translators: City.*/ __( 'Toronto county', 'describr' ),
        215 => /*translators: City.*/ __( 'Tottenham', 'describr' ),
        216 => /*translators: City.*/ __( 'Tweed', 'describr' ),
        217 => /*translators: City.*/ __( 'Uxbridge', 'describr' ),
        218 => /*translators: City.*/ __( 'Valley East', 'describr' ),
        219 => /*translators: City.*/ __( 'Vanier', 'describr' ),
        220 => /*translators: City.*/ __( 'Vaughan', 'describr' ),
        221 => /*translators: City.*/ __( 'Vineland', 'describr' ),
        222 => /*translators: City.*/ __( 'Virgil', 'describr' ),
        223 => /*translators: City.*/ __( 'Walpole Island', 'describr' ),
        224 => /*translators: City.*/ __( 'Wasaga Beach', 'describr' ),
        225 => /*translators: City.*/ __( 'Waterford', 'describr' ),
        226 => /*translators: City.*/ __( 'Waterloo', 'describr' ),
        227 => /*translators: City.*/ __( 'Watford', 'describr' ),
        228 => /*translators: City.*/ __( 'Wawa', 'describr' ),
        229 => /*translators: City.*/ __( 'Welland', 'describr' ),
        230 => /*translators: City.*/ __( 'Wellesley', 'describr' ),
        231 => /*translators: City.*/ __( 'Wendover', 'describr' ),
        232 => /*translators: City.*/ __( 'West Lorne', 'describr' ),
        233 => /*translators: City.*/ __( 'Willowdale', 'describr' ),
        234 => /*translators: City.*/ __( 'Winchester', 'describr' ),
        235 => /*translators: City.*/ __( 'Windsor', 'describr' ),
        236 => /*translators: City.*/ __( 'Wingham', 'describr' ),
        237 => /*translators: City.*/ __( 'Woodstock', 'describr' ),
        238 => /*translators: City.*/ __( 'York', 'describr' ),
      ),
    ),
    'MB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manitoba', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Altona', 'describr' ),
        1 => /*translators: City.*/ __( 'Beausejour', 'describr' ),
        2 => /*translators: City.*/ __( 'Boissevain', 'describr' ),
        3 => /*translators: City.*/ __( 'Brandon', 'describr' ),
        4 => /*translators: City.*/ __( 'Carberry', 'describr' ),
        5 => /*translators: City.*/ __( 'Carman', 'describr' ),
        6 => /*translators: City.*/ __( 'Cross Lake 19A', 'describr' ),
        7 => /*translators: City.*/ __( 'Dauphin', 'describr' ),
        8 => /*translators: City.*/ __( 'De Salaberry', 'describr' ),
        9 => /*translators: City.*/ __( 'Deloraine', 'describr' ),
        10 => /*translators: City.*/ __( 'Flin Flon', 'describr' ),
        11 => /*translators: City.*/ __( 'Gimli', 'describr' ),
        12 => /*translators: City.*/ __( 'Grunthal', 'describr' ),
        13 => /*translators: City.*/ __( 'Headingley', 'describr' ),
        14 => /*translators: City.*/ __( 'Ile des Chênes', 'describr' ),
        15 => /*translators: City.*/ __( 'Killarney', 'describr' ),
        16 => /*translators: City.*/ __( 'La Broquerie', 'describr' ),
        17 => /*translators: City.*/ __( 'Lac du Bonnet', 'describr' ),
        18 => /*translators: City.*/ __( 'Landmark', 'describr' ),
        19 => /*translators: City.*/ __( 'Lorette', 'describr' ),
        20 => /*translators: City.*/ __( 'Melita', 'describr' ),
        21 => /*translators: City.*/ __( 'Minnedosa', 'describr' ),
        22 => /*translators: City.*/ __( 'Moose Lake', 'describr' ),
        23 => /*translators: City.*/ __( 'Morden', 'describr' ),
        24 => /*translators: City.*/ __( 'Morris', 'describr' ),
        25 => /*translators: City.*/ __( 'Neepawa', 'describr' ),
        26 => /*translators: City.*/ __( 'Niverville', 'describr' ),
        27 => /*translators: City.*/ __( 'Portage la Prairie', 'describr' ),
        28 => /*translators: City.*/ __( 'Rivers', 'describr' ),
        29 => /*translators: City.*/ __( 'Roblin', 'describr' ),
        30 => /*translators: City.*/ __( 'Selkirk', 'describr' ),
        31 => /*translators: City.*/ __( 'Shilo', 'describr' ),
        32 => /*translators: City.*/ __( 'Souris', 'describr' ),
        33 => /*translators: City.*/ __( 'St. Adolphe', 'describr' ),
        34 => /*translators: City.*/ __( 'Steinbach', 'describr' ),
        35 => /*translators: City.*/ __( 'Stonewall', 'describr' ),
        36 => /*translators: City.*/ __( 'Swan River', 'describr' ),
        37 => /*translators: City.*/ __( 'The Pas', 'describr' ),
        38 => /*translators: City.*/ __( 'Thompson', 'describr' ),
        39 => /*translators: City.*/ __( 'Virden', 'describr' ),
        40 => /*translators: City.*/ __( 'West St. Paul', 'describr' ),
        41 => /*translators: City.*/ __( 'Winkler', 'describr' ),
        42 => /*translators: City.*/ __( 'Winnipeg', 'describr' ),
      ),
    ),
    'NB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'New Brunswick', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baie Ste. Anne', 'describr' ),
        1 => /*translators: City.*/ __( 'Bathurst', 'describr' ),
        2 => /*translators: City.*/ __( 'Bouctouche', 'describr' ),
        3 => /*translators: City.*/ __( 'Campbellton', 'describr' ),
        4 => /*translators: City.*/ __( 'Dieppe', 'describr' ),
        5 => /*translators: City.*/ __( 'Edmundston', 'describr' ),
        6 => /*translators: City.*/ __( 'Florenceville-Bristol', 'describr' ),
        7 => /*translators: City.*/ __( 'Fredericton', 'describr' ),
        8 => /*translators: City.*/ __( 'Fundy Bay', 'describr' ),
        9 => /*translators: City.*/ __( 'Grande-Digue', 'describr' ),
        10 => /*translators: City.*/ __( 'Greater Lakeburn', 'describr' ),
        11 => /*translators: City.*/ __( 'Hampton', 'describr' ),
        12 => /*translators: City.*/ __( 'Harrison Brook', 'describr' ),
        13 => /*translators: City.*/ __( 'Keswick Ridge', 'describr' ),
        14 => /*translators: City.*/ __( 'Lincoln', 'describr' ),
        15 => /*translators: City.*/ __( 'Lutes Mountain', 'describr' ),
        16 => /*translators: City.*/ __( 'McEwen', 'describr' ),
        17 => /*translators: City.*/ __( 'Miramichi', 'describr' ),
        18 => /*translators: City.*/ __( 'Moncton', 'describr' ),
        19 => /*translators: City.*/ __( 'Nackawic', 'describr' ),
        20 => /*translators: City.*/ __( 'New Maryland', 'describr' ),
        21 => /*translators: City.*/ __( 'Noonan', 'describr' ),
        22 => /*translators: City.*/ __( 'Oromocto', 'describr' ),
        23 => /*translators: City.*/ __( 'Richibucto', 'describr' ),
        24 => /*translators: City.*/ __( 'Sackville', 'describr' ),
        25 => /*translators: City.*/ __( 'Saint Andrews', 'describr' ),
        26 => /*translators: City.*/ __( 'Saint John', 'describr' ),
        27 => /*translators: City.*/ __( 'Saint-Antoine', 'describr' ),
        28 => /*translators: City.*/ __( 'Saint-Léonard', 'describr' ),
        29 => /*translators: City.*/ __( 'Salisbury', 'describr' ),
        30 => /*translators: City.*/ __( 'Shediac', 'describr' ),
        31 => /*translators: City.*/ __( 'Shediac Bridge-Shediac River', 'describr' ),
        32 => /*translators: City.*/ __( 'Shippagan', 'describr' ),
        33 => /*translators: City.*/ __( 'Starlight Village', 'describr' ),
        34 => /*translators: City.*/ __( 'Sussex', 'describr' ),
        35 => /*translators: City.*/ __( 'Tracadie-Sheila', 'describr' ),
        36 => /*translators: City.*/ __( 'Wells', 'describr' ),
      ),
    ),
    'YT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yukon', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dawson City', 'describr' ),
        1 => /*translators: City.*/ __( 'Haines Junction', 'describr' ),
        2 => /*translators: City.*/ __( 'Watson Lake', 'describr' ),
        3 => /*translators: City.*/ __( 'Whitehorse', 'describr' ),
      ),
    ),
    'SK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saskatchewan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Assiniboia', 'describr' ),
        1 => /*translators: City.*/ __( 'Biggar', 'describr' ),
        2 => /*translators: City.*/ __( 'Canora', 'describr' ),
        3 => /*translators: City.*/ __( 'Carlyle', 'describr' ),
        4 => /*translators: City.*/ __( 'Dalmeny', 'describr' ),
        5 => /*translators: City.*/ __( 'Esterhazy', 'describr' ),
        6 => /*translators: City.*/ __( 'Estevan', 'describr' ),
        7 => /*translators: City.*/ __( 'Foam Lake', 'describr' ),
        8 => /*translators: City.*/ __( 'Gravelbourg', 'describr' ),
        9 => /*translators: City.*/ __( 'Hudson Bay', 'describr' ),
        10 => /*translators: City.*/ __( 'Humboldt', 'describr' ),
        11 => /*translators: City.*/ __( 'Indian Head', 'describr' ),
        12 => /*translators: City.*/ __( 'Kamsack', 'describr' ),
        13 => /*translators: City.*/ __( 'Kerrobert', 'describr' ),
        14 => /*translators: City.*/ __( 'Kindersley', 'describr' ),
        15 => /*translators: City.*/ __( 'La Ronge', 'describr' ),
        16 => /*translators: City.*/ __( 'Langenburg', 'describr' ),
        17 => /*translators: City.*/ __( 'Langham', 'describr' ),
        18 => /*translators: City.*/ __( 'Lanigan', 'describr' ),
        19 => /*translators: City.*/ __( 'Lumsden', 'describr' ),
        20 => /*translators: City.*/ __( 'Macklin', 'describr' ),
        21 => /*translators: City.*/ __( 'Maple Creek', 'describr' ),
        22 => /*translators: City.*/ __( 'Martensville', 'describr' ),
        23 => /*translators: City.*/ __( 'Meadow Lake', 'describr' ),
        24 => /*translators: City.*/ __( 'Melfort', 'describr' ),
        25 => /*translators: City.*/ __( 'Melville', 'describr' ),
        26 => /*translators: City.*/ __( 'Moose Jaw', 'describr' ),
        27 => /*translators: City.*/ __( 'Moosomin', 'describr' ),
        28 => /*translators: City.*/ __( 'Nipawin', 'describr' ),
        29 => /*translators: City.*/ __( 'North Battleford', 'describr' ),
        30 => /*translators: City.*/ __( 'Outlook', 'describr' ),
        31 => /*translators: City.*/ __( 'Oxbow', 'describr' ),
        32 => /*translators: City.*/ __( 'Pelican Narrows', 'describr' ),
        33 => /*translators: City.*/ __( 'Pilot Butte', 'describr' ),
        34 => /*translators: City.*/ __( 'Preeceville', 'describr' ),
        35 => /*translators: City.*/ __( 'Prince Albert', 'describr' ),
        36 => /*translators: City.*/ __( 'Regina', 'describr' ),
        37 => /*translators: City.*/ __( 'Regina Beach', 'describr' ),
        38 => /*translators: City.*/ __( 'Rosetown', 'describr' ),
        39 => /*translators: City.*/ __( 'Rosthern', 'describr' ),
        40 => /*translators: City.*/ __( 'Saskatoon', 'describr' ),
        41 => /*translators: City.*/ __( 'Shaunavon', 'describr' ),
        42 => /*translators: City.*/ __( 'Shellbrook', 'describr' ),
        43 => /*translators: City.*/ __( 'Swift Current', 'describr' ),
        44 => /*translators: City.*/ __( 'Tisdale', 'describr' ),
        45 => /*translators: City.*/ __( 'Unity', 'describr' ),
        46 => /*translators: City.*/ __( 'Wadena', 'describr' ),
        47 => /*translators: City.*/ __( 'Warman', 'describr' ),
        48 => /*translators: City.*/ __( 'Watrous', 'describr' ),
        49 => /*translators: City.*/ __( 'Weyburn', 'describr' ),
        50 => /*translators: City.*/ __( 'White City', 'describr' ),
        51 => /*translators: City.*/ __( 'Wilkie', 'describr' ),
        52 => /*translators: City.*/ __( 'Wynyard', 'describr' ),
        53 => /*translators: City.*/ __( 'Yorkton', 'describr' ),
      ),
    ),
    'PE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Prince Edward Island', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alberton', 'describr' ),
        1 => /*translators: City.*/ __( 'Belfast', 'describr' ),
        2 => /*translators: City.*/ __( 'Charlottetown', 'describr' ),
        3 => /*translators: City.*/ __( 'Cornwall', 'describr' ),
        4 => /*translators: City.*/ __( 'Fallingbrook', 'describr' ),
        5 => /*translators: City.*/ __( 'Kensington', 'describr' ),
        6 => /*translators: City.*/ __( 'Montague', 'describr' ),
        7 => /*translators: City.*/ __( 'Souris', 'describr' ),
        8 => /*translators: City.*/ __( 'Summerside', 'describr' ),
      ),
    ),
    'AB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Alberta', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Airdrie', 'describr' ),
        1 => /*translators: City.*/ __( 'Athabasca', 'describr' ),
        2 => /*translators: City.*/ __( 'Banff', 'describr' ),
        3 => /*translators: City.*/ __( 'Barrhead', 'describr' ),
        4 => /*translators: City.*/ __( 'Bassano', 'describr' ),
        5 => /*translators: City.*/ __( 'Beaumont', 'describr' ),
        6 => /*translators: City.*/ __( 'Beaverlodge', 'describr' ),
        7 => /*translators: City.*/ __( 'Black Diamond', 'describr' ),
        8 => /*translators: City.*/ __( 'Blackfalds', 'describr' ),
        9 => /*translators: City.*/ __( 'Bon Accord', 'describr' ),
        10 => /*translators: City.*/ __( 'Bonnyville', 'describr' ),
        11 => /*translators: City.*/ __( 'Bow Island', 'describr' ),
        12 => /*translators: City.*/ __( 'Brooks', 'describr' ),
        13 => /*translators: City.*/ __( 'Calgary', 'describr' ),
        14 => /*translators: City.*/ __( 'Calmar', 'describr' ),
        15 => /*translators: City.*/ __( 'Camrose', 'describr' ),
        16 => /*translators: City.*/ __( 'Canmore', 'describr' ),
        17 => /*translators: City.*/ __( 'Cardston', 'describr' ),
        18 => /*translators: City.*/ __( 'Carstairs', 'describr' ),
        19 => /*translators: City.*/ __( 'Chestermere', 'describr' ),
        20 => /*translators: City.*/ __( 'Claresholm', 'describr' ),
        21 => /*translators: City.*/ __( 'Coaldale', 'describr' ),
        22 => /*translators: City.*/ __( 'Coalhurst', 'describr' ),
        23 => /*translators: City.*/ __( 'Cochrane', 'describr' ),
        24 => /*translators: City.*/ __( 'Cold Lake', 'describr' ),
        25 => /*translators: City.*/ __( 'Crossfield', 'describr' ),
        26 => /*translators: City.*/ __( 'Devon', 'describr' ),
        27 => /*translators: City.*/ __( 'Didsbury', 'describr' ),
        28 => /*translators: City.*/ __( 'Drayton Valley', 'describr' ),
        29 => /*translators: City.*/ __( 'Edmonton', 'describr' ),
        30 => /*translators: City.*/ __( 'Edson', 'describr' ),
        31 => /*translators: City.*/ __( 'Elk Point', 'describr' ),
        32 => /*translators: City.*/ __( 'Fairview', 'describr' ),
        33 => /*translators: City.*/ __( 'Falher', 'describr' ),
        34 => /*translators: City.*/ __( 'Fort Macleod', 'describr' ),
        35 => /*translators: City.*/ __( 'Fort McMurray', 'describr' ),
        36 => /*translators: City.*/ __( 'Fort Saskatchewan', 'describr' ),
        37 => /*translators: City.*/ __( 'Fox Creek', 'describr' ),
        38 => /*translators: City.*/ __( 'Gibbons', 'describr' ),
        39 => /*translators: City.*/ __( 'Grand Centre', 'describr' ),
        40 => /*translators: City.*/ __( 'Grande Cache', 'describr' ),
        41 => /*translators: City.*/ __( 'Grande Prairie', 'describr' ),
        42 => /*translators: City.*/ __( 'Grimshaw', 'describr' ),
        43 => /*translators: City.*/ __( 'Hanna', 'describr' ),
        44 => /*translators: City.*/ __( 'Heritage Pointe', 'describr' ),
        45 => /*translators: City.*/ __( 'High Level', 'describr' ),
        46 => /*translators: City.*/ __( 'High Prairie', 'describr' ),
        47 => /*translators: City.*/ __( 'High River', 'describr' ),
        48 => /*translators: City.*/ __( 'Hinton', 'describr' ),
        49 => /*translators: City.*/ __( 'Irricana', 'describr' ),
        50 => /*translators: City.*/ __( 'Jasper Park Lodge', 'describr' ),
        51 => /*translators: City.*/ __( 'Killam', 'describr' ),
        52 => /*translators: City.*/ __( 'Lac La Biche', 'describr' ),
        53 => /*translators: City.*/ __( 'Lacombe', 'describr' ),
        54 => /*translators: City.*/ __( 'Lamont', 'describr' ),
        55 => /*translators: City.*/ __( 'Larkspur', 'describr' ),
        56 => /*translators: City.*/ __( 'Laurel', 'describr' ),
        57 => /*translators: City.*/ __( 'Leduc', 'describr' ),
        58 => /*translators: City.*/ __( 'Lethbridge', 'describr' ),
        59 => /*translators: City.*/ __( 'Lloydminster', 'describr' ),
        60 => /*translators: City.*/ __( 'Magrath', 'describr' ),
        61 => /*translators: City.*/ __( 'Manning', 'describr' ),
        62 => /*translators: City.*/ __( 'Mannville', 'describr' ),
        63 => /*translators: City.*/ __( 'Maple Ridge', 'describr' ),
        64 => /*translators: City.*/ __( 'Mayerthorpe', 'describr' ),
        65 => /*translators: City.*/ __( 'Medicine Hat', 'describr' ),
        66 => /*translators: City.*/ __( 'Mill Woods Town Centre', 'describr' ),
        67 => /*translators: City.*/ __( 'Millet', 'describr' ),
        68 => /*translators: City.*/ __( 'Morinville', 'describr' ),
        69 => /*translators: City.*/ __( 'Nanton', 'describr' ),
        70 => /*translators: City.*/ __( 'Okotoks', 'describr' ),
        71 => /*translators: City.*/ __( 'Olds', 'describr' ),
        72 => /*translators: City.*/ __( 'Peace River', 'describr' ),
        73 => /*translators: City.*/ __( 'Penhold', 'describr' ),
        74 => /*translators: City.*/ __( 'Picture Butte', 'describr' ),
        75 => /*translators: City.*/ __( 'Pincher Creek', 'describr' ),
        76 => /*translators: City.*/ __( 'Ponoka', 'describr' ),
        77 => /*translators: City.*/ __( 'Provost', 'describr' ),
        78 => /*translators: City.*/ __( 'Raymond', 'describr' ),
        79 => /*translators: City.*/ __( 'Red Deer', 'describr' ),
        80 => /*translators: City.*/ __( 'Rideau Park', 'describr' ),
        81 => /*translators: City.*/ __( 'Rimbey', 'describr' ),
        82 => /*translators: City.*/ __( 'Rocky Mountain House', 'describr' ),
        83 => /*translators: City.*/ __( 'Sexsmith', 'describr' ),
        84 => /*translators: City.*/ __( 'Sherwood Park', 'describr' ),
        85 => /*translators: City.*/ __( 'Silver Berry', 'describr' ),
        86 => /*translators: City.*/ __( 'Slave Lake', 'describr' ),
        87 => /*translators: City.*/ __( 'Smoky Lake', 'describr' ),
        88 => /*translators: City.*/ __( 'Spirit River', 'describr' ),
        89 => /*translators: City.*/ __( 'Springbrook', 'describr' ),
        90 => /*translators: City.*/ __( 'Spruce Grove', 'describr' ),
        91 => /*translators: City.*/ __( 'St. Albert', 'describr' ),
        92 => /*translators: City.*/ __( 'Stettler', 'describr' ),
        93 => /*translators: City.*/ __( 'Stony Plain', 'describr' ),
        94 => /*translators: City.*/ __( 'Strathmore', 'describr' ),
        95 => /*translators: City.*/ __( 'Sundre', 'describr' ),
        96 => /*translators: City.*/ __( 'Swan Hills', 'describr' ),
        97 => /*translators: City.*/ __( 'Sylvan Lake', 'describr' ),
        98 => /*translators: City.*/ __( 'Taber', 'describr' ),
        99 => /*translators: City.*/ __( 'Tamarack', 'describr' ),
        100 => /*translators: City.*/ __( 'Three Hills', 'describr' ),
        101 => /*translators: City.*/ __( 'Tofield', 'describr' ),
        102 => /*translators: City.*/ __( 'Two Hills', 'describr' ),
        103 => /*translators: City.*/ __( 'Valleyview', 'describr' ),
        104 => /*translators: City.*/ __( 'Vegreville', 'describr' ),
        105 => /*translators: City.*/ __( 'Vermilion', 'describr' ),
        106 => /*translators: City.*/ __( 'Viking', 'describr' ),
        107 => /*translators: City.*/ __( 'Vulcan', 'describr' ),
        108 => /*translators: City.*/ __( 'Wainwright', 'describr' ),
        109 => /*translators: City.*/ __( 'Wembley', 'describr' ),
        110 => /*translators: City.*/ __( 'Westlake', 'describr' ),
        111 => /*translators: City.*/ __( 'Westlock', 'describr' ),
        112 => /*translators: City.*/ __( 'Wetaskiwin', 'describr' ),
        113 => /*translators: City.*/ __( 'Whitecourt', 'describr' ),
        114 => /*translators: City.*/ __( 'Wild Rose', 'describr' ),
      ),
    ),
    'QC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Quebec', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abitibi-Témiscamingue', 'describr' ),
        1 => /*translators: City.*/ __( 'Acton Vale', 'describr' ),
        2 => /*translators: City.*/ __( 'Adstock', 'describr' ),
        3 => /*translators: City.*/ __( 'Albanel', 'describr' ),
        4 => /*translators: City.*/ __( 'Alma', 'describr' ),
        5 => /*translators: City.*/ __( 'Amos', 'describr' ),
        6 => /*translators: City.*/ __( 'Amqui', 'describr' ),
        7 => /*translators: City.*/ __( 'Ange-Gardien', 'describr' ),
        8 => /*translators: City.*/ __( 'Asbestos', 'describr' ),
        9 => /*translators: City.*/ __( 'Baie-Comeau', 'describr' ),
        10 => /*translators: City.*/ __( 'Baie-D&#039;Urfé', 'describr' ),
        11 => /*translators: City.*/ __( 'Baie-Saint-Paul', 'describr' ),
        12 => /*translators: City.*/ __( 'Barraute', 'describr' ),
        13 => /*translators: City.*/ __( 'Bas-Saint-Laurent', 'describr' ),
        14 => /*translators: City.*/ __( 'Beaconsfield', 'describr' ),
        15 => /*translators: City.*/ __( 'Beauceville', 'describr' ),
        16 => /*translators: City.*/ __( 'Beauharnois', 'describr' ),
        17 => /*translators: City.*/ __( 'Beaupré', 'describr' ),
        18 => /*translators: City.*/ __( 'Bedford', 'describr' ),
        19 => /*translators: City.*/ __( 'Beloeil', 'describr' ),
        20 => /*translators: City.*/ __( 'Berthierville', 'describr' ),
        21 => /*translators: City.*/ __( 'Blainville', 'describr' ),
        22 => /*translators: City.*/ __( 'Bois-des-Filion', 'describr' ),
        23 => /*translators: City.*/ __( 'Boisbriand', 'describr' ),
        24 => /*translators: City.*/ __( 'Bonaventure', 'describr' ),
        25 => /*translators: City.*/ __( 'Boucherville', 'describr' ),
        26 => /*translators: City.*/ __( 'Breakeyville', 'describr' ),
        27 => /*translators: City.*/ __( 'Bromont', 'describr' ),
        28 => /*translators: City.*/ __( 'Brossard', 'describr' ),
        29 => /*translators: City.*/ __( 'Brownsburg-Chatham', 'describr' ),
        30 => /*translators: City.*/ __( 'Buckingham', 'describr' ),
        31 => /*translators: City.*/ __( 'Bécancour', 'describr' ),
        32 => /*translators: City.*/ __( 'Cabano', 'describr' ),
        33 => /*translators: City.*/ __( 'Cacouna', 'describr' ),
        34 => /*translators: City.*/ __( 'Candiac', 'describr' ),
        35 => /*translators: City.*/ __( 'Cantley', 'describr' ),
        36 => /*translators: City.*/ __( 'Cap-Chat', 'describr' ),
        37 => /*translators: City.*/ __( 'Cap-Santé', 'describr' ),
        38 => /*translators: City.*/ __( 'Capitale-Nationale', 'describr' ),
        39 => /*translators: City.*/ __( 'Carignan', 'describr' ),
        40 => /*translators: City.*/ __( 'Carleton', 'describr' ),
        41 => /*translators: City.*/ __( 'Carleton-sur-Mer', 'describr' ),
        42 => /*translators: City.*/ __( 'Centre-du-Québec', 'describr' ),
        43 => /*translators: City.*/ __( 'Chambly', 'describr' ),
        44 => /*translators: City.*/ __( 'Chambord', 'describr' ),
        45 => /*translators: City.*/ __( 'Chandler', 'describr' ),
        46 => /*translators: City.*/ __( 'Chapais', 'describr' ),
        47 => /*translators: City.*/ __( 'Charlemagne', 'describr' ),
        48 => /*translators: City.*/ __( 'Chaudière-Appalaches', 'describr' ),
        49 => /*translators: City.*/ __( 'Chertsey', 'describr' ),
        50 => /*translators: City.*/ __( 'Chibougamau', 'describr' ),
        51 => /*translators: City.*/ __( 'Chute-aux-Outardes', 'describr' ),
        52 => /*translators: City.*/ __( 'Château-Richer', 'describr' ),
        53 => /*translators: City.*/ __( 'Châteauguay', 'describr' ),
        54 => /*translators: City.*/ __( 'Coaticook', 'describr' ),
        55 => /*translators: City.*/ __( 'Contrecoeur', 'describr' ),
        56 => /*translators: City.*/ __( 'Cookshire', 'describr' ),
        57 => /*translators: City.*/ __( 'Cookshire-Eaton', 'describr' ),
        58 => /*translators: City.*/ __( 'Coteau-du-Lac', 'describr' ),
        59 => /*translators: City.*/ __( 'Cowansville', 'describr' ),
        60 => /*translators: City.*/ __( 'Crabtree', 'describr' ),
        61 => /*translators: City.*/ __( 'Côte-Nord', 'describr' ),
        62 => /*translators: City.*/ __( 'Côte-Saint-Luc', 'describr' ),
        63 => /*translators: City.*/ __( 'Danville', 'describr' ),
        64 => /*translators: City.*/ __( 'Daveluyville', 'describr' ),
        65 => /*translators: City.*/ __( 'Delson', 'describr' ),
        66 => /*translators: City.*/ __( 'Deux-Montagnes', 'describr' ),
        67 => /*translators: City.*/ __( 'Disraeli', 'describr' ),
        68 => /*translators: City.*/ __( 'Dolbeau-Mistassini', 'describr' ),
        69 => /*translators: City.*/ __( 'Dollard-Des Ormeaux', 'describr' ),
        70 => /*translators: City.*/ __( 'Donnacona', 'describr' ),
        71 => /*translators: City.*/ __( 'Dorval', 'describr' ),
        72 => /*translators: City.*/ __( 'Drummondville', 'describr' ),
        73 => /*translators: City.*/ __( 'Dunham', 'describr' ),
        74 => /*translators: City.*/ __( 'East Angus', 'describr' ),
        75 => /*translators: City.*/ __( 'East Broughton', 'describr' ),
        76 => /*translators: City.*/ __( 'Farnham', 'describr' ),
        77 => /*translators: City.*/ __( 'Ferme-Neuve', 'describr' ),
        78 => /*translators: City.*/ __( 'Fermont', 'describr' ),
        79 => /*translators: City.*/ __( 'Forestville', 'describr' ),
        80 => /*translators: City.*/ __( 'Fort-Coulonge', 'describr' ),
        81 => /*translators: City.*/ __( 'Fossambault-sur-le-Lac', 'describr' ),
        82 => /*translators: City.*/ __( 'Franklin', 'describr' ),
        83 => /*translators: City.*/ __( 'Gaspé', 'describr' ),
        84 => /*translators: City.*/ __( 'Gaspésie-Îles-de-la-Madeleine', 'describr' ),
        85 => /*translators: City.*/ __( 'Gatineau', 'describr' ),
        86 => /*translators: City.*/ __( 'Godefroy', 'describr' ),
        87 => /*translators: City.*/ __( 'Granby', 'describr' ),
        88 => /*translators: City.*/ __( 'Hampstead', 'describr' ),
        89 => /*translators: City.*/ __( 'Hauterive', 'describr' ),
        90 => /*translators: City.*/ __( 'Havre-Saint-Pierre', 'describr' ),
        91 => /*translators: City.*/ __( 'Hudson', 'describr' ),
        92 => /*translators: City.*/ __( 'Huntingdon', 'describr' ),
        93 => /*translators: City.*/ __( 'Hérouxville', 'describr' ),
        94 => /*translators: City.*/ __( 'Joliette', 'describr' ),
        95 => /*translators: City.*/ __( 'Jonquière', 'describr' ),
        96 => /*translators: City.*/ __( 'Kingsey Falls', 'describr' ),
        97 => /*translators: City.*/ __( 'Kirkland', 'describr' ),
        98 => /*translators: City.*/ __( 'L&#039;Ancienne-Lorette', 'describr' ),
        99 => /*translators: City.*/ __( 'L&#039;Ange-Gardien', 'describr' ),
        100 => /*translators: City.*/ __( 'L&#039;Ascension-de-Notre-Seigneur', 'describr' ),
        101 => /*translators: City.*/ __( 'L&#039;Assomption', 'describr' ),
        102 => /*translators: City.*/ __( 'L&#039;Épiphanie', 'describr' ),
        103 => /*translators: City.*/ __( 'L&#039;Île-Perrot', 'describr' ),
        104 => /*translators: City.*/ __( 'La Conception', 'describr' ),
        105 => /*translators: City.*/ __( 'La Haute-Saint-Charles', 'describr' ),
        106 => /*translators: City.*/ __( 'La Malbaie', 'describr' ),
        107 => /*translators: City.*/ __( 'La Minerve', 'describr' ),
        108 => /*translators: City.*/ __( 'La Pocatière', 'describr' ),
        109 => /*translators: City.*/ __( 'La Prairie', 'describr' ),
        110 => /*translators: City.*/ __( 'La Sarre', 'describr' ),
        111 => /*translators: City.*/ __( 'La Tuque', 'describr' ),
        112 => /*translators: City.*/ __( 'Labelle', 'describr' ),
        113 => /*translators: City.*/ __( 'Lac-Alouette', 'describr' ),
        114 => /*translators: City.*/ __( 'Lac-Brome', 'describr' ),
        115 => /*translators: City.*/ __( 'Lac-Connelly', 'describr' ),
        116 => /*translators: City.*/ __( 'Lac-Lapierre', 'describr' ),
        117 => /*translators: City.*/ __( 'Lac-Mégantic', 'describr' ),
        118 => /*translators: City.*/ __( 'Lac-Simon', 'describr' ),
        119 => /*translators: City.*/ __( 'Lachute', 'describr' ),
        120 => /*translators: City.*/ __( 'Lacolle', 'describr' ),
        121 => /*translators: City.*/ __( 'Lanoraie', 'describr' ),
        122 => /*translators: City.*/ __( 'Laval', 'describr' ),
        123 => /*translators: City.*/ __( 'Lavaltrie', 'describr' ),
        124 => /*translators: City.*/ __( 'Le Bic', 'describr' ),
        125 => /*translators: City.*/ __( 'Lebel-sur-Quévillon', 'describr' ),
        126 => /*translators: City.*/ __( 'Leblanc', 'describr' ),
        127 => /*translators: City.*/ __( 'Les Coteaux', 'describr' ),
        128 => /*translators: City.*/ __( 'Les Cèdres', 'describr' ),
        129 => /*translators: City.*/ __( 'Les Escoumins', 'describr' ),
        130 => /*translators: City.*/ __( 'Linière', 'describr' ),
        131 => /*translators: City.*/ __( 'Longueuil', 'describr' ),
        132 => /*translators: City.*/ __( 'Lorraine', 'describr' ),
        133 => /*translators: City.*/ __( 'Louiseville', 'describr' ),
        134 => /*translators: City.*/ __( 'Luceville', 'describr' ),
        135 => /*translators: City.*/ __( 'Lévis', 'describr' ),
        136 => /*translators: City.*/ __( 'Macamic', 'describr' ),
        137 => /*translators: City.*/ __( 'Magog', 'describr' ),
        138 => /*translators: City.*/ __( 'Malartic', 'describr' ),
        139 => /*translators: City.*/ __( 'Maliotenam', 'describr' ),
        140 => /*translators: City.*/ __( 'Manawan', 'describr' ),
        141 => /*translators: City.*/ __( 'Mandeville', 'describr' ),
        142 => /*translators: City.*/ __( 'Maniwaki', 'describr' ),
        143 => /*translators: City.*/ __( 'Maria', 'describr' ),
        144 => /*translators: City.*/ __( 'Marieville', 'describr' ),
        145 => /*translators: City.*/ __( 'Mascouche', 'describr' ),
        146 => /*translators: City.*/ __( 'Maskinongé', 'describr' ),
        147 => /*translators: City.*/ __( 'Matagami', 'describr' ),
        148 => /*translators: City.*/ __( 'Matane', 'describr' ),
        149 => /*translators: City.*/ __( 'Mauricie', 'describr' ),
        150 => /*translators: City.*/ __( 'Melocheville', 'describr' ),
        151 => /*translators: City.*/ __( 'Mercier', 'describr' ),
        152 => /*translators: City.*/ __( 'Metabetchouan-Lac-a-la-Croix', 'describr' ),
        153 => /*translators: City.*/ __( 'Mirabel', 'describr' ),
        154 => /*translators: City.*/ __( 'Mistissini', 'describr' ),
        155 => /*translators: City.*/ __( 'Mont-Joli', 'describr' ),
        156 => /*translators: City.*/ __( 'Mont-Laurier', 'describr' ),
        157 => /*translators: City.*/ __( 'Mont-Royal', 'describr' ),
        158 => /*translators: City.*/ __( 'Mont-Saint-Grégoire', 'describr' ),
        159 => /*translators: City.*/ __( 'Mont-Saint-Hilaire', 'describr' ),
        160 => /*translators: City.*/ __( 'Mont-Tremblant', 'describr' ),
        161 => /*translators: City.*/ __( 'Montmagny', 'describr' ),
        162 => /*translators: City.*/ __( 'Montréal', 'describr' ),
        163 => /*translators: City.*/ __( 'Montréal-Est', 'describr' ),
        164 => /*translators: City.*/ __( 'Montréal-Ouest', 'describr' ),
        165 => /*translators: City.*/ __( 'Morin-Heights', 'describr' ),
        166 => /*translators: City.*/ __( 'Métabetchouan', 'describr' ),
        167 => /*translators: City.*/ __( 'Napierville', 'describr' ),
        168 => /*translators: City.*/ __( 'Neuville', 'describr' ),
        169 => /*translators: City.*/ __( 'New Carlisle', 'describr' ),
        170 => /*translators: City.*/ __( 'New-Richmond', 'describr' ),
        171 => /*translators: City.*/ __( 'Nicolet', 'describr' ),
        172 => /*translators: City.*/ __( 'Nord-du-Québec', 'describr' ),
        173 => /*translators: City.*/ __( 'Normandin', 'describr' ),
        174 => /*translators: City.*/ __( 'Notre-Dame-de-Grâce', 'describr' ),
        175 => /*translators: City.*/ __( 'Notre-Dame-de-l&#039;Île-Perrot', 'describr' ),
        176 => /*translators: City.*/ __( 'Notre-Dame-des-Prairies', 'describr' ),
        177 => /*translators: City.*/ __( 'Notre-Dame-du-Lac', 'describr' ),
        178 => /*translators: City.*/ __( 'Notre-Dame-du-Mont-Carmel', 'describr' ),
        179 => /*translators: City.*/ __( 'Oka', 'describr' ),
        180 => /*translators: City.*/ __( 'Ormstown', 'describr' ),
        181 => /*translators: City.*/ __( 'Otterburn Park', 'describr' ),
        182 => /*translators: City.*/ __( 'Outaouais', 'describr' ),
        183 => /*translators: City.*/ __( 'Papineauville', 'describr' ),
        184 => /*translators: City.*/ __( 'Parc-Boutin', 'describr' ),
        185 => /*translators: City.*/ __( 'Piedmont', 'describr' ),
        186 => /*translators: City.*/ __( 'Pierreville', 'describr' ),
        187 => /*translators: City.*/ __( 'Pincourt', 'describr' ),
        188 => /*translators: City.*/ __( 'Plessisville', 'describr' ),
        189 => /*translators: City.*/ __( 'Pohénégamook', 'describr' ),
        190 => /*translators: City.*/ __( 'Pointe-Calumet', 'describr' ),
        191 => /*translators: City.*/ __( 'Pointe-Claire', 'describr' ),
        192 => /*translators: City.*/ __( 'Pointe-du-Lac', 'describr' ),
        193 => /*translators: City.*/ __( 'Pont Rouge', 'describr' ),
        194 => /*translators: City.*/ __( 'Pont-Rouge', 'describr' ),
        195 => /*translators: City.*/ __( 'Port-Cartier', 'describr' ),
        196 => /*translators: City.*/ __( 'Portneuf', 'describr' ),
        197 => /*translators: City.*/ __( 'Princeville', 'describr' ),
        198 => /*translators: City.*/ __( 'Prévost', 'describr' ),
        199 => /*translators: City.*/ __( 'Québec', 'describr' ),
        200 => /*translators: City.*/ __( 'Rawdon', 'describr' ),
        201 => /*translators: City.*/ __( 'Repentigny', 'describr' ),
        202 => /*translators: City.*/ __( 'Richelieu', 'describr' ),
        203 => /*translators: City.*/ __( 'Richmond', 'describr' ),
        204 => /*translators: City.*/ __( 'Rigaud', 'describr' ),
        205 => /*translators: City.*/ __( 'Rimouski', 'describr' ),
        206 => /*translators: City.*/ __( 'Rivière-Rouge', 'describr' ),
        207 => /*translators: City.*/ __( 'Rivière-du-Loup', 'describr' ),
        208 => /*translators: City.*/ __( 'Roberval', 'describr' ),
        209 => /*translators: City.*/ __( 'Rock Forest', 'describr' ),
        210 => /*translators: City.*/ __( 'Rosemère', 'describr' ),
        211 => /*translators: City.*/ __( 'Rougemont', 'describr' ),
        212 => /*translators: City.*/ __( 'Rouyn-Noranda', 'describr' ),
        213 => /*translators: City.*/ __( 'Sacré-Coeur', 'describr' ),
        214 => /*translators: City.*/ __( 'Saguenay', 'describr' ),
        215 => /*translators: City.*/ __( 'Saint-Adolphe-d&#039;Howard', 'describr' ),
        216 => /*translators: City.*/ __( 'Saint-Alexandre', 'describr' ),
        217 => /*translators: City.*/ __( 'Saint-Amable', 'describr' ),
        218 => /*translators: City.*/ __( 'Saint-Ambroise', 'describr' ),
        219 => /*translators: City.*/ __( 'Saint-André-Avellin', 'describr' ),
        220 => /*translators: City.*/ __( 'Saint-Anselme', 'describr' ),
        221 => /*translators: City.*/ __( 'Saint-Antoine-de-Tilly', 'describr' ),
        222 => /*translators: City.*/ __( 'Saint-Augustin', 'describr' ),
        223 => /*translators: City.*/ __( 'Saint-Augustin-de-Desmaures', 'describr' ),
        224 => /*translators: City.*/ __( 'Saint-Barnabé-Sud', 'describr' ),
        225 => /*translators: City.*/ __( 'Saint-Basile-le-Grand', 'describr' ),
        226 => /*translators: City.*/ __( 'Saint-Boniface', 'describr' ),
        227 => /*translators: City.*/ __( 'Saint-Bruno', 'describr' ),
        228 => /*translators: City.*/ __( 'Saint-Bruno-de-Guigues', 'describr' ),
        229 => /*translators: City.*/ __( 'Saint-Bruno-de-Montarville', 'describr' ),
        230 => /*translators: City.*/ __( 'Saint-Canut', 'describr' ),
        231 => /*translators: City.*/ __( 'Saint-Charles', 'describr' ),
        232 => /*translators: City.*/ __( 'Saint-Constant', 'describr' ),
        233 => /*translators: City.*/ __( 'Saint-Cyrille-de-Wendover', 'describr' ),
        234 => /*translators: City.*/ __( 'Saint-Césaire', 'describr' ),
        235 => /*translators: City.*/ __( 'Saint-Côme--Linière', 'describr' ),
        236 => /*translators: City.*/ __( 'Saint-Damase', 'describr' ),
        237 => /*translators: City.*/ __( 'Saint-Denis-sur-Richelieu', 'describr' ),
        238 => /*translators: City.*/ __( 'Saint-Donat-de-Montcalm', 'describr' ),
        239 => /*translators: City.*/ __( 'Saint-Elzéar', 'describr' ),
        240 => /*translators: City.*/ __( 'Saint-Eustache', 'describr' ),
        241 => /*translators: City.*/ __( 'Saint-Félicien', 'describr' ),
        242 => /*translators: City.*/ __( 'Saint-Félix-de-Valois', 'describr' ),
        243 => /*translators: City.*/ __( 'Saint-Gabriel', 'describr' ),
        244 => /*translators: City.*/ __( 'Saint-Georges', 'describr' ),
        245 => /*translators: City.*/ __( 'Saint-Germain-de-Grantham', 'describr' ),
        246 => /*translators: City.*/ __( 'Saint-Gédéon', 'describr' ),
        247 => /*translators: City.*/ __( 'Saint-Henri', 'describr' ),
        248 => /*translators: City.*/ __( 'Saint-Hippolyte', 'describr' ),
        249 => /*translators: City.*/ __( 'Saint-Honoré', 'describr' ),
        250 => /*translators: City.*/ __( 'Saint-Hyacinthe', 'describr' ),
        251 => /*translators: City.*/ __( 'Saint-Isidore', 'describr' ),
        252 => /*translators: City.*/ __( 'Saint-Jacques-le-Mineur', 'describr' ),
        253 => /*translators: City.*/ __( 'Saint-Jean-Baptiste', 'describr' ),
        254 => /*translators: City.*/ __( 'Saint-Jean-sur-Richelieu', 'describr' ),
        255 => /*translators: City.*/ __( 'Saint-Joseph', 'describr' ),
        256 => /*translators: City.*/ __( 'Saint-Joseph-de-Beauce', 'describr' ),
        257 => /*translators: City.*/ __( 'Saint-Joseph-de-Coleraine', 'describr' ),
        258 => /*translators: City.*/ __( 'Saint-Joseph-du-Lac', 'describr' ),
        259 => /*translators: City.*/ __( 'Saint-Jérôme', 'describr' ),
        260 => /*translators: City.*/ __( 'Saint-Lambert-de-Lauzon', 'describr' ),
        261 => /*translators: City.*/ __( 'Saint-Laurent', 'describr' ),
        262 => /*translators: City.*/ __( 'Saint-Lazare', 'describr' ),
        263 => /*translators: City.*/ __( 'Saint-Liboire', 'describr' ),
        264 => /*translators: City.*/ __( 'Saint-Lin-Laurentides', 'describr' ),
        265 => /*translators: City.*/ __( 'Saint-Léonard', 'describr' ),
        266 => /*translators: City.*/ __( 'Saint-Léonard-d&#039;Aston', 'describr' ),
        267 => /*translators: City.*/ __( 'Saint-Marc-des-Carrières', 'describr' ),
        268 => /*translators: City.*/ __( 'Saint-Mathieu', 'describr' ),
        269 => /*translators: City.*/ __( 'Saint-Michel', 'describr' ),
        270 => /*translators: City.*/ __( 'Saint-Michel-des-Saints', 'describr' ),
        271 => /*translators: City.*/ __( 'Saint-Nazaire', 'describr' ),
        272 => /*translators: City.*/ __( 'Saint-Norbert', 'describr' ),
        273 => /*translators: City.*/ __( 'Saint-Pacôme', 'describr' ),
        274 => /*translators: City.*/ __( 'Saint-Pascal', 'describr' ),
        275 => /*translators: City.*/ __( 'Saint-Philippe-de-La Prairie', 'describr' ),
        276 => /*translators: City.*/ __( 'Saint-Pie', 'describr' ),
        277 => /*translators: City.*/ __( 'Saint-Pierre-les-Becquets', 'describr' ),
        278 => /*translators: City.*/ __( 'Saint-Prime', 'describr' ),
        279 => /*translators: City.*/ __( 'Saint-Raphaël', 'describr' ),
        280 => /*translators: City.*/ __( 'Saint-Raymond', 'describr' ),
        281 => /*translators: City.*/ __( 'Saint-Rémi', 'describr' ),
        282 => /*translators: City.*/ __( 'Saint-Rémi-de-Tingwick', 'describr' ),
        283 => /*translators: City.*/ __( 'Saint-Sauveur', 'describr' ),
        284 => /*translators: City.*/ __( 'Saint-Sauveur-des-Monts', 'describr' ),
        285 => /*translators: City.*/ __( 'Saint-Siméon', 'describr' ),
        286 => /*translators: City.*/ __( 'Saint-Thomas', 'describr' ),
        287 => /*translators: City.*/ __( 'Saint-Tite', 'describr' ),
        288 => /*translators: City.*/ __( 'Saint-Victor', 'describr' ),
        289 => /*translators: City.*/ __( 'Saint-Zotique', 'describr' ),
        290 => /*translators: City.*/ __( 'Saint-Édouard', 'describr' ),
        291 => /*translators: City.*/ __( 'Saint-Éphrem-de-Beauce', 'describr' ),
        292 => /*translators: City.*/ __( 'Sainte Catherine de la Jacques Cartier', 'describr' ),
        293 => /*translators: City.*/ __( 'Sainte-Adèle', 'describr' ),
        294 => /*translators: City.*/ __( 'Sainte-Agathe-des-Monts', 'describr' ),
        295 => /*translators: City.*/ __( 'Sainte-Anne-de-Bellevue', 'describr' ),
        296 => /*translators: City.*/ __( 'Sainte-Anne-des-Monts', 'describr' ),
        297 => /*translators: City.*/ __( 'Sainte-Anne-des-Plaines', 'describr' ),
        298 => /*translators: City.*/ __( 'Sainte-Béatrix', 'describr' ),
        299 => /*translators: City.*/ __( 'Sainte-Catherine', 'describr' ),
        300 => /*translators: City.*/ __( 'Sainte-Croix', 'describr' ),
        301 => /*translators: City.*/ __( 'Sainte-Julie', 'describr' ),
        302 => /*translators: City.*/ __( 'Sainte-Julienne', 'describr' ),
        303 => /*translators: City.*/ __( 'Sainte-Madeleine', 'describr' ),
        304 => /*translators: City.*/ __( 'Sainte-Marie', 'describr' ),
        305 => /*translators: City.*/ __( 'Sainte-Marthe-sur-le-Lac', 'describr' ),
        306 => /*translators: City.*/ __( 'Sainte-Martine', 'describr' ),
        307 => /*translators: City.*/ __( 'Sainte-Sophie', 'describr' ),
        308 => /*translators: City.*/ __( 'Sainte-Thècle', 'describr' ),
        309 => /*translators: City.*/ __( 'Sainte-Thérèse', 'describr' ),
        310 => /*translators: City.*/ __( 'Sainte-Élisabeth', 'describr' ),
        311 => /*translators: City.*/ __( 'Salaberry-de-Valleyfield', 'describr' ),
        312 => /*translators: City.*/ __( 'Salluit', 'describr' ),
        313 => /*translators: City.*/ __( 'Senneterre', 'describr' ),
        314 => /*translators: City.*/ __( 'Sept-Îles', 'describr' ),
        315 => /*translators: City.*/ __( 'Shannon', 'describr' ),
        316 => /*translators: City.*/ __( 'Shawinigan', 'describr' ),
        317 => /*translators: City.*/ __( 'Shawville', 'describr' ),
        318 => /*translators: City.*/ __( 'Sherbrooke', 'describr' ),
        319 => /*translators: City.*/ __( 'Sorel-Tracy', 'describr' ),
        320 => /*translators: City.*/ __( 'St-Jean-Port-Joli', 'describr' ),
        321 => /*translators: City.*/ __( 'Sutton', 'describr' ),
        322 => /*translators: City.*/ __( 'Terrasse-des-Pins', 'describr' ),
        323 => /*translators: City.*/ __( 'Terrebonne', 'describr' ),
        324 => /*translators: City.*/ __( 'Thetford-Mines', 'describr' ),
        325 => /*translators: City.*/ __( 'Thurso', 'describr' ),
        326 => /*translators: City.*/ __( 'Trois-Rivières', 'describr' ),
        327 => /*translators: City.*/ __( 'Témiscaming', 'describr' ),
        328 => /*translators: City.*/ __( 'Val-David', 'describr' ),
        329 => /*translators: City.*/ __( 'Val-Morin', 'describr' ),
        330 => /*translators: City.*/ __( 'Val-d&#039;Or', 'describr' ),
        331 => /*translators: City.*/ __( 'Val-des-Monts', 'describr' ),
        332 => /*translators: City.*/ __( 'Valcourt', 'describr' ),
        333 => /*translators: City.*/ __( 'Vallée-Jonction', 'describr' ),
        334 => /*translators: City.*/ __( 'Varennes', 'describr' ),
        335 => /*translators: City.*/ __( 'Vaudreuil-Dorion', 'describr' ),
        336 => /*translators: City.*/ __( 'Venise-en-Québec', 'describr' ),
        337 => /*translators: City.*/ __( 'Verchères', 'describr' ),
        338 => /*translators: City.*/ __( 'Victoriaville', 'describr' ),
        339 => /*translators: City.*/ __( 'Ville-Marie', 'describr' ),
        340 => /*translators: City.*/ __( 'Wakefield', 'describr' ),
        341 => /*translators: City.*/ __( 'Warwick', 'describr' ),
        342 => /*translators: City.*/ __( 'Waskaganish', 'describr' ),
        343 => /*translators: City.*/ __( 'Waswanipi', 'describr' ),
        344 => /*translators: City.*/ __( 'Waterloo', 'describr' ),
        345 => /*translators: City.*/ __( 'Weedon Centre', 'describr' ),
        346 => /*translators: City.*/ __( 'Westmount', 'describr' ),
        347 => /*translators: City.*/ __( 'Weymontachie', 'describr' ),
        348 => /*translators: City.*/ __( 'Windsor', 'describr' ),
        349 => /*translators: City.*/ __( 'Yamachiche', 'describr' ),
        350 => /*translators: City.*/ __( 'le Plateau', 'describr' ),
      ),
    ),
    'NS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nova Scotia', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amherst', 'describr' ),
        1 => /*translators: City.*/ __( 'Annapolis County', 'describr' ),
        2 => /*translators: City.*/ __( 'Antigonish', 'describr' ),
        3 => /*translators: City.*/ __( 'Berwick', 'describr' ),
        4 => /*translators: City.*/ __( 'Bridgewater', 'describr' ),
        5 => /*translators: City.*/ __( 'Cape Breton County', 'describr' ),
        6 => /*translators: City.*/ __( 'Chester', 'describr' ),
        7 => /*translators: City.*/ __( 'Colchester', 'describr' ),
        8 => /*translators: City.*/ __( 'Cole Harbour', 'describr' ),
        9 => /*translators: City.*/ __( 'Cow Bay', 'describr' ),
        10 => /*translators: City.*/ __( 'Dartmouth', 'describr' ),
        11 => /*translators: City.*/ __( 'Digby', 'describr' ),
        12 => /*translators: City.*/ __( 'Digby County', 'describr' ),
        13 => /*translators: City.*/ __( 'English Corner', 'describr' ),
        14 => /*translators: City.*/ __( 'Eskasoni 3', 'describr' ),
        15 => /*translators: City.*/ __( 'Fall River', 'describr' ),
        16 => /*translators: City.*/ __( 'Glace Bay', 'describr' ),
        17 => /*translators: City.*/ __( 'Greenwood', 'describr' ),
        18 => /*translators: City.*/ __( 'Halifax', 'describr' ),
        19 => /*translators: City.*/ __( 'Hantsport', 'describr' ),
        20 => /*translators: City.*/ __( 'Hayes Subdivision', 'describr' ),
        21 => /*translators: City.*/ __( 'Kentville', 'describr' ),
        22 => /*translators: City.*/ __( 'Lake Echo', 'describr' ),
        23 => /*translators: City.*/ __( 'Lantz', 'describr' ),
        24 => /*translators: City.*/ __( 'Lower Sackville', 'describr' ),
        25 => /*translators: City.*/ __( 'Lunenburg', 'describr' ),
        26 => /*translators: City.*/ __( 'Middleton', 'describr' ),
        27 => /*translators: City.*/ __( 'New Glasgow', 'describr' ),
        28 => /*translators: City.*/ __( 'Oxford', 'describr' ),
        29 => /*translators: City.*/ __( 'Parrsboro', 'describr' ),
        30 => /*translators: City.*/ __( 'Pictou', 'describr' ),
        31 => /*translators: City.*/ __( 'Pictou County', 'describr' ),
        32 => /*translators: City.*/ __( 'Port Hawkesbury', 'describr' ),
        33 => /*translators: City.*/ __( 'Port Williams', 'describr' ),
        34 => /*translators: City.*/ __( 'Princeville', 'describr' ),
        35 => /*translators: City.*/ __( 'Shelburne', 'describr' ),
        36 => /*translators: City.*/ __( 'Springhill', 'describr' ),
        37 => /*translators: City.*/ __( 'Sydney', 'describr' ),
        38 => /*translators: City.*/ __( 'Sydney Mines', 'describr' ),
        39 => /*translators: City.*/ __( 'Truro', 'describr' ),
        40 => /*translators: City.*/ __( 'Windsor', 'describr' ),
        41 => /*translators: City.*/ __( 'Wolfville', 'describr' ),
        42 => /*translators: City.*/ __( 'Yarmouth', 'describr' ),
      ),
    ),
    'BC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'British Columbia', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abbotsford', 'describr' ),
        1 => /*translators: City.*/ __( 'Agassiz', 'describr' ),
        2 => /*translators: City.*/ __( 'Aldergrove', 'describr' ),
        3 => /*translators: City.*/ __( 'Aldergrove East', 'describr' ),
        4 => /*translators: City.*/ __( 'Anmore', 'describr' ),
        5 => /*translators: City.*/ __( 'Arbutus Ridge', 'describr' ),
        6 => /*translators: City.*/ __( 'Armstrong', 'describr' ),
        7 => /*translators: City.*/ __( 'Ashcroft', 'describr' ),
        8 => /*translators: City.*/ __( 'Barrière', 'describr' ),
        9 => /*translators: City.*/ __( 'Bowen Island', 'describr' ),
        10 => /*translators: City.*/ __( 'Burnaby', 'describr' ),
        11 => /*translators: City.*/ __( 'Burns Lake', 'describr' ),
        12 => /*translators: City.*/ __( 'Cache Creek', 'describr' ),
        13 => /*translators: City.*/ __( 'Campbell River', 'describr' ),
        14 => /*translators: City.*/ __( 'Castlegar', 'describr' ),
        15 => /*translators: City.*/ __( 'Cedar', 'describr' ),
        16 => /*translators: City.*/ __( 'Central Coast Regional District', 'describr' ),
        17 => /*translators: City.*/ __( 'Chase', 'describr' ),
        18 => /*translators: City.*/ __( 'Chemainus', 'describr' ),
        19 => /*translators: City.*/ __( 'Chetwynd', 'describr' ),
        20 => /*translators: City.*/ __( 'Chilliwack', 'describr' ),
        21 => /*translators: City.*/ __( 'Colwood', 'describr' ),
        22 => /*translators: City.*/ __( 'Coombs', 'describr' ),
        23 => /*translators: City.*/ __( 'Coquitlam', 'describr' ),
        24 => /*translators: City.*/ __( 'Courtenay', 'describr' ),
        25 => /*translators: City.*/ __( 'Cowichan Bay', 'describr' ),
        26 => /*translators: City.*/ __( 'Cranbrook', 'describr' ),
        27 => /*translators: City.*/ __( 'Creston', 'describr' ),
        28 => /*translators: City.*/ __( 'Cumberland', 'describr' ),
        29 => /*translators: City.*/ __( 'Dawson Creek', 'describr' ),
        30 => /*translators: City.*/ __( 'Delta', 'describr' ),
        31 => /*translators: City.*/ __( 'Denman Island', 'describr' ),
        32 => /*translators: City.*/ __( 'Denman Island Trust Area', 'describr' ),
        33 => /*translators: City.*/ __( 'Duck Lake', 'describr' ),
        34 => /*translators: City.*/ __( 'Duncan', 'describr' ),
        35 => /*translators: City.*/ __( 'East Wellington', 'describr' ),
        36 => /*translators: City.*/ __( 'Elkford', 'describr' ),
        37 => /*translators: City.*/ __( 'Ellison', 'describr' ),
        38 => /*translators: City.*/ __( 'Enderby', 'describr' ),
        39 => /*translators: City.*/ __( 'Fairwinds', 'describr' ),
        40 => /*translators: City.*/ __( 'Fernie', 'describr' ),
        41 => /*translators: City.*/ __( 'Fort Nelson', 'describr' ),
        42 => /*translators: City.*/ __( 'Fort St. John', 'describr' ),
        43 => /*translators: City.*/ __( 'Fraser Valley Regional District', 'describr' ),
        44 => /*translators: City.*/ __( 'French Creek', 'describr' ),
        45 => /*translators: City.*/ __( 'Fruitvale', 'describr' ),
        46 => /*translators: City.*/ __( 'Gibsons', 'describr' ),
        47 => /*translators: City.*/ __( 'Golden', 'describr' ),
        48 => /*translators: City.*/ __( 'Grand Forks', 'describr' ),
        49 => /*translators: City.*/ __( 'Hanceville', 'describr' ),
        50 => /*translators: City.*/ __( 'Hope', 'describr' ),
        51 => /*translators: City.*/ __( 'Hornby Island', 'describr' ),
        52 => /*translators: City.*/ __( 'Houston', 'describr' ),
        53 => /*translators: City.*/ __( 'Invermere', 'describr' ),
        54 => /*translators: City.*/ __( 'Kamloops', 'describr' ),
        55 => /*translators: City.*/ __( 'Kelowna', 'describr' ),
        56 => /*translators: City.*/ __( 'Kimberley', 'describr' ),
        57 => /*translators: City.*/ __( 'Kitimat', 'describr' ),
        58 => /*translators: City.*/ __( 'Ladner', 'describr' ),
        59 => /*translators: City.*/ __( 'Ladysmith', 'describr' ),
        60 => /*translators: City.*/ __( 'Lake Cowichan', 'describr' ),
        61 => /*translators: City.*/ __( 'Langford', 'describr' ),
        62 => /*translators: City.*/ __( 'Langley', 'describr' ),
        63 => /*translators: City.*/ __( 'Lillooet', 'describr' ),
        64 => /*translators: City.*/ __( 'Lions Bay', 'describr' ),
        65 => /*translators: City.*/ __( 'Logan Lake', 'describr' ),
        66 => /*translators: City.*/ __( 'Lumby', 'describr' ),
        67 => /*translators: City.*/ __( 'Mackenzie', 'describr' ),
        68 => /*translators: City.*/ __( 'Maple Ridge', 'describr' ),
        69 => /*translators: City.*/ __( 'Merritt', 'describr' ),
        70 => /*translators: City.*/ __( 'Metchosin', 'describr' ),
        71 => /*translators: City.*/ __( 'Metro Vancouver Regional District', 'describr' ),
        72 => /*translators: City.*/ __( 'Mission', 'describr' ),
        73 => /*translators: City.*/ __( 'Nakusp', 'describr' ),
        74 => /*translators: City.*/ __( 'Nanaimo', 'describr' ),
        75 => /*translators: City.*/ __( 'Nelson', 'describr' ),
        76 => /*translators: City.*/ __( 'New Westminster', 'describr' ),
        77 => /*translators: City.*/ __( 'North Cowichan', 'describr' ),
        78 => /*translators: City.*/ __( 'North Oyster/Yellow Point', 'describr' ),
        79 => /*translators: City.*/ __( 'North Saanich', 'describr' ),
        80 => /*translators: City.*/ __( 'North Vancouver', 'describr' ),
        81 => /*translators: City.*/ __( 'Oak Bay', 'describr' ),
        82 => /*translators: City.*/ __( 'Okanagan', 'describr' ),
        83 => /*translators: City.*/ __( 'Okanagan Falls', 'describr' ),
        84 => /*translators: City.*/ __( 'Oliver', 'describr' ),
        85 => /*translators: City.*/ __( 'Osoyoos', 'describr' ),
        86 => /*translators: City.*/ __( 'Parksville', 'describr' ),
        87 => /*translators: City.*/ __( 'Peace River Regional District', 'describr' ),
        88 => /*translators: City.*/ __( 'Peachland', 'describr' ),
        89 => /*translators: City.*/ __( 'Pemberton', 'describr' ),
        90 => /*translators: City.*/ __( 'Penticton', 'describr' ),
        91 => /*translators: City.*/ __( 'Pitt Meadows', 'describr' ),
        92 => /*translators: City.*/ __( 'Port Alberni', 'describr' ),
        93 => /*translators: City.*/ __( 'Port Coquitlam', 'describr' ),
        94 => /*translators: City.*/ __( 'Port McNeill', 'describr' ),
        95 => /*translators: City.*/ __( 'Port Moody', 'describr' ),
        96 => /*translators: City.*/ __( 'Powell River', 'describr' ),
        97 => /*translators: City.*/ __( 'Prince George', 'describr' ),
        98 => /*translators: City.*/ __( 'Prince Rupert', 'describr' ),
        99 => /*translators: City.*/ __( 'Princeton', 'describr' ),
        100 => /*translators: City.*/ __( 'Puntledge', 'describr' ),
        101 => /*translators: City.*/ __( 'Quesnel', 'describr' ),
        102 => /*translators: City.*/ __( 'Regional District of Alberni-Clayoquot', 'describr' ),
        103 => /*translators: City.*/ __( 'Regional District of Central Okanagan', 'describr' ),
        104 => /*translators: City.*/ __( 'Revelstoke', 'describr' ),
        105 => /*translators: City.*/ __( 'Richmond', 'describr' ),
        106 => /*translators: City.*/ __( 'Rossland', 'describr' ),
        107 => /*translators: City.*/ __( 'Royston', 'describr' ),
        108 => /*translators: City.*/ __( 'Salmo', 'describr' ),
        109 => /*translators: City.*/ __( 'Salmon Arm', 'describr' ),
        110 => /*translators: City.*/ __( 'Salt Spring Island', 'describr' ),
        111 => /*translators: City.*/ __( 'Saltair', 'describr' ),
        112 => /*translators: City.*/ __( 'Sechelt', 'describr' ),
        113 => /*translators: City.*/ __( 'Sicamous', 'describr' ),
        114 => /*translators: City.*/ __( 'Six Mile', 'describr' ),
        115 => /*translators: City.*/ __( 'Smithers', 'describr' ),
        116 => /*translators: City.*/ __( 'Sooke', 'describr' ),
        117 => /*translators: City.*/ __( 'South Pender Harbour', 'describr' ),
        118 => /*translators: City.*/ __( 'Sparwood', 'describr' ),
        119 => /*translators: City.*/ __( 'Summerland', 'describr' ),
        120 => /*translators: City.*/ __( 'Surrey', 'describr' ),
        121 => /*translators: City.*/ __( 'Terrace', 'describr' ),
        122 => /*translators: City.*/ __( 'Tofino', 'describr' ),
        123 => /*translators: City.*/ __( 'Trail', 'describr' ),
        124 => /*translators: City.*/ __( 'Tsawwassen', 'describr' ),
        125 => /*translators: City.*/ __( 'Tumbler Ridge', 'describr' ),
        126 => /*translators: City.*/ __( 'Ucluelet', 'describr' ),
        127 => /*translators: City.*/ __( 'Vancouver', 'describr' ),
        128 => /*translators: City.*/ __( 'Vanderhoof', 'describr' ),
        129 => /*translators: City.*/ __( 'Vernon', 'describr' ),
        130 => /*translators: City.*/ __( 'Victoria', 'describr' ),
        131 => /*translators: City.*/ __( 'Walnut Grove', 'describr' ),
        132 => /*translators: City.*/ __( 'Welcome Beach', 'describr' ),
        133 => /*translators: City.*/ __( 'West End', 'describr' ),
        134 => /*translators: City.*/ __( 'West Kelowna', 'describr' ),
        135 => /*translators: City.*/ __( 'West Vancouver', 'describr' ),
        136 => /*translators: City.*/ __( 'Whistler', 'describr' ),
        137 => /*translators: City.*/ __( 'White Rock', 'describr' ),
        138 => /*translators: City.*/ __( 'Williams Lake', 'describr' ),
      ),
    ),
    'NU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nunavut', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Clyde River', 'describr' ),
        1 => /*translators: City.*/ __( 'Gjoa Haven', 'describr' ),
        2 => /*translators: City.*/ __( 'Iqaluit', 'describr' ),
        3 => /*translators: City.*/ __( 'Kugluktuk', 'describr' ),
        4 => /*translators: City.*/ __( 'Pangnirtung', 'describr' ),
        5 => /*translators: City.*/ __( 'Rankin Inlet', 'describr' ),
      ),
    ),
    'NL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Newfoundland and Labrador', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bay Roberts', 'describr' ),
        1 => /*translators: City.*/ __( 'Bay St. George South', 'describr' ),
        2 => /*translators: City.*/ __( 'Bonavista', 'describr' ),
        3 => /*translators: City.*/ __( 'Botwood', 'describr' ),
        4 => /*translators: City.*/ __( 'Burgeo', 'describr' ),
        5 => /*translators: City.*/ __( 'Carbonear', 'describr' ),
        6 => /*translators: City.*/ __( 'Catalina', 'describr' ),
        7 => /*translators: City.*/ __( 'Channel-Port aux Basques', 'describr' ),
        8 => /*translators: City.*/ __( 'Clarenville-Shoal Harbour', 'describr' ),
        9 => /*translators: City.*/ __( 'Conception Bay South', 'describr' ),
        10 => /*translators: City.*/ __( 'Corner Brook', 'describr' ),
        11 => /*translators: City.*/ __( 'Deer Lake', 'describr' ),
        12 => /*translators: City.*/ __( 'Fogo Island', 'describr' ),
        13 => /*translators: City.*/ __( 'Gambo', 'describr' ),
        14 => /*translators: City.*/ __( 'Goulds', 'describr' ),
        15 => /*translators: City.*/ __( 'Grand Bank', 'describr' ),
        16 => /*translators: City.*/ __( 'Grand Falls-Windsor', 'describr' ),
        17 => /*translators: City.*/ __( 'Happy Valley-Goose Bay', 'describr' ),
        18 => /*translators: City.*/ __( 'Harbour Breton', 'describr' ),
        19 => /*translators: City.*/ __( 'Labrador City', 'describr' ),
        20 => /*translators: City.*/ __( 'Lewisporte', 'describr' ),
        21 => /*translators: City.*/ __( 'Marystown', 'describr' ),
        22 => /*translators: City.*/ __( 'Mount Pearl', 'describr' ),
        23 => /*translators: City.*/ __( 'Pasadena', 'describr' ),
        24 => /*translators: City.*/ __( 'Springdale', 'describr' ),
        25 => /*translators: City.*/ __( 'St. Anthony', 'describr' ),
        26 => /*translators: City.*/ __( 'St. John&#039;s', 'describr' ),
        27 => /*translators: City.*/ __( 'Stephenville', 'describr' ),
        28 => /*translators: City.*/ __( 'Stephenville Crossing', 'describr' ),
        29 => /*translators: City.*/ __( 'Torbay', 'describr' ),
        30 => /*translators: City.*/ __( 'Upper Island Cove', 'describr' ),
        31 => /*translators: City.*/ __( 'Wabana', 'describr' ),
      ),
    ),
    'NT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northwest Territories', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Behchokǫ̀', 'describr' ),
        1 => /*translators: City.*/ __( 'Fort McPherson', 'describr' ),
        2 => /*translators: City.*/ __( 'Fort Smith', 'describr' ),
        3 => /*translators: City.*/ __( 'Hay River', 'describr' ),
        4 => /*translators: City.*/ __( 'Inuvik', 'describr' ),
        5 => /*translators: City.*/ __( 'Norman Wells', 'describr' ),
        6 => /*translators: City.*/ __( 'Yellowknife', 'describr' ),
      ),
    ),
  ),
  'SD' => 
  array (
    'NW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'White Nile', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ad Douiem', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Kawa', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Qiţena', 'describr' ),
        3 => /*translators: City.*/ __( 'Kosti', 'describr' ),
        4 => /*translators: City.*/ __( 'Marabba', 'describr' ),
        5 => /*translators: City.*/ __( 'Rabak', 'describr' ),
        6 => /*translators: City.*/ __( 'Tandaltī', 'describr' ),
        7 => /*translators: City.*/ __( 'Um Jar Al Gharbiyya', 'describr' ),
        8 => /*translators: City.*/ __( 'Wad az Zāki', 'describr' ),
      ),
    ),
    'RS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Red Sea', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gebeit', 'describr' ),
        1 => /*translators: City.*/ __( 'Port Sudan', 'describr' ),
        2 => /*translators: City.*/ __( 'Sawākin', 'describr' ),
        3 => /*translators: City.*/ __( 'Tokār', 'describr' ),
      ),
    ),
    'KH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khartoum', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Khartoum', 'describr' ),
        1 => /*translators: City.*/ __( 'Omdurman', 'describr' ),
      ),
    ),
    'SI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sennar', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ad Dindar', 'describr' ),
        1 => /*translators: City.*/ __( 'As Sūkī', 'describr' ),
        2 => /*translators: City.*/ __( 'Jalqani', 'describr' ),
        3 => /*translators: City.*/ __( 'Kināna', 'describr' ),
        4 => /*translators: City.*/ __( 'Maiurno', 'describr' ),
        5 => /*translators: City.*/ __( 'Singa', 'describr' ),
        6 => /*translators: City.*/ __( 'Sinnar', 'describr' ),
      ),
    ),
    'KS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'South Kordofan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abu Jibeha', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Fūlah', 'describr' ),
        2 => /*translators: City.*/ __( 'Dilling', 'describr' ),
        3 => /*translators: City.*/ __( 'Kadugli', 'describr' ),
        4 => /*translators: City.*/ __( 'Talodi', 'describr' ),
      ),
    ),
    'KA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kassala', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aroma', 'describr' ),
        1 => /*translators: City.*/ __( 'Kassala', 'describr' ),
        2 => /*translators: City.*/ __( 'Wagar', 'describr' ),
      ),
    ),
    'GZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Jazirah', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Hasaheisa', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Hilāliyya', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Kiremit al &#039;Arakiyyīn', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Manāqil', 'describr' ),
        4 => /*translators: City.*/ __( 'Al Masallamiyya', 'describr' ),
        5 => /*translators: City.*/ __( 'Wad Medani', 'describr' ),
        6 => /*translators: City.*/ __( 'Wad Rāwah', 'describr' ),
      ),
    ),
    'GD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Qadarif', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Qadarif', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Ḩawātah', 'describr' ),
        2 => /*translators: City.*/ __( 'Doka', 'describr' ),
      ),
    ),
    'NB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Blue Nile', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ad-Damazin', 'describr' ),
        1 => /*translators: City.*/ __( 'Ar Ruseris', 'describr' ),
        2 => /*translators: City.*/ __( 'Kurmuk', 'describr' ),
      ),
    ),
    'DW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'West Darfur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Geneina', 'describr' ),
      ),
    ),
    'GK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'West Kordofan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abū Zabad', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Lagowa', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Mijlad', 'describr' ),
        3 => /*translators: City.*/ __( 'An Nuhūd', 'describr' ),
      ),
    ),
    'DN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North Darfur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Fasher', 'describr' ),
        1 => /*translators: City.*/ __( 'Kutum', 'describr' ),
        2 => /*translators: City.*/ __( 'Umm Kaddadah', 'describr' ),
      ),
    ),
    'NR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'River Nile', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Atbara', 'describr' ),
        1 => /*translators: City.*/ __( 'Berber', 'describr' ),
        2 => /*translators: City.*/ __( 'Ed Damer', 'describr' ),
        3 => /*translators: City.*/ __( 'El Bauga', 'describr' ),
        4 => /*translators: City.*/ __( 'El Matama', 'describr' ),
        5 => /*translators: City.*/ __( 'Shendi', 'describr' ),
      ),
    ),
    'DE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'East Darfur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Daein', 'describr' ),
      ),
    ),
    'KN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North Kordofan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ar Rahad', 'describr' ),
        1 => /*translators: City.*/ __( 'Bārah', 'describr' ),
        2 => /*translators: City.*/ __( 'El Obeid', 'describr' ),
        3 => /*translators: City.*/ __( 'Umm Ruwaba', 'describr' ),
      ),
    ),
    'DS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'South Darfur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gereida', 'describr' ),
        1 => /*translators: City.*/ __( 'Nyala', 'describr' ),
      ),
    ),
    'NO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ad Dabbah', 'describr' ),
        1 => /*translators: City.*/ __( 'Argo', 'describr' ),
        2 => /*translators: City.*/ __( 'Dongola', 'describr' ),
        3 => /*translators: City.*/ __( 'Karmah an Nuzul', 'describr' ),
        4 => /*translators: City.*/ __( 'Kuraymah', 'describr' ),
        5 => /*translators: City.*/ __( 'Merowe', 'describr' ),
      ),
    ),
    'DC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Darfur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Zalingei', 'describr' ),
      ),
    ),
  ),
  'GE' => 
  array (
    'TB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tbilisi', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tbilisi', 'describr' ),
      ),
    ),
    'AJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Adjara', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akhaldaba', 'describr' ),
        1 => /*translators: City.*/ __( 'Batumi', 'describr' ),
        2 => /*translators: City.*/ __( 'Chakvi', 'describr' ),
        3 => /*translators: City.*/ __( 'Dioknisi', 'describr' ),
        4 => /*translators: City.*/ __( 'Khelvachauri', 'describr' ),
        5 => /*translators: City.*/ __( 'Khulo', 'describr' ),
        6 => /*translators: City.*/ __( 'Kobuleti', 'describr' ),
        7 => /*translators: City.*/ __( 'Makhinjauri', 'describr' ),
        8 => /*translators: City.*/ __( 'Ochkhamuri', 'describr' ),
        9 => /*translators: City.*/ __( 'Shuakhevi', 'describr' ),
        10 => /*translators: City.*/ __( 'Tsikhisdziri', 'describr' ),
      ),
    ),
    'AB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Autonomous Republic of Abkhazia', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bich&#039;vinta', 'describr' ),
        1 => /*translators: City.*/ __( 'Dranda', 'describr' ),
        2 => /*translators: City.*/ __( 'Gagra', 'describr' ),
        3 => /*translators: City.*/ __( 'Gali', 'describr' ),
        4 => /*translators: City.*/ __( 'Gantiadi', 'describr' ),
        5 => /*translators: City.*/ __( 'Gudauta', 'describr' ),
        6 => /*translators: City.*/ __( 'Kelasuri', 'describr' ),
        7 => /*translators: City.*/ __( 'Och&#039;amch&#039;ire', 'describr' ),
        8 => /*translators: City.*/ __( 'P&#039;rimorsk&#039;oe', 'describr' ),
        9 => /*translators: City.*/ __( 'Sokhumi', 'describr' ),
        10 => /*translators: City.*/ __( 'Stantsiya Novyy Afon', 'describr' ),
        11 => /*translators: City.*/ __( 'Tqvarch&#039;eli', 'describr' ),
      ),
    ),
    'MM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mtskheta-Mtianeti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akhalgori', 'describr' ),
        1 => /*translators: City.*/ __( 'Dzegvi', 'describr' ),
        2 => /*translators: City.*/ __( 'Gudauri', 'describr' ),
        3 => /*translators: City.*/ __( 'Java', 'describr' ),
        4 => /*translators: City.*/ __( 'Mtskheta', 'describr' ),
        5 => /*translators: City.*/ __( 'P&#039;asanauri', 'describr' ),
        6 => /*translators: City.*/ __( 'Step&#039;antsminda', 'describr' ),
        7 => /*translators: City.*/ __( 'Zhinvali', 'describr' ),
      ),
    ),
    'SK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shida Kartli', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agara', 'describr' ),
        1 => /*translators: City.*/ __( 'Gori', 'describr' ),
        2 => /*translators: City.*/ __( 'Goris Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        3 => /*translators: City.*/ __( 'Kaspi', 'describr' ),
        4 => /*translators: City.*/ __( 'Khashuri', 'describr' ),
        5 => /*translators: City.*/ __( 'Surami', 'describr' ),
        6 => /*translators: City.*/ __( 'Ts&#039;khinvali', 'describr' ),
      ),
    ),
    'KK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kvemo Kartli', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bolnisi', 'describr' ),
        1 => /*translators: City.*/ __( 'Bolnisis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        2 => /*translators: City.*/ __( 'Didi Lilo', 'describr' ),
        3 => /*translators: City.*/ __( 'Dmanisis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        4 => /*translators: City.*/ __( 'Gardabani', 'describr' ),
        5 => /*translators: City.*/ __( 'Gardabnis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        6 => /*translators: City.*/ __( 'Manglisi', 'describr' ),
        7 => /*translators: City.*/ __( 'Marneuli', 'describr' ),
        8 => /*translators: City.*/ __( 'Marneulis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        9 => /*translators: City.*/ __( 'Naghvarevi', 'describr' ),
        10 => /*translators: City.*/ __( 'Rust&#039;avi', 'describr' ),
        11 => /*translators: City.*/ __( 'Tetrits&#039;q&#039;alos Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        12 => /*translators: City.*/ __( 'Tsalka', 'describr' ),
        13 => /*translators: City.*/ __( 'Ts&#039;alk&#039;is Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        14 => /*translators: City.*/ __( 'T&#039;et&#039;ri Tsqaro', 'describr' ),
      ),
    ),
    'IM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Imereti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baghdatis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        1 => /*translators: City.*/ __( 'Chiat&#039;ura', 'describr' ),
        2 => /*translators: City.*/ __( 'Kharagauli', 'describr' ),
        3 => /*translators: City.*/ __( 'Khoni', 'describr' ),
        4 => /*translators: City.*/ __( 'Kutaisi', 'describr' ),
        5 => /*translators: City.*/ __( 'K&#039;alak&#039;i Chiat&#039;ura', 'describr' ),
        6 => /*translators: City.*/ __( 'K&#039;ulashi', 'describr' ),
        7 => /*translators: City.*/ __( 'Sach&#039;khere', 'describr' ),
        8 => /*translators: City.*/ __( 'Samtredia', 'describr' ),
        9 => /*translators: City.*/ __( 'Shorapani', 'describr' ),
        10 => /*translators: City.*/ __( 'Tqibuli', 'describr' ),
        11 => /*translators: City.*/ __( 'Tsqaltubo', 'describr' ),
        12 => /*translators: City.*/ __( 'Vani', 'describr' ),
        13 => /*translators: City.*/ __( 'Zestap&#039;oni', 'describr' ),
      ),
    ),
    'SJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Samtskhe-Javakheti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adigeni', 'describr' ),
        1 => /*translators: City.*/ __( 'Adigeni Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Akhaldaba', 'describr' ),
        3 => /*translators: City.*/ __( 'Akhalk&#039;alak&#039;i', 'describr' ),
        4 => /*translators: City.*/ __( 'Akhaltsikhe', 'describr' ),
        5 => /*translators: City.*/ __( 'Akhaltsikhis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        6 => /*translators: City.*/ __( 'Aspindza', 'describr' ),
        7 => /*translators: City.*/ __( 'Asp&#039;indzis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        8 => /*translators: City.*/ __( 'Bakuriani', 'describr' ),
        9 => /*translators: City.*/ __( 'Borjomi', 'describr' ),
        10 => /*translators: City.*/ __( 'Ninotsminda', 'describr' ),
        11 => /*translators: City.*/ __( 'Tsaghveri', 'describr' ),
        12 => /*translators: City.*/ __( 'Vale', 'describr' ),
      ),
    ),
    'GU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Guria', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lanchkhuti', 'describr' ),
        1 => /*translators: City.*/ __( 'Naruja', 'describr' ),
        2 => /*translators: City.*/ __( 'Ozurgeti', 'describr' ),
        3 => /*translators: City.*/ __( 'Urek&#039;i', 'describr' ),
      ),
    ),
    'SZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Samegrelo-Zemo Svaneti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abasha', 'describr' ),
        1 => /*translators: City.*/ __( 'Jvari', 'describr' ),
        2 => /*translators: City.*/ __( 'Khobi', 'describr' ),
        3 => /*translators: City.*/ __( 'Kveda Chkhorots&#039;q&#039;u', 'describr' ),
        4 => /*translators: City.*/ __( 'Mart&#039;vili', 'describr' ),
        5 => /*translators: City.*/ __( 'Mest&#039;ia', 'describr' ),
        6 => /*translators: City.*/ __( 'Mest&#039;iis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        7 => /*translators: City.*/ __( 'Orsant&#039;ia', 'describr' ),
        8 => /*translators: City.*/ __( 'P&#039;ot&#039;i', 'describr' ),
        9 => /*translators: City.*/ __( 'Senak&#039;i', 'describr' ),
        10 => /*translators: City.*/ __( 'Tsalenjikha', 'describr' ),
        11 => /*translators: City.*/ __( 'Zugdidi', 'describr' ),
      ),
    ),
    'RL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Racha-Lechkhumi and Kvemo Svaneti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ambrolauri', 'describr' ),
        1 => /*translators: City.*/ __( 'Ambrolauris Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        2 => /*translators: City.*/ __( 'Lent&#039;ekhi', 'describr' ),
        3 => /*translators: City.*/ __( 'Oni', 'describr' ),
      ),
    ),
    'KA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kakheti', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akhmet&#039;a', 'describr' ),
        1 => /*translators: City.*/ __( 'Akhmet&#039;is Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        2 => /*translators: City.*/ __( 'Gurjaani', 'describr' ),
        3 => /*translators: City.*/ __( 'Lagodekhi', 'describr' ),
        4 => /*translators: City.*/ __( 'Qvareli', 'describr' ),
        5 => /*translators: City.*/ __( 'Sagarejo', 'describr' ),
        6 => /*translators: City.*/ __( 'Sighnaghi', 'describr' ),
        7 => /*translators: City.*/ __( 'Sighnaghis Munitsip&#039;alit&#039;et&#039;i', 'describr' ),
        8 => /*translators: City.*/ __( 'Telavi', 'describr' ),
        9 => /*translators: City.*/ __( 'Tsinandali', 'describr' ),
        10 => /*translators: City.*/ __( 'Tsnori', 'describr' ),
      ),
    ),
  ),
  'SL' => 
  array (
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alikalia', 'describr' ),
        1 => /*translators: City.*/ __( 'Bindi', 'describr' ),
        2 => /*translators: City.*/ __( 'Binkolo', 'describr' ),
        3 => /*translators: City.*/ __( 'Bombali District', 'describr' ),
        4 => /*translators: City.*/ __( 'Bumbuna', 'describr' ),
        5 => /*translators: City.*/ __( 'Gberia Fotombu', 'describr' ),
        6 => /*translators: City.*/ __( 'Kabala', 'describr' ),
        7 => /*translators: City.*/ __( 'Kamakwie', 'describr' ),
        8 => /*translators: City.*/ __( 'Kambia', 'describr' ),
        9 => /*translators: City.*/ __( 'Kassiri', 'describr' ),
        10 => /*translators: City.*/ __( 'Koinadugu District', 'describr' ),
        11 => /*translators: City.*/ __( 'Konakridee', 'describr' ),
        12 => /*translators: City.*/ __( 'Kukuna', 'describr' ),
        13 => /*translators: City.*/ __( 'Loma', 'describr' ),
        14 => /*translators: City.*/ __( 'Lunsar', 'describr' ),
        15 => /*translators: City.*/ __( 'Magburaka', 'describr' ),
        16 => /*translators: City.*/ __( 'Makali', 'describr' ),
        17 => /*translators: City.*/ __( 'Makeni', 'describr' ),
        18 => /*translators: City.*/ __( 'Mambolo', 'describr' ),
        19 => /*translators: City.*/ __( 'Mange', 'describr' ),
        20 => /*translators: City.*/ __( 'Masaka', 'describr' ),
        21 => /*translators: City.*/ __( 'Masingbi', 'describr' ),
        22 => /*translators: City.*/ __( 'Masoyila', 'describr' ),
        23 => /*translators: City.*/ __( 'Pepel', 'describr' ),
        24 => /*translators: City.*/ __( 'Rokupr', 'describr' ),
        25 => /*translators: City.*/ __( 'Sawkta', 'describr' ),
        26 => /*translators: City.*/ __( 'Seidu', 'describr' ),
        27 => /*translators: City.*/ __( 'Tintafor', 'describr' ),
        28 => /*translators: City.*/ __( 'Tonkolili District', 'describr' ),
        29 => /*translators: City.*/ __( 'Yonibana', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baiima', 'describr' ),
        1 => /*translators: City.*/ __( 'Baoma', 'describr' ),
        2 => /*translators: City.*/ __( 'Bo', 'describr' ),
        3 => /*translators: City.*/ __( 'Bo District', 'describr' ),
        4 => /*translators: City.*/ __( 'Bomi', 'describr' ),
        5 => /*translators: City.*/ __( 'Bonthe', 'describr' ),
        6 => /*translators: City.*/ __( 'Bonthe District', 'describr' ),
        7 => /*translators: City.*/ __( 'Bumpe', 'describr' ),
        8 => /*translators: City.*/ __( 'Foindu', 'describr' ),
        9 => /*translators: City.*/ __( 'Gandorhun', 'describr' ),
        10 => /*translators: City.*/ __( 'Gbewebu', 'describr' ),
        11 => /*translators: City.*/ __( 'Koribundu', 'describr' ),
        12 => /*translators: City.*/ __( 'Largo', 'describr' ),
        13 => /*translators: City.*/ __( 'Mamboma', 'describr' ),
        14 => /*translators: City.*/ __( 'Mogbwemo', 'describr' ),
        15 => /*translators: City.*/ __( 'Moyamba', 'describr' ),
        16 => /*translators: City.*/ __( 'Moyamba District', 'describr' ),
        17 => /*translators: City.*/ __( 'Palima', 'describr' ),
        18 => /*translators: City.*/ __( 'Potoru', 'describr' ),
        19 => /*translators: City.*/ __( 'Pujehun', 'describr' ),
        20 => /*translators: City.*/ __( 'Pujehun District', 'describr' ),
        21 => /*translators: City.*/ __( 'Rotifunk', 'describr' ),
        22 => /*translators: City.*/ __( 'Serabu', 'describr' ),
        23 => /*translators: City.*/ __( 'Sumbuya', 'describr' ),
        24 => /*translators: City.*/ __( 'Tongole', 'describr' ),
        25 => /*translators: City.*/ __( 'Zimmi', 'describr' ),
      ),
    ),
    'W' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Area', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Freetown', 'describr' ),
        1 => /*translators: City.*/ __( 'Hastings', 'describr' ),
        2 => /*translators: City.*/ __( 'Kent', 'describr' ),
        3 => /*translators: City.*/ __( 'Waterloo', 'describr' ),
      ),
    ),
    'E' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barma', 'describr' ),
        1 => /*translators: City.*/ __( 'Blama', 'describr' ),
        2 => /*translators: City.*/ __( 'Boajibu', 'describr' ),
        3 => /*translators: City.*/ __( 'Buedu', 'describr' ),
        4 => /*translators: City.*/ __( 'Bunumbu', 'describr' ),
        5 => /*translators: City.*/ __( 'Daru', 'describr' ),
        6 => /*translators: City.*/ __( 'Giehun', 'describr' ),
        7 => /*translators: City.*/ __( 'Gorahun', 'describr' ),
        8 => /*translators: City.*/ __( 'Hangha', 'describr' ),
        9 => /*translators: City.*/ __( 'Jojoima', 'describr' ),
        10 => /*translators: City.*/ __( 'Kailahun', 'describr' ),
        11 => /*translators: City.*/ __( 'Kailahun District', 'describr' ),
        12 => /*translators: City.*/ __( 'Kayima', 'describr' ),
        13 => /*translators: City.*/ __( 'Kenema', 'describr' ),
        14 => /*translators: City.*/ __( 'Kenema District', 'describr' ),
        15 => /*translators: City.*/ __( 'Koidu', 'describr' ),
        16 => /*translators: City.*/ __( 'Kono District', 'describr' ),
        17 => /*translators: City.*/ __( 'Koyima', 'describr' ),
        18 => /*translators: City.*/ __( 'Manowa', 'describr' ),
        19 => /*translators: City.*/ __( 'Mobai', 'describr' ),
        20 => /*translators: City.*/ __( 'Motema', 'describr' ),
        21 => /*translators: City.*/ __( 'Panguma', 'describr' ),
        22 => /*translators: City.*/ __( 'Pendembu', 'describr' ),
        23 => /*translators: City.*/ __( 'Segbwema', 'describr' ),
        24 => /*translators: City.*/ __( 'Simbakoro', 'describr' ),
        25 => /*translators: City.*/ __( 'Tefeya', 'describr' ),
        26 => /*translators: City.*/ __( 'Tombodu', 'describr' ),
        27 => /*translators: City.*/ __( 'Tombu', 'describr' ),
        28 => /*translators: City.*/ __( 'Wima', 'describr' ),
        29 => /*translators: City.*/ __( 'Yengema', 'describr' ),
      ),
    ),
  ),
  'SO' => 
  array (
    'HI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hiran', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beledweyne', 'describr' ),
        1 => /*translators: City.*/ __( 'Buulobarde', 'describr' ),
        2 => /*translators: City.*/ __( 'Jalalaqsi', 'describr' ),
      ),
    ),
    'MU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mudug', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gaalkacyo', 'describr' ),
        1 => /*translators: City.*/ __( 'Hobyo', 'describr' ),
        2 => /*translators: City.*/ __( 'Xarardheere', 'describr' ),
      ),
    ),
    'BK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bakool', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tayeeglow', 'describr' ),
        1 => /*translators: City.*/ __( 'Waajid', 'describr' ),
        2 => /*translators: City.*/ __( 'Xuddur', 'describr' ),
        3 => /*translators: City.*/ __( 'Yeed', 'describr' ),
      ),
    ),
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Galguduud', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ceelbuur', 'describr' ),
        1 => /*translators: City.*/ __( 'Ceeldheer', 'describr' ),
        2 => /*translators: City.*/ __( 'Dhuusamarreeb', 'describr' ),
      ),
    ),
    'SA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sanaag Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ceerigaabo', 'describr' ),
        1 => /*translators: City.*/ __( 'Las Khorey', 'describr' ),
      ),
    ),
    'NU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nugal', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Eyl', 'describr' ),
        1 => /*translators: City.*/ __( 'Garoowe', 'describr' ),
      ),
    ),
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lower Shebelle', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Afgooye', 'describr' ),
        1 => /*translators: City.*/ __( 'Marka', 'describr' ),
        2 => /*translators: City.*/ __( 'Qoryooley', 'describr' ),
        3 => /*translators: City.*/ __( 'Wanlaweyn', 'describr' ),
      ),
    ),
    'JD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Middle Juba', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dujuuma', 'describr' ),
        1 => /*translators: City.*/ __( 'Jilib', 'describr' ),
        2 => /*translators: City.*/ __( 'Saacow', 'describr' ),
      ),
    ),
    'SD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Middle Shebelle', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cadale', 'describr' ),
        1 => /*translators: City.*/ __( 'Jawhar', 'describr' ),
        2 => /*translators: City.*/ __( 'Mahaddayweyne', 'describr' ),
      ),
    ),
    'JH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lower Juba', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Buur Gaabo', 'describr' ),
        1 => /*translators: City.*/ __( 'Jamaame', 'describr' ),
        2 => /*translators: City.*/ __( 'Kismayo', 'describr' ),
      ),
    ),
    'BY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bay', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baidoa', 'describr' ),
        1 => /*translators: City.*/ __( 'Buurhakaba', 'describr' ),
      ),
    ),
    'BN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Banaadir', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mogadishu', 'describr' ),
      ),
    ),
    'GE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gedo', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baardheere', 'describr' ),
        1 => /*translators: City.*/ __( 'Garbahaarrey', 'describr' ),
        2 => /*translators: City.*/ __( 'Luuq', 'describr' ),
      ),
    ),
    'TO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Togdheer Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Burao', 'describr' ),
        1 => /*translators: City.*/ __( 'Ceek', 'describr' ),
        2 => /*translators: City.*/ __( 'Oodweyne', 'describr' ),
      ),
    ),
    'BR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bari', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bandarbeyla', 'describr' ),
        1 => /*translators: City.*/ __( 'Bargaal', 'describr' ),
        2 => /*translators: City.*/ __( 'Bereeda', 'describr' ),
        3 => /*translators: City.*/ __( 'Bosaso', 'describr' ),
        4 => /*translators: City.*/ __( 'Caluula', 'describr' ),
        5 => /*translators: City.*/ __( 'Iskushuban', 'describr' ),
        6 => /*translators: City.*/ __( 'Qandala', 'describr' ),
      ),
    ),
  ),
  'ZA' => 
  array (
    'NC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Cape', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barkly West', 'describr' ),
        1 => /*translators: City.*/ __( 'Brandvlei', 'describr' ),
        2 => /*translators: City.*/ __( 'Calvinia', 'describr' ),
        3 => /*translators: City.*/ __( 'Carnarvon', 'describr' ),
        4 => /*translators: City.*/ __( 'Colesberg', 'describr' ),
        5 => /*translators: City.*/ __( 'Daniëlskuil', 'describr' ),
        6 => /*translators: City.*/ __( 'De Aar', 'describr' ),
        7 => /*translators: City.*/ __( 'Frances Baard District Municipality', 'describr' ),
        8 => /*translators: City.*/ __( 'Fraserburg', 'describr' ),
        9 => /*translators: City.*/ __( 'John Taolo Gaetsewe District Municipality', 'describr' ),
        10 => /*translators: City.*/ __( 'Kathu', 'describr' ),
        11 => /*translators: City.*/ __( 'Kenhardt', 'describr' ),
        12 => /*translators: City.*/ __( 'Kimberley', 'describr' ),
        13 => /*translators: City.*/ __( 'Kuruman', 'describr' ),
        14 => /*translators: City.*/ __( 'Namakwa District Municipality', 'describr' ),
        15 => /*translators: City.*/ __( 'Noupoort', 'describr' ),
        16 => /*translators: City.*/ __( 'Orania', 'describr' ),
        17 => /*translators: City.*/ __( 'Pampierstad', 'describr' ),
        18 => /*translators: City.*/ __( 'Pixley ka Seme District Municipality', 'describr' ),
        19 => /*translators: City.*/ __( 'Pofadder', 'describr' ),
        20 => /*translators: City.*/ __( 'Postmasburg', 'describr' ),
        21 => /*translators: City.*/ __( 'Prieska', 'describr' ),
        22 => /*translators: City.*/ __( 'Ritchie', 'describr' ),
        23 => /*translators: City.*/ __( 'Siyanda District Municipality', 'describr' ),
        24 => /*translators: City.*/ __( 'Springbok', 'describr' ),
        25 => /*translators: City.*/ __( 'Upington', 'describr' ),
        26 => /*translators: City.*/ __( 'Van Wyksvlei', 'describr' ),
        27 => /*translators: City.*/ __( 'Warrenton', 'describr' ),
      ),
    ),
    'FS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Free State', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Allanridge', 'describr' ),
        1 => /*translators: City.*/ __( 'Bethlehem', 'describr' ),
        2 => /*translators: City.*/ __( 'Bloemfontein', 'describr' ),
        3 => /*translators: City.*/ __( 'Bothaville', 'describr' ),
        4 => /*translators: City.*/ __( 'Botshabelo', 'describr' ),
        5 => /*translators: City.*/ __( 'Brandfort', 'describr' ),
        6 => /*translators: City.*/ __( 'Clocolan', 'describr' ),
        7 => /*translators: City.*/ __( 'Deneysville', 'describr' ),
        8 => /*translators: City.*/ __( 'Fezile Dabi District Municipality', 'describr' ),
        9 => /*translators: City.*/ __( 'Frankfort', 'describr' ),
        10 => /*translators: City.*/ __( 'Harrismith', 'describr' ),
        11 => /*translators: City.*/ __( 'Heilbron', 'describr' ),
        12 => /*translators: City.*/ __( 'Hennenman', 'describr' ),
        13 => /*translators: City.*/ __( 'Hoopstad', 'describr' ),
        14 => /*translators: City.*/ __( 'Koppies', 'describr' ),
        15 => /*translators: City.*/ __( 'Kroonstad', 'describr' ),
        16 => /*translators: City.*/ __( 'Kutloanong', 'describr' ),
        17 => /*translators: City.*/ __( 'Ladybrand', 'describr' ),
        18 => /*translators: City.*/ __( 'Lejweleputswa District Municipality', 'describr' ),
        19 => /*translators: City.*/ __( 'Lindley', 'describr' ),
        20 => /*translators: City.*/ __( 'Mangaung Metropolitan Municipality', 'describr' ),
        21 => /*translators: City.*/ __( 'Marquard', 'describr' ),
        22 => /*translators: City.*/ __( 'Parys', 'describr' ),
        23 => /*translators: City.*/ __( 'Phuthaditjhaba', 'describr' ),
        24 => /*translators: City.*/ __( 'Reitz', 'describr' ),
        25 => /*translators: City.*/ __( 'Sasolburg', 'describr' ),
        26 => /*translators: City.*/ __( 'Senekal', 'describr' ),
        27 => /*translators: City.*/ __( 'Thaba Nchu', 'describr' ),
        28 => /*translators: City.*/ __( 'Thabo Mofutsanyana District Municipality', 'describr' ),
        29 => /*translators: City.*/ __( 'Theunissen', 'describr' ),
        30 => /*translators: City.*/ __( 'Ventersburg', 'describr' ),
        31 => /*translators: City.*/ __( 'Viljoenskroon', 'describr' ),
        32 => /*translators: City.*/ __( 'Villiers', 'describr' ),
        33 => /*translators: City.*/ __( 'Virginia', 'describr' ),
        34 => /*translators: City.*/ __( 'Vrede', 'describr' ),
        35 => /*translators: City.*/ __( 'Vredefort', 'describr' ),
        36 => /*translators: City.*/ __( 'Welkom', 'describr' ),
        37 => /*translators: City.*/ __( 'Wesselsbron', 'describr' ),
        38 => /*translators: City.*/ __( 'Winburg', 'describr' ),
        39 => /*translators: City.*/ __( 'Xhariep District Municipality', 'describr' ),
        40 => /*translators: City.*/ __( 'Zastron', 'describr' ),
      ),
    ),
    'LP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Limpopo', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bochum', 'describr' ),
        1 => /*translators: City.*/ __( 'Capricorn District Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Duiwelskloof', 'describr' ),
        3 => /*translators: City.*/ __( 'Ga-Kgapane', 'describr' ),
        4 => /*translators: City.*/ __( 'Giyani', 'describr' ),
        5 => /*translators: City.*/ __( 'Lebowakgomo', 'describr' ),
        6 => /*translators: City.*/ __( 'Louis Trichardt', 'describr' ),
        7 => /*translators: City.*/ __( 'Mankoeng', 'describr' ),
        8 => /*translators: City.*/ __( 'Modimolle', 'describr' ),
        9 => /*translators: City.*/ __( 'Mokopane', 'describr' ),
        10 => /*translators: City.*/ __( 'Mopani District Municipality', 'describr' ),
        11 => /*translators: City.*/ __( 'Musina', 'describr' ),
        12 => /*translators: City.*/ __( 'Nkowakowa', 'describr' ),
        13 => /*translators: City.*/ __( 'Phalaborwa', 'describr' ),
        14 => /*translators: City.*/ __( 'Polokwane', 'describr' ),
        15 => /*translators: City.*/ __( 'Sekhukhune District Municipality', 'describr' ),
        16 => /*translators: City.*/ __( 'Thabazimbi', 'describr' ),
        17 => /*translators: City.*/ __( 'Thohoyandou', 'describr' ),
        18 => /*translators: City.*/ __( 'Thulamahashi', 'describr' ),
        19 => /*translators: City.*/ __( 'Tzaneen', 'describr' ),
        20 => /*translators: City.*/ __( 'Vhembe District Municipality', 'describr' ),
        21 => /*translators: City.*/ __( 'Warmbaths', 'describr' ),
        22 => /*translators: City.*/ __( 'Waterberg District Municipality', 'describr' ),
      ),
    ),
    'NW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North West', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bloemhof', 'describr' ),
        1 => /*translators: City.*/ __( 'Bojanala Platinum District Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Brits', 'describr' ),
        3 => /*translators: City.*/ __( 'Christiana', 'describr' ),
        4 => /*translators: City.*/ __( 'Dr Kenneth Kaunda District Municipality', 'describr' ),
        5 => /*translators: City.*/ __( 'Dr Ruth Segomotsi Mompati District Municipality', 'describr' ),
        6 => /*translators: City.*/ __( 'Fochville', 'describr' ),
        7 => /*translators: City.*/ __( 'Ga-Rankuwa', 'describr' ),
        8 => /*translators: City.*/ __( 'Jan Kempdorp', 'describr' ),
        9 => /*translators: City.*/ __( 'Klerksdorp', 'describr' ),
        10 => /*translators: City.*/ __( 'Koster', 'describr' ),
        11 => /*translators: City.*/ __( 'Lichtenburg', 'describr' ),
        12 => /*translators: City.*/ __( 'Mahikeng', 'describr' ),
        13 => /*translators: City.*/ __( 'Maile', 'describr' ),
        14 => /*translators: City.*/ __( 'Mmabatho', 'describr' ),
        15 => /*translators: City.*/ __( 'Ngaka Modiri Molema District Municipality', 'describr' ),
        16 => /*translators: City.*/ __( 'Orkney', 'describr' ),
        17 => /*translators: City.*/ __( 'Potchefstroom', 'describr' ),
        18 => /*translators: City.*/ __( 'Rustenburg', 'describr' ),
        19 => /*translators: City.*/ __( 'Schweizer-Reneke', 'describr' ),
        20 => /*translators: City.*/ __( 'Stilfontein', 'describr' ),
        21 => /*translators: City.*/ __( 'Vryburg', 'describr' ),
        22 => /*translators: City.*/ __( 'Wolmaransstad', 'describr' ),
        23 => /*translators: City.*/ __( 'Zeerust', 'describr' ),
      ),
    ),
    'KZN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'KwaZulu-Natal', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amajuba District Municipality', 'describr' ),
        1 => /*translators: City.*/ __( 'Ballito', 'describr' ),
        2 => /*translators: City.*/ __( 'Berea', 'describr' ),
        3 => /*translators: City.*/ __( 'Dundee', 'describr' ),
        4 => /*translators: City.*/ __( 'Durban', 'describr' ),
        5 => /*translators: City.*/ __( 'Ekuvukeni', 'describr' ),
        6 => /*translators: City.*/ __( 'Empangeni', 'describr' ),
        7 => /*translators: City.*/ __( 'Eshowe', 'describr' ),
        8 => /*translators: City.*/ __( 'Glencoe', 'describr' ),
        9 => /*translators: City.*/ __( 'Greytown', 'describr' ),
        10 => /*translators: City.*/ __( 'Hluhluwe', 'describr' ),
        11 => /*translators: City.*/ __( 'Howick', 'describr' ),
        12 => /*translators: City.*/ __( 'Kokstad', 'describr' ),
        13 => /*translators: City.*/ __( 'KwaDukuza', 'describr' ),
        14 => /*translators: City.*/ __( 'Margate', 'describr' ),
        15 => /*translators: City.*/ __( 'Mondlo', 'describr' ),
        16 => /*translators: City.*/ __( 'Mooirivier', 'describr' ),
        17 => /*translators: City.*/ __( 'Mpophomeni', 'describr' ),
        18 => /*translators: City.*/ __( 'Mpumalanga', 'describr' ),
        19 => /*translators: City.*/ __( 'Mtubatuba', 'describr' ),
        20 => /*translators: City.*/ __( 'Ndwedwe', 'describr' ),
        21 => /*translators: City.*/ __( 'Newcastle', 'describr' ),
        22 => /*translators: City.*/ __( 'Pietermaritzburg', 'describr' ),
        23 => /*translators: City.*/ __( 'Port Shepstone', 'describr' ),
        24 => /*translators: City.*/ __( 'Richards Bay', 'describr' ),
        25 => /*translators: City.*/ __( 'Richmond', 'describr' ),
        26 => /*translators: City.*/ __( 'Scottburgh', 'describr' ),
        27 => /*translators: City.*/ __( 'Sisonke District Municipality', 'describr' ),
        28 => /*translators: City.*/ __( 'Sundumbili', 'describr' ),
        29 => /*translators: City.*/ __( 'Ugu District Municipality', 'describr' ),
        30 => /*translators: City.*/ __( 'Ulundi', 'describr' ),
        31 => /*translators: City.*/ __( 'Utrecht', 'describr' ),
        32 => /*translators: City.*/ __( 'Vryheid', 'describr' ),
        33 => /*translators: City.*/ __( 'Zululand District Municipality', 'describr' ),
        34 => /*translators: City.*/ __( 'eMkhomazi', 'describr' ),
        35 => /*translators: City.*/ __( 'eSikhaleni', 'describr' ),
        36 => /*translators: City.*/ __( 'eThekwini Metropolitan Municipality', 'describr' ),
        37 => /*translators: City.*/ __( 'iLembe District Municipality', 'describr' ),
        38 => /*translators: City.*/ __( 'uMgungundlovu District Municipality', 'describr' ),
        39 => /*translators: City.*/ __( 'uMkhanyakude District Municipality', 'describr' ),
        40 => /*translators: City.*/ __( 'uMzinyathi District Municipality', 'describr' ),
        41 => /*translators: City.*/ __( 'uThukela District Municipality', 'describr' ),
        42 => /*translators: City.*/ __( 'uThungulu District Municipality', 'describr' ),
      ),
    ),
    'GP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gauteng', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alberton', 'describr' ),
        1 => /*translators: City.*/ __( 'Benoni', 'describr' ),
        2 => /*translators: City.*/ __( 'Boksburg', 'describr' ),
        3 => /*translators: City.*/ __( 'Brakpan', 'describr' ),
        4 => /*translators: City.*/ __( 'Bronkhorstspruit', 'describr' ),
        5 => /*translators: City.*/ __( 'Carletonville', 'describr' ),
        6 => /*translators: City.*/ __( 'Centurion', 'describr' ),
        7 => /*translators: City.*/ __( 'City of Johannesburg Metropolitan Municipality', 'describr' ),
        8 => /*translators: City.*/ __( 'City of Tshwane Metropolitan Municipality', 'describr' ),
        9 => /*translators: City.*/ __( 'Cullinan', 'describr' ),
        10 => /*translators: City.*/ __( 'Diepsloot', 'describr' ),
        11 => /*translators: City.*/ __( 'Eastleigh', 'describr' ),
        12 => /*translators: City.*/ __( 'Eden Glen', 'describr' ),
        13 => /*translators: City.*/ __( 'Eden Glen Ext 60', 'describr' ),
        14 => /*translators: City.*/ __( 'Edenvale', 'describr' ),
        15 => /*translators: City.*/ __( 'Ekangala', 'describr' ),
        16 => /*translators: City.*/ __( 'Ekurhuleni Metropolitan Municipality', 'describr' ),
        17 => /*translators: City.*/ __( 'Heidelberg', 'describr' ),
        18 => /*translators: City.*/ __( 'Johannesburg', 'describr' ),
        19 => /*translators: City.*/ __( 'Krugersdorp', 'describr' ),
        20 => /*translators: City.*/ __( 'Mabopane', 'describr' ),
        21 => /*translators: City.*/ __( 'Midrand', 'describr' ),
        22 => /*translators: City.*/ __( 'Midstream', 'describr' ),
        23 => /*translators: City.*/ __( 'Modderfontein', 'describr' ),
        24 => /*translators: City.*/ __( 'Muldersdriseloop', 'describr' ),
        25 => /*translators: City.*/ __( 'Nigel', 'describr' ),
        26 => /*translators: City.*/ __( 'Orange Farm', 'describr' ),
        27 => /*translators: City.*/ __( 'Pretoria', 'describr' ),
        28 => /*translators: City.*/ __( 'Randburg', 'describr' ),
        29 => /*translators: City.*/ __( 'Randfontein', 'describr' ),
        30 => /*translators: City.*/ __( 'Roodepoort', 'describr' ),
        31 => /*translators: City.*/ __( 'Sedibeng District Municipality', 'describr' ),
        32 => /*translators: City.*/ __( 'Soweto', 'describr' ),
        33 => /*translators: City.*/ __( 'Springs', 'describr' ),
        34 => /*translators: City.*/ __( 'Tembisa', 'describr' ),
        35 => /*translators: City.*/ __( 'Vanderbijlpark', 'describr' ),
        36 => /*translators: City.*/ __( 'Vereeniging', 'describr' ),
        37 => /*translators: City.*/ __( 'West Rand District Municipality', 'describr' ),
        38 => /*translators: City.*/ __( 'Westonaria', 'describr' ),
      ),
    ),
    'MP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mpumalanga', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balfour', 'describr' ),
        1 => /*translators: City.*/ __( 'Barberton', 'describr' ),
        2 => /*translators: City.*/ __( 'Belfast', 'describr' ),
        3 => /*translators: City.*/ __( 'Bethal', 'describr' ),
        4 => /*translators: City.*/ __( 'Breyten', 'describr' ),
        5 => /*translators: City.*/ __( 'Carolina', 'describr' ),
        6 => /*translators: City.*/ __( 'Delmas', 'describr' ),
        7 => /*translators: City.*/ __( 'Driefontein', 'describr' ),
        8 => /*translators: City.*/ __( 'Ehlanzeni District', 'describr' ),
        9 => /*translators: City.*/ __( 'Ermelo', 'describr' ),
        10 => /*translators: City.*/ __( 'Gert Sibande District Municipality', 'describr' ),
        11 => /*translators: City.*/ __( 'Hendrina', 'describr' ),
        12 => /*translators: City.*/ __( 'Komatipoort', 'describr' ),
        13 => /*translators: City.*/ __( 'Kriel', 'describr' ),
        14 => /*translators: City.*/ __( 'Lydenburg', 'describr' ),
        15 => /*translators: City.*/ __( 'Middelburg', 'describr' ),
        16 => /*translators: City.*/ __( 'Nelspruit', 'describr' ),
        17 => /*translators: City.*/ __( 'Nkangala District Municipality', 'describr' ),
        18 => /*translators: City.*/ __( 'Piet Retief', 'describr' ),
        19 => /*translators: City.*/ __( 'Secunda', 'describr' ),
        20 => /*translators: City.*/ __( 'Siyabuswa', 'describr' ),
        21 => /*translators: City.*/ __( 'Standerton', 'describr' ),
        22 => /*translators: City.*/ __( 'Volksrust', 'describr' ),
        23 => /*translators: City.*/ __( 'White River', 'describr' ),
        24 => /*translators: City.*/ __( 'Witbank', 'describr' ),
        25 => /*translators: City.*/ __( 'eMbalenhle', 'describr' ),
      ),
    ),
    'EC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Cape', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adelaide', 'describr' ),
        1 => /*translators: City.*/ __( 'Alfred Nzo District Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Alice', 'describr' ),
        3 => /*translators: City.*/ __( 'Aliwal North', 'describr' ),
        4 => /*translators: City.*/ __( 'Amathole District Municipality', 'describr' ),
        5 => /*translators: City.*/ __( 'Bhisho', 'describr' ),
        6 => /*translators: City.*/ __( 'Buffalo City Metropolitan Municipality', 'describr' ),
        7 => /*translators: City.*/ __( 'Burgersdorp', 'describr' ),
        8 => /*translators: City.*/ __( 'Butterworth', 'describr' ),
        9 => /*translators: City.*/ __( 'Cacadu District Municipality', 'describr' ),
        10 => /*translators: City.*/ __( 'Chris Hani District Municipality', 'describr' ),
        11 => /*translators: City.*/ __( 'Cradock', 'describr' ),
        12 => /*translators: City.*/ __( 'Dordrecht', 'describr' ),
        13 => /*translators: City.*/ __( 'East London', 'describr' ),
        14 => /*translators: City.*/ __( 'Elliot', 'describr' ),
        15 => /*translators: City.*/ __( 'Fort Beaufort', 'describr' ),
        16 => /*translators: City.*/ __( 'Graaff-Reinet', 'describr' ),
        17 => /*translators: City.*/ __( 'Grahamstown', 'describr' ),
        18 => /*translators: City.*/ __( 'Ilinge', 'describr' ),
        19 => /*translators: City.*/ __( 'Joe Gqabi District Municipality', 'describr' ),
        20 => /*translators: City.*/ __( 'Kirkwood', 'describr' ),
        21 => /*translators: City.*/ __( 'Kruisfontein', 'describr' ),
        22 => /*translators: City.*/ __( 'Lady Frere', 'describr' ),
        23 => /*translators: City.*/ __( 'Middelburg', 'describr' ),
        24 => /*translators: City.*/ __( 'Molteno', 'describr' ),
        25 => /*translators: City.*/ __( 'Mthatha', 'describr' ),
        26 => /*translators: City.*/ __( 'Nelson Mandela Bay Metropolitan Municipality', 'describr' ),
        27 => /*translators: City.*/ __( 'OR Tambo District Municipality', 'describr' ),
        28 => /*translators: City.*/ __( 'Port Alfred', 'describr' ),
        29 => /*translators: City.*/ __( 'Port Elizabeth', 'describr' ),
        30 => /*translators: City.*/ __( 'Port Saint John&#039;s', 'describr' ),
        31 => /*translators: City.*/ __( 'Queensdale', 'describr' ),
        32 => /*translators: City.*/ __( 'Queenstown', 'describr' ),
        33 => /*translators: City.*/ __( 'Somerset East', 'describr' ),
        34 => /*translators: City.*/ __( 'Stutterheim', 'describr' ),
        35 => /*translators: City.*/ __( 'Uitenhage', 'describr' ),
        36 => /*translators: City.*/ __( 'Whittlesea', 'describr' ),
        37 => /*translators: City.*/ __( 'Willowmore', 'describr' ),
      ),
    ),
    'WC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Cape', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Albertina', 'describr' ),
        1 => /*translators: City.*/ __( 'Arniston', 'describr' ),
        2 => /*translators: City.*/ __( 'Atlantis', 'describr' ),
        3 => /*translators: City.*/ __( 'Beaufort West', 'describr' ),
        4 => /*translators: City.*/ __( 'Bergvliet', 'describr' ),
        5 => /*translators: City.*/ __( 'Bredasdorp', 'describr' ),
        6 => /*translators: City.*/ __( 'Caledon', 'describr' ),
        7 => /*translators: City.*/ __( 'Calitzdorp', 'describr' ),
        8 => /*translators: City.*/ __( 'Cape Town', 'describr' ),
        9 => /*translators: City.*/ __( 'Cape Winelands District Municipality', 'describr' ),
        10 => /*translators: City.*/ __( 'Central Karoo District Municipality', 'describr' ),
        11 => /*translators: City.*/ __( 'Ceres', 'describr' ),
        12 => /*translators: City.*/ __( 'City of Cape Town', 'describr' ),
        13 => /*translators: City.*/ __( 'Clanwilliam', 'describr' ),
        14 => /*translators: City.*/ __( 'Claremont', 'describr' ),
        15 => /*translators: City.*/ __( 'Constantia', 'describr' ),
        16 => /*translators: City.*/ __( 'De Rust', 'describr' ),
        17 => /*translators: City.*/ __( 'Eden District Municipality', 'describr' ),
        18 => /*translators: City.*/ __( 'George', 'describr' ),
        19 => /*translators: City.*/ __( 'Grabouw', 'describr' ),
        20 => /*translators: City.*/ __( 'Hardys Memories of Africa', 'describr' ),
        21 => /*translators: City.*/ __( 'Hermanus', 'describr' ),
        22 => /*translators: City.*/ __( 'Knysna', 'describr' ),
        23 => /*translators: City.*/ __( 'Kraaifontein', 'describr' ),
        24 => /*translators: City.*/ __( 'Ladismith', 'describr' ),
        25 => /*translators: City.*/ __( 'Lansdowne', 'describr' ),
        26 => /*translators: City.*/ __( 'Malmesbury', 'describr' ),
        27 => /*translators: City.*/ __( 'Montagu', 'describr' ),
        28 => /*translators: City.*/ __( 'Moorreesburg', 'describr' ),
        29 => /*translators: City.*/ __( 'Mossel Bay', 'describr' ),
        30 => /*translators: City.*/ __( 'Newlands', 'describr' ),
        31 => /*translators: City.*/ __( 'Oudtshoorn', 'describr' ),
        32 => /*translators: City.*/ __( 'Overberg District Municipality', 'describr' ),
        33 => /*translators: City.*/ __( 'Paarl', 'describr' ),
        34 => /*translators: City.*/ __( 'Piketberg', 'describr' ),
        35 => /*translators: City.*/ __( 'Plettenberg Bay', 'describr' ),
        36 => /*translators: City.*/ __( 'Prince Albert', 'describr' ),
        37 => /*translators: City.*/ __( 'Retreat', 'describr' ),
        38 => /*translators: City.*/ __( 'Riversdale', 'describr' ),
        39 => /*translators: City.*/ __( 'Robertson', 'describr' ),
        40 => /*translators: City.*/ __( 'Rondebosch', 'describr' ),
        41 => /*translators: City.*/ __( 'Rosebank', 'describr' ),
        42 => /*translators: City.*/ __( 'Saldanha', 'describr' ),
        43 => /*translators: City.*/ __( 'Stellenbosch', 'describr' ),
        44 => /*translators: City.*/ __( 'Sunset Beach', 'describr' ),
        45 => /*translators: City.*/ __( 'Swellendam', 'describr' ),
        46 => /*translators: City.*/ __( 'Vredenburg', 'describr' ),
        47 => /*translators: City.*/ __( 'Vredendal', 'describr' ),
        48 => /*translators: City.*/ __( 'Wellington', 'describr' ),
        49 => /*translators: City.*/ __( 'West Coast District Municipality', 'describr' ),
        50 => /*translators: City.*/ __( 'Worcester', 'describr' ),
        51 => /*translators: City.*/ __( 'Zoar', 'describr' ),
      ),
    ),
  ),
  'NI' => 
  array (
    'CO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chontales Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acoyapa', 'describr' ),
        1 => /*translators: City.*/ __( 'Comalapa', 'describr' ),
        2 => /*translators: City.*/ __( 'Cuapa', 'describr' ),
        3 => /*translators: City.*/ __( 'El Ayote', 'describr' ),
        4 => /*translators: City.*/ __( 'Juigalpa', 'describr' ),
        5 => /*translators: City.*/ __( 'La Libertad', 'describr' ),
        6 => /*translators: City.*/ __( 'Santo Domingo', 'describr' ),
        7 => /*translators: City.*/ __( 'Santo Tomás', 'describr' ),
        8 => /*translators: City.*/ __( 'Villa Sandino', 'describr' ),
      ),
    ),
    'MN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Managua Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ciudad Sandino', 'describr' ),
        1 => /*translators: City.*/ __( 'El Crucero', 'describr' ),
        2 => /*translators: City.*/ __( 'Managua', 'describr' ),
        3 => /*translators: City.*/ __( 'Masachapa', 'describr' ),
        4 => /*translators: City.*/ __( 'San Rafael del Sur', 'describr' ),
        5 => /*translators: City.*/ __( 'Ticuantepe', 'describr' ),
        6 => /*translators: City.*/ __( 'Tipitapa', 'describr' ),
        7 => /*translators: City.*/ __( 'Valle San Francisco', 'describr' ),
        8 => /*translators: City.*/ __( 'Villa El Carmen', 'describr' ),
      ),
    ),
    'RI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rivas Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Altagracia', 'describr' ),
        1 => /*translators: City.*/ __( 'Belén', 'describr' ),
        2 => /*translators: City.*/ __( 'Buenos Aires', 'describr' ),
        3 => /*translators: City.*/ __( 'Cárdenas', 'describr' ),
        4 => /*translators: City.*/ __( 'Moyogalpa', 'describr' ),
        5 => /*translators: City.*/ __( 'Municipio de Altagracia', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Belén', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de Buenos Aires', 'describr' ),
        8 => /*translators: City.*/ __( 'Municipio de Cárdenas', 'describr' ),
        9 => /*translators: City.*/ __( 'Municipio de Moyogalpa', 'describr' ),
        10 => /*translators: City.*/ __( 'Municipio de Potosí', 'describr' ),
        11 => /*translators: City.*/ __( 'Municipio de Rivas', 'describr' ),
        12 => /*translators: City.*/ __( 'Municipio de San Jorge', 'describr' ),
        13 => /*translators: City.*/ __( 'Municipio de San Juan del Sur', 'describr' ),
        14 => /*translators: City.*/ __( 'Municipio de Tola', 'describr' ),
        15 => /*translators: City.*/ __( 'Potosí', 'describr' ),
        16 => /*translators: City.*/ __( 'Rivas', 'describr' ),
        17 => /*translators: City.*/ __( 'San Jorge', 'describr' ),
        18 => /*translators: City.*/ __( 'San Juan del Sur', 'describr' ),
        19 => /*translators: City.*/ __( 'Tola', 'describr' ),
      ),
    ),
    'GR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Granada Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Diriomo', 'describr' ),
        1 => /*translators: City.*/ __( 'Diriá', 'describr' ),
        2 => /*translators: City.*/ __( 'Granada', 'describr' ),
        3 => /*translators: City.*/ __( 'Nandaime', 'describr' ),
      ),
    ),
    'LE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'León Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Achuapa', 'describr' ),
        1 => /*translators: City.*/ __( 'El Jicaral', 'describr' ),
        2 => /*translators: City.*/ __( 'El Sauce', 'describr' ),
        3 => /*translators: City.*/ __( 'La Paz Centro', 'describr' ),
        4 => /*translators: City.*/ __( 'Larreynaga', 'describr' ),
        5 => /*translators: City.*/ __( 'León', 'describr' ),
        6 => /*translators: City.*/ __( 'Nagarote', 'describr' ),
        7 => /*translators: City.*/ __( 'Quezalguaque', 'describr' ),
        8 => /*translators: City.*/ __( 'Santa Rosa del Peñón', 'describr' ),
        9 => /*translators: City.*/ __( 'Telica', 'describr' ),
      ),
    ),
    'ES' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Estelí Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Condega', 'describr' ),
        1 => /*translators: City.*/ __( 'Estelí', 'describr' ),
        2 => /*translators: City.*/ __( 'La Trinidad', 'describr' ),
        3 => /*translators: City.*/ __( 'Pueblo Nuevo', 'describr' ),
        4 => /*translators: City.*/ __( 'San Juan de Limay', 'describr' ),
      ),
    ),
    'BO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Boaco Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Boaco', 'describr' ),
        1 => /*translators: City.*/ __( 'Camoapa', 'describr' ),
        2 => /*translators: City.*/ __( 'San José de los Remates', 'describr' ),
        3 => /*translators: City.*/ __( 'San Lorenzo', 'describr' ),
        4 => /*translators: City.*/ __( 'Santa Lucía', 'describr' ),
        5 => /*translators: City.*/ __( 'Teustepe', 'describr' ),
      ),
    ),
    'MT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Matagalpa Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ciudad Darío', 'describr' ),
        1 => /*translators: City.*/ __( 'Matagalpa', 'describr' ),
        2 => /*translators: City.*/ __( 'Matiguás', 'describr' ),
        3 => /*translators: City.*/ __( 'Muy Muy', 'describr' ),
        4 => /*translators: City.*/ __( 'Río Blanco', 'describr' ),
        5 => /*translators: City.*/ __( 'San Dionisio', 'describr' ),
        6 => /*translators: City.*/ __( 'San Ramón', 'describr' ),
        7 => /*translators: City.*/ __( 'Terrabona', 'describr' ),
      ),
    ),
    'MD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Madriz Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Las Sabanas', 'describr' ),
        1 => /*translators: City.*/ __( 'Palacagüina', 'describr' ),
        2 => /*translators: City.*/ __( 'San José de Cusmapa', 'describr' ),
        3 => /*translators: City.*/ __( 'San Juan de Río Coco', 'describr' ),
        4 => /*translators: City.*/ __( 'San Lucas', 'describr' ),
        5 => /*translators: City.*/ __( 'Somoto', 'describr' ),
        6 => /*translators: City.*/ __( 'Telpaneca', 'describr' ),
        7 => /*translators: City.*/ __( 'Totogalpa', 'describr' ),
        8 => /*translators: City.*/ __( 'Yalagüina', 'describr' ),
      ),
    ),
    'SJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Río San Juan Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Almendro', 'describr' ),
        1 => /*translators: City.*/ __( 'Greytown', 'describr' ),
        2 => /*translators: City.*/ __( 'Morrito', 'describr' ),
        3 => /*translators: City.*/ __( 'San Carlos', 'describr' ),
        4 => /*translators: City.*/ __( 'San Miguelito', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Carazo Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Diriamba', 'describr' ),
        1 => /*translators: City.*/ __( 'Dolores', 'describr' ),
        2 => /*translators: City.*/ __( 'El Rosario', 'describr' ),
        3 => /*translators: City.*/ __( 'Jinotepe', 'describr' ),
        4 => /*translators: City.*/ __( 'La Conquista', 'describr' ),
        5 => /*translators: City.*/ __( 'La Paz de Carazo', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de San Marcos', 'describr' ),
        7 => /*translators: City.*/ __( 'San Marcos', 'describr' ),
        8 => /*translators: City.*/ __( 'Santa Teresa', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North Caribbean Coast Autonomous Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bonanza', 'describr' ),
        1 => /*translators: City.*/ __( 'Prinzapolka', 'describr' ),
        2 => /*translators: City.*/ __( 'Puerto Cabezas', 'describr' ),
        3 => /*translators: City.*/ __( 'Siuna', 'describr' ),
        4 => /*translators: City.*/ __( 'Waslala', 'describr' ),
        5 => /*translators: City.*/ __( 'Waspán', 'describr' ),
      ),
    ),
    'AS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'South Caribbean Coast Autonomous Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bluefields', 'describr' ),
        1 => /*translators: City.*/ __( 'Bocana de Paiwas', 'describr' ),
        2 => /*translators: City.*/ __( 'Corn Island', 'describr' ),
        3 => /*translators: City.*/ __( 'El Rama', 'describr' ),
        4 => /*translators: City.*/ __( 'El Tortuguero', 'describr' ),
        5 => /*translators: City.*/ __( 'Kukrahill', 'describr' ),
        6 => /*translators: City.*/ __( 'La Cruz de Río Grande', 'describr' ),
        7 => /*translators: City.*/ __( 'Laguna de Perlas', 'describr' ),
        8 => /*translators: City.*/ __( 'Muelle de los Bueyes', 'describr' ),
        9 => /*translators: City.*/ __( 'Nueva Guinea', 'describr' ),
      ),
    ),
    'MS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Masaya Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Catarina', 'describr' ),
        1 => /*translators: City.*/ __( 'La Concepción', 'describr' ),
        2 => /*translators: City.*/ __( 'Masatepe', 'describr' ),
        3 => /*translators: City.*/ __( 'Masaya', 'describr' ),
        4 => /*translators: City.*/ __( 'Municipio de Masatepe', 'describr' ),
        5 => /*translators: City.*/ __( 'Municipio de Nandasmo', 'describr' ),
        6 => /*translators: City.*/ __( 'Municipio de Niquinohomo', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de San Juan de Oriente', 'describr' ),
        8 => /*translators: City.*/ __( 'Nandasmo', 'describr' ),
        9 => /*translators: City.*/ __( 'Nindirí', 'describr' ),
        10 => /*translators: City.*/ __( 'Niquinohomo', 'describr' ),
        11 => /*translators: City.*/ __( 'San Juan de Oriente', 'describr' ),
        12 => /*translators: City.*/ __( 'Tisma', 'describr' ),
      ),
    ),
    'CI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chinandega Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chichigalpa', 'describr' ),
        1 => /*translators: City.*/ __( 'Chinandega', 'describr' ),
        2 => /*translators: City.*/ __( 'Cinco Pinos', 'describr' ),
        3 => /*translators: City.*/ __( 'Corinto', 'describr' ),
        4 => /*translators: City.*/ __( 'El Realejo', 'describr' ),
        5 => /*translators: City.*/ __( 'El Viejo', 'describr' ),
        6 => /*translators: City.*/ __( 'Jiquilillo', 'describr' ),
        7 => /*translators: City.*/ __( 'Municipio de San Francisco del Norte', 'describr' ),
        8 => /*translators: City.*/ __( 'Posoltega', 'describr' ),
        9 => /*translators: City.*/ __( 'Puerto Morazán', 'describr' ),
        10 => /*translators: City.*/ __( 'Santo Tomás del Norte', 'describr' ),
        11 => /*translators: City.*/ __( 'Somotillo', 'describr' ),
      ),
    ),
    'JI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jinotega Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Cuá', 'describr' ),
        1 => /*translators: City.*/ __( 'Jinotega', 'describr' ),
        2 => /*translators: City.*/ __( 'LLano de La Cruz', 'describr' ),
        3 => /*translators: City.*/ __( 'La Concordia', 'describr' ),
        4 => /*translators: City.*/ __( 'Las Praderas', 'describr' ),
        5 => /*translators: City.*/ __( 'San José de Bocay', 'describr' ),
        6 => /*translators: City.*/ __( 'San Rafael del Norte', 'describr' ),
        7 => /*translators: City.*/ __( 'San Sebastián de Yalí', 'describr' ),
      ),
    ),
  ),
  'JO' => 
  array (
    'KA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Karak Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adir', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Khinzīrah', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Mazār al Janūbī', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Qaşr', 'describr' ),
        4 => /*translators: City.*/ __( 'Ar Rabbah', 'describr' ),
        5 => /*translators: City.*/ __( 'Karak City', 'describr' ),
        6 => /*translators: City.*/ __( 'Safi', 'describr' ),
        7 => /*translators: City.*/ __( '&#039;Ayy', 'describr' ),
        8 => /*translators: City.*/ __( '&#039;Izrā', 'describr' ),
      ),
    ),
    'AT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tafilah Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aţ Ţafīlah', 'describr' ),
        1 => /*translators: City.*/ __( 'Buşayrā', 'describr' ),
      ),
    ),
    'MD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Madaba Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mādabā', 'describr' ),
      ),
    ),
    'AQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aqaba Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aqaba', 'describr' ),
        1 => /*translators: City.*/ __( 'Tala Bay', 'describr' ),
      ),
    ),
    'IR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Irbid Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ar Ramthā', 'describr' ),
        1 => /*translators: City.*/ __( 'Ash Shajarah', 'describr' ),
        2 => /*translators: City.*/ __( 'Aydūn', 'describr' ),
        3 => /*translators: City.*/ __( 'Aţ Ţayyibah', 'describr' ),
        4 => /*translators: City.*/ __( 'Aţ Ţurrah', 'describr' ),
        5 => /*translators: City.*/ __( 'Bayt Yāfā', 'describr' ),
        6 => /*translators: City.*/ __( 'Bayt Īdis', 'describr' ),
        7 => /*translators: City.*/ __( 'Dayr Yūsuf', 'describr' ),
        8 => /*translators: City.*/ __( 'Irbid', 'describr' ),
        9 => /*translators: City.*/ __( 'Judita', 'describr' ),
        10 => /*translators: City.*/ __( 'Kafr Abīl', 'describr' ),
        11 => /*translators: City.*/ __( 'Kafr Asad', 'describr' ),
        12 => /*translators: City.*/ __( 'Kafr Sawm', 'describr' ),
        13 => /*translators: City.*/ __( 'Kharjā', 'describr' ),
        14 => /*translators: City.*/ __( 'Kitim', 'describr' ),
        15 => /*translators: City.*/ __( 'Kurayyimah', 'describr' ),
        16 => /*translators: City.*/ __( 'Malkā', 'describr' ),
        17 => /*translators: City.*/ __( 'Qumaym', 'describr' ),
        18 => /*translators: City.*/ __( 'Saḩam al Kaffārāt', 'describr' ),
        19 => /*translators: City.*/ __( 'Sāl', 'describr' ),
        20 => /*translators: City.*/ __( 'Tibnah', 'describr' ),
        21 => /*translators: City.*/ __( 'Umm Qays', 'describr' ),
        22 => /*translators: City.*/ __( 'Waqqāş', 'describr' ),
        23 => /*translators: City.*/ __( 'Zaḩar', 'describr' ),
        24 => /*translators: City.*/ __( 'Şammā', 'describr' ),
        25 => /*translators: City.*/ __( 'Ḩakamā', 'describr' ),
        26 => /*translators: City.*/ __( 'Ḩātim', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balqa Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Karāmah', 'describr' ),
        1 => /*translators: City.*/ __( 'As Salţ', 'describr' ),
        2 => /*translators: City.*/ __( 'Yarqā', 'describr' ),
      ),
    ),
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mafraq Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Ḩamrā&#039;', 'describr' ),
        1 => /*translators: City.*/ __( 'Mafraq', 'describr' ),
        2 => /*translators: City.*/ __( 'Rehab', 'describr' ),
        3 => /*translators: City.*/ __( 'Rukban', 'describr' ),
        4 => /*translators: City.*/ __( 'Umm al Qiţţayn', 'describr' ),
        5 => /*translators: City.*/ __( 'Şabḩā', 'describr' ),
      ),
    ),
    'AJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ajloun Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Şakhrah', 'describr' ),
        1 => /*translators: City.*/ __( 'Ḩalāwah', 'describr' ),
        2 => /*translators: City.*/ __( '&#039;Ajlūn', 'describr' ),
        3 => /*translators: City.*/ __( '&#039;Anjarah', 'describr' ),
        4 => /*translators: City.*/ __( '&#039;Ayn Jannah', 'describr' ),
      ),
    ),
    'MN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ma&#039;an Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Jafr', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Quwayrah', 'describr' ),
        2 => /*translators: City.*/ __( 'Ash Shawbak', 'describr' ),
        3 => /*translators: City.*/ __( 'Aţ Ţayyibah', 'describr' ),
        4 => /*translators: City.*/ __( 'Ma&#039;an', 'describr' ),
        5 => /*translators: City.*/ __( 'Petra', 'describr' ),
        6 => /*translators: City.*/ __( 'Qīr Moāv', 'describr' ),
      ),
    ),
    'AM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Amman Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Jubayhah', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Jīzah', 'describr' ),
        2 => /*translators: City.*/ __( 'Amman', 'describr' ),
        3 => /*translators: City.*/ __( 'Jāwā', 'describr' ),
        4 => /*translators: City.*/ __( 'Saḩāb', 'describr' ),
        5 => /*translators: City.*/ __( 'Umm as Summāq', 'describr' ),
        6 => /*translators: City.*/ __( 'Wādī as Sīr', 'describr' ),
        7 => /*translators: City.*/ __( 'Ḩayy al Bunayyāt', 'describr' ),
        8 => /*translators: City.*/ __( 'Ḩayy al Quwaysimah', 'describr' ),
      ),
    ),
    'JA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jerash Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Kittah', 'describr' ),
        1 => /*translators: City.*/ __( 'Balīlā', 'describr' ),
        2 => /*translators: City.*/ __( 'Burmā', 'describr' ),
        3 => /*translators: City.*/ __( 'Jarash', 'describr' ),
        4 => /*translators: City.*/ __( 'Qafqafā', 'describr' ),
        5 => /*translators: City.*/ __( 'Raymūn', 'describr' ),
        6 => /*translators: City.*/ __( 'Sakib', 'describr' ),
        7 => /*translators: City.*/ __( 'Sūf', 'describr' ),
      ),
    ),
    'AZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zarqa Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Azraq ash Shamālī', 'describr' ),
        1 => /*translators: City.*/ __( 'Russeifa', 'describr' ),
        2 => /*translators: City.*/ __( 'Zarqa', 'describr' ),
      ),
    ),
  ),
  'SZ' => 
  array (
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manzini District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bhunya', 'describr' ),
        1 => /*translators: City.*/ __( 'Ekukhanyeni', 'describr' ),
        2 => /*translators: City.*/ __( 'Kwaluseni', 'describr' ),
        3 => /*translators: City.*/ __( 'Malkerns', 'describr' ),
        4 => /*translators: City.*/ __( 'Manzini', 'describr' ),
        5 => /*translators: City.*/ __( 'Manzini South', 'describr' ),
        6 => /*translators: City.*/ __( 'Mhlambanyatsi', 'describr' ),
        7 => /*translators: City.*/ __( 'Ngwempisi', 'describr' ),
        8 => /*translators: City.*/ __( 'Ntondozi', 'describr' ),
        9 => /*translators: City.*/ __( 'Sidvokodvo', 'describr' ),
      ),
    ),
    'HH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hhohho District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bulembu', 'describr' ),
        1 => /*translators: City.*/ __( 'Hhukwini', 'describr' ),
        2 => /*translators: City.*/ __( 'Lobamba', 'describr' ),
        3 => /*translators: City.*/ __( 'Mbabane', 'describr' ),
        4 => /*translators: City.*/ __( 'Nkhaba', 'describr' ),
        5 => /*translators: City.*/ __( 'Piggs Peak', 'describr' ),
      ),
    ),
    'LU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lubombo District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Big Bend', 'describr' ),
        1 => /*translators: City.*/ __( 'Dvokodvweni Inkhundla', 'describr' ),
        2 => /*translators: City.*/ __( 'Lomashasha', 'describr' ),
        3 => /*translators: City.*/ __( 'Mhlume', 'describr' ),
        4 => /*translators: City.*/ __( 'Nsoko', 'describr' ),
        5 => /*translators: City.*/ __( 'Siteki', 'describr' ),
        6 => /*translators: City.*/ __( 'Tshaneni', 'describr' ),
        7 => /*translators: City.*/ __( 'Vuvulane', 'describr' ),
      ),
    ),
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Shiselweni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hlatikulu', 'describr' ),
        1 => /*translators: City.*/ __( 'Hluti', 'describr' ),
        2 => /*translators: City.*/ __( 'Kubuta', 'describr' ),
        3 => /*translators: City.*/ __( 'Lavumisa', 'describr' ),
        4 => /*translators: City.*/ __( 'Matsanjeni', 'describr' ),
        5 => /*translators: City.*/ __( 'Ngudzeni', 'describr' ),
        6 => /*translators: City.*/ __( 'Nhlangano', 'describr' ),
        7 => /*translators: City.*/ __( 'Nkwene', 'describr' ),
        8 => /*translators: City.*/ __( 'Sigwe Inkhundla', 'describr' ),
        9 => /*translators: City.*/ __( 'Zombodze Ikhundla', 'describr' ),
      ),
    ),
  ),
  'KW' => 
  array (
    'JA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Jahra Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Jahrā&#039;', 'describr' ),
      ),
    ),
    'HA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hawalli Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ar Rumaythīyah', 'describr' ),
        1 => /*translators: City.*/ __( 'As Sālimīyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Bayān', 'describr' ),
        3 => /*translators: City.*/ __( 'Salwá', 'describr' ),
        4 => /*translators: City.*/ __( 'Ḩawallī', 'describr' ),
      ),
    ),
    'MU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mubarak Al-Kabeer Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abu Al Hasaniya', 'describr' ),
        1 => /*translators: City.*/ __( 'Abu Fatira', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Funayţīs', 'describr' ),
        3 => /*translators: City.*/ __( 'Al-Masayel', 'describr' ),
        4 => /*translators: City.*/ __( 'Şabāḩ as Sālim', 'describr' ),
      ),
    ),
    'FA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Farwaniyah Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Farwānīyah', 'describr' ),
        1 => /*translators: City.*/ __( 'Janūb as Surrah', 'describr' ),
      ),
    ),
    'KU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Capital Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ad Dasmah', 'describr' ),
        1 => /*translators: City.*/ __( 'Ar Rābiyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Ash Shāmīyah', 'describr' ),
        3 => /*translators: City.*/ __( 'Az Zawr', 'describr' ),
        4 => /*translators: City.*/ __( 'Kuwait City', 'describr' ),
      ),
    ),
    'AH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Ahmadi Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Aḩmadī', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Faḩāḩīl', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Finţās', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Mahbūlah', 'describr' ),
        4 => /*translators: City.*/ __( 'Al Manqaf', 'describr' ),
        5 => /*translators: City.*/ __( 'Al Wafrah', 'describr' ),
        6 => /*translators: City.*/ __( 'Ar Riqqah', 'describr' ),
      ),
    ),
  ),
  'LA' => 
  array (
    'LP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luang Prabang Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luang Prabang', 'describr' ),
      ),
    ),
    'VT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vientiane Prefecture', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Vientiane', 'describr' ),
      ),
    ),
    'VI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vientiane Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muang Phôn-Hông', 'describr' ),
        1 => /*translators: City.*/ __( 'Vangviang', 'describr' ),
      ),
    ),
    'SL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Salavan Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muang Khôngxédôn', 'describr' ),
        1 => /*translators: City.*/ __( 'Muang Lakhonphéng', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Laongam', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Samouay', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Saravan', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Ta-Ôy', 'describr' ),
        6 => /*translators: City.*/ __( 'Muang Toumlan', 'describr' ),
        7 => /*translators: City.*/ __( 'Muang Vapi', 'describr' ),
        8 => /*translators: City.*/ __( 'Salavan', 'describr' ),
      ),
    ),
    'AT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Attapeu Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Attapeu', 'describr' ),
        1 => /*translators: City.*/ __( 'Muang Phouvong', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Samakhixai', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Sanamxai', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Sanxai', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Xaiséttha', 'describr' ),
      ),
    ),
    'XS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Xaisomboun Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anouvong district', 'describr' ),
        1 => /*translators: City.*/ __( 'Longchaeng', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Longxan', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Thathôm', 'describr' ),
      ),
    ),
    'XE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sekong Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ban Thatèng', 'describr' ),
        1 => /*translators: City.*/ __( 'Lamam', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Dakchung', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Khaleum', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Laman', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Thatèng', 'describr' ),
      ),
    ),
    'BL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bolikhamsai Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ban Nahin', 'describr' ),
        1 => /*translators: City.*/ __( 'Pakxan', 'describr' ),
      ),
    ),
    'KH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khammouane Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muang Thakhèk', 'describr' ),
        1 => /*translators: City.*/ __( 'Thakhèk', 'describr' ),
      ),
    ),
    'PH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Phongsaly Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Phôngsali', 'describr' ),
      ),
    ),
    'OU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oudomxay Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muang Xay', 'describr' ),
      ),
    ),
    'HO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Houaphanh Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Xam Neua', 'describr' ),
        1 => /*translators: City.*/ __( 'Xam Nua', 'describr' ),
      ),
    ),
    'SV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Savannakhet Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kaysone Phomvihane', 'describr' ),
        1 => /*translators: City.*/ __( 'Muang Alsaphangthong', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Atsaphan', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Champhon', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Nong', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Outhoumphon', 'describr' ),
        6 => /*translators: City.*/ __( 'Muang Phin', 'describr' ),
        7 => /*translators: City.*/ __( 'Muang Songkhon', 'describr' ),
        8 => /*translators: City.*/ __( 'Muang Thapangthong', 'describr' ),
        9 => /*translators: City.*/ __( 'Muang Vilabouli', 'describr' ),
        10 => /*translators: City.*/ __( 'Muang Xaibouli', 'describr' ),
        11 => /*translators: City.*/ __( 'Muang Xayphoothong', 'describr' ),
        12 => /*translators: City.*/ __( 'Muang Xônbouli', 'describr' ),
        13 => /*translators: City.*/ __( 'Savannakhet', 'describr' ),
        14 => /*translators: City.*/ __( 'Thaphalanxay', 'describr' ),
      ),
    ),
    'BK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bokeo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ban Houakhoua', 'describr' ),
        1 => /*translators: City.*/ __( 'Ban Houayxay', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Houayxay', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Meung', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Paktha', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Pha Oudôm', 'describr' ),
        6 => /*translators: City.*/ __( 'Muang Tônpheung', 'describr' ),
      ),
    ),
    'LM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luang Namtha Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luang Namtha', 'describr' ),
        1 => /*translators: City.*/ __( 'Muang Louang Namtha', 'describr' ),
      ),
    ),
    'XA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sainyabuli Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sainyabuli', 'describr' ),
      ),
    ),
    'XI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Xiangkhouang Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muang Phônsavan', 'describr' ),
      ),
    ),
    'CH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Champasak Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Champasak', 'describr' ),
        1 => /*translators: City.*/ __( 'Muang Bachiangchaleunsook', 'describr' ),
        2 => /*translators: City.*/ __( 'Muang Champasak', 'describr' ),
        3 => /*translators: City.*/ __( 'Muang Không', 'describr' ),
        4 => /*translators: City.*/ __( 'Muang Mounlapamôk', 'describr' ),
        5 => /*translators: City.*/ __( 'Muang Pakxong', 'describr' ),
        6 => /*translators: City.*/ __( 'Muang Pakxé', 'describr' ),
        7 => /*translators: City.*/ __( 'Muang Pathoumphon', 'describr' ),
        8 => /*translators: City.*/ __( 'Muang Phônthong', 'describr' ),
        9 => /*translators: City.*/ __( 'Muang Soukhouma', 'describr' ),
        10 => /*translators: City.*/ __( 'Muang Xanasômboun', 'describr' ),
        11 => /*translators: City.*/ __( 'Pakse', 'describr' ),
        12 => /*translators: City.*/ __( 'Pakxong', 'describr' ),
      ),
    ),
  ),
  'KG' => 
  array (
    'T' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Talas Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kara-Buurinskiy Rayon', 'describr' ),
        1 => /*translators: City.*/ __( 'Talas', 'describr' ),
        2 => /*translators: City.*/ __( 'Talasskiy Rayon', 'describr' ),
      ),
    ),
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Batken Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aydarken', 'describr' ),
        1 => /*translators: City.*/ __( 'Batken', 'describr' ),
        2 => /*translators: City.*/ __( 'Iradan', 'describr' ),
        3 => /*translators: City.*/ __( 'Isfana', 'describr' ),
        4 => /*translators: City.*/ __( 'Karavan', 'describr' ),
        5 => /*translators: City.*/ __( 'Kyzyl-Kyya', 'describr' ),
        6 => /*translators: City.*/ __( 'Suluktu', 'describr' ),
      ),
    ),
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Naryn Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'At-Bashi', 'describr' ),
        1 => /*translators: City.*/ __( 'Jumgal', 'describr' ),
        2 => /*translators: City.*/ __( 'Naryn', 'describr' ),
      ),
    ),
    'J' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jalal-Abad Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ala-Buka', 'describr' ),
        1 => /*translators: City.*/ __( 'Bazar-Korgon', 'describr' ),
        2 => /*translators: City.*/ __( 'Jalal-Abad', 'describr' ),
        3 => /*translators: City.*/ __( 'Kazarman', 'describr' ),
        4 => /*translators: City.*/ __( 'Kerben', 'describr' ),
        5 => /*translators: City.*/ __( 'Kochkor-Ata', 'describr' ),
        6 => /*translators: City.*/ __( 'Suzak', 'describr' ),
        7 => /*translators: City.*/ __( 'Tash-Kumyr', 'describr' ),
        8 => /*translators: City.*/ __( 'Toktogul', 'describr' ),
        9 => /*translators: City.*/ __( 'Toktogul District', 'describr' ),
      ),
    ),
    'GB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bishkek', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bishkek', 'describr' ),
      ),
    ),
    'Y' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Issyk-Kul Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ak-Suu', 'describr' ),
        1 => /*translators: City.*/ __( 'Balykchy', 'describr' ),
        2 => /*translators: City.*/ __( 'Cholpon-Ata', 'describr' ),
        3 => /*translators: City.*/ __( 'Kadzhi-Say', 'describr' ),
        4 => /*translators: City.*/ __( 'Karakol', 'describr' ),
        5 => /*translators: City.*/ __( 'Kyzyl-Suu', 'describr' ),
        6 => /*translators: City.*/ __( 'Tyup', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chuy Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alamudunskiy Rayon', 'describr' ),
        1 => /*translators: City.*/ __( 'Belovodskoye', 'describr' ),
        2 => /*translators: City.*/ __( 'Chuyskiy Rayon', 'describr' ),
        3 => /*translators: City.*/ __( 'Ivanovka', 'describr' ),
        4 => /*translators: City.*/ __( 'Kaindy', 'describr' ),
        5 => /*translators: City.*/ __( 'Kant', 'describr' ),
        6 => /*translators: City.*/ __( 'Kara-Balta', 'describr' ),
        7 => /*translators: City.*/ __( 'Kemin', 'describr' ),
        8 => /*translators: City.*/ __( 'Lebedinovka', 'describr' ),
        9 => /*translators: City.*/ __( 'Sokulukskiy Rayon', 'describr' ),
        10 => /*translators: City.*/ __( 'Sosnovka', 'describr' ),
        11 => /*translators: City.*/ __( 'Tokmok', 'describr' ),
        12 => /*translators: City.*/ __( 'Ysyk-Ata', 'describr' ),
      ),
    ),
    'O' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Osh Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chong-Alay District', 'describr' ),
        1 => /*translators: City.*/ __( 'Daroot-Korgon', 'describr' ),
        2 => /*translators: City.*/ __( 'Kara Kulja', 'describr' ),
        3 => /*translators: City.*/ __( 'Kara Suu', 'describr' ),
        4 => /*translators: City.*/ __( 'Kyzyl-Eshme', 'describr' ),
        5 => /*translators: City.*/ __( 'Nookat', 'describr' ),
        6 => /*translators: City.*/ __( 'Osh', 'describr' ),
        7 => /*translators: City.*/ __( 'Uzgen', 'describr' ),
        8 => /*translators: City.*/ __( 'Uzgen District', 'describr' ),
      ),
    ),
  ),
  'NO' => 
  array (
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oslo', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Oslo', 'describr' ),
        1 => /*translators: City.*/ __( 'Sjølyststranda', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vestfold', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barkåker', 'describr' ),
        1 => /*translators: City.*/ __( 'Berger', 'describr' ),
        2 => /*translators: City.*/ __( 'Færder', 'describr' ),
        3 => /*translators: City.*/ __( 'Gullhaug', 'describr' ),
        4 => /*translators: City.*/ __( 'Holmestrand', 'describr' ),
        5 => /*translators: City.*/ __( 'Horten', 'describr' ),
        6 => /*translators: City.*/ __( 'Larvik', 'describr' ),
        7 => /*translators: City.*/ __( 'Melsomvik', 'describr' ),
        8 => /*translators: City.*/ __( 'Re', 'describr' ),
        9 => /*translators: City.*/ __( 'Sande', 'describr' ),
        10 => /*translators: City.*/ __( 'Sandefjord', 'describr' ),
        11 => /*translators: City.*/ __( 'Selvik', 'describr' ),
        12 => /*translators: City.*/ __( 'Sem', 'describr' ),
        13 => /*translators: City.*/ __( 'Skoppum', 'describr' ),
        14 => /*translators: City.*/ __( 'Stavern', 'describr' ),
        15 => /*translators: City.*/ __( 'Stokke', 'describr' ),
        16 => /*translators: City.*/ __( 'Svelvik', 'describr' ),
        17 => /*translators: City.*/ __( 'Tjøme', 'describr' ),
        18 => /*translators: City.*/ __( 'Tønsberg', 'describr' ),
        19 => /*translators: City.*/ __( 'Årøysund', 'describr' ),
        20 => /*translators: City.*/ __( 'Åsgårdstrand', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oppland', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bagn', 'describr' ),
        1 => /*translators: City.*/ __( 'Dokka', 'describr' ),
        2 => /*translators: City.*/ __( 'Dombås', 'describr' ),
        3 => /*translators: City.*/ __( 'Dovre', 'describr' ),
        4 => /*translators: City.*/ __( 'Etnedal', 'describr' ),
        5 => /*translators: City.*/ __( 'Fagernes', 'describr' ),
        6 => /*translators: City.*/ __( 'Fossbergom', 'describr' ),
        7 => /*translators: City.*/ __( 'Gausdal', 'describr' ),
        8 => /*translators: City.*/ __( 'Gjøvik', 'describr' ),
        9 => /*translators: City.*/ __( 'Gran', 'describr' ),
        10 => /*translators: City.*/ __( 'Grua', 'describr' ),
        11 => /*translators: City.*/ __( 'Hov', 'describr' ),
        12 => /*translators: City.*/ __( 'Hundorp', 'describr' ),
        13 => /*translators: City.*/ __( 'Jevnaker', 'describr' ),
        14 => /*translators: City.*/ __( 'Lena', 'describr' ),
        15 => /*translators: City.*/ __( 'Lesja', 'describr' ),
        16 => /*translators: City.*/ __( 'Lillehammer', 'describr' ),
        17 => /*translators: City.*/ __( 'Lom', 'describr' ),
        18 => /*translators: City.*/ __( 'Lunner', 'describr' ),
        19 => /*translators: City.*/ __( 'Nord-Aurdal', 'describr' ),
        20 => /*translators: City.*/ __( 'Nord-Fron', 'describr' ),
        21 => /*translators: City.*/ __( 'Nordre Land', 'describr' ),
        22 => /*translators: City.*/ __( 'Otta', 'describr' ),
        23 => /*translators: City.*/ __( 'Raufoss', 'describr' ),
        24 => /*translators: City.*/ __( 'Reinsvoll', 'describr' ),
        25 => /*translators: City.*/ __( 'Ringebu', 'describr' ),
        26 => /*translators: City.*/ __( 'Sel', 'describr' ),
        27 => /*translators: City.*/ __( 'Skjåk', 'describr' ),
        28 => /*translators: City.*/ __( 'Skreia', 'describr' ),
        29 => /*translators: City.*/ __( 'Søndre Land', 'describr' ),
        30 => /*translators: City.*/ __( 'Sør-Aurdal', 'describr' ),
        31 => /*translators: City.*/ __( 'Sør-Fron', 'describr' ),
        32 => /*translators: City.*/ __( 'Tretten', 'describr' ),
        33 => /*translators: City.*/ __( 'Vang', 'describr' ),
        34 => /*translators: City.*/ __( 'Vestre Slidre', 'describr' ),
        35 => /*translators: City.*/ __( 'Vestre Toten', 'describr' ),
        36 => /*translators: City.*/ __( 'Vinstra', 'describr' ),
        37 => /*translators: City.*/ __( 'Vågå', 'describr' ),
        38 => /*translators: City.*/ __( 'Vågåmo', 'describr' ),
        39 => /*translators: City.*/ __( 'Østre Toten', 'describr' ),
        40 => /*translators: City.*/ __( 'Øyer', 'describr' ),
        41 => /*translators: City.*/ __( 'Øystre Slidre', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Buskerud', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Drammen', 'describr' ),
        1 => /*translators: City.*/ __( 'Flesberg', 'describr' ),
        2 => /*translators: City.*/ __( 'Flå', 'describr' ),
        3 => /*translators: City.*/ __( 'Geilo', 'describr' ),
        4 => /*translators: City.*/ __( 'Gol', 'describr' ),
        5 => /*translators: City.*/ __( 'Hemsedal', 'describr' ),
        6 => /*translators: City.*/ __( 'Hol', 'describr' ),
        7 => /*translators: City.*/ __( 'Hole', 'describr' ),
        8 => /*translators: City.*/ __( 'Hurum', 'describr' ),
        9 => /*translators: City.*/ __( 'Hvittingfoss', 'describr' ),
        10 => /*translators: City.*/ __( 'Hønefoss', 'describr' ),
        11 => /*translators: City.*/ __( 'Kongsberg', 'describr' ),
        12 => /*translators: City.*/ __( 'Krødsherad', 'describr' ),
        13 => /*translators: City.*/ __( 'Lier', 'describr' ),
        14 => /*translators: City.*/ __( 'Modum', 'describr' ),
        15 => /*translators: City.*/ __( 'Nedre Eiker', 'describr' ),
        16 => /*translators: City.*/ __( 'Nes', 'describr' ),
        17 => /*translators: City.*/ __( 'Nesbyen', 'describr' ),
        18 => /*translators: City.*/ __( 'Nore og Uvdal', 'describr' ),
        19 => /*translators: City.*/ __( 'Noresund', 'describr' ),
        20 => /*translators: City.*/ __( 'Prestfoss', 'describr' ),
        21 => /*translators: City.*/ __( 'Ringerike', 'describr' ),
        22 => /*translators: City.*/ __( 'Rollag', 'describr' ),
        23 => /*translators: City.*/ __( 'Røyken', 'describr' ),
        24 => /*translators: City.*/ __( 'Sigdal', 'describr' ),
        25 => /*translators: City.*/ __( 'Skoger', 'describr' ),
        26 => /*translators: City.*/ __( 'Sætre', 'describr' ),
        27 => /*translators: City.*/ __( 'Tofte', 'describr' ),
        28 => /*translators: City.*/ __( 'Tranby', 'describr' ),
        29 => /*translators: City.*/ __( 'Vikersund', 'describr' ),
        30 => /*translators: City.*/ __( 'Ål', 'describr' ),
        31 => /*translators: City.*/ __( 'Åros', 'describr' ),
        32 => /*translators: City.*/ __( 'Øvre Eiker', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Akershus', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ask', 'describr' ),
        1 => /*translators: City.*/ __( 'Asker', 'describr' ),
        2 => /*translators: City.*/ __( 'Auli', 'describr' ),
        3 => /*translators: City.*/ __( 'Aurskog-Høland', 'describr' ),
        4 => /*translators: City.*/ __( 'Aursmoen', 'describr' ),
        5 => /*translators: City.*/ __( 'Billingstad', 'describr' ),
        6 => /*translators: City.*/ __( 'Bjørkelangen', 'describr' ),
        7 => /*translators: City.*/ __( 'Blakstad', 'describr' ),
        8 => /*translators: City.*/ __( 'Bærum', 'describr' ),
        9 => /*translators: City.*/ __( 'Drøbak', 'describr' ),
        10 => /*translators: City.*/ __( 'Eidsvoll', 'describr' ),
        11 => /*translators: City.*/ __( 'Enebakk', 'describr' ),
        12 => /*translators: City.*/ __( 'Fagerstrand', 'describr' ),
        13 => /*translators: City.*/ __( 'Fet', 'describr' ),
        14 => /*translators: City.*/ __( 'Fetsund', 'describr' ),
        15 => /*translators: City.*/ __( 'Fjellfoten', 'describr' ),
        16 => /*translators: City.*/ __( 'Flateby', 'describr' ),
        17 => /*translators: City.*/ __( 'Frogn', 'describr' ),
        18 => /*translators: City.*/ __( 'Frogner', 'describr' ),
        19 => /*translators: City.*/ __( 'Gjerdrum', 'describr' ),
        20 => /*translators: City.*/ __( 'Hurdal', 'describr' ),
        21 => /*translators: City.*/ __( 'Jessheim', 'describr' ),
        22 => /*translators: City.*/ __( 'Kløfta', 'describr' ),
        23 => /*translators: City.*/ __( 'Leirsund', 'describr' ),
        24 => /*translators: City.*/ __( 'Lillestrøm', 'describr' ),
        25 => /*translators: City.*/ __( 'Lysaker', 'describr' ),
        26 => /*translators: City.*/ __( 'Lørenskog', 'describr' ),
        27 => /*translators: City.*/ __( 'Maura', 'describr' ),
        28 => /*translators: City.*/ __( 'Nannestad', 'describr' ),
        29 => /*translators: City.*/ __( 'Nes', 'describr' ),
        30 => /*translators: City.*/ __( 'Neskollen', 'describr' ),
        31 => /*translators: City.*/ __( 'Nesodden', 'describr' ),
        32 => /*translators: City.*/ __( 'Nesoddtangen', 'describr' ),
        33 => /*translators: City.*/ __( 'Nittedal', 'describr' ),
        34 => /*translators: City.*/ __( 'Oppegård', 'describr' ),
        35 => /*translators: City.*/ __( 'Rotnes', 'describr' ),
        36 => /*translators: City.*/ __( 'Råholt', 'describr' ),
        37 => /*translators: City.*/ __( 'Rælingen', 'describr' ),
        38 => /*translators: City.*/ __( 'Skedsmo', 'describr' ),
        39 => /*translators: City.*/ __( 'Ski', 'describr' ),
        40 => /*translators: City.*/ __( 'Skui', 'describr' ),
        41 => /*translators: City.*/ __( 'Sørum', 'describr' ),
        42 => /*translators: City.*/ __( 'Sørumsand', 'describr' ),
        43 => /*translators: City.*/ __( 'Ullensaker', 'describr' ),
        44 => /*translators: City.*/ __( 'Vestby', 'describr' ),
        45 => /*translators: City.*/ __( 'Åneby', 'describr' ),
        46 => /*translators: City.*/ __( 'Årnes', 'describr' ),
        47 => /*translators: City.*/ __( 'Ås', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hedmark', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alvdal', 'describr' ),
        1 => /*translators: City.*/ __( 'Brumunddal', 'describr' ),
        2 => /*translators: City.*/ __( 'Eidskog', 'describr' ),
        3 => /*translators: City.*/ __( 'Elverum', 'describr' ),
        4 => /*translators: City.*/ __( 'Engerdal', 'describr' ),
        5 => /*translators: City.*/ __( 'Folldal', 'describr' ),
        6 => /*translators: City.*/ __( 'Grue', 'describr' ),
        7 => /*translators: City.*/ __( 'Hamar', 'describr' ),
        8 => /*translators: City.*/ __( 'Innbygda', 'describr' ),
        9 => /*translators: City.*/ __( 'Kirkenær', 'describr' ),
        10 => /*translators: City.*/ __( 'Kongsvinger', 'describr' ),
        11 => /*translators: City.*/ __( 'Koppang', 'describr' ),
        12 => /*translators: City.*/ __( 'Løten', 'describr' ),
        13 => /*translators: City.*/ __( 'Moelv', 'describr' ),
        14 => /*translators: City.*/ __( 'Nord-Odal', 'describr' ),
        15 => /*translators: City.*/ __( 'Os', 'describr' ),
        16 => /*translators: City.*/ __( 'Rena', 'describr' ),
        17 => /*translators: City.*/ __( 'Rendalen', 'describr' ),
        18 => /*translators: City.*/ __( 'Ringsaker', 'describr' ),
        19 => /*translators: City.*/ __( 'Sand', 'describr' ),
        20 => /*translators: City.*/ __( 'Skarnes', 'describr' ),
        21 => /*translators: City.*/ __( 'Skotterud', 'describr' ),
        22 => /*translators: City.*/ __( 'Spetalen', 'describr' ),
        23 => /*translators: City.*/ __( 'Stange', 'describr' ),
        24 => /*translators: City.*/ __( 'Stor-Elvdal', 'describr' ),
        25 => /*translators: City.*/ __( 'Sør-Odal', 'describr' ),
        26 => /*translators: City.*/ __( 'Tolga', 'describr' ),
        27 => /*translators: City.*/ __( 'Trysil', 'describr' ),
        28 => /*translators: City.*/ __( 'Tynset', 'describr' ),
        29 => /*translators: City.*/ __( 'Våler', 'describr' ),
        30 => /*translators: City.*/ __( 'Åmot', 'describr' ),
        31 => /*translators: City.*/ __( 'Åsnes', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Østfold', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aremark', 'describr' ),
        1 => /*translators: City.*/ __( 'Askim', 'describr' ),
        2 => /*translators: City.*/ __( 'Eidsberg', 'describr' ),
        3 => /*translators: City.*/ __( 'Fossby', 'describr' ),
        4 => /*translators: City.*/ __( 'Fredrikstad', 'describr' ),
        5 => /*translators: City.*/ __( 'Halden', 'describr' ),
        6 => /*translators: City.*/ __( 'Hobøl', 'describr' ),
        7 => /*translators: City.*/ __( 'Hvaler', 'describr' ),
        8 => /*translators: City.*/ __( 'Karlshus', 'describr' ),
        9 => /*translators: City.*/ __( 'Knappstad', 'describr' ),
        10 => /*translators: City.*/ __( 'Larkollen', 'describr' ),
        11 => /*translators: City.*/ __( 'Lervik', 'describr' ),
        12 => /*translators: City.*/ __( 'Marker', 'describr' ),
        13 => /*translators: City.*/ __( 'Moss', 'describr' ),
        14 => /*translators: City.*/ __( 'Mysen', 'describr' ),
        15 => /*translators: City.*/ __( 'Rakkestad', 'describr' ),
        16 => /*translators: City.*/ __( 'Rygge', 'describr' ),
        17 => /*translators: City.*/ __( 'Ryggebyen', 'describr' ),
        18 => /*translators: City.*/ __( 'Råde', 'describr' ),
        19 => /*translators: City.*/ __( 'Rømskog', 'describr' ),
        20 => /*translators: City.*/ __( 'Sarpsborg', 'describr' ),
        21 => /*translators: City.*/ __( 'Skiptvet', 'describr' ),
        22 => /*translators: City.*/ __( 'Skjeberg', 'describr' ),
        23 => /*translators: City.*/ __( 'Skjærhalden', 'describr' ),
        24 => /*translators: City.*/ __( 'Spydeberg', 'describr' ),
        25 => /*translators: City.*/ __( 'Tomter', 'describr' ),
        26 => /*translators: City.*/ __( 'Trøgstad', 'describr' ),
        27 => /*translators: City.*/ __( 'Våler', 'describr' ),
        28 => /*translators: City.*/ __( 'Ørje', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Telemark', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bamble', 'describr' ),
        1 => /*translators: City.*/ __( 'Bø', 'describr' ),
        2 => /*translators: City.*/ __( 'Dalen', 'describr' ),
        3 => /*translators: City.*/ __( 'Drangedal', 'describr' ),
        4 => /*translators: City.*/ __( 'Fyresdal', 'describr' ),
        5 => /*translators: City.*/ __( 'Gvarv', 'describr' ),
        6 => /*translators: City.*/ __( 'Herre', 'describr' ),
        7 => /*translators: City.*/ __( 'Hjartdal', 'describr' ),
        8 => /*translators: City.*/ __( 'Kragerø', 'describr' ),
        9 => /*translators: City.*/ __( 'Kviteseid', 'describr' ),
        10 => /*translators: City.*/ __( 'Lunde', 'describr' ),
        11 => /*translators: City.*/ __( 'Nissedal', 'describr' ),
        12 => /*translators: City.*/ __( 'Nome', 'describr' ),
        13 => /*translators: City.*/ __( 'Notodden', 'describr' ),
        14 => /*translators: City.*/ __( 'Porsgrunn', 'describr' ),
        15 => /*translators: City.*/ __( 'Prestestranda', 'describr' ),
        16 => /*translators: City.*/ __( 'Rjukan', 'describr' ),
        17 => /*translators: City.*/ __( 'Sauherad', 'describr' ),
        18 => /*translators: City.*/ __( 'Seljord', 'describr' ),
        19 => /*translators: City.*/ __( 'Siljan', 'describr' ),
        20 => /*translators: City.*/ __( 'Skien', 'describr' ),
        21 => /*translators: City.*/ __( 'Tinn', 'describr' ),
        22 => /*translators: City.*/ __( 'Tokke', 'describr' ),
        23 => /*translators: City.*/ __( 'Ulefoss', 'describr' ),
        24 => /*translators: City.*/ __( 'Vinje', 'describr' ),
      ),
    ),
  ),
  'HU' => 
  array (
    'CS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Csongrád County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Algyő', 'describr' ),
        1 => /*translators: City.*/ __( 'Apátfalva', 'describr' ),
        2 => /*translators: City.*/ __( 'Baks', 'describr' ),
        3 => /*translators: City.*/ __( 'Balástya', 'describr' ),
        4 => /*translators: City.*/ __( 'Bordány', 'describr' ),
        5 => /*translators: City.*/ __( 'Csanytelek', 'describr' ),
        6 => /*translators: City.*/ __( 'Csanádpalota', 'describr' ),
        7 => /*translators: City.*/ __( 'Csengele', 'describr' ),
        8 => /*translators: City.*/ __( 'Csongrád', 'describr' ),
        9 => /*translators: City.*/ __( 'Csongrádi Járás', 'describr' ),
        10 => /*translators: City.*/ __( 'Deszk', 'describr' ),
        11 => /*translators: City.*/ __( 'Domaszék', 'describr' ),
        12 => /*translators: City.*/ __( 'Forráskút', 'describr' ),
        13 => /*translators: City.*/ __( 'Fábiánsebestyén', 'describr' ),
        14 => /*translators: City.*/ __( 'Földeák', 'describr' ),
        15 => /*translators: City.*/ __( 'Hódmezővásárhely', 'describr' ),
        16 => /*translators: City.*/ __( 'Hódmezővásárhelyi Járás', 'describr' ),
        17 => /*translators: City.*/ __( 'Kistelek', 'describr' ),
        18 => /*translators: City.*/ __( 'Kisteleki Járás', 'describr' ),
        19 => /*translators: City.*/ __( 'Kiszombor', 'describr' ),
        20 => /*translators: City.*/ __( 'Makó', 'describr' ),
        21 => /*translators: City.*/ __( 'Makói Járás', 'describr' ),
        22 => /*translators: City.*/ __( 'Maroslele', 'describr' ),
        23 => /*translators: City.*/ __( 'Mindszent', 'describr' ),
        24 => /*translators: City.*/ __( 'Mórahalmi Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Mórahalom', 'describr' ),
        26 => /*translators: City.*/ __( 'Pusztaszer', 'describr' ),
        27 => /*translators: City.*/ __( 'Ruzsa', 'describr' ),
        28 => /*translators: City.*/ __( 'Röszke', 'describr' ),
        29 => /*translators: City.*/ __( 'Szatymaz', 'describr' ),
        30 => /*translators: City.*/ __( 'Szeged', 'describr' ),
        31 => /*translators: City.*/ __( 'Szegedi Járás', 'describr' ),
        32 => /*translators: City.*/ __( 'Szegvár', 'describr' ),
        33 => /*translators: City.*/ __( 'Szentes', 'describr' ),
        34 => /*translators: City.*/ __( 'Szentesi Járás', 'describr' ),
        35 => /*translators: City.*/ __( 'Székkutas', 'describr' ),
        36 => /*translators: City.*/ __( 'Sándorfalva', 'describr' ),
        37 => /*translators: City.*/ __( 'Tömörkény', 'describr' ),
        38 => /*translators: City.*/ __( 'Zsombó', 'describr' ),
        39 => /*translators: City.*/ __( 'Zákányszék', 'describr' ),
        40 => /*translators: City.*/ __( 'Ásotthalom', 'describr' ),
        41 => /*translators: City.*/ __( 'Ópusztaszer', 'describr' ),
        42 => /*translators: City.*/ __( 'Üllés', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Somogy County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Babócsa', 'describr' ),
        1 => /*translators: City.*/ __( 'Balatonberény', 'describr' ),
        2 => /*translators: City.*/ __( 'Balatonboglár', 'describr' ),
        3 => /*translators: City.*/ __( 'Balatonfenyves', 'describr' ),
        4 => /*translators: City.*/ __( 'Balatonföldvár', 'describr' ),
        5 => /*translators: City.*/ __( 'Balatonlelle', 'describr' ),
        6 => /*translators: City.*/ __( 'Balatonszabadi', 'describr' ),
        7 => /*translators: City.*/ __( 'Balatonszárszó', 'describr' ),
        8 => /*translators: City.*/ __( 'Barcs', 'describr' ),
        9 => /*translators: City.*/ __( 'Barcsi Járás', 'describr' ),
        10 => /*translators: City.*/ __( 'Berzence', 'describr' ),
        11 => /*translators: City.*/ __( 'Böhönye', 'describr' ),
        12 => /*translators: City.*/ __( 'Csurgó', 'describr' ),
        13 => /*translators: City.*/ __( 'Csurgói Járás', 'describr' ),
        14 => /*translators: City.*/ __( 'Fonyód', 'describr' ),
        15 => /*translators: City.*/ __( 'Fonyódi Járás', 'describr' ),
        16 => /*translators: City.*/ __( 'Kadarkút', 'describr' ),
        17 => /*translators: City.*/ __( 'Kaposmérő', 'describr' ),
        18 => /*translators: City.*/ __( 'Kaposvár', 'describr' ),
        19 => /*translators: City.*/ __( 'Kaposvári Járás', 'describr' ),
        20 => /*translators: City.*/ __( 'Karád', 'describr' ),
        21 => /*translators: City.*/ __( 'Kéthely', 'describr' ),
        22 => /*translators: City.*/ __( 'Lengyeltóti', 'describr' ),
        23 => /*translators: City.*/ __( 'Lábod', 'describr' ),
        24 => /*translators: City.*/ __( 'Marcali', 'describr' ),
        25 => /*translators: City.*/ __( 'Marcali Járás', 'describr' ),
        26 => /*translators: City.*/ __( 'Nagyatád', 'describr' ),
        27 => /*translators: City.*/ __( 'Nagyatádi Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Nagybajom', 'describr' ),
        29 => /*translators: City.*/ __( 'Segesd', 'describr' ),
        30 => /*translators: City.*/ __( 'Siófok', 'describr' ),
        31 => /*translators: City.*/ __( 'Siófoki Járás', 'describr' ),
        32 => /*translators: City.*/ __( 'Somogyvár', 'describr' ),
        33 => /*translators: City.*/ __( 'Tab', 'describr' ),
        34 => /*translators: City.*/ __( 'Tabi Járás', 'describr' ),
        35 => /*translators: City.*/ __( 'Taszár', 'describr' ),
        36 => /*translators: City.*/ __( 'Zamárdi', 'describr' ),
        37 => /*translators: City.*/ __( 'Ádánd', 'describr' ),
      ),
    ),
    'TO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tolna County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bogyiszló', 'describr' ),
        1 => /*translators: City.*/ __( 'Bonyhád', 'describr' ),
        2 => /*translators: City.*/ __( 'Bonyhádi Járás', 'describr' ),
        3 => /*translators: City.*/ __( 'Báta', 'describr' ),
        4 => /*translators: City.*/ __( 'Bátaszék', 'describr' ),
        5 => /*translators: City.*/ __( 'Bölcske', 'describr' ),
        6 => /*translators: City.*/ __( 'Decs', 'describr' ),
        7 => /*translators: City.*/ __( 'Dombóvár', 'describr' ),
        8 => /*translators: City.*/ __( 'Dombóvári Járás', 'describr' ),
        9 => /*translators: City.*/ __( 'Dunaföldvár', 'describr' ),
        10 => /*translators: City.*/ __( 'Dunaszentgyörgy', 'describr' ),
        11 => /*translators: City.*/ __( 'Döbrököz', 'describr' ),
        12 => /*translators: City.*/ __( 'Fadd', 'describr' ),
        13 => /*translators: City.*/ __( 'Gyönk', 'describr' ),
        14 => /*translators: City.*/ __( 'Hőgyész', 'describr' ),
        15 => /*translators: City.*/ __( 'Iregszemcse', 'describr' ),
        16 => /*translators: City.*/ __( 'Madocsa', 'describr' ),
        17 => /*translators: City.*/ __( 'Nagydorog', 'describr' ),
        18 => /*translators: City.*/ __( 'Nagymányok', 'describr' ),
        19 => /*translators: City.*/ __( 'Németkér', 'describr' ),
        20 => /*translators: City.*/ __( 'Ozora', 'describr' ),
        21 => /*translators: City.*/ __( 'Paks', 'describr' ),
        22 => /*translators: City.*/ __( 'Paksi Járás', 'describr' ),
        23 => /*translators: City.*/ __( 'Pincehely', 'describr' ),
        24 => /*translators: City.*/ __( 'Simontornya', 'describr' ),
        25 => /*translators: City.*/ __( 'Szedres', 'describr' ),
        26 => /*translators: City.*/ __( 'Szekszárd', 'describr' ),
        27 => /*translators: City.*/ __( 'Szekszárdi Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Szentgálpuszta', 'describr' ),
        29 => /*translators: City.*/ __( 'Tamási', 'describr' ),
        30 => /*translators: City.*/ __( 'Tamási Járás', 'describr' ),
        31 => /*translators: City.*/ __( 'Tengelic', 'describr' ),
        32 => /*translators: City.*/ __( 'Tolna', 'describr' ),
        33 => /*translators: City.*/ __( 'Tolnai Járás', 'describr' ),
        34 => /*translators: City.*/ __( 'Zomba', 'describr' ),
        35 => /*translators: City.*/ __( 'Őcsény', 'describr' ),
      ),
    ),
    'VA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vas County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bük', 'describr' ),
        1 => /*translators: City.*/ __( 'Celldömölk', 'describr' ),
        2 => /*translators: City.*/ __( 'Celldömölki Járás', 'describr' ),
        3 => /*translators: City.*/ __( 'Csepreg', 'describr' ),
        4 => /*translators: City.*/ __( 'Gencsapáti', 'describr' ),
        5 => /*translators: City.*/ __( 'Ják', 'describr' ),
        6 => /*translators: City.*/ __( 'Jánosháza', 'describr' ),
        7 => /*translators: City.*/ __( 'Körmend', 'describr' ),
        8 => /*translators: City.*/ __( 'Körmendi Járás', 'describr' ),
        9 => /*translators: City.*/ __( 'Kőszeg', 'describr' ),
        10 => /*translators: City.*/ __( 'Kőszegi Járás', 'describr' ),
        11 => /*translators: City.*/ __( 'Répcelak', 'describr' ),
        12 => /*translators: City.*/ __( 'Szentgotthárd', 'describr' ),
        13 => /*translators: City.*/ __( 'Szentgotthárdi Járás', 'describr' ),
        14 => /*translators: City.*/ __( 'Szombathely', 'describr' ),
        15 => /*translators: City.*/ __( 'Szombathelyi Járás', 'describr' ),
        16 => /*translators: City.*/ __( 'Sárvár', 'describr' ),
        17 => /*translators: City.*/ __( 'Sárvári Járás', 'describr' ),
        18 => /*translators: City.*/ __( 'Táplánszentkereszt', 'describr' ),
        19 => /*translators: City.*/ __( 'Vasvár', 'describr' ),
        20 => /*translators: City.*/ __( 'Vasvári Járás', 'describr' ),
        21 => /*translators: City.*/ __( 'Vép', 'describr' ),
      ),
    ),
    'HE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Heves County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abasár', 'describr' ),
        1 => /*translators: City.*/ __( 'Adács', 'describr' ),
        2 => /*translators: City.*/ __( 'Andornaktálya', 'describr' ),
        3 => /*translators: City.*/ __( 'Apc', 'describr' ),
        4 => /*translators: City.*/ __( 'Besenyőtelek', 'describr' ),
        5 => /*translators: City.*/ __( 'Boldog', 'describr' ),
        6 => /*translators: City.*/ __( 'Bélapátfalva', 'describr' ),
        7 => /*translators: City.*/ __( 'Bélapátfalvai Járás', 'describr' ),
        8 => /*translators: City.*/ __( 'Csány', 'describr' ),
        9 => /*translators: City.*/ __( 'Domoszló', 'describr' ),
        10 => /*translators: City.*/ __( 'Ecséd', 'describr' ),
        11 => /*translators: City.*/ __( 'Eger', 'describr' ),
        12 => /*translators: City.*/ __( 'Egerszalók', 'describr' ),
        13 => /*translators: City.*/ __( 'Egri Járás', 'describr' ),
        14 => /*translators: City.*/ __( 'Erdőtelek', 'describr' ),
        15 => /*translators: City.*/ __( 'Felsőtárkány', 'describr' ),
        16 => /*translators: City.*/ __( 'Füzesabony', 'describr' ),
        17 => /*translators: City.*/ __( 'Füzesabonyi Járás', 'describr' ),
        18 => /*translators: City.*/ __( 'Gyöngyös', 'describr' ),
        19 => /*translators: City.*/ __( 'Gyöngyöshalász', 'describr' ),
        20 => /*translators: City.*/ __( 'Gyöngyösi Járás', 'describr' ),
        21 => /*translators: City.*/ __( 'Gyöngyöspata', 'describr' ),
        22 => /*translators: City.*/ __( 'Gyöngyössolymos', 'describr' ),
        23 => /*translators: City.*/ __( 'Gyöngyöstarján', 'describr' ),
        24 => /*translators: City.*/ __( 'Hatvan', 'describr' ),
        25 => /*translators: City.*/ __( 'Hatvani Járás', 'describr' ),
        26 => /*translators: City.*/ __( 'Heréd', 'describr' ),
        27 => /*translators: City.*/ __( 'Heves', 'describr' ),
        28 => /*translators: City.*/ __( 'Hevesi Járás', 'describr' ),
        29 => /*translators: City.*/ __( 'Hort', 'describr' ),
        30 => /*translators: City.*/ __( 'Karácsond', 'describr' ),
        31 => /*translators: City.*/ __( 'Kerecsend', 'describr' ),
        32 => /*translators: City.*/ __( 'Kisköre', 'describr' ),
        33 => /*translators: City.*/ __( 'Kompolt', 'describr' ),
        34 => /*translators: City.*/ __( 'Kál', 'describr' ),
        35 => /*translators: City.*/ __( 'Lőrinci', 'describr' ),
        36 => /*translators: City.*/ __( 'Maklár', 'describr' ),
        37 => /*translators: City.*/ __( 'Mátraderecske', 'describr' ),
        38 => /*translators: City.*/ __( 'Nagyréde', 'describr' ),
        39 => /*translators: City.*/ __( 'Ostoros', 'describr' ),
        40 => /*translators: City.*/ __( 'Parád', 'describr' ),
        41 => /*translators: City.*/ __( 'Parádsasvár', 'describr' ),
        42 => /*translators: City.*/ __( 'Petőfibánya', 'describr' ),
        43 => /*translators: City.*/ __( 'Poroszló', 'describr' ),
        44 => /*translators: City.*/ __( 'Pétervására', 'describr' ),
        45 => /*translators: City.*/ __( 'Pétervásárai Járás', 'describr' ),
        46 => /*translators: City.*/ __( 'Recsk', 'describr' ),
        47 => /*translators: City.*/ __( 'Rózsaszentmárton', 'describr' ),
        48 => /*translators: City.*/ __( 'Sirok', 'describr' ),
        49 => /*translators: City.*/ __( 'Szihalom', 'describr' ),
        50 => /*translators: City.*/ __( 'Szilvásvárad', 'describr' ),
        51 => /*translators: City.*/ __( 'Tarnalelesz', 'describr' ),
        52 => /*translators: City.*/ __( 'Tarnaörs', 'describr' ),
        53 => /*translators: City.*/ __( 'Tiszanána', 'describr' ),
        54 => /*translators: City.*/ __( 'Verpelét', 'describr' ),
        55 => /*translators: City.*/ __( 'Vámosgyörk', 'describr' ),
        56 => /*translators: City.*/ __( 'Zagyvaszántó', 'describr' ),
      ),
    ),
    'GS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Győr-Moson-Sopron County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abda', 'describr' ),
        1 => /*translators: City.*/ __( 'Bakonyszentlászló', 'describr' ),
        2 => /*translators: City.*/ __( 'Beled', 'describr' ),
        3 => /*translators: City.*/ __( 'Bőny', 'describr' ),
        4 => /*translators: City.*/ __( 'Bősárkány', 'describr' ),
        5 => /*translators: City.*/ __( 'Csorna', 'describr' ),
        6 => /*translators: City.*/ __( 'Csornai Járás', 'describr' ),
        7 => /*translators: City.*/ __( 'Farád', 'describr' ),
        8 => /*translators: City.*/ __( 'Fertőd', 'describr' ),
        9 => /*translators: City.*/ __( 'Fertőrákos', 'describr' ),
        10 => /*translators: City.*/ __( 'Fertőszentmiklós', 'describr' ),
        11 => /*translators: City.*/ __( 'Győr', 'describr' ),
        12 => /*translators: City.*/ __( 'Győri Járás', 'describr' ),
        13 => /*translators: City.*/ __( 'Győrszemere', 'describr' ),
        14 => /*translators: City.*/ __( 'Győrújbarát', 'describr' ),
        15 => /*translators: City.*/ __( 'Halászi', 'describr' ),
        16 => /*translators: City.*/ __( 'Jánossomorja', 'describr' ),
        17 => /*translators: City.*/ __( 'Kapuvár', 'describr' ),
        18 => /*translators: City.*/ __( 'Kapuvári Járás', 'describr' ),
        19 => /*translators: City.*/ __( 'Kimle', 'describr' ),
        20 => /*translators: City.*/ __( 'Kóny', 'describr' ),
        21 => /*translators: City.*/ __( 'Lébény', 'describr' ),
        22 => /*translators: City.*/ __( 'Mihályi', 'describr' ),
        23 => /*translators: City.*/ __( 'Mosonmagyaróvár', 'describr' ),
        24 => /*translators: City.*/ __( 'Mosonmagyaróvári Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Mosonszentmiklós', 'describr' ),
        26 => /*translators: City.*/ __( 'Nagycenk', 'describr' ),
        27 => /*translators: City.*/ __( 'Nyúl', 'describr' ),
        28 => /*translators: City.*/ __( 'Pannonhalma', 'describr' ),
        29 => /*translators: City.*/ __( 'Pannonhalmi Járás', 'describr' ),
        30 => /*translators: City.*/ __( 'Pér', 'describr' ),
        31 => /*translators: City.*/ __( 'Rajka', 'describr' ),
        32 => /*translators: City.*/ __( 'Rábapatona', 'describr' ),
        33 => /*translators: City.*/ __( 'Sopron', 'describr' ),
        34 => /*translators: City.*/ __( 'Soproni Járás', 'describr' ),
        35 => /*translators: City.*/ __( 'Szany', 'describr' ),
        36 => /*translators: City.*/ __( 'Tét', 'describr' ),
        37 => /*translators: City.*/ __( 'Téti Járás', 'describr' ),
        38 => /*translators: City.*/ __( 'Töltéstava', 'describr' ),
        39 => /*translators: City.*/ __( 'Ágfalva', 'describr' ),
        40 => /*translators: City.*/ __( 'Ásványráró', 'describr' ),
        41 => /*translators: City.*/ __( 'Öttevény', 'describr' ),
      ),
    ),
    'JN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jász-Nagykun-Szolnok County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abádszalók', 'describr' ),
        1 => /*translators: City.*/ __( 'Alattyán', 'describr' ),
        2 => /*translators: City.*/ __( 'Besenyszög', 'describr' ),
        3 => /*translators: City.*/ __( 'Cibakháza', 'describr' ),
        4 => /*translators: City.*/ __( 'Cserkeszőlő', 'describr' ),
        5 => /*translators: City.*/ __( 'Fegyvernek', 'describr' ),
        6 => /*translators: City.*/ __( 'Jánoshida', 'describr' ),
        7 => /*translators: City.*/ __( 'Jászalsószentgyörgy', 'describr' ),
        8 => /*translators: City.*/ __( 'Jászapáti', 'describr' ),
        9 => /*translators: City.*/ __( 'Jászapáti Járás', 'describr' ),
        10 => /*translators: City.*/ __( 'Jászberény', 'describr' ),
        11 => /*translators: City.*/ __( 'Jászberényi Járás', 'describr' ),
        12 => /*translators: City.*/ __( 'Jászdózsa', 'describr' ),
        13 => /*translators: City.*/ __( 'Jászjákóhalma', 'describr' ),
        14 => /*translators: City.*/ __( 'Jászkisér', 'describr' ),
        15 => /*translators: City.*/ __( 'Jászladány', 'describr' ),
        16 => /*translators: City.*/ __( 'Jászszentandrás', 'describr' ),
        17 => /*translators: City.*/ __( 'Jászárokszállás', 'describr' ),
        18 => /*translators: City.*/ __( 'Karcag', 'describr' ),
        19 => /*translators: City.*/ __( 'Karcagi Járás', 'describr' ),
        20 => /*translators: City.*/ __( 'Kenderes', 'describr' ),
        21 => /*translators: City.*/ __( 'Kengyel', 'describr' ),
        22 => /*translators: City.*/ __( 'Kisújszállás', 'describr' ),
        23 => /*translators: City.*/ __( 'Kunhegyes', 'describr' ),
        24 => /*translators: City.*/ __( 'Kunhegyesi Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Kunmadaras', 'describr' ),
        26 => /*translators: City.*/ __( 'Kunszentmárton', 'describr' ),
        27 => /*translators: City.*/ __( 'Kunszentmártoni Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Mezőtúr', 'describr' ),
        29 => /*translators: City.*/ __( 'Mezőtúri Járás', 'describr' ),
        30 => /*translators: City.*/ __( 'Rákóczifalva', 'describr' ),
        31 => /*translators: City.*/ __( 'Rákócziújfalu', 'describr' ),
        32 => /*translators: City.*/ __( 'Szajol', 'describr' ),
        33 => /*translators: City.*/ __( 'Szelevény', 'describr' ),
        34 => /*translators: City.*/ __( 'Szolnok', 'describr' ),
        35 => /*translators: City.*/ __( 'Szolnoki Járás', 'describr' ),
        36 => /*translators: City.*/ __( 'Tiszabura', 'describr' ),
        37 => /*translators: City.*/ __( 'Tiszabő', 'describr' ),
        38 => /*translators: City.*/ __( 'Tiszaföldvár', 'describr' ),
        39 => /*translators: City.*/ __( 'Tiszafüred', 'describr' ),
        40 => /*translators: City.*/ __( 'Tiszafüredi Járás', 'describr' ),
        41 => /*translators: City.*/ __( 'Tiszapüspöki', 'describr' ),
        42 => /*translators: City.*/ __( 'Tiszaroff', 'describr' ),
        43 => /*translators: City.*/ __( 'Tiszaszentimre', 'describr' ),
        44 => /*translators: City.*/ __( 'Tiszaszőlős', 'describr' ),
        45 => /*translators: City.*/ __( 'Tiszasüly', 'describr' ),
        46 => /*translators: City.*/ __( 'Tószeg', 'describr' ),
        47 => /*translators: City.*/ __( 'Törökszentmiklós', 'describr' ),
        48 => /*translators: City.*/ __( 'Törökszentmiklósi Járás', 'describr' ),
        49 => /*translators: City.*/ __( 'Túrkeve', 'describr' ),
        50 => /*translators: City.*/ __( 'Zagyvarékas', 'describr' ),
        51 => /*translators: City.*/ __( 'Öcsöd', 'describr' ),
        52 => /*translators: City.*/ __( 'Újszász', 'describr' ),
      ),
    ),
    'FE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fejér County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aba', 'describr' ),
        1 => /*translators: City.*/ __( 'Adony', 'describr' ),
        2 => /*translators: City.*/ __( 'Alap', 'describr' ),
        3 => /*translators: City.*/ __( 'Bakonycsernye', 'describr' ),
        4 => /*translators: City.*/ __( 'Baracs', 'describr' ),
        5 => /*translators: City.*/ __( 'Baracska', 'describr' ),
        6 => /*translators: City.*/ __( 'Bicske', 'describr' ),
        7 => /*translators: City.*/ __( 'Bicskei Járás', 'describr' ),
        8 => /*translators: City.*/ __( 'Bodajk', 'describr' ),
        9 => /*translators: City.*/ __( 'Cece', 'describr' ),
        10 => /*translators: City.*/ __( 'Csákvár', 'describr' ),
        11 => /*translators: City.*/ __( 'Dunaújvárosi Járás', 'describr' ),
        12 => /*translators: City.*/ __( 'Dég', 'describr' ),
        13 => /*translators: City.*/ __( 'Előszállás', 'describr' ),
        14 => /*translators: City.*/ __( 'Enying', 'describr' ),
        15 => /*translators: City.*/ __( 'Enyingi Járás', 'describr' ),
        16 => /*translators: City.*/ __( 'Ercsi', 'describr' ),
        17 => /*translators: City.*/ __( 'Etyek', 'describr' ),
        18 => /*translators: City.*/ __( 'Fehérvárcsurgó', 'describr' ),
        19 => /*translators: City.*/ __( 'Gárdony', 'describr' ),
        20 => /*translators: City.*/ __( 'Gárdonyi Járás', 'describr' ),
        21 => /*translators: City.*/ __( 'Iváncsa', 'describr' ),
        22 => /*translators: City.*/ __( 'Kincsesbánya', 'describr' ),
        23 => /*translators: City.*/ __( 'Kisláng', 'describr' ),
        24 => /*translators: City.*/ __( 'Káloz', 'describr' ),
        25 => /*translators: City.*/ __( 'Kápolnásnyék', 'describr' ),
        26 => /*translators: City.*/ __( 'Lajoskomárom', 'describr' ),
        27 => /*translators: City.*/ __( 'Lepsény', 'describr' ),
        28 => /*translators: City.*/ __( 'Lovasberény', 'describr' ),
        29 => /*translators: City.*/ __( 'Martonvásár', 'describr' ),
        30 => /*translators: City.*/ __( 'Martonvásári Járás', 'describr' ),
        31 => /*translators: City.*/ __( 'Mezőfalva', 'describr' ),
        32 => /*translators: City.*/ __( 'Mezőszilas', 'describr' ),
        33 => /*translators: City.*/ __( 'Mány', 'describr' ),
        34 => /*translators: City.*/ __( 'Mór', 'describr' ),
        35 => /*translators: City.*/ __( 'Móri Járás', 'describr' ),
        36 => /*translators: City.*/ __( 'Perkáta', 'describr' ),
        37 => /*translators: City.*/ __( 'Polgárdi', 'describr' ),
        38 => /*translators: City.*/ __( 'Pusztaszabolcs', 'describr' ),
        39 => /*translators: City.*/ __( 'Pusztavám', 'describr' ),
        40 => /*translators: City.*/ __( 'Pákozd', 'describr' ),
        41 => /*translators: City.*/ __( 'Pázmánd', 'describr' ),
        42 => /*translators: City.*/ __( 'Rácalmás', 'describr' ),
        43 => /*translators: City.*/ __( 'Ráckeresztúr', 'describr' ),
        44 => /*translators: City.*/ __( 'Seregélyes', 'describr' ),
        45 => /*translators: City.*/ __( 'Soponya', 'describr' ),
        46 => /*translators: City.*/ __( 'Szabadbattyán', 'describr' ),
        47 => /*translators: City.*/ __( 'Szárliget', 'describr' ),
        48 => /*translators: City.*/ __( 'Székesfehérvár', 'describr' ),
        49 => /*translators: City.*/ __( 'Székesfehérvári Járás', 'describr' ),
        50 => /*translators: City.*/ __( 'Sárbogárd', 'describr' ),
        51 => /*translators: City.*/ __( 'Sárbogárdi Járás', 'describr' ),
        52 => /*translators: City.*/ __( 'Sárkeresztúr', 'describr' ),
        53 => /*translators: City.*/ __( 'Sárosd', 'describr' ),
        54 => /*translators: City.*/ __( 'Sárszentmihály', 'describr' ),
        55 => /*translators: City.*/ __( 'Velence', 'describr' ),
        56 => /*translators: City.*/ __( 'Vál', 'describr' ),
        57 => /*translators: City.*/ __( 'Zámoly', 'describr' ),
        58 => /*translators: City.*/ __( 'dunaújváros', 'describr' ),
      ),
    ),
    'SZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Szabolcs-Szatmár-Bereg County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajak', 'describr' ),
        1 => /*translators: City.*/ __( 'Anarcs', 'describr' ),
        2 => /*translators: City.*/ __( 'Apagy', 'describr' ),
        3 => /*translators: City.*/ __( 'Aranyosapáti', 'describr' ),
        4 => /*translators: City.*/ __( 'Baktalórántháza', 'describr' ),
        5 => /*translators: City.*/ __( 'Baktalórántházai Járás', 'describr' ),
        6 => /*translators: City.*/ __( 'Balkány', 'describr' ),
        7 => /*translators: City.*/ __( 'Buj', 'describr' ),
        8 => /*translators: City.*/ __( 'Bököny', 'describr' ),
        9 => /*translators: City.*/ __( 'Csenger', 'describr' ),
        10 => /*translators: City.*/ __( 'Csengeri Járás', 'describr' ),
        11 => /*translators: City.*/ __( 'Demecser', 'describr' ),
        12 => /*translators: City.*/ __( 'Dombrád', 'describr' ),
        13 => /*translators: City.*/ __( 'Döge', 'describr' ),
        14 => /*translators: City.*/ __( 'Encsencs', 'describr' ),
        15 => /*translators: City.*/ __( 'Fehérgyarmat', 'describr' ),
        16 => /*translators: City.*/ __( 'Fehérgyarmati Járás', 'describr' ),
        17 => /*translators: City.*/ __( 'Fényeslitke', 'describr' ),
        18 => /*translators: City.*/ __( 'Gyulaháza', 'describr' ),
        19 => /*translators: City.*/ __( 'Gégény', 'describr' ),
        20 => /*translators: City.*/ __( 'Hodász', 'describr' ),
        21 => /*translators: City.*/ __( 'Ibrány', 'describr' ),
        22 => /*translators: City.*/ __( 'Ibrányi Járás', 'describr' ),
        23 => /*translators: City.*/ __( 'Kemecse', 'describr' ),
        24 => /*translators: City.*/ __( 'Kemecsei Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Kisléta', 'describr' ),
        26 => /*translators: City.*/ __( 'Kisvárda', 'describr' ),
        27 => /*translators: City.*/ __( 'Kisvárdai Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Kocsord', 'describr' ),
        29 => /*translators: City.*/ __( 'Kállósemjén', 'describr' ),
        30 => /*translators: City.*/ __( 'Kálmánháza', 'describr' ),
        31 => /*translators: City.*/ __( 'Kántorjánosi', 'describr' ),
        32 => /*translators: City.*/ __( 'Kék', 'describr' ),
        33 => /*translators: City.*/ __( 'Kótaj', 'describr' ),
        34 => /*translators: City.*/ __( 'Levelek', 'describr' ),
        35 => /*translators: City.*/ __( 'Mándok', 'describr' ),
        36 => /*translators: City.*/ __( 'Máriapócs', 'describr' ),
        37 => /*translators: City.*/ __( 'Mátészalka', 'describr' ),
        38 => /*translators: City.*/ __( 'Mátészalkai Járás', 'describr' ),
        39 => /*translators: City.*/ __( 'Mérk', 'describr' ),
        40 => /*translators: City.*/ __( 'Nagycserkesz', 'describr' ),
        41 => /*translators: City.*/ __( 'Nagydobos', 'describr' ),
        42 => /*translators: City.*/ __( 'Nagyecsed', 'describr' ),
        43 => /*translators: City.*/ __( 'Nagyhalász', 'describr' ),
        44 => /*translators: City.*/ __( 'Nagykálló', 'describr' ),
        45 => /*translators: City.*/ __( 'Nagykállói Járás', 'describr' ),
        46 => /*translators: City.*/ __( 'Napkor', 'describr' ),
        47 => /*translators: City.*/ __( 'Nyírbogdány', 'describr' ),
        48 => /*translators: City.*/ __( 'Nyírbogát', 'describr' ),
        49 => /*translators: City.*/ __( 'Nyírbátor', 'describr' ),
        50 => /*translators: City.*/ __( 'Nyírbátori Járás', 'describr' ),
        51 => /*translators: City.*/ __( 'Nyírbéltek', 'describr' ),
        52 => /*translators: City.*/ __( 'Nyírcsaholy', 'describr' ),
        53 => /*translators: City.*/ __( 'Nyíregyháza', 'describr' ),
        54 => /*translators: City.*/ __( 'Nyíregyházi Járás', 'describr' ),
        55 => /*translators: City.*/ __( 'Nyírgyulaj', 'describr' ),
        56 => /*translators: City.*/ __( 'Nyírkarász', 'describr' ),
        57 => /*translators: City.*/ __( 'Nyírlugos', 'describr' ),
        58 => /*translators: City.*/ __( 'Nyírmada', 'describr' ),
        59 => /*translators: City.*/ __( 'Nyírmeggyes', 'describr' ),
        60 => /*translators: City.*/ __( 'Nyírmihálydi', 'describr' ),
        61 => /*translators: City.*/ __( 'Nyírpazony', 'describr' ),
        62 => /*translators: City.*/ __( 'Nyírtass', 'describr' ),
        63 => /*translators: City.*/ __( 'Nyírtelek', 'describr' ),
        64 => /*translators: City.*/ __( 'Nyírvasvári', 'describr' ),
        65 => /*translators: City.*/ __( 'Petneháza', 'describr' ),
        66 => /*translators: City.*/ __( 'Porcsalma', 'describr' ),
        67 => /*translators: City.*/ __( 'Pátroha', 'describr' ),
        68 => /*translators: City.*/ __( 'Rakamaz', 'describr' ),
        69 => /*translators: City.*/ __( 'Szakoly', 'describr' ),
        70 => /*translators: City.*/ __( 'Szamosszeg', 'describr' ),
        71 => /*translators: City.*/ __( 'Tarpa', 'describr' ),
        72 => /*translators: City.*/ __( 'Tiszabercel', 'describr' ),
        73 => /*translators: City.*/ __( 'Tiszabezdéd', 'describr' ),
        74 => /*translators: City.*/ __( 'Tiszadada', 'describr' ),
        75 => /*translators: City.*/ __( 'Tiszadob', 'describr' ),
        76 => /*translators: City.*/ __( 'Tiszaeszlár', 'describr' ),
        77 => /*translators: City.*/ __( 'Tiszalök', 'describr' ),
        78 => /*translators: City.*/ __( 'Tiszanagyfalu', 'describr' ),
        79 => /*translators: City.*/ __( 'Tiszavasvári', 'describr' ),
        80 => /*translators: City.*/ __( 'Tiszavasvári Járás', 'describr' ),
        81 => /*translators: City.*/ __( 'Tornyospálca', 'describr' ),
        82 => /*translators: City.*/ __( 'Tunyogmatolcs', 'describr' ),
        83 => /*translators: City.*/ __( 'Tuzsér', 'describr' ),
        84 => /*translators: City.*/ __( 'Tyukod', 'describr' ),
        85 => /*translators: City.*/ __( 'Vaja', 'describr' ),
        86 => /*translators: City.*/ __( 'Vásárosnamény', 'describr' ),
        87 => /*translators: City.*/ __( 'Vásárosnaményi Járás', 'describr' ),
        88 => /*translators: City.*/ __( 'Záhony', 'describr' ),
        89 => /*translators: City.*/ __( 'Záhonyi Járás', 'describr' ),
        90 => /*translators: City.*/ __( 'Ófehértó', 'describr' ),
        91 => /*translators: City.*/ __( 'Ópályi', 'describr' ),
        92 => /*translators: City.*/ __( 'Ököritófülpös', 'describr' ),
        93 => /*translators: City.*/ __( 'Újfehértó', 'describr' ),
      ),
    ),
    'ZA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zala County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Becsehely', 'describr' ),
        1 => /*translators: City.*/ __( 'Cserszegtomaj', 'describr' ),
        2 => /*translators: City.*/ __( 'Gyenesdiás', 'describr' ),
        3 => /*translators: City.*/ __( 'Hévíz', 'describr' ),
        4 => /*translators: City.*/ __( 'Keszthely', 'describr' ),
        5 => /*translators: City.*/ __( 'Keszthelyi Járás', 'describr' ),
        6 => /*translators: City.*/ __( 'Lenti', 'describr' ),
        7 => /*translators: City.*/ __( 'Lenti Járás', 'describr' ),
        8 => /*translators: City.*/ __( 'Letenye', 'describr' ),
        9 => /*translators: City.*/ __( 'Letenyei Járás', 'describr' ),
        10 => /*translators: City.*/ __( 'Murakeresztúr', 'describr' ),
        11 => /*translators: City.*/ __( 'Nagykanizsa', 'describr' ),
        12 => /*translators: City.*/ __( 'Nagykanizsai Járás', 'describr' ),
        13 => /*translators: City.*/ __( 'Pacsa', 'describr' ),
        14 => /*translators: City.*/ __( 'Sármellék', 'describr' ),
        15 => /*translators: City.*/ __( 'Türje', 'describr' ),
        16 => /*translators: City.*/ __( 'Vonyarcvashegy', 'describr' ),
        17 => /*translators: City.*/ __( 'Zalaegerszeg', 'describr' ),
        18 => /*translators: City.*/ __( 'Zalaegerszegi Járás', 'describr' ),
        19 => /*translators: City.*/ __( 'Zalakomár', 'describr' ),
        20 => /*translators: City.*/ __( 'Zalalövő', 'describr' ),
        21 => /*translators: City.*/ __( 'Zalaszentgrót', 'describr' ),
        22 => /*translators: City.*/ __( 'Zalaszentgróti Járás', 'describr' ),
      ),
    ),
    'BK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bács-Kiskun County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akasztó', 'describr' ),
        1 => /*translators: City.*/ __( 'Apostag', 'describr' ),
        2 => /*translators: City.*/ __( 'Baja', 'describr' ),
        3 => /*translators: City.*/ __( 'Bajai Járás', 'describr' ),
        4 => /*translators: City.*/ __( 'Ballószög', 'describr' ),
        5 => /*translators: City.*/ __( 'Bugac', 'describr' ),
        6 => /*translators: City.*/ __( 'Bácsalmás', 'describr' ),
        7 => /*translators: City.*/ __( 'Bácsalmási Járás', 'describr' ),
        8 => /*translators: City.*/ __( 'Bácsbokod', 'describr' ),
        9 => /*translators: City.*/ __( 'Bátya', 'describr' ),
        10 => /*translators: City.*/ __( 'Csengőd', 'describr' ),
        11 => /*translators: City.*/ __( 'Császártöltés', 'describr' ),
        12 => /*translators: City.*/ __( 'Csávoly', 'describr' ),
        13 => /*translators: City.*/ __( 'Dunapataj', 'describr' ),
        14 => /*translators: City.*/ __( 'Dunavecse', 'describr' ),
        15 => /*translators: City.*/ __( 'Dusnok', 'describr' ),
        16 => /*translators: City.*/ __( 'Dávod', 'describr' ),
        17 => /*translators: City.*/ __( 'Felsőszentiván', 'describr' ),
        18 => /*translators: City.*/ __( 'Fülöpjakab', 'describr' ),
        19 => /*translators: City.*/ __( 'Fülöpszállás', 'describr' ),
        20 => /*translators: City.*/ __( 'Gara', 'describr' ),
        21 => /*translators: City.*/ __( 'Hajós', 'describr' ),
        22 => /*translators: City.*/ __( 'Harta', 'describr' ),
        23 => /*translators: City.*/ __( 'Helvécia', 'describr' ),
        24 => /*translators: City.*/ __( 'Hercegszántó', 'describr' ),
        25 => /*translators: City.*/ __( 'Izsák', 'describr' ),
        26 => /*translators: City.*/ __( 'Jánoshalma', 'describr' ),
        27 => /*translators: City.*/ __( 'Jánoshalmai Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Jászszentlászló', 'describr' ),
        29 => /*translators: City.*/ __( 'Kalocsa', 'describr' ),
        30 => /*translators: City.*/ __( 'Kalocsai Járás', 'describr' ),
        31 => /*translators: City.*/ __( 'Katymár', 'describr' ),
        32 => /*translators: City.*/ __( 'Kecel', 'describr' ),
        33 => /*translators: City.*/ __( 'Kecskemét', 'describr' ),
        34 => /*translators: City.*/ __( 'Kecskeméti Járás', 'describr' ),
        35 => /*translators: City.*/ __( 'Kelebia', 'describr' ),
        36 => /*translators: City.*/ __( 'Kerekegyháza', 'describr' ),
        37 => /*translators: City.*/ __( 'Kiskunfélegyháza', 'describr' ),
        38 => /*translators: City.*/ __( 'Kiskunfélegyházi Járás', 'describr' ),
        39 => /*translators: City.*/ __( 'Kiskunhalas', 'describr' ),
        40 => /*translators: City.*/ __( 'Kiskunhalasi Járás', 'describr' ),
        41 => /*translators: City.*/ __( 'Kiskunmajsa', 'describr' ),
        42 => /*translators: City.*/ __( 'Kiskunmajsai Járás', 'describr' ),
        43 => /*translators: City.*/ __( 'Kiskőrös', 'describr' ),
        44 => /*translators: City.*/ __( 'Kiskőrösi Járás', 'describr' ),
        45 => /*translators: City.*/ __( 'Kisszállás', 'describr' ),
        46 => /*translators: City.*/ __( 'Kunfehértó', 'describr' ),
        47 => /*translators: City.*/ __( 'Kunszentmiklós', 'describr' ),
        48 => /*translators: City.*/ __( 'Kunszentmiklósi Járás', 'describr' ),
        49 => /*translators: City.*/ __( 'Lajosmizse', 'describr' ),
        50 => /*translators: City.*/ __( 'Lakitelek', 'describr' ),
        51 => /*translators: City.*/ __( 'Madaras', 'describr' ),
        52 => /*translators: City.*/ __( 'Mélykút', 'describr' ),
        53 => /*translators: City.*/ __( 'Nagybaracska', 'describr' ),
        54 => /*translators: City.*/ __( 'Nemesnádudvar', 'describr' ),
        55 => /*translators: City.*/ __( 'Nyárlőrinc', 'describr' ),
        56 => /*translators: City.*/ __( 'Orgovány', 'describr' ),
        57 => /*translators: City.*/ __( 'Pálmonostora', 'describr' ),
        58 => /*translators: City.*/ __( 'Solt', 'describr' ),
        59 => /*translators: City.*/ __( 'Soltvadkert', 'describr' ),
        60 => /*translators: City.*/ __( 'Szabadszállás', 'describr' ),
        61 => /*translators: City.*/ __( 'Szalkszentmárton', 'describr' ),
        62 => /*translators: City.*/ __( 'Szank', 'describr' ),
        63 => /*translators: City.*/ __( 'Szentkirály', 'describr' ),
        64 => /*translators: City.*/ __( 'Sükösd', 'describr' ),
        65 => /*translators: City.*/ __( 'Tass', 'describr' ),
        66 => /*translators: City.*/ __( 'Tiszaalpár', 'describr' ),
        67 => /*translators: City.*/ __( 'Tiszakécske', 'describr' ),
        68 => /*translators: City.*/ __( 'Tiszakécskei Járás', 'describr' ),
        69 => /*translators: City.*/ __( 'Tompa', 'describr' ),
        70 => /*translators: City.*/ __( 'Tázlár', 'describr' ),
        71 => /*translators: City.*/ __( 'Vaskút', 'describr' ),
        72 => /*translators: City.*/ __( 'Városföld', 'describr' ),
        73 => /*translators: City.*/ __( 'Ágasegyháza', 'describr' ),
        74 => /*translators: City.*/ __( 'Érsekcsanád', 'describr' ),
      ),
    ),
    'NO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nógrád County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balassagyarmat', 'describr' ),
        1 => /*translators: City.*/ __( 'Balassagyarmati Járás', 'describr' ),
        2 => /*translators: City.*/ __( 'Bercel', 'describr' ),
        3 => /*translators: City.*/ __( 'Buják', 'describr' ),
        4 => /*translators: City.*/ __( 'Bátonyterenye', 'describr' ),
        5 => /*translators: City.*/ __( 'Bátonyterenyei Járás', 'describr' ),
        6 => /*translators: City.*/ __( 'Diósjenő', 'describr' ),
        7 => /*translators: City.*/ __( 'Héhalom', 'describr' ),
        8 => /*translators: City.*/ __( 'Jobbágyi', 'describr' ),
        9 => /*translators: City.*/ __( 'Karancskeszi', 'describr' ),
        10 => /*translators: City.*/ __( 'Karancslapujtő', 'describr' ),
        11 => /*translators: City.*/ __( 'Kazár', 'describr' ),
        12 => /*translators: City.*/ __( 'Mátranovák', 'describr' ),
        13 => /*translators: City.*/ __( 'Mátraterenye', 'describr' ),
        14 => /*translators: City.*/ __( 'Mátraverebély', 'describr' ),
        15 => /*translators: City.*/ __( 'Nagyoroszi', 'describr' ),
        16 => /*translators: City.*/ __( 'Palotás', 'describr' ),
        17 => /*translators: City.*/ __( 'Pásztó', 'describr' ),
        18 => /*translators: City.*/ __( 'Pásztói Járás', 'describr' ),
        19 => /*translators: City.*/ __( 'Rimóc', 'describr' ),
        20 => /*translators: City.*/ __( 'Romhány', 'describr' ),
        21 => /*translators: City.*/ __( 'Rétság', 'describr' ),
        22 => /*translators: City.*/ __( 'Rétsági Járás', 'describr' ),
        23 => /*translators: City.*/ __( 'Salgótarján', 'describr' ),
        24 => /*translators: City.*/ __( 'Salgótarjáni Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Somoskőújfalu', 'describr' ),
        26 => /*translators: City.*/ __( 'Szurdokpüspöki', 'describr' ),
        27 => /*translators: City.*/ __( 'Szécsény', 'describr' ),
        28 => /*translators: City.*/ __( 'Szécsényi Járás', 'describr' ),
        29 => /*translators: City.*/ __( 'Tar', 'describr' ),
        30 => /*translators: City.*/ __( 'Érsekvadkert', 'describr' ),
      ),
    ),
    'VE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Veszprém County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajka', 'describr' ),
        1 => /*translators: City.*/ __( 'Ajkai Járás', 'describr' ),
        2 => /*translators: City.*/ __( 'Badacsonytomaj', 'describr' ),
        3 => /*translators: City.*/ __( 'Balatonalmádi', 'describr' ),
        4 => /*translators: City.*/ __( 'Balatonalmádi Járás', 'describr' ),
        5 => /*translators: City.*/ __( 'Balatonfüred', 'describr' ),
        6 => /*translators: City.*/ __( 'Balatonfüredi Járás', 'describr' ),
        7 => /*translators: City.*/ __( 'Balatonkenese', 'describr' ),
        8 => /*translators: City.*/ __( 'Berhida', 'describr' ),
        9 => /*translators: City.*/ __( 'Csabrendek', 'describr' ),
        10 => /*translators: City.*/ __( 'Csetény', 'describr' ),
        11 => /*translators: City.*/ __( 'Csopak', 'describr' ),
        12 => /*translators: City.*/ __( 'Devecser', 'describr' ),
        13 => /*translators: City.*/ __( 'Devecseri Járás', 'describr' ),
        14 => /*translators: City.*/ __( 'Hajmáskér', 'describr' ),
        15 => /*translators: City.*/ __( 'Herend', 'describr' ),
        16 => /*translators: City.*/ __( 'Litér', 'describr' ),
        17 => /*translators: City.*/ __( 'Nemesvámos', 'describr' ),
        18 => /*translators: City.*/ __( 'Pápa', 'describr' ),
        19 => /*translators: City.*/ __( 'Pápai Járás', 'describr' ),
        20 => /*translators: City.*/ __( 'Pétfürdő', 'describr' ),
        21 => /*translators: City.*/ __( 'Révfülöp', 'describr' ),
        22 => /*translators: City.*/ __( 'Szentkirályszabadja', 'describr' ),
        23 => /*translators: City.*/ __( 'Sümeg', 'describr' ),
        24 => /*translators: City.*/ __( 'Sümegi Járás', 'describr' ),
        25 => /*translators: City.*/ __( 'Tapolca', 'describr' ),
        26 => /*translators: City.*/ __( 'Tapolcai Járás', 'describr' ),
        27 => /*translators: City.*/ __( 'Tihany', 'describr' ),
        28 => /*translators: City.*/ __( 'Veszprém', 'describr' ),
        29 => /*translators: City.*/ __( 'Veszprémi Járás', 'describr' ),
        30 => /*translators: City.*/ __( 'Várpalota', 'describr' ),
        31 => /*translators: City.*/ __( 'Várpalotai Járás', 'describr' ),
        32 => /*translators: City.*/ __( 'Zirc', 'describr' ),
        33 => /*translators: City.*/ __( 'Zirci Járás', 'describr' ),
        34 => /*translators: City.*/ __( 'Zánka', 'describr' ),
        35 => /*translators: City.*/ __( 'Úrkút', 'describr' ),
        36 => /*translators: City.*/ __( 'Ősi', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baranya County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beremend', 'describr' ),
        1 => /*translators: City.*/ __( 'Bóly', 'describr' ),
        2 => /*translators: City.*/ __( 'Bólyi Járás', 'describr' ),
        3 => /*translators: City.*/ __( 'Bükkösd', 'describr' ),
        4 => /*translators: City.*/ __( 'Dunaszekcső', 'describr' ),
        5 => /*translators: City.*/ __( 'Harkány', 'describr' ),
        6 => /*translators: City.*/ __( 'Hegyháti Járás', 'describr' ),
        7 => /*translators: City.*/ __( 'Hidas', 'describr' ),
        8 => /*translators: City.*/ __( 'Hosszúhetény', 'describr' ),
        9 => /*translators: City.*/ __( 'Komló', 'describr' ),
        10 => /*translators: City.*/ __( 'Komlói Járás', 'describr' ),
        11 => /*translators: City.*/ __( 'Kozármisleny', 'describr' ),
        12 => /*translators: City.*/ __( 'Lánycsók', 'describr' ),
        13 => /*translators: City.*/ __( 'Mecseknádasd', 'describr' ),
        14 => /*translators: City.*/ __( 'Mohács', 'describr' ),
        15 => /*translators: City.*/ __( 'Mohácsi Járás', 'describr' ),
        16 => /*translators: City.*/ __( 'Mágocs', 'describr' ),
        17 => /*translators: City.*/ __( 'Pellérd', 'describr' ),
        18 => /*translators: City.*/ __( 'Pécs', 'describr' ),
        19 => /*translators: City.*/ __( 'Pécsi Járás', 'describr' ),
        20 => /*translators: City.*/ __( 'Pécsvárad', 'describr' ),
        21 => /*translators: City.*/ __( 'Pécsváradi Járás', 'describr' ),
        22 => /*translators: City.*/ __( 'Sellye', 'describr' ),
        23 => /*translators: City.*/ __( 'Sellyei Járás', 'describr' ),
        24 => /*translators: City.*/ __( 'Siklós', 'describr' ),
        25 => /*translators: City.*/ __( 'Siklósi Járás', 'describr' ),
        26 => /*translators: City.*/ __( 'Szentlőrinc', 'describr' ),
        27 => /*translators: City.*/ __( 'Szentlőrinci Járás', 'describr' ),
        28 => /*translators: City.*/ __( 'Szigetvár', 'describr' ),
        29 => /*translators: City.*/ __( 'Szigetvári Járás', 'describr' ),
        30 => /*translators: City.*/ __( 'Szászvár', 'describr' ),
        31 => /*translators: City.*/ __( 'Sásd', 'describr' ),
        32 => /*translators: City.*/ __( 'Vajszló', 'describr' ),
        33 => /*translators: City.*/ __( 'Villány', 'describr' ),
      ),
    ),
    'BZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Borsod-Abaúj-Zemplén County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abaújszántó', 'describr' ),
        1 => /*translators: City.*/ __( 'Alsózsolca', 'describr' ),
        2 => /*translators: City.*/ __( 'Arló', 'describr' ),
        3 => /*translators: City.*/ __( 'Arnót', 'describr' ),
        4 => /*translators: City.*/ __( 'Aszaló', 'describr' ),
        5 => /*translators: City.*/ __( 'Bekecs', 'describr' ),
        6 => /*translators: City.*/ __( 'Bogács', 'describr' ),
        7 => /*translators: City.*/ __( 'Boldva', 'describr' ),
        8 => /*translators: City.*/ __( 'Borsodnádasd', 'describr' ),
        9 => /*translators: City.*/ __( 'Bőcs', 'describr' ),
        10 => /*translators: City.*/ __( 'Cigánd', 'describr' ),
        11 => /*translators: City.*/ __( 'Cigándi Járás', 'describr' ),
        12 => /*translators: City.*/ __( 'Edelény', 'describr' ),
        13 => /*translators: City.*/ __( 'Edelényi Járás', 'describr' ),
        14 => /*translators: City.*/ __( 'Emőd', 'describr' ),
        15 => /*translators: City.*/ __( 'Encs', 'describr' ),
        16 => /*translators: City.*/ __( 'Encsi Járás', 'describr' ),
        17 => /*translators: City.*/ __( 'Farkaslyuk', 'describr' ),
        18 => /*translators: City.*/ __( 'Felsőzsolca', 'describr' ),
        19 => /*translators: City.*/ __( 'Gesztely', 'describr' ),
        20 => /*translators: City.*/ __( 'Gönc', 'describr' ),
        21 => /*translators: City.*/ __( 'Gönci Járás', 'describr' ),
        22 => /*translators: City.*/ __( 'Halmaj', 'describr' ),
        23 => /*translators: City.*/ __( 'Harsány', 'describr' ),
        24 => /*translators: City.*/ __( 'Hejőbába', 'describr' ),
        25 => /*translators: City.*/ __( 'Hernádnémeti', 'describr' ),
        26 => /*translators: City.*/ __( 'Izsófalva', 'describr' ),
        27 => /*translators: City.*/ __( 'Járdánháza', 'describr' ),
        28 => /*translators: City.*/ __( 'Karcsa', 'describr' ),
        29 => /*translators: City.*/ __( 'Kazincbarcika', 'describr' ),
        30 => /*translators: City.*/ __( 'Kazincbarcikai Járás', 'describr' ),
        31 => /*translators: City.*/ __( 'Megyaszó', 'describr' ),
        32 => /*translators: City.*/ __( 'Mezőcsát', 'describr' ),
        33 => /*translators: City.*/ __( 'Mezőcsáti Járás', 'describr' ),
        34 => /*translators: City.*/ __( 'Mezőkeresztes', 'describr' ),
        35 => /*translators: City.*/ __( 'Mezőkövesd', 'describr' ),
        36 => /*translators: City.*/ __( 'Mezőkövesdi Járás', 'describr' ),
        37 => /*translators: City.*/ __( 'Mezőzombor', 'describr' ),
        38 => /*translators: City.*/ __( 'Miskolc', 'describr' ),
        39 => /*translators: City.*/ __( 'Miskolci Járás', 'describr' ),
        40 => /*translators: City.*/ __( 'Monok', 'describr' ),
        41 => /*translators: City.*/ __( 'Mád', 'describr' ),
        42 => /*translators: City.*/ __( 'Mályi', 'describr' ),
        43 => /*translators: City.*/ __( 'Múcsony', 'describr' ),
        44 => /*translators: City.*/ __( 'Nyékládháza', 'describr' ),
        45 => /*translators: City.*/ __( 'Olaszliszka', 'describr' ),
        46 => /*translators: City.*/ __( 'Onga', 'describr' ),
        47 => /*translators: City.*/ __( 'Prügy', 'describr' ),
        48 => /*translators: City.*/ __( 'Putnok', 'describr' ),
        49 => /*translators: City.*/ __( 'Putnoki Járás', 'describr' ),
        50 => /*translators: City.*/ __( 'Ricse', 'describr' ),
        51 => /*translators: City.*/ __( 'Rudabánya', 'describr' ),
        52 => /*translators: City.*/ __( 'Sajóbábony', 'describr' ),
        53 => /*translators: City.*/ __( 'Sajókaza', 'describr' ),
        54 => /*translators: City.*/ __( 'Sajólád', 'describr' ),
        55 => /*translators: City.*/ __( 'Sajószentpéter', 'describr' ),
        56 => /*translators: City.*/ __( 'Sajószöged', 'describr' ),
        57 => /*translators: City.*/ __( 'Sajóvámos', 'describr' ),
        58 => /*translators: City.*/ __( 'Sajóörös', 'describr' ),
        59 => /*translators: City.*/ __( 'Szendrő', 'describr' ),
        60 => /*translators: City.*/ __( 'Szentistván', 'describr' ),
        61 => /*translators: City.*/ __( 'Szerencs', 'describr' ),
        62 => /*translators: City.*/ __( 'Szerencsi Járás', 'describr' ),
        63 => /*translators: City.*/ __( 'Szikszó', 'describr' ),
        64 => /*translators: City.*/ __( 'Szikszói Járás', 'describr' ),
        65 => /*translators: City.*/ __( 'Szirmabesenyő', 'describr' ),
        66 => /*translators: City.*/ __( 'Sály', 'describr' ),
        67 => /*translators: City.*/ __( 'Sárospatak', 'describr' ),
        68 => /*translators: City.*/ __( 'Sárospataki Járás', 'describr' ),
        69 => /*translators: City.*/ __( 'Sátoraljaújhely', 'describr' ),
        70 => /*translators: City.*/ __( 'Sátoraljaújhelyi Járás', 'describr' ),
        71 => /*translators: City.*/ __( 'Taktaharkány', 'describr' ),
        72 => /*translators: City.*/ __( 'Taktaszada', 'describr' ),
        73 => /*translators: City.*/ __( 'Tarcal', 'describr' ),
        74 => /*translators: City.*/ __( 'Tiszakarád', 'describr' ),
        75 => /*translators: City.*/ __( 'Tiszakeszi', 'describr' ),
        76 => /*translators: City.*/ __( 'Tiszalúc', 'describr' ),
        77 => /*translators: City.*/ __( 'Tiszaújváros', 'describr' ),
        78 => /*translators: City.*/ __( 'Tiszaújvárosi Járás', 'describr' ),
        79 => /*translators: City.*/ __( 'Tokaj', 'describr' ),
        80 => /*translators: City.*/ __( 'Tokaji Járás', 'describr' ),
        81 => /*translators: City.*/ __( 'Tolcsva', 'describr' ),
        82 => /*translators: City.*/ __( 'Tállya', 'describr' ),
        83 => /*translators: City.*/ __( 'Ónod', 'describr' ),
        84 => /*translators: City.*/ __( 'Ózd', 'describr' ),
        85 => /*translators: City.*/ __( 'Ózdi Járás', 'describr' ),
      ),
    ),
    'PE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pest County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abony', 'describr' ),
        1 => /*translators: City.*/ __( 'Acsa', 'describr' ),
        2 => /*translators: City.*/ __( 'Albertirsa', 'describr' ),
        3 => /*translators: City.*/ __( 'Alsónémedi', 'describr' ),
        4 => /*translators: City.*/ __( 'Aszód', 'describr' ),
        5 => /*translators: City.*/ __( 'Aszódi Járás', 'describr' ),
        6 => /*translators: City.*/ __( 'Bag', 'describr' ),
        7 => /*translators: City.*/ __( 'Biatorbágy', 'describr' ),
        8 => /*translators: City.*/ __( 'Budakalász', 'describr' ),
        9 => /*translators: City.*/ __( 'Budakeszi', 'describr' ),
        10 => /*translators: City.*/ __( 'Budakeszi Járás', 'describr' ),
        11 => /*translators: City.*/ __( 'Budaörs', 'describr' ),
        12 => /*translators: City.*/ __( 'Bugyi', 'describr' ),
        13 => /*translators: City.*/ __( 'Cegléd', 'describr' ),
        14 => /*translators: City.*/ __( 'Ceglédbercel', 'describr' ),
        15 => /*translators: City.*/ __( 'Ceglédi Járás', 'describr' ),
        16 => /*translators: City.*/ __( 'Csemő', 'describr' ),
        17 => /*translators: City.*/ __( 'Csobánka', 'describr' ),
        18 => /*translators: City.*/ __( 'Csömör', 'describr' ),
        19 => /*translators: City.*/ __( 'Dabas', 'describr' ),
        20 => /*translators: City.*/ __( 'Dabasi Járás', 'describr' ),
        21 => /*translators: City.*/ __( 'Diósd', 'describr' ),
        22 => /*translators: City.*/ __( 'Domony', 'describr' ),
        23 => /*translators: City.*/ __( 'Dunabogdány', 'describr' ),
        24 => /*translators: City.*/ __( 'Dunaharaszti', 'describr' ),
        25 => /*translators: City.*/ __( 'Dunakeszi', 'describr' ),
        26 => /*translators: City.*/ __( 'Dunakeszi Járás', 'describr' ),
        27 => /*translators: City.*/ __( 'Dunavarsány', 'describr' ),
        28 => /*translators: City.*/ __( 'Dánszentmiklós', 'describr' ),
        29 => /*translators: City.*/ __( 'Dány', 'describr' ),
        30 => /*translators: City.*/ __( 'Délegyháza', 'describr' ),
        31 => /*translators: City.*/ __( 'Dömsöd', 'describr' ),
        32 => /*translators: City.*/ __( 'Ecser', 'describr' ),
        33 => /*translators: City.*/ __( 'Erdőkertes', 'describr' ),
        34 => /*translators: City.*/ __( 'Farmos', 'describr' ),
        35 => /*translators: City.*/ __( 'Felsőpakony', 'describr' ),
        36 => /*translators: City.*/ __( 'Forrópuszta', 'describr' ),
        37 => /*translators: City.*/ __( 'Fót', 'describr' ),
        38 => /*translators: City.*/ __( 'Galgahévíz', 'describr' ),
        39 => /*translators: City.*/ __( 'Galgamácsa', 'describr' ),
        40 => /*translators: City.*/ __( 'Gomba', 'describr' ),
        41 => /*translators: City.*/ __( 'Gyál', 'describr' ),
        42 => /*translators: City.*/ __( 'Gyáli Járás', 'describr' ),
        43 => /*translators: City.*/ __( 'Gyömrő', 'describr' ),
        44 => /*translators: City.*/ __( 'Göd', 'describr' ),
        45 => /*translators: City.*/ __( 'Gödöllő', 'describr' ),
        46 => /*translators: City.*/ __( 'Gödöllői Járás', 'describr' ),
        47 => /*translators: City.*/ __( 'Halásztelek', 'describr' ),
        48 => /*translators: City.*/ __( 'Hernád', 'describr' ),
        49 => /*translators: City.*/ __( 'Hévízgyörk', 'describr' ),
        50 => /*translators: City.*/ __( 'Iklad', 'describr' ),
        51 => /*translators: City.*/ __( 'Inárcs', 'describr' ),
        52 => /*translators: City.*/ __( 'Isaszeg', 'describr' ),
        53 => /*translators: City.*/ __( 'Jászkarajenő', 'describr' ),
        54 => /*translators: City.*/ __( 'Kakucs', 'describr' ),
        55 => /*translators: City.*/ __( 'Kartal', 'describr' ),
        56 => /*translators: City.*/ __( 'Kerepes', 'describr' ),
        57 => /*translators: City.*/ __( 'Kiskunlacháza', 'describr' ),
        58 => /*translators: City.*/ __( 'Kismaros', 'describr' ),
        59 => /*translators: City.*/ __( 'Kistarcsa', 'describr' ),
        60 => /*translators: City.*/ __( 'Kocsér', 'describr' ),
        61 => /*translators: City.*/ __( 'Kosd', 'describr' ),
        62 => /*translators: City.*/ __( 'Kóka', 'describr' ),
        63 => /*translators: City.*/ __( 'Leányfalu', 'describr' ),
        64 => /*translators: City.*/ __( 'Maglód', 'describr' ),
        65 => /*translators: City.*/ __( 'Mende', 'describr' ),
        66 => /*translators: City.*/ __( 'Mogyoród', 'describr' ),
        67 => /*translators: City.*/ __( 'Monor', 'describr' ),
        68 => /*translators: City.*/ __( 'Monori Járás', 'describr' ),
        69 => /*translators: City.*/ __( 'Nagykovácsi', 'describr' ),
        70 => /*translators: City.*/ __( 'Nagykáta', 'describr' ),
        71 => /*translators: City.*/ __( 'Nagykátai Járás', 'describr' ),
        72 => /*translators: City.*/ __( 'Nagykőrös', 'describr' ),
        73 => /*translators: City.*/ __( 'Nagykőrösi Járás', 'describr' ),
        74 => /*translators: City.*/ __( 'Nagymaros', 'describr' ),
        75 => /*translators: City.*/ __( 'Nagytarcsa', 'describr' ),
        76 => /*translators: City.*/ __( 'Nyáregyháza', 'describr' ),
        77 => /*translators: City.*/ __( 'Perbál', 'describr' ),
        78 => /*translators: City.*/ __( 'Pilis', 'describr' ),
        79 => /*translators: City.*/ __( 'Pilisborosjenő', 'describr' ),
        80 => /*translators: City.*/ __( 'Piliscsaba', 'describr' ),
        81 => /*translators: City.*/ __( 'Pilisszentiván', 'describr' ),
        82 => /*translators: City.*/ __( 'Pilisszentkereszt', 'describr' ),
        83 => /*translators: City.*/ __( 'Pilisszántó', 'describr' ),
        84 => /*translators: City.*/ __( 'Pilisvörösvár', 'describr' ),
        85 => /*translators: City.*/ __( 'Pilisvörösvári Járás', 'describr' ),
        86 => /*translators: City.*/ __( 'Pomáz', 'describr' ),
        87 => /*translators: City.*/ __( 'Pánd', 'describr' ),
        88 => /*translators: City.*/ __( 'Páty', 'describr' ),
        89 => /*translators: City.*/ __( 'Pécel', 'describr' ),
        90 => /*translators: City.*/ __( 'Péteri', 'describr' ),
        91 => /*translators: City.*/ __( 'Ráckeve', 'describr' ),
        92 => /*translators: City.*/ __( 'Ráckevei Járás', 'describr' ),
        93 => /*translators: City.*/ __( 'Solymár', 'describr' ),
        94 => /*translators: City.*/ __( 'Szada', 'describr' ),
        95 => /*translators: City.*/ __( 'Szentendre', 'describr' ),
        96 => /*translators: City.*/ __( 'Szentendrei Járás', 'describr' ),
        97 => /*translators: City.*/ __( 'Szentlőrinckáta', 'describr' ),
        98 => /*translators: City.*/ __( 'Szentmártonkáta', 'describr' ),
        99 => /*translators: City.*/ __( 'Szigetcsép', 'describr' ),
        100 => /*translators: City.*/ __( 'Szigethalom', 'describr' ),
        101 => /*translators: City.*/ __( 'Szigetszentmiklós', 'describr' ),
        102 => /*translators: City.*/ __( 'Szigetszentmiklósi Járás', 'describr' ),
        103 => /*translators: City.*/ __( 'Szigetújfalu', 'describr' ),
        104 => /*translators: City.*/ __( 'Szob', 'describr' ),
        105 => /*translators: City.*/ __( 'Szobi Járás', 'describr' ),
        106 => /*translators: City.*/ __( 'Százhalombatta', 'describr' ),
        107 => /*translators: City.*/ __( 'Sződ', 'describr' ),
        108 => /*translators: City.*/ __( 'Sződliget', 'describr' ),
        109 => /*translators: City.*/ __( 'Sóskút', 'describr' ),
        110 => /*translators: City.*/ __( 'Sülysáp', 'describr' ),
        111 => /*translators: City.*/ __( 'Tahitótfalu', 'describr' ),
        112 => /*translators: City.*/ __( 'Taksony', 'describr' ),
        113 => /*translators: City.*/ __( 'Telki', 'describr' ),
        114 => /*translators: City.*/ __( 'Tura', 'describr' ),
        115 => /*translators: City.*/ __( 'Táborfalva', 'describr' ),
        116 => /*translators: City.*/ __( 'Tápióbicske', 'describr' ),
        117 => /*translators: City.*/ __( 'Tápiógyörgye', 'describr' ),
        118 => /*translators: City.*/ __( 'Tápiószecső', 'describr' ),
        119 => /*translators: City.*/ __( 'Tápiószele', 'describr' ),
        120 => /*translators: City.*/ __( 'Tápiószentmárton', 'describr' ),
        121 => /*translators: City.*/ __( 'Tápiószőlős', 'describr' ),
        122 => /*translators: City.*/ __( 'Tápióság', 'describr' ),
        123 => /*translators: City.*/ __( 'Tárnok', 'describr' ),
        124 => /*translators: City.*/ __( 'Tóalmás', 'describr' ),
        125 => /*translators: City.*/ __( 'Tököl', 'describr' ),
        126 => /*translators: City.*/ __( 'Törtel', 'describr' ),
        127 => /*translators: City.*/ __( 'Törökbálint', 'describr' ),
        128 => /*translators: City.*/ __( 'Valkó', 'describr' ),
        129 => /*translators: City.*/ __( 'Vecsés', 'describr' ),
        130 => /*translators: City.*/ __( 'Vecsési Járás', 'describr' ),
        131 => /*translators: City.*/ __( 'Veresegyház', 'describr' ),
        132 => /*translators: City.*/ __( 'Verőce', 'describr' ),
        133 => /*translators: City.*/ __( 'Visegrád', 'describr' ),
        134 => /*translators: City.*/ __( 'Vác', 'describr' ),
        135 => /*translators: City.*/ __( 'Váci Járás', 'describr' ),
        136 => /*translators: City.*/ __( 'Vácszentlászló', 'describr' ),
        137 => /*translators: City.*/ __( 'Zsámbok', 'describr' ),
        138 => /*translators: City.*/ __( 'Zsámbék', 'describr' ),
        139 => /*translators: City.*/ __( 'Érd', 'describr' ),
        140 => /*translators: City.*/ __( 'Érdi Járás', 'describr' ),
        141 => /*translators: City.*/ __( 'Ócsa', 'describr' ),
        142 => /*translators: City.*/ __( 'Örkény', 'describr' ),
        143 => /*translators: City.*/ __( 'Újhartyán', 'describr' ),
        144 => /*translators: City.*/ __( 'Újszilvás', 'describr' ),
        145 => /*translators: City.*/ __( 'Úri', 'describr' ),
        146 => /*translators: City.*/ __( 'Üllő', 'describr' ),
        147 => /*translators: City.*/ __( 'Üröm', 'describr' ),
        148 => /*translators: City.*/ __( 'Őrbottyán', 'describr' ),
      ),
    ),
    'BE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Békés County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Battonya', 'describr' ),
        1 => /*translators: City.*/ __( 'Bucsa', 'describr' ),
        2 => /*translators: City.*/ __( 'Békés', 'describr' ),
        3 => /*translators: City.*/ __( 'Békéscsaba', 'describr' ),
        4 => /*translators: City.*/ __( 'Békéscsabai Járás', 'describr' ),
        5 => /*translators: City.*/ __( 'Békési Járás', 'describr' ),
        6 => /*translators: City.*/ __( 'Békésszentandrás', 'describr' ),
        7 => /*translators: City.*/ __( 'Békéssámson', 'describr' ),
        8 => /*translators: City.*/ __( 'Csanádapáca', 'describr' ),
        9 => /*translators: City.*/ __( 'Csorvás', 'describr' ),
        10 => /*translators: City.*/ __( 'Doboz', 'describr' ),
        11 => /*translators: City.*/ __( 'Dombegyház', 'describr' ),
        12 => /*translators: City.*/ __( 'Dévaványa', 'describr' ),
        13 => /*translators: City.*/ __( 'Elek', 'describr' ),
        14 => /*translators: City.*/ __( 'Füzesgyarmat', 'describr' ),
        15 => /*translators: City.*/ __( 'Gyomaendrőd', 'describr' ),
        16 => /*translators: City.*/ __( 'Gyomaendrődi Járás', 'describr' ),
        17 => /*translators: City.*/ __( 'Gyula', 'describr' ),
        18 => /*translators: City.*/ __( 'Gyulai Járás', 'describr' ),
        19 => /*translators: City.*/ __( 'Gádoros', 'describr' ),
        20 => /*translators: City.*/ __( 'Kaszaper', 'describr' ),
        21 => /*translators: City.*/ __( 'Kevermes', 'describr' ),
        22 => /*translators: City.*/ __( 'Kondoros', 'describr' ),
        23 => /*translators: City.*/ __( 'Kunágota', 'describr' ),
        24 => /*translators: City.*/ __( 'Kétegyháza', 'describr' ),
        25 => /*translators: City.*/ __( 'Körösladány', 'describr' ),
        26 => /*translators: City.*/ __( 'Köröstarcsa', 'describr' ),
        27 => /*translators: City.*/ __( 'Lőkösháza', 'describr' ),
        28 => /*translators: City.*/ __( 'Magyarbánhegyes', 'describr' ),
        29 => /*translators: City.*/ __( 'Medgyesegyháza', 'describr' ),
        30 => /*translators: City.*/ __( 'Mezőberény', 'describr' ),
        31 => /*translators: City.*/ __( 'Mezőhegyes', 'describr' ),
        32 => /*translators: City.*/ __( 'Mezőkovácsháza', 'describr' ),
        33 => /*translators: City.*/ __( 'Mezőkovácsházai Járás', 'describr' ),
        34 => /*translators: City.*/ __( 'Méhkerék', 'describr' ),
        35 => /*translators: City.*/ __( 'Nagyszénás', 'describr' ),
        36 => /*translators: City.*/ __( 'Okány', 'describr' ),
        37 => /*translators: City.*/ __( 'Orosháza', 'describr' ),
        38 => /*translators: City.*/ __( 'Orosházi Járás', 'describr' ),
        39 => /*translators: City.*/ __( 'Pusztaföldvár', 'describr' ),
        40 => /*translators: City.*/ __( 'Sarkad', 'describr' ),
        41 => /*translators: City.*/ __( 'Sarkadi Járás', 'describr' ),
        42 => /*translators: City.*/ __( 'Szabadkígyós', 'describr' ),
        43 => /*translators: City.*/ __( 'Szarvas', 'describr' ),
        44 => /*translators: City.*/ __( 'Szarvasi Járás', 'describr' ),
        45 => /*translators: City.*/ __( 'Szeghalmi Járás', 'describr' ),
        46 => /*translators: City.*/ __( 'Szeghalom', 'describr' ),
        47 => /*translators: City.*/ __( 'Tótkomlós', 'describr' ),
        48 => /*translators: City.*/ __( 'Vésztő', 'describr' ),
        49 => /*translators: City.*/ __( 'Újkígyós', 'describr' ),
      ),
    ),
    'HB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hajdú-Bihar County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bagamér', 'describr' ),
        1 => /*translators: City.*/ __( 'Balmazújváros', 'describr' ),
        2 => /*translators: City.*/ __( 'Balmazújvárosi Járás', 'describr' ),
        3 => /*translators: City.*/ __( 'Berettyóújfalu', 'describr' ),
        4 => /*translators: City.*/ __( 'Berettyóújfalui Járás', 'describr' ),
        5 => /*translators: City.*/ __( 'Biharkeresztes', 'describr' ),
        6 => /*translators: City.*/ __( 'Biharnagybajom', 'describr' ),
        7 => /*translators: City.*/ __( 'Báránd', 'describr' ),
        8 => /*translators: City.*/ __( 'Csökmő', 'describr' ),
        9 => /*translators: City.*/ __( 'Debrecen', 'describr' ),
        10 => /*translators: City.*/ __( 'Debreceni Járás', 'describr' ),
        11 => /*translators: City.*/ __( 'Derecske', 'describr' ),
        12 => /*translators: City.*/ __( 'Derecskei Járás', 'describr' ),
        13 => /*translators: City.*/ __( 'Ebes', 'describr' ),
        14 => /*translators: City.*/ __( 'Egyek', 'describr' ),
        15 => /*translators: City.*/ __( 'Földes', 'describr' ),
        16 => /*translators: City.*/ __( 'Görbeháza', 'describr' ),
        17 => /*translators: City.*/ __( 'Hadjúszoboszlói Járás', 'describr' ),
        18 => /*translators: City.*/ __( 'Hajdúbagos', 'describr' ),
        19 => /*translators: City.*/ __( 'Hajdúböszörmény', 'describr' ),
        20 => /*translators: City.*/ __( 'Hajdúböszörményi Járás', 'describr' ),
        21 => /*translators: City.*/ __( 'Hajdúdorog', 'describr' ),
        22 => /*translators: City.*/ __( 'Hajdúhadház', 'describr' ),
        23 => /*translators: City.*/ __( 'Hajdúhadházi Járás', 'describr' ),
        24 => /*translators: City.*/ __( 'Hajdúnánás', 'describr' ),
        25 => /*translators: City.*/ __( 'Hajdúnánási Járás', 'describr' ),
        26 => /*translators: City.*/ __( 'Hajdúszoboszló', 'describr' ),
        27 => /*translators: City.*/ __( 'Hajdúszovát', 'describr' ),
        28 => /*translators: City.*/ __( 'Hajdúsámson', 'describr' ),
        29 => /*translators: City.*/ __( 'Hortobágy', 'describr' ),
        30 => /*translators: City.*/ __( 'Hosszúpályi', 'describr' ),
        31 => /*translators: City.*/ __( 'Kaba', 'describr' ),
        32 => /*translators: City.*/ __( 'Komádi', 'describr' ),
        33 => /*translators: City.*/ __( 'Konyár', 'describr' ),
        34 => /*translators: City.*/ __( 'Létavértes', 'describr' ),
        35 => /*translators: City.*/ __( 'Mikepércs', 'describr' ),
        36 => /*translators: City.*/ __( 'Monostorpályi', 'describr' ),
        37 => /*translators: City.*/ __( 'Nagyrábé', 'describr' ),
        38 => /*translators: City.*/ __( 'Nyíracsád', 'describr' ),
        39 => /*translators: City.*/ __( 'Nyíradony', 'describr' ),
        40 => /*translators: City.*/ __( 'Nyíradonyi Járás', 'describr' ),
        41 => /*translators: City.*/ __( 'Nyírmártonfalva', 'describr' ),
        42 => /*translators: City.*/ __( 'Nyírábrány', 'describr' ),
        43 => /*translators: City.*/ __( 'Nádudvar', 'describr' ),
        44 => /*translators: City.*/ __( 'Pocsaj', 'describr' ),
        45 => /*translators: City.*/ __( 'Polgár', 'describr' ),
        46 => /*translators: City.*/ __( 'Püspökladány', 'describr' ),
        47 => /*translators: City.*/ __( 'Püspökladányi Járás', 'describr' ),
        48 => /*translators: City.*/ __( 'Sárrétudvari', 'describr' ),
        49 => /*translators: City.*/ __( 'Sáránd', 'describr' ),
        50 => /*translators: City.*/ __( 'Tiszacsege', 'describr' ),
        51 => /*translators: City.*/ __( 'Téglás', 'describr' ),
        52 => /*translators: City.*/ __( 'Vámospércs', 'describr' ),
      ),
    ),
    'BU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Budapest', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Budapest', 'describr' ),
        1 => /*translators: City.*/ __( 'Budapest I. kerület', 'describr' ),
        2 => /*translators: City.*/ __( 'Budapest II. kerület', 'describr' ),
        3 => /*translators: City.*/ __( 'Budapest III. kerület', 'describr' ),
        4 => /*translators: City.*/ __( 'Budapest IV. kerület', 'describr' ),
        5 => /*translators: City.*/ __( 'Budapest VI. kerület', 'describr' ),
        6 => /*translators: City.*/ __( 'Budapest VIII. kerület', 'describr' ),
        7 => /*translators: City.*/ __( 'Budapest X. kerület', 'describr' ),
        8 => /*translators: City.*/ __( 'Budapest XI. kerület', 'describr' ),
        9 => /*translators: City.*/ __( 'Budapest XII. kerület', 'describr' ),
        10 => /*translators: City.*/ __( 'Budapest XIII. kerület', 'describr' ),
        11 => /*translators: City.*/ __( 'Budapest XV. kerület', 'describr' ),
        12 => /*translators: City.*/ __( 'Budapest XVI. kerület', 'describr' ),
        13 => /*translators: City.*/ __( 'Budapest XVII. kerület', 'describr' ),
        14 => /*translators: City.*/ __( 'Budapest XVIII. kerület', 'describr' ),
        15 => /*translators: City.*/ __( 'Budapest XX. kerület', 'describr' ),
        16 => /*translators: City.*/ __( 'Budapest XXI. kerület', 'describr' ),
        17 => /*translators: City.*/ __( 'Budapest XXII. kerület', 'describr' ),
        18 => /*translators: City.*/ __( 'Budapest XXIII. kerület', 'describr' ),
        19 => /*translators: City.*/ __( 'Erzsébetváros', 'describr' ),
        20 => /*translators: City.*/ __( 'Józsefváros', 'describr' ),
        21 => /*translators: City.*/ __( 'Kispest', 'describr' ),
        22 => /*translators: City.*/ __( 'Zugló', 'describr' ),
      ),
    ),
  ),
  'IE' => 
  array (
    'L' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Leinster', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abbeyleix', 'describr' ),
        1 => /*translators: City.*/ __( 'An Iarmhí', 'describr' ),
        2 => /*translators: City.*/ __( 'An Longfort', 'describr' ),
        3 => /*translators: City.*/ __( 'An Mhí', 'describr' ),
        4 => /*translators: City.*/ __( 'An Muileann gCearr', 'describr' ),
        5 => /*translators: City.*/ __( 'An Ros', 'describr' ),
        6 => /*translators: City.*/ __( 'Ardee', 'describr' ),
        7 => /*translators: City.*/ __( 'Arklow', 'describr' ),
        8 => /*translators: City.*/ __( 'Artane', 'describr' ),
        9 => /*translators: City.*/ __( 'Ashbourne', 'describr' ),
        10 => /*translators: City.*/ __( 'Ashford', 'describr' ),
        11 => /*translators: City.*/ __( 'Athboy', 'describr' ),
        12 => /*translators: City.*/ __( 'Athgarvan', 'describr' ),
        13 => /*translators: City.*/ __( 'Athlone', 'describr' ),
        14 => /*translators: City.*/ __( 'Athy', 'describr' ),
        15 => /*translators: City.*/ __( 'Aughrim', 'describr' ),
        16 => /*translators: City.*/ __( 'Bagenalstown', 'describr' ),
        17 => /*translators: City.*/ __( 'Balally', 'describr' ),
        18 => /*translators: City.*/ __( 'Balbriggan', 'describr' ),
        19 => /*translators: City.*/ __( 'Baldoyle', 'describr' ),
        20 => /*translators: City.*/ __( 'Ballinroad', 'describr' ),
        21 => /*translators: City.*/ __( 'Ballinteer', 'describr' ),
        22 => /*translators: City.*/ __( 'Ballivor', 'describr' ),
        23 => /*translators: City.*/ __( 'Ballyboden', 'describr' ),
        24 => /*translators: City.*/ __( 'Ballyfermot', 'describr' ),
        25 => /*translators: City.*/ __( 'Ballygerry', 'describr' ),
        26 => /*translators: City.*/ __( 'Ballylinan', 'describr' ),
        27 => /*translators: City.*/ __( 'Ballymahon', 'describr' ),
        28 => /*translators: City.*/ __( 'Ballymun', 'describr' ),
        29 => /*translators: City.*/ __( 'Ballyragget', 'describr' ),
        30 => /*translators: City.*/ __( 'Balrothery', 'describr' ),
        31 => /*translators: City.*/ __( 'Baltinglass', 'describr' ),
        32 => /*translators: City.*/ __( 'Banagher', 'describr' ),
        33 => /*translators: City.*/ __( 'Bayside', 'describr' ),
        34 => /*translators: City.*/ __( 'Beaumont', 'describr' ),
        35 => /*translators: City.*/ __( 'Birr', 'describr' ),
        36 => /*translators: City.*/ __( 'Blackrock', 'describr' ),
        37 => /*translators: City.*/ __( 'Blanchardstown', 'describr' ),
        38 => /*translators: City.*/ __( 'Blessington', 'describr' ),
        39 => /*translators: City.*/ __( 'Bonnybrook', 'describr' ),
        40 => /*translators: City.*/ __( 'Booterstown', 'describr' ),
        41 => /*translators: City.*/ __( 'Bray', 'describr' ),
        42 => /*translators: City.*/ __( 'Bunclody', 'describr' ),
        43 => /*translators: City.*/ __( 'Cabinteely', 'describr' ),
        44 => /*translators: City.*/ __( 'Cabra', 'describr' ),
        45 => /*translators: City.*/ __( 'Callan', 'describr' ),
        46 => /*translators: City.*/ __( 'Carlingford', 'describr' ),
        47 => /*translators: City.*/ __( 'Carlow', 'describr' ),
        48 => /*translators: City.*/ __( 'Carnew', 'describr' ),
        49 => /*translators: City.*/ __( 'Castlebellingham', 'describr' ),
        50 => /*translators: City.*/ __( 'Castlebridge', 'describr' ),
        51 => /*translators: City.*/ __( 'Castlecomer', 'describr' ),
        52 => /*translators: City.*/ __( 'Castledermot', 'describr' ),
        53 => /*translators: City.*/ __( 'Castleknock', 'describr' ),
        54 => /*translators: City.*/ __( 'Castlepollard', 'describr' ),
        55 => /*translators: City.*/ __( 'Castletown', 'describr' ),
        56 => /*translators: City.*/ __( 'Celbridge', 'describr' ),
        57 => /*translators: City.*/ __( 'Chapelizod', 'describr' ),
        58 => /*translators: City.*/ __( 'Charlesland', 'describr' ),
        59 => /*translators: City.*/ __( 'Cherry Orchard', 'describr' ),
        60 => /*translators: City.*/ __( 'Cherryville', 'describr' ),
        61 => /*translators: City.*/ __( 'Clane', 'describr' ),
        62 => /*translators: City.*/ __( 'Clara', 'describr' ),
        63 => /*translators: City.*/ __( 'Clogherhead', 'describr' ),
        64 => /*translators: City.*/ __( 'Clondalkin', 'describr' ),
        65 => /*translators: City.*/ __( 'Clonskeagh', 'describr' ),
        66 => /*translators: City.*/ __( 'Confey', 'describr' ),
        67 => /*translators: City.*/ __( 'Coolock', 'describr' ),
        68 => /*translators: City.*/ __( 'County Carlow', 'describr' ),
        69 => /*translators: City.*/ __( 'Courtown', 'describr' ),
        70 => /*translators: City.*/ __( 'Crumlin', 'describr' ),
        71 => /*translators: City.*/ __( 'Daingean', 'describr' ),
        72 => /*translators: City.*/ __( 'Dalkey', 'describr' ),
        73 => /*translators: City.*/ __( 'Darndale', 'describr' ),
        74 => /*translators: City.*/ __( 'Derrinturn', 'describr' ),
        75 => /*translators: City.*/ __( 'Dollymount', 'describr' ),
        76 => /*translators: City.*/ __( 'Donabate', 'describr' ),
        77 => /*translators: City.*/ __( 'Donaghmede', 'describr' ),
        78 => /*translators: City.*/ __( 'Donnybrook', 'describr' ),
        79 => /*translators: City.*/ __( 'Donnycarney', 'describr' ),
        80 => /*translators: City.*/ __( 'Drogheda', 'describr' ),
        81 => /*translators: City.*/ __( 'Droichead Nua', 'describr' ),
        82 => /*translators: City.*/ __( 'Dromiskin', 'describr' ),
        83 => /*translators: City.*/ __( 'Drumcondra', 'describr' ),
        84 => /*translators: City.*/ __( 'Dublin', 'describr' ),
        85 => /*translators: City.*/ __( 'Dublin City', 'describr' ),
        86 => /*translators: City.*/ __( 'Duleek', 'describr' ),
        87 => /*translators: City.*/ __( 'Dunboyne', 'describr' ),
        88 => /*translators: City.*/ __( 'Dundalk', 'describr' ),
        89 => /*translators: City.*/ __( 'Dundrum', 'describr' ),
        90 => /*translators: City.*/ __( 'Dunleer', 'describr' ),
        91 => /*translators: City.*/ __( 'Dunshaughlin', 'describr' ),
        92 => /*translators: City.*/ __( 'Dún Laoghaire', 'describr' ),
        93 => /*translators: City.*/ __( 'Dún Laoghaire-Rathdown', 'describr' ),
        94 => /*translators: City.*/ __( 'Eadestown', 'describr' ),
        95 => /*translators: City.*/ __( 'Edenderry', 'describr' ),
        96 => /*translators: City.*/ __( 'Edgeworthstown', 'describr' ),
        97 => /*translators: City.*/ __( 'Enfield', 'describr' ),
        98 => /*translators: City.*/ __( 'Enniscorthy', 'describr' ),
        99 => /*translators: City.*/ __( 'Enniskerry', 'describr' ),
        100 => /*translators: City.*/ __( 'Fairview', 'describr' ),
        101 => /*translators: City.*/ __( 'Ferbane', 'describr' ),
        102 => /*translators: City.*/ __( 'Ferns', 'describr' ),
        103 => /*translators: City.*/ __( 'Fingal County', 'describr' ),
        104 => /*translators: City.*/ __( 'Finglas', 'describr' ),
        105 => /*translators: City.*/ __( 'Firhouse', 'describr' ),
        106 => /*translators: City.*/ __( 'Foxrock', 'describr' ),
        107 => /*translators: City.*/ __( 'Glasnevin', 'describr' ),
        108 => /*translators: City.*/ __( 'Gorey', 'describr' ),
        109 => /*translators: City.*/ __( 'Graiguenamanagh', 'describr' ),
        110 => /*translators: City.*/ __( 'Granard', 'describr' ),
        111 => /*translators: City.*/ __( 'Greenhills', 'describr' ),
        112 => /*translators: City.*/ __( 'Greystones', 'describr' ),
        113 => /*translators: City.*/ __( 'Hartstown', 'describr' ),
        114 => /*translators: City.*/ __( 'Howth', 'describr' ),
        115 => /*translators: City.*/ __( 'Jobstown', 'describr' ),
        116 => /*translators: City.*/ __( 'Johnstown', 'describr' ),
        117 => /*translators: City.*/ __( 'Kells', 'describr' ),
        118 => /*translators: City.*/ __( 'Kentstown', 'describr' ),
        119 => /*translators: City.*/ __( 'Kilbeggan', 'describr' ),
        120 => /*translators: City.*/ __( 'Kilcock', 'describr' ),
        121 => /*translators: City.*/ __( 'Kilcoole', 'describr' ),
        122 => /*translators: City.*/ __( 'Kilcullen', 'describr' ),
        123 => /*translators: City.*/ __( 'Kildare', 'describr' ),
        124 => /*translators: City.*/ __( 'Kilkenny', 'describr' ),
        125 => /*translators: City.*/ __( 'Kill', 'describr' ),
        126 => /*translators: City.*/ __( 'Killester', 'describr' ),
        127 => /*translators: City.*/ __( 'Kilmacanoge', 'describr' ),
        128 => /*translators: City.*/ __( 'Kilpedder', 'describr' ),
        129 => /*translators: City.*/ __( 'Kilquade', 'describr' ),
        130 => /*translators: City.*/ __( 'Kinnegad', 'describr' ),
        131 => /*translators: City.*/ __( 'Kinsealy-Drinan', 'describr' ),
        132 => /*translators: City.*/ __( 'Knocklyon', 'describr' ),
        133 => /*translators: City.*/ __( 'Lanesborough', 'describr' ),
        134 => /*translators: City.*/ __( 'Laois', 'describr' ),
        135 => /*translators: City.*/ __( 'Laytown', 'describr' ),
        136 => /*translators: City.*/ __( 'Leixlip', 'describr' ),
        137 => /*translators: City.*/ __( 'Little Bray', 'describr' ),
        138 => /*translators: City.*/ __( 'Loch Garman', 'describr' ),
        139 => /*translators: City.*/ __( 'Longford', 'describr' ),
        140 => /*translators: City.*/ __( 'Longwood', 'describr' ),
        141 => /*translators: City.*/ __( 'Loughlinstown', 'describr' ),
        142 => /*translators: City.*/ __( 'Lucan', 'describr' ),
        143 => /*translators: City.*/ __( 'Lusk', 'describr' ),
        144 => /*translators: City.*/ __( 'Lú', 'describr' ),
        145 => /*translators: City.*/ __( 'Malahide', 'describr' ),
        146 => /*translators: City.*/ __( 'Marino', 'describr' ),
        147 => /*translators: City.*/ __( 'Maynooth', 'describr' ),
        148 => /*translators: City.*/ __( 'Milltown', 'describr' ),
        149 => /*translators: City.*/ __( 'Moate', 'describr' ),
        150 => /*translators: City.*/ __( 'Monasterevin', 'describr' ),
        151 => /*translators: City.*/ __( 'Monkstown', 'describr' ),
        152 => /*translators: City.*/ __( 'Mooncoin', 'describr' ),
        153 => /*translators: City.*/ __( 'Moone', 'describr' ),
        154 => /*translators: City.*/ __( 'Mount Merrion', 'describr' ),
        155 => /*translators: City.*/ __( 'Mountmellick', 'describr' ),
        156 => /*translators: City.*/ __( 'Mountrath', 'describr' ),
        157 => /*translators: City.*/ __( 'Naas', 'describr' ),
        158 => /*translators: City.*/ __( 'Navan', 'describr' ),
        159 => /*translators: City.*/ __( 'New Ross', 'describr' ),
        160 => /*translators: City.*/ __( 'Newcastle', 'describr' ),
        161 => /*translators: City.*/ __( 'Newtown Trim', 'describr' ),
        162 => /*translators: City.*/ __( 'Newtownmountkennedy', 'describr' ),
        163 => /*translators: City.*/ __( 'Old Kilcullen', 'describr' ),
        164 => /*translators: City.*/ __( 'Oldbawn', 'describr' ),
        165 => /*translators: City.*/ __( 'Oldcastle', 'describr' ),
        166 => /*translators: City.*/ __( 'Palmerstown', 'describr' ),
        167 => /*translators: City.*/ __( 'Piltown', 'describr' ),
        168 => /*translators: City.*/ __( 'Portarlington', 'describr' ),
        169 => /*translators: City.*/ __( 'Portlaoise', 'describr' ),
        170 => /*translators: City.*/ __( 'Portmarnock', 'describr' ),
        171 => /*translators: City.*/ __( 'Portraine', 'describr' ),
        172 => /*translators: City.*/ __( 'Prosperous', 'describr' ),
        173 => /*translators: City.*/ __( 'Raheny', 'describr' ),
        174 => /*translators: City.*/ __( 'Rathangan', 'describr' ),
        175 => /*translators: City.*/ __( 'Rathcoole', 'describr' ),
        176 => /*translators: City.*/ __( 'Rathdowney', 'describr' ),
        177 => /*translators: City.*/ __( 'Rathdrum', 'describr' ),
        178 => /*translators: City.*/ __( 'Rathgar', 'describr' ),
        179 => /*translators: City.*/ __( 'Rathmines', 'describr' ),
        180 => /*translators: City.*/ __( 'Rathnew', 'describr' ),
        181 => /*translators: City.*/ __( 'Rathwire', 'describr' ),
        182 => /*translators: City.*/ __( 'Ratoath', 'describr' ),
        183 => /*translators: City.*/ __( 'Rialto', 'describr' ),
        184 => /*translators: City.*/ __( 'Ringsend', 'describr' ),
        185 => /*translators: City.*/ __( 'Rochfortbridge', 'describr' ),
        186 => /*translators: City.*/ __( 'Rosslare', 'describr' ),
        187 => /*translators: City.*/ __( 'Saggart', 'describr' ),
        188 => /*translators: City.*/ __( 'Sallins', 'describr' ),
        189 => /*translators: City.*/ __( 'Sallynoggin', 'describr' ),
        190 => /*translators: City.*/ __( 'Sandyford', 'describr' ),
        191 => /*translators: City.*/ __( 'Sandymount', 'describr' ),
        192 => /*translators: City.*/ __( 'Shankill', 'describr' ),
        193 => /*translators: City.*/ __( 'Skerries', 'describr' ),
        194 => /*translators: City.*/ __( 'Slane', 'describr' ),
        195 => /*translators: City.*/ __( 'South Dublin', 'describr' ),
        196 => /*translators: City.*/ __( 'Stamullin', 'describr' ),
        197 => /*translators: City.*/ __( 'Stradbally', 'describr' ),
        198 => /*translators: City.*/ __( 'Sutton', 'describr' ),
        199 => /*translators: City.*/ __( 'Swords', 'describr' ),
        200 => /*translators: City.*/ __( 'Tallaght', 'describr' ),
        201 => /*translators: City.*/ __( 'Templeogue', 'describr' ),
        202 => /*translators: City.*/ __( 'Terenure', 'describr' ),
        203 => /*translators: City.*/ __( 'Termonfeckin', 'describr' ),
        204 => /*translators: City.*/ __( 'Thomastown', 'describr' ),
        205 => /*translators: City.*/ __( 'Trim', 'describr' ),
        206 => /*translators: City.*/ __( 'Tullamore', 'describr' ),
        207 => /*translators: City.*/ __( 'Tullow', 'describr' ),
        208 => /*translators: City.*/ __( 'Tullyallen', 'describr' ),
        209 => /*translators: City.*/ __( 'Uíbh Fhailí', 'describr' ),
        210 => /*translators: City.*/ __( 'Valleymount', 'describr' ),
        211 => /*translators: City.*/ __( 'Wicklow', 'describr' ),
      ),
    ),
    'M' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Munster', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abbeyfeale', 'describr' ),
        1 => /*translators: City.*/ __( 'Adare', 'describr' ),
        2 => /*translators: City.*/ __( 'Aghada', 'describr' ),
        3 => /*translators: City.*/ __( 'An Clár', 'describr' ),
        4 => /*translators: City.*/ __( 'Annacotty', 'describr' ),
        5 => /*translators: City.*/ __( 'Ardnacrusha', 'describr' ),
        6 => /*translators: City.*/ __( 'Askeaton', 'describr' ),
        7 => /*translators: City.*/ __( 'Ballina', 'describr' ),
        8 => /*translators: City.*/ __( 'Ballybunnion', 'describr' ),
        9 => /*translators: City.*/ __( 'Bandon', 'describr' ),
        10 => /*translators: City.*/ __( 'Bantry', 'describr' ),
        11 => /*translators: City.*/ __( 'Blarney', 'describr' ),
        12 => /*translators: City.*/ __( 'Caherconlish', 'describr' ),
        13 => /*translators: City.*/ __( 'Cahersiveen', 'describr' ),
        14 => /*translators: City.*/ __( 'Cahir', 'describr' ),
        15 => /*translators: City.*/ __( 'Carrick-on-Suir', 'describr' ),
        16 => /*translators: City.*/ __( 'Carrigaline', 'describr' ),
        17 => /*translators: City.*/ __( 'Carrigtwohill', 'describr' ),
        18 => /*translators: City.*/ __( 'Cashel', 'describr' ),
        19 => /*translators: City.*/ __( 'Castleconnell', 'describr' ),
        20 => /*translators: City.*/ __( 'Castleisland', 'describr' ),
        21 => /*translators: City.*/ __( 'Castlemartyr', 'describr' ),
        22 => /*translators: City.*/ __( 'Ciarraí', 'describr' ),
        23 => /*translators: City.*/ __( 'Cill Airne', 'describr' ),
        24 => /*translators: City.*/ __( 'Clonakilty', 'describr' ),
        25 => /*translators: City.*/ __( 'Cloyne', 'describr' ),
        26 => /*translators: City.*/ __( 'Cluain Meala', 'describr' ),
        27 => /*translators: City.*/ __( 'Cobh', 'describr' ),
        28 => /*translators: City.*/ __( 'Cork', 'describr' ),
        29 => /*translators: City.*/ __( 'Cork City', 'describr' ),
        30 => /*translators: City.*/ __( 'County Cork', 'describr' ),
        31 => /*translators: City.*/ __( 'County Tipperary', 'describr' ),
        32 => /*translators: City.*/ __( 'Croom', 'describr' ),
        33 => /*translators: City.*/ __( 'Crosshaven', 'describr' ),
        34 => /*translators: City.*/ __( 'Derry', 'describr' ),
        35 => /*translators: City.*/ __( 'Dingle', 'describr' ),
        36 => /*translators: City.*/ __( 'Dungarvan', 'describr' ),
        37 => /*translators: City.*/ __( 'Dunmanway', 'describr' ),
        38 => /*translators: City.*/ __( 'Dunmore East', 'describr' ),
        39 => /*translators: City.*/ __( 'Ennis', 'describr' ),
        40 => /*translators: City.*/ __( 'Fermoy', 'describr' ),
        41 => /*translators: City.*/ __( 'Fethard', 'describr' ),
        42 => /*translators: City.*/ __( 'Kanturk', 'describr' ),
        43 => /*translators: City.*/ __( 'Kenmare', 'describr' ),
        44 => /*translators: City.*/ __( 'Killaloe', 'describr' ),
        45 => /*translators: City.*/ __( 'Killorglin', 'describr' ),
        46 => /*translators: City.*/ __( 'Killumney', 'describr' ),
        47 => /*translators: City.*/ __( 'Kilmallock', 'describr' ),
        48 => /*translators: City.*/ __( 'Kilrush', 'describr' ),
        49 => /*translators: City.*/ __( 'Kinsale', 'describr' ),
        50 => /*translators: City.*/ __( 'Listowel', 'describr' ),
        51 => /*translators: City.*/ __( 'Luimneach', 'describr' ),
        52 => /*translators: City.*/ __( 'Macroom', 'describr' ),
        53 => /*translators: City.*/ __( 'Mallow', 'describr' ),
        54 => /*translators: City.*/ __( 'Midleton', 'describr' ),
        55 => /*translators: City.*/ __( 'Millstreet', 'describr' ),
        56 => /*translators: City.*/ __( 'Mitchelstown', 'describr' ),
        57 => /*translators: City.*/ __( 'Moroe', 'describr' ),
        58 => /*translators: City.*/ __( 'Moyross', 'describr' ),
        59 => /*translators: City.*/ __( 'Nenagh', 'describr' ),
        60 => /*translators: City.*/ __( 'Nenagh Bridge', 'describr' ),
        61 => /*translators: City.*/ __( 'Newcastle West', 'describr' ),
        62 => /*translators: City.*/ __( 'Newmarket on Fergus', 'describr' ),
        63 => /*translators: City.*/ __( 'Newport', 'describr' ),
        64 => /*translators: City.*/ __( 'Passage West', 'describr' ),
        65 => /*translators: City.*/ __( 'Portlaw', 'describr' ),
        66 => /*translators: City.*/ __( 'Rathcormac', 'describr' ),
        67 => /*translators: City.*/ __( 'Rathkeale', 'describr' ),
        68 => /*translators: City.*/ __( 'Roscrea', 'describr' ),
        69 => /*translators: City.*/ __( 'Ráth Luirc', 'describr' ),
        70 => /*translators: City.*/ __( 'Shannon', 'describr' ),
        71 => /*translators: City.*/ __( 'Sixmilebridge', 'describr' ),
        72 => /*translators: City.*/ __( 'Skibbereen', 'describr' ),
        73 => /*translators: City.*/ __( 'Templemore', 'describr' ),
        74 => /*translators: City.*/ __( 'Thurles', 'describr' ),
        75 => /*translators: City.*/ __( 'Tipperary', 'describr' ),
        76 => /*translators: City.*/ __( 'Tower', 'describr' ),
        77 => /*translators: City.*/ __( 'Tralee', 'describr' ),
        78 => /*translators: City.*/ __( 'Trá Mhór', 'describr' ),
        79 => /*translators: City.*/ __( 'Waterford', 'describr' ),
        80 => /*translators: City.*/ __( 'Watergrasshill', 'describr' ),
        81 => /*translators: City.*/ __( 'Whitegate', 'describr' ),
        82 => /*translators: City.*/ __( 'Youghal', 'describr' ),
      ),
    ),
    'U' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ulster', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'An Cabhán', 'describr' ),
        1 => /*translators: City.*/ __( 'Bailieborough', 'describr' ),
        2 => /*translators: City.*/ __( 'Ballybofey', 'describr' ),
        3 => /*translators: City.*/ __( 'Ballyconnell', 'describr' ),
        4 => /*translators: City.*/ __( 'Ballyjamesduff', 'describr' ),
        5 => /*translators: City.*/ __( 'Ballyshannon', 'describr' ),
        6 => /*translators: City.*/ __( 'Belturbet', 'describr' ),
        7 => /*translators: City.*/ __( 'Buncrana', 'describr' ),
        8 => /*translators: City.*/ __( 'Bundoran', 'describr' ),
        9 => /*translators: City.*/ __( 'Carndonagh', 'describr' ),
        10 => /*translators: City.*/ __( 'Carrickmacross', 'describr' ),
        11 => /*translators: City.*/ __( 'Castleblayney', 'describr' ),
        12 => /*translators: City.*/ __( 'Cavan', 'describr' ),
        13 => /*translators: City.*/ __( 'Clones', 'describr' ),
        14 => /*translators: City.*/ __( 'Convoy', 'describr' ),
        15 => /*translators: City.*/ __( 'Cootehill', 'describr' ),
        16 => /*translators: City.*/ __( 'County Donegal', 'describr' ),
        17 => /*translators: City.*/ __( 'County Monaghan', 'describr' ),
        18 => /*translators: City.*/ __( 'Derrybeg', 'describr' ),
        19 => /*translators: City.*/ __( 'Donegal', 'describr' ),
        20 => /*translators: City.*/ __( 'Dungloe', 'describr' ),
        21 => /*translators: City.*/ __( 'Dunlewy', 'describr' ),
        22 => /*translators: City.*/ __( 'Gweedore', 'describr' ),
        23 => /*translators: City.*/ __( 'Killybegs', 'describr' ),
        24 => /*translators: City.*/ __( 'Kingscourt', 'describr' ),
        25 => /*translators: City.*/ __( 'Leifear', 'describr' ),
        26 => /*translators: City.*/ __( 'Letterkenny', 'describr' ),
        27 => /*translators: City.*/ __( 'Monaghan', 'describr' ),
        28 => /*translators: City.*/ __( 'Moville', 'describr' ),
        29 => /*translators: City.*/ __( 'Muff', 'describr' ),
        30 => /*translators: City.*/ __( 'Mullagh', 'describr' ),
        31 => /*translators: City.*/ __( 'Newtown Cunningham', 'describr' ),
        32 => /*translators: City.*/ __( 'Ramelton', 'describr' ),
        33 => /*translators: City.*/ __( 'Raphoe', 'describr' ),
        34 => /*translators: City.*/ __( 'Virginia', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Connacht', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Athenry', 'describr' ),
        1 => /*translators: City.*/ __( 'Ballaghaderreen', 'describr' ),
        2 => /*translators: City.*/ __( 'Ballina', 'describr' ),
        3 => /*translators: City.*/ __( 'Ballinasloe', 'describr' ),
        4 => /*translators: City.*/ __( 'Ballinrobe', 'describr' ),
        5 => /*translators: City.*/ __( 'Ballisodare', 'describr' ),
        6 => /*translators: City.*/ __( 'Ballyhaunis', 'describr' ),
        7 => /*translators: City.*/ __( 'Ballymote', 'describr' ),
        8 => /*translators: City.*/ __( 'Bearna', 'describr' ),
        9 => /*translators: City.*/ __( 'Belmullet', 'describr' ),
        10 => /*translators: City.*/ __( 'Boyle', 'describr' ),
        11 => /*translators: City.*/ __( 'Carrick-on-Shannon', 'describr' ),
        12 => /*translators: City.*/ __( 'Castlebar', 'describr' ),
        13 => /*translators: City.*/ __( 'Castlerea', 'describr' ),
        14 => /*translators: City.*/ __( 'Claregalway', 'describr' ),
        15 => /*translators: City.*/ __( 'Claremorris', 'describr' ),
        16 => /*translators: City.*/ __( 'Clifden', 'describr' ),
        17 => /*translators: City.*/ __( 'Collooney', 'describr' ),
        18 => /*translators: City.*/ __( 'County Galway', 'describr' ),
        19 => /*translators: City.*/ __( 'County Leitrim', 'describr' ),
        20 => /*translators: City.*/ __( 'Crossmolina', 'describr' ),
        21 => /*translators: City.*/ __( 'Foxford', 'describr' ),
        22 => /*translators: City.*/ __( 'Gaillimh', 'describr' ),
        23 => /*translators: City.*/ __( 'Galway City', 'describr' ),
        24 => /*translators: City.*/ __( 'Gort', 'describr' ),
        25 => /*translators: City.*/ __( 'Inishcrone', 'describr' ),
        26 => /*translators: City.*/ __( 'Kiltamagh', 'describr' ),
        27 => /*translators: City.*/ __( 'Kinlough', 'describr' ),
        28 => /*translators: City.*/ __( 'Loughrea', 'describr' ),
        29 => /*translators: City.*/ __( 'Manorhamilton', 'describr' ),
        30 => /*translators: City.*/ __( 'Mayo County', 'describr' ),
        31 => /*translators: City.*/ __( 'Moycullen', 'describr' ),
        32 => /*translators: City.*/ __( 'Oranmore', 'describr' ),
        33 => /*translators: City.*/ __( 'Oughterard', 'describr' ),
        34 => /*translators: City.*/ __( 'Portumna', 'describr' ),
        35 => /*translators: City.*/ __( 'Roscommon', 'describr' ),
        36 => /*translators: City.*/ __( 'Sligo', 'describr' ),
        37 => /*translators: City.*/ __( 'Strandhill', 'describr' ),
        38 => /*translators: City.*/ __( 'Swinford', 'describr' ),
        39 => /*translators: City.*/ __( 'Tobercurry', 'describr' ),
        40 => /*translators: City.*/ __( 'Tuam', 'describr' ),
        41 => /*translators: City.*/ __( 'Westport', 'describr' ),
      ),
    ),
  ),
  'DZ' => 
  array (
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chlef Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abou el Hassan', 'describr' ),
        1 => /*translators: City.*/ __( 'Boukadir', 'describr' ),
        2 => /*translators: City.*/ __( 'Chlef', 'describr' ),
        3 => /*translators: City.*/ __( 'Ech Chettia', 'describr' ),
        4 => /*translators: City.*/ __( 'Oued Fodda', 'describr' ),
        5 => /*translators: City.*/ __( 'Oued Sly', 'describr' ),
        6 => /*translators: City.*/ __( 'Sidi Akkacha', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Béchar Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Béchar', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Blida Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beni Mered', 'describr' ),
        1 => /*translators: City.*/ __( 'Blida', 'describr' ),
        2 => /*translators: City.*/ __( 'Boufarik', 'describr' ),
        3 => /*translators: City.*/ __( 'Bougara', 'describr' ),
        4 => /*translators: City.*/ __( 'Bouinan', 'describr' ),
        5 => /*translators: City.*/ __( 'Boû Arfa', 'describr' ),
        6 => /*translators: City.*/ __( 'Chebli', 'describr' ),
        7 => /*translators: City.*/ __( 'Chiffa', 'describr' ),
        8 => /*translators: City.*/ __( 'Larbaâ', 'describr' ),
        9 => /*translators: City.*/ __( 'Meftah', 'describr' ),
        10 => /*translators: City.*/ __( 'Sidi Moussa', 'describr' ),
        11 => /*translators: City.*/ __( 'Souma', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Biskra', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Biskra', 'describr' ),
        1 => /*translators: City.*/ __( 'Oumache', 'describr' ),
        2 => /*translators: City.*/ __( 'Sidi Khaled', 'describr' ),
        3 => /*translators: City.*/ __( 'Sidi Okba', 'describr' ),
        4 => /*translators: City.*/ __( 'Tolga', 'describr' ),
        5 => /*translators: City.*/ __( 'Zeribet el Oued', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Adrar Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adrar', 'describr' ),
        1 => /*translators: City.*/ __( 'Aoulef', 'describr' ),
        2 => /*translators: City.*/ __( 'Reggane', 'describr' ),
        3 => /*translators: City.*/ __( 'Timimoun', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Béjaïa Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akbou', 'describr' ),
        1 => /*translators: City.*/ __( 'Amizour', 'describr' ),
        2 => /*translators: City.*/ __( 'Barbacha', 'describr' ),
        3 => /*translators: City.*/ __( 'Bejaïa', 'describr' ),
        4 => /*translators: City.*/ __( 'El Kseur', 'describr' ),
        5 => /*translators: City.*/ __( 'Feraoun', 'describr' ),
        6 => /*translators: City.*/ __( 'Seddouk', 'describr' ),
        7 => /*translators: City.*/ __( 'el hed', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oum El Bouaghi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aïn Beïda', 'describr' ),
        1 => /*translators: City.*/ __( 'Aïn Fakroun', 'describr' ),
        2 => /*translators: City.*/ __( 'Aïn Kercha', 'describr' ),
        3 => /*translators: City.*/ __( 'El Aouinet', 'describr' ),
        4 => /*translators: City.*/ __( 'Meskiana', 'describr' ),
        5 => /*translators: City.*/ __( 'Oum el Bouaghi', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Laghouat Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aflou', 'describr' ),
        1 => /*translators: City.*/ __( 'Laghouat', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Batna Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arris', 'describr' ),
        1 => /*translators: City.*/ __( 'Aïn Touta', 'describr' ),
        2 => /*translators: City.*/ __( 'Barika', 'describr' ),
        3 => /*translators: City.*/ __( 'Batna', 'describr' ),
        4 => /*translators: City.*/ __( 'Boumagueur', 'describr' ),
        5 => /*translators: City.*/ __( 'Merouana', 'describr' ),
        6 => /*translators: City.*/ __( 'Râs el Aïoun', 'describr' ),
        7 => /*translators: City.*/ __( 'Tazoult-Lambese', 'describr' ),
      ),
    ),
  ),
);