<?php
/**
 * An array of states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 * @since 3.0.2 Data no longer translatable.
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'PG' => 
  array (
    'WBK' => 
    array (
      'name' => 'West New Britain Province',
      'cities' => 
      array (
        0 => 'Kandrian',
        1 => 'Kandrian Gloucester',
        2 => 'Kimbe',
        3 => 'Talasea',
      ),
    ),
    'NSB' => 
    array (
      'name' => 'Bougainville',
      'cities' => 
      array (
        0 => 'Arawa',
        1 => 'Central Bougainville',
        2 => 'Kieta',
        3 => 'North Bougainville',
        4 => 'Panguna',
        5 => 'South Bougainville',
      ),
    ),
    'JWK' => 
    array (
      'name' => 'Jiwaka Province',
      'cities' => 
      array (
        0 => 'Angalimp South Wahgi',
        1 => 'Jimi',
        2 => 'North Wahgi',
      ),
    ),
    'HLA' => 
    array (
      'name' => 'Hela',
      'cities' => 
      array (
        0 => 'Komo Margarima',
        1 => 'Koroba-Lake Kopiago',
        2 => 'Tari',
        3 => 'Tari Pori',
      ),
    ),
    'EBR' => 
    array (
      'name' => 'East New Britain',
      'cities' => 
      array (
        0 => 'Gazelle',
        1 => 'Kokopo',
        2 => 'Pomio',
        3 => 'Rabaul',
      ),
    ),
    'MPL' => 
    array (
      'name' => 'Morobe Province',
      'cities' => 
      array (
        0 => 'Bulolo',
        1 => 'Finschhafen',
        2 => 'Huon Gulf',
        3 => 'Kabwum',
        4 => 'Lae',
        5 => 'Markham',
        6 => 'Menyamya',
        7 => 'Nawae',
        8 => 'Tewai Siassi',
        9 => 'Wau',
      ),
    ),
    'SAN' => 
    array (
      'name' => 'Sandaun Province',
      'cities' => 
      array (
        0 => 'Aitape',
        1 => 'Aitape Lumi',
        2 => 'Nuku',
        3 => 'Telefomin',
        4 => 'Vanimo',
        5 => 'Vanimo Green',
      ),
    ),
    'NCD' => 
    array (
      'name' => 'Port Moresby',
      'cities' => 
      array (
        0 => 'National Capital District',
        1 => 'Port Moresby',
      ),
    ),
    'NPP' => 
    array (
      'name' => 'Oro Province',
      'cities' => 
      array (
        0 => 'Ijivitari',
        1 => 'Kokoda',
        2 => 'Popondetta',
        3 => 'Sohe',
      ),
    ),
    'GPK' => 
    array (
      'name' => 'Gulf',
      'cities' => 
      array (
        0 => 'Kerema',
        1 => 'Kikori',
      ),
    ),
    'WHM' => 
    array (
      'name' => 'Western Highlands Province',
      'cities' => 
      array (
        0 => 'Baiyer Mul',
        1 => 'Dei',
        2 => 'Hagen',
        3 => 'Mount Hagen',
        4 => 'Tambul Nebilyer',
      ),
    ),
    'NIK' => 
    array (
      'name' => 'New Ireland Province',
      'cities' => 
      array (
        0 => 'Kavieng',
        1 => 'Namatanai',
      ),
    ),
    'MRL' => 
    array (
      'name' => 'Manus Province',
      'cities' => 
      array (
        0 => 'Lorengau',
        1 => 'Manus',
      ),
    ),
    'MPM' => 
    array (
      'name' => 'Madang Province',
      'cities' => 
      array (
        0 => 'Bogia',
        1 => 'Madang',
        2 => 'Middle Ramu',
        3 => 'Rai Coast',
        4 => 'Sumkar',
        5 => 'Usino Bundi',
      ),
    ),
    'SHM' => 
    array (
      'name' => 'Southern Highlands Province',
      'cities' => 
      array (
        0 => 'Ialibu',
        1 => 'Ialibu Pangia',
        2 => 'Imbonggu',
        3 => 'Kagua Erave',
        4 => 'Mendi',
        5 => 'Nipa Kutubu',
      ),
    ),
    'EHG' => 
    array (
      'name' => 'Eastern Highlands Province',
      'cities' => 
      array (
        0 => 'Daulo',
        1 => 'Goroka',
        2 => 'Henganofi',
        3 => 'Kainantu',
        4 => 'Lufa',
        5 => 'Obura Wonenara',
        6 => 'Okapa',
        7 => 'Unggai Bena',
      ),
    ),
    'CPK' => 
    array (
      'name' => 'Chimbu Province',
      'cities' => 
      array (
        0 => 'Chuave',
        1 => 'Gumine',
        2 => 'Karimui Nomane',
        3 => 'Kerowagi',
        4 => 'Kundiawa',
        5 => 'Sinasina Yonggamugl',
      ),
    ),
    'CPM' => 
    array (
      'name' => 'Central Province',
      'cities' => 
      array (
        0 => 'Abau',
        1 => 'Goilala',
        2 => 'Kairuku-Hiri',
        3 => 'Rigo',
      ),
    ),
    'EPW' => 
    array (
      'name' => 'Enga Province',
      'cities' => 
      array (
        0 => 'Kandep',
        1 => 'Kompiam Ambum',
        2 => 'Lagaip Porgera',
        3 => 'Porgera',
        4 => 'Wabag',
        5 => 'Wapenamanda',
      ),
    ),
    'MBA' => 
    array (
      'name' => 'Milne Bay Province',
      'cities' => 
      array (
        0 => 'Alotau',
        1 => 'Esa&#039;ala',
        2 => 'Kiriwina Goodenough',
        3 => 'Samarai',
        4 => 'Samarai Murua',
      ),
    ),
    'WPD' => 
    array (
      'name' => 'Western Province',
      'cities' => 
      array (
        0 => 'Daru',
        1 => 'Kiunga',
        2 => 'Middle Fly',
        3 => 'Morehead',
        4 => 'North Fly',
        5 => 'South Fly',
      ),
    ),
  ),
);