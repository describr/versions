<?php
/**
 * Plugin Name: Describr
 * Description: The best user profile and membership plugin for WordPress. Describr makes it easy to create beautiful user profiles on the front end. Describr makes it easy for users to manage their profiles and accounts on the front end. Describr is extensible and makes it easy for you to create websites where users can become members.
 * Version: 3.0.2
 * Requires at least: 4.7
 * Requires PHP: 8.4
 * Author: profiletoggler
 * Author URI: https://facebook.com/plzr17
 * Plugin URI: https://github.com/describr/versions/
 * Update URI: https://raw.githubusercontent.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: describr
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DESCRIBR', 'Describr' );
define( 'DESCRIBR_VERSION', '3.0.2' );
define( 'DESCRIBR_DIR', plugin_dir_path( __FILE__ ) );
define( 'DESCRIBR_URL', plugin_dir_url( __FILE__ ) );
define( 'DESCRIBR_FILE', plugin_basename( __FILE__ ) );
define( 'DESCRIBR_TEMPLATE', DESCRIBR_DIR . 'templates' . DIRECTORY_SEPARATOR );

require_once DESCRIBR_DIR . 'includes' . DIRECTORY_SEPARATOR . 'class-config.php';
require_once DESCRIBR_DIR . 'includes' . DIRECTORY_SEPARATOR . 'class-init.php';

