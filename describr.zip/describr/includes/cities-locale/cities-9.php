<?php
/**
 * An array of states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 * @since 3.0.2 Data no longer translatable.
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'LS' => 
  array (
    'E' => 
    array (
      'name' => 'Mafeteng District',
      'cities' => 
      array (
        0 => 'Mafeteng',
      ),
    ),
    'F' => 
    array (
      'name' => 'Mohale&#039;s Hoek District',
      'cities' => 
      array (
        0 => 'Mohale&#039;s Hoek',
      ),
    ),
    'J' => 
    array (
      'name' => 'Mokhotlong District',
      'cities' => 
      array (
        0 => 'Mokhotlong',
      ),
    ),
    'H' => 
    array (
      'name' => 'Qacha&#039;s Nek District',
      'cities' => 
      array (
        0 => 'Qacha&#039;s Nek',
      ),
    ),
    'C' => 
    array (
      'name' => 'Leribe District',
      'cities' => 
      array (
        0 => 'Leribe',
        1 => 'Maputsoe',
      ),
    ),
    'G' => 
    array (
      'name' => 'Quthing District',
      'cities' => 
      array (
        0 => 'Quthing',
      ),
    ),
    'A' => 
    array (
      'name' => 'Maseru District',
      'cities' => 
      array (
        0 => 'Maseru',
        1 => 'Nako',
      ),
    ),
    'B' => 
    array (
      'name' => 'Butha-Buthe District',
      'cities' => 
      array (
        0 => 'Butha-Buthe',
      ),
    ),
    'D' => 
    array (
      'name' => 'Berea District',
      'cities' => 
      array (
        0 => 'Teyateyaneng',
      ),
    ),
    'K' => 
    array (
      'name' => 'Thaba-Tseka District',
      'cities' => 
      array (
        0 => 'Thaba-Tseka',
      ),
    ),
  ),
  'LR' => 
  array (
    'MO' => 
    array (
      'name' => 'Montserrado County',
      'cities' => 
      array (
        0 => 'Bensonville',
        1 => 'Monrovia',
      ),
    ),
    'RI' => 
    array (
      'name' => 'River Cess County',
      'cities' => 
      array (
        0 => 'Cestos City',
      ),
    ),
    'BG' => 
    array (
      'name' => 'Bong County',
      'cities' => 
      array (
        0 => 'Gbarnga',
      ),
    ),
    'SI' => 
    array (
      'name' => 'Sinoe County',
      'cities' => 
      array (
        0 => 'Greenville',
      ),
    ),
    'CM' => 
    array (
      'name' => 'Grand Cape Mount County',
      'cities' => 
      array (
        0 => 'Robertsport',
      ),
    ),
    'LO' => 
    array (
      'name' => 'Lofa County',
      'cities' => 
      array (
        0 => 'Voinjama',
      ),
    ),
    'RG' => 
    array (
      'name' => 'River Gee County',
      'cities' => 
      array (
        0 => 'Fish Town',
      ),
    ),
    'GG' => 
    array (
      'name' => 'Grand Gedeh County',
      'cities' => 
      array (
        0 => 'Zwedru',
      ),
    ),
    'GB' => 
    array (
      'name' => 'Grand Bassa County',
      'cities' => 
      array (
        0 => 'Buchanan',
      ),
    ),
    'BM' => 
    array (
      'name' => 'Bomi County',
      'cities' => 
      array (
        0 => 'Tubmanburg',
      ),
    ),
    'MY' => 
    array (
      'name' => 'Maryland County',
      'cities' => 
      array (
        0 => 'Harper',
      ),
    ),
    'MG' => 
    array (
      'name' => 'Margibi County',
      'cities' => 
      array (
        0 => 'Kakata',
      ),
    ),
    'GP' => 
    array (
      'name' => 'Gbarpolu County',
      'cities' => 
      array (
        0 => 'Bopolu',
      ),
    ),
    'GK' => 
    array (
      'name' => 'Grand Kru County',
      'cities' => 
      array (
        0 => 'Barclayville',
      ),
    ),
    'NI' => 
    array (
      'name' => 'Nimba',
      'cities' => 
      array (
        0 => 'Ganta',
        1 => 'New Yekepa',
        2 => 'Sanniquellie',
      ),
    ),
  ),
  'OM' => 
  array (
    'ZA' => 
    array (
      'name' => 'Ad Dhahirah Governorate',
      'cities' => 
      array (
        0 => 'Yanqul',
        1 => '&#039;Ibrī',
      ),
    ),
    'BS' => 
    array (
      'name' => 'Al Batinah North Governorate',
      'cities' => 
      array (
        0 => 'Al Khābūrah',
        1 => 'As Suwayq',
        2 => 'Liwá',
        3 => 'Shināş',
        4 => 'Sohar',
        5 => 'Şaḩam',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Al Batinah Region',
      'cities' => 
      array (
        0 => 'Barkā&#039;',
        1 => 'Bayt al &#039;Awābī',
        2 => 'Oman Smart Future City',
        3 => 'Rustaq',
      ),
    ),
    'SH' => 
    array (
      'name' => 'Ash Sharqiyah Region',
      'cities' => 
      array (
        0 => 'Sur',
      ),
    ),
    'MU' => 
    array (
      'name' => 'Musandam Governorate',
      'cities' => 
      array (
        0 => 'Dib Dibba',
        1 => 'Khasab',
        2 => 'Madḩā&#039; al Jadīdah',
      ),
    ),
    'MA' => 
    array (
      'name' => 'Muscat Governorate',
      'cities' => 
      array (
        0 => 'Bawshar',
        1 => 'Muscat',
        2 => 'Seeb',
      ),
    ),
    'WU' => 
    array (
      'name' => 'Al Wusta Governorate',
      'cities' => 
      array (
        0 => 'Haymā&#039;',
      ),
    ),
    'ZU' => 
    array (
      'name' => 'Dhofar Governorate',
      'cities' => 
      array (
        0 => 'Şalālah',
      ),
    ),
    'DA' => 
    array (
      'name' => 'Ad Dakhiliyah Governorate',
      'cities' => 
      array (
        0 => 'Adam',
        1 => 'Bahlā&#039;',
        2 => 'Bidbid',
        3 => 'Izkī',
        4 => 'Nizwá',
        5 => 'Sufālat Samā&#039;il',
      ),
    ),
    'BU' => 
    array (
      'name' => 'Al Buraimi Governorate',
      'cities' => 
      array (
        0 => 'Al Buraymī',
      ),
    ),
  ),
  'BW' => 
  array (
    'GH' => 
    array (
      'name' => 'Ghanzi District',
      'cities' => 
      array (
        0 => 'Dekar',
        1 => 'Ghanzi',
      ),
    ),
    'KL' => 
    array (
      'name' => 'Kgatleng District',
      'cities' => 
      array (
        0 => 'Bokaa',
        1 => 'Mmathubudukwane',
        2 => 'Mochudi',
        3 => 'Pilane',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Southern District',
      'cities' => 
      array (
        0 => 'Kanye',
        1 => 'Khakhea',
        2 => 'Mosopa',
        3 => 'Sekoma',
      ),
    ),
    'SE' => 
    array (
      'name' => 'South-East District',
      'cities' => 
      array (
        0 => 'Gaborone',
        1 => 'Janeng',
        2 => 'Kopong',
        3 => 'Otse',
        4 => 'Ramotswa',
      ),
    ),
    'NW' => 
    array (
      'name' => 'North-West District',
      'cities' => 
      array (
        0 => 'Maun',
        1 => 'Nokaneng',
        2 => 'Pandamatenga',
        3 => 'Sehithwa',
        4 => 'Shakawe',
      ),
    ),
    'KG' => 
    array (
      'name' => 'Kgalagadi District',
      'cities' => 
      array (
        0 => 'Hukuntsi',
        1 => 'Kang',
        2 => 'Lehututu',
        3 => 'Manyana',
        4 => 'Tshabong',
        5 => 'Werda',
      ),
    ),
    'CE' => 
    array (
      'name' => 'Central District',
      'cities' => 
      array (
        0 => 'Gobojango',
        1 => 'Gweta',
        2 => 'Kalamare',
        3 => 'Letlhakane',
        4 => 'Letsheng',
        5 => 'Maapi',
        6 => 'Machaneng',
        7 => 'Mahalapye',
        8 => 'Makobeng',
        9 => 'Makwata',
        10 => 'Mathakola',
        11 => 'Mathambgwane',
        12 => 'Mathathane',
        13 => 'Maunatlala',
        14 => 'Mogapi',
        15 => 'Moijabana',
        16 => 'Mookane',
        17 => 'Mopipi',
        18 => 'Mosetse',
        19 => 'Nata',
        20 => 'Orapa',
        21 => 'Palapye',
        22 => 'Pilikwe',
        23 => 'Rakops',
        24 => 'Ramokgonami',
        25 => 'Ratholo',
        26 => 'Sefophe',
        27 => 'Serowe',
        28 => 'Sua',
        29 => 'Tamasane',
        30 => 'Tobane',
        31 => 'Tonota',
      ),
    ),
    'NE' => 
    array (
      'name' => 'North-East District',
      'cities' => 
      array (
        0 => 'Dukwe',
        1 => 'Makaleng',
        2 => 'Masunga',
        3 => 'Sebina',
      ),
    ),
    'KW' => 
    array (
      'name' => 'Kweneng District',
      'cities' => 
      array (
        0 => 'Botlhapatlou',
        1 => 'Dutlwe',
        2 => 'Gabane',
        3 => 'Gaphatshwe',
        4 => 'Khudumelapye',
        5 => 'Lenchwe Le Tau',
        6 => 'Letlhakeng',
        7 => 'Metsemotlhaba',
        8 => 'Mmopone',
        9 => 'Mogoditshane',
        10 => 'Molepolole',
        11 => 'Nkoyaphiri',
        12 => 'Thamaga',
      ),
    ),
  ),
  'BJ' => 
  array (
    'CO' => 
    array (
      'name' => 'Collines Department',
      'cities' => 
      array (
        0 => 'Comé',
        1 => 'Dassa-Zoumé',
        2 => 'Savalou',
        3 => 'Savé',
      ),
    ),
    'KO' => 
    array (
      'name' => 'Kouffo Department',
      'cities' => 
      array (
        0 => 'Djakotomey',
        1 => 'Dogbo',
      ),
    ),
    'DO' => 
    array (
      'name' => 'Donga Department',
      'cities' => 
      array (
        0 => 'Bassila',
        1 => 'Commune of Djougou',
        2 => 'Djougou',
      ),
    ),
    'ZO' => 
    array (
      'name' => 'Zou Department',
      'cities' => 
      array (
        0 => 'Abomey',
        1 => 'Bohicon',
        2 => 'Commune of Agbangnizoun',
        3 => 'Cové',
      ),
    ),
    'PL' => 
    array (
      'name' => 'Plateau Department',
      'cities' => 
      array (
        0 => 'Kétou',
        1 => 'Pobé',
        2 => 'Sakété',
      ),
    ),
    'MO' => 
    array (
      'name' => 'Mono Department',
      'cities' => 
      array (
        0 => 'Commune of Athieme',
        1 => 'Lokossa',
      ),
    ),
    'AK' => 
    array (
      'name' => 'Atakora Department',
      'cities' => 
      array (
        0 => 'Guilmaro',
        1 => 'Natitingou',
        2 => 'Tanguieta',
        3 => 'Tanguiéta',
      ),
    ),
    'AL' => 
    array (
      'name' => 'Alibori Department',
      'cities' => 
      array (
        0 => 'Banikoara',
        1 => 'Kandi',
        2 => 'Malanville',
      ),
    ),
    'BO' => 
    array (
      'name' => 'Borgou Department',
      'cities' => 
      array (
        0 => 'Bembèrèkè',
        1 => 'Bétérou',
        2 => 'Nikki',
        3 => 'Parakou',
        4 => 'Tchaourou',
      ),
    ),
    'AQ' => 
    array (
      'name' => 'Atlantique Department',
      'cities' => 
      array (
        0 => 'Abomey-Calavi',
        1 => 'Allada',
        2 => 'Hinvi',
        3 => 'Hévié',
        4 => 'Ouidah',
      ),
    ),
    'OU' => 
    array (
      'name' => 'Ouémé Department',
      'cities' => 
      array (
        0 => 'Porto-Novo',
      ),
    ),
    'LI' => 
    array (
      'name' => 'Littoral Department',
      'cities' => 
      array (
        0 => 'Cotonou',
      ),
    ),
  ),
  'MW' => 
  array (
    'C' => 
    array (
      'name' => 'Central Region',
      'cities' => 
      array (
        0 => 'Chipoka',
        1 => 'Dedza',
        2 => 'Dedza District',
        3 => 'Dowa',
        4 => 'Dowa District',
        5 => 'Kasungu',
        6 => 'Kasungu District',
        7 => 'Lilongwe',
        8 => 'Lilongwe District',
        9 => 'Mchinji',
        10 => 'Mchinji District',
        11 => 'Mponela',
        12 => 'Nkhotakota',
        13 => 'Nkhotakota District',
        14 => 'Ntcheu',
        15 => 'Ntcheu District',
        16 => 'Ntchisi',
        17 => 'Ntchisi District',
        18 => 'Salima',
        19 => 'Salima District',
      ),
    ),
    'N' => 
    array (
      'name' => 'Northern Region',
      'cities' => 
      array (
        0 => 'Chitipa',
        1 => 'Chitipa District',
        2 => 'Karonga',
        3 => 'Karonga District',
        4 => 'Likoma District',
        5 => 'Livingstonia',
        6 => 'Mzimba',
        7 => 'Mzimba District',
        8 => 'Mzuzu',
        9 => 'Nkhata Bay',
        10 => 'Nkhata Bay District',
        11 => 'Rumphi',
        12 => 'Rumphi District',
      ),
    ),
    'S' => 
    array (
      'name' => 'Southern Region',
      'cities' => 
      array (
        0 => 'Balaka',
        1 => 'Balaka District',
        2 => 'Blantyre',
        3 => 'Blantyre District',
        4 => 'Chikwawa',
        5 => 'Chikwawa District',
        6 => 'Chiradzulu',
        7 => 'Chiradzulu District',
        8 => 'Liwonde',
        9 => 'Luchenza',
        10 => 'Machinga',
        11 => 'Machinga District',
        12 => 'Mangochi',
        13 => 'Mangochi District',
        14 => 'Monkey Bay',
        15 => 'Mulanje',
        16 => 'Mulanje District',
        17 => 'Mwanza',
        18 => 'Mwanza District',
        19 => 'Neno District',
        20 => 'Nsanje',
        21 => 'Nsanje District',
        22 => 'Phalombe',
        23 => 'Phalombe District',
        24 => 'Thyolo',
        25 => 'Thyolo District',
        26 => 'Zomba',
        27 => 'Zomba District',
      ),
    ),
  ),
  'BF' => 
  array (
    '06' => 
    array (
      'name' => 'Centre-Ouest Region',
      'cities' => 
      array (
        0 => 'Goulouré',
        1 => 'Kokologo',
        2 => 'Koudougou',
        3 => 'Léo',
        4 => 'Pitmoaga',
        5 => 'Province de la Sissili',
        6 => 'Province du Boulkiemdé',
        7 => 'Province du Sanguié',
        8 => 'Province du Ziro',
        9 => 'Réo',
        10 => 'Sapouy',
      ),
    ),
    '05' => 
    array (
      'name' => 'Centre-Nord Region',
      'cities' => 
      array (
        0 => 'Boulsa',
        1 => 'Kaya',
        2 => 'Kongoussi',
        3 => 'Province du Bam',
        4 => 'Province du Namentenga',
        5 => 'Province du Sanmatenga',
      ),
    ),
    '03' => 
    array (
      'name' => 'Centre',
      'cities' => 
      array (
        0 => 'Kadiogo Province',
        1 => 'Ouagadougou',
      ),
    ),
    '01' => 
    array (
      'name' => 'Boucle du Mouhoun Region',
      'cities' => 
      array (
        0 => 'Barani',
        1 => 'Boromo',
        2 => 'Dédougou',
        3 => 'Nouna',
        4 => 'Province de la Kossi',
        5 => 'Province des Balé',
        6 => 'Province des Banwa',
        7 => 'Province du Mouhoun',
        8 => 'Province du Nayala',
        9 => 'Province du Sourou',
        10 => 'Salanso',
        11 => 'Toma',
        12 => 'Tougan',
      ),
    ),
    '07' => 
    array (
      'name' => 'Centre-Sud Region',
      'cities' => 
      array (
        0 => 'Bazega Province',
        1 => 'Kombissiri',
        2 => 'Manga',
        3 => 'Nahouri Province',
        4 => 'Pô',
        5 => 'Zoundweogo Province',
      ),
    ),
    '02' => 
    array (
      'name' => 'Cascades Region',
      'cities' => 
      array (
        0 => 'Banfora',
        1 => 'Province de la Comoé',
        2 => 'Province de la Léraba',
        3 => 'Sindou',
      ),
    ),
    '08' => 
    array (
      'name' => 'Est Region',
      'cities' => 
      array (
        0 => 'Bogandé',
        1 => 'Diapaga',
        2 => 'Fada N&#039;gourma',
        3 => 'Gayéri',
        4 => 'Gnagna Province',
        5 => 'Pama',
        6 => 'Province de la Komandjoari',
        7 => 'Province de la Kompienga',
        8 => 'Province de la Tapoa',
        9 => 'Province du Gourma',
      ),
    ),
    '04' => 
    array (
      'name' => 'Centre-Est Region',
      'cities' => 
      array (
        0 => 'Garango',
        1 => 'Koupéla',
        2 => 'Kouritenga Province',
        3 => 'Ouargaye',
        4 => 'Province du Boulgou',
        5 => 'Province du Koulpélogo',
        6 => 'Tenkodogo',
      ),
    ),
    '09' => 
    array (
      'name' => 'Hauts-Bassins Region',
      'cities' => 
      array (
        0 => 'Bobo-Dioulasso',
        1 => 'Houndé',
        2 => 'Province du Houet',
        3 => 'Province du Kénédougou',
        4 => 'Province du Tuy',
      ),
    ),
  ),
  'PK' => 
  array (
    'IS' => 
    array (
      'name' => 'Islamabad Capital Territory',
      'cities' => 
      array (
        0 => 'Islamabad',
      ),
    ),
    'GB' => 
    array (
      'name' => 'Gilgit-Baltistan',
      'cities' => 
      array (
        0 => 'Barishal',
        1 => 'Gilgit',
        2 => 'Skardu',
      ),
    ),
    'KP' => 
    array (
      'name' => 'Khyber Pakhtunkhwa',
      'cities' => 
      array (
        0 => 'Abbottabad',
        1 => 'Akora',
        2 => 'Aman Garh',
        3 => 'Amirabad',
        4 => 'Ashanagro Koto',
        5 => 'Baffa',
        6 => 'Bannu',
        7 => 'Bat Khela',
        8 => 'Battagram',
        9 => 'Battagram District',
        10 => 'Buner District',
        11 => 'Charsadda',
        12 => 'Cherat Cantonement',
        13 => 'Chitral',
        14 => 'Dera Ismail Khan',
        15 => 'Dera Ismāīl Khān District',
        16 => 'Doaba',
        17 => 'Hangu',
        18 => 'Haripur',
        19 => 'Havelian',
        20 => 'Kakad Wari Dir Upper',
        21 => 'Karak',
        22 => 'Khalabat',
        23 => 'Kohat',
        24 => 'Kulachi',
        25 => 'Lachi',
        26 => 'Lakki',
        27 => 'Mansehra',
        28 => 'Mardan',
        29 => 'Mingora',
        30 => 'Noorabad',
        31 => 'Nowshera',
        32 => 'Nowshera Cantonment',
        33 => 'Pabbi',
        34 => 'Paharpur',
        35 => 'Peshawar',
        36 => 'Risalpur Cantonment',
        37 => 'Sarai Naurang',
        38 => 'Shabqadar',
        39 => 'Shingli Bala',
        40 => 'Shorkot',
        41 => 'Swabi',
        42 => 'Tangi',
        43 => 'Tank',
        44 => 'Thal',
        45 => 'Topi',
        46 => 'Upper Dir',
        47 => 'Utmanzai',
        48 => 'Zaida',
      ),
    ),
    'JK' => 
    array (
      'name' => 'Azad Kashmir',
      'cities' => 
      array (
        0 => 'Bhimbar',
        1 => 'Kotli',
        2 => 'Kotli District',
        3 => 'Mirpur District',
        4 => 'Muzaffarābād',
        5 => 'New Mirpur',
        6 => 'Rawala Kot',
      ),
    ),
    'TA' => 
    array (
      'name' => 'Federally Administered Tribal Areas',
      'cities' => 
      array (
        0 => 'Alizai',
        1 => 'Gulishah Kach',
        2 => 'Landi Kotal',
        3 => 'Miran Shah',
        4 => 'North Wazīristān Agency',
        5 => 'Shinpokh',
        6 => 'South Wazīristān Agency',
        7 => 'Wana',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Balochistan',
      'cities' => 
      array (
        0 => 'Alik Ghund',
        1 => 'Awārān District',
        2 => 'Barkhan',
        3 => 'Bela',
        4 => 'Bhag',
        5 => 'Bārkhān District',
        6 => 'Chaman',
        7 => 'Chowki Jamali',
        8 => 'Chāgai District',
        9 => 'Dadhar',
        10 => 'Dalbandin',
        11 => 'Dera Bugti',
        12 => 'Dera Bugti District',
        13 => 'Duki',
        14 => 'Gadani',
        15 => 'Garhi Khairo',
        16 => 'Gwadar',
        17 => 'Harnai',
        18 => 'Jhal Magsi District',
        19 => 'Jiwani',
        20 => 'Jāfarābād District',
        21 => 'Kalat',
        22 => 'Kalāt District',
        23 => 'Khadan Khak',
        24 => 'Kharan',
        25 => 'Khuzdar',
        26 => 'Khuzdār District',
        27 => 'Khārān District',
        28 => 'Kohlu',
        29 => 'Kot Malik Barkhurdar',
        30 => 'Lasbela District',
        31 => 'Loralai',
        32 => 'Loralai District',
        33 => 'Mach',
        34 => 'Mastung',
        35 => 'Mastung District',
        36 => 'Mehrabpur',
        37 => 'Mūsa Khel District',
        38 => 'Nasīrābād District',
        39 => 'Nushki',
        40 => 'Ormara',
        41 => 'Panjgūr District',
        42 => 'Pasni',
        43 => 'Pishin',
        44 => 'Qila Saifullāh District',
        45 => 'Quetta',
        46 => 'Quetta District',
        47 => 'Sibi',
        48 => 'Sohbatpur',
        49 => 'Surab',
        50 => 'Turbat',
        51 => 'Usta Muhammad',
        52 => 'Uthal',
        53 => 'Zhob',
        54 => 'Zhob District',
        55 => 'Ziarat',
        56 => 'Ziārat District',
      ),
    ),
    'SD' => 
    array (
      'name' => 'Sindh',
      'cities' => 
      array (
        0 => 'Adilpur',
        1 => 'Badin',
        2 => 'Bagarji',
        3 => 'Bandhi',
        4 => 'Berani',
        5 => 'Bhan',
        6 => 'Bhiria',
        7 => 'Bhit Shah',
        8 => 'Bozdar Wada',
        9 => 'Bulri',
        10 => 'Chak',
        11 => 'Chamber',
        12 => 'Chhor',
        13 => 'Chuhar Jamali',
        14 => 'Dadu',
        15 => 'Daromehar',
        16 => 'Darya Khan Marri',
        17 => 'Daulatpur',
        18 => 'Daur',
        19 => 'Dhoro Naro',
        20 => 'Digri',
        21 => 'Diplo',
        22 => 'Dokri',
        23 => 'Gambat',
        24 => 'Garhiyasin',
        25 => 'Gharo',
        26 => 'Ghauspur',
        27 => 'Ghotki',
        28 => 'Goth Garelo',
        29 => 'Goth Phulji',
        30 => 'Goth Radhan',
        31 => 'Hala',
        32 => 'Hingorja',
        33 => 'Hyderabad',
        34 => 'Islamkot',
        35 => 'Jacobabad',
        36 => 'Jamshoro',
        37 => 'Jati',
        38 => 'Jhol',
        39 => 'Johi',
        40 => 'Jām Sāhib',
        41 => 'Kadhan',
        42 => 'Kambar',
        43 => 'Kandhkot',
        44 => 'Kandiari',
        45 => 'Kandiaro',
        46 => 'Karachi',
        47 => 'Karaundi',
        48 => 'Kario Ghanwar',
        49 => 'Kashmor',
        50 => 'Keti Bandar',
        51 => 'Khadro',
        52 => 'Khairpur',
        53 => 'Khairpur Mir&#039;s',
        54 => 'Khairpur Nathan Shah',
        55 => 'Khanpur Mahar',
        56 => 'Kot Diji',
        57 => 'Kotri',
        58 => 'Kunri',
        59 => 'Lakhi',
        60 => 'Larkana',
        61 => 'Madeji',
        62 => 'Malir Cantonment',
        63 => 'Matiari',
        64 => 'Matli',
        65 => 'Mehar',
        66 => 'Miro Khan',
        67 => 'Mirpur Bhtoro',
        68 => 'Mirpur Khas',
        69 => 'Mirpur Mathelo',
        70 => 'Mirpur Sakro',
        71 => 'Mirwah Gorchani',
        72 => 'Mithi',
        73 => 'Moro',
        74 => 'Nabisar',
        75 => 'Nasirabad',
        76 => 'Naudero',
        77 => 'Naukot',
        78 => 'Naushahro Firoz',
        79 => 'Nawabshah',
        80 => 'New Bādāh',
        81 => 'Pad Idan',
        82 => 'Pano Aqil',
        83 => 'Pir Jo Goth',
        84 => 'Pithoro',
        85 => 'Rajo Khanani',
        86 => 'Ranipur',
        87 => 'Ratodero',
        88 => 'Rohri',
        89 => 'Rustam',
        90 => 'Sakrand',
        91 => 'Samaro',
        92 => 'Sanghar',
        93 => 'Sann',
        94 => 'Sehwan',
        95 => 'Setharja Old',
        96 => 'Shahdad Kot',
        97 => 'Shahdadpur',
        98 => 'Shahpur Chakar',
        99 => 'Shikarpur',
        100 => 'Sinjhoro',
        101 => 'Sobhodero',
        102 => 'Sukkur',
        103 => 'Sīta Road',
        104 => 'Talhar',
        105 => 'Tando Adam',
        106 => 'Tando Allahyar',
        107 => 'Tando Bago',
        108 => 'Tando Jam',
        109 => 'Tando Mitha Khan',
        110 => 'Tando Muhammad Khan',
        111 => 'Tangwani',
        112 => 'Tharu Shah',
        113 => 'Thatta',
        114 => 'Thul',
        115 => 'Ubauro',
        116 => 'Umarkot',
        117 => 'Umerkot District',
        118 => 'Warah',
      ),
    ),
    'PB' => 
    array (
      'name' => 'Punjab',
      'cities' => 
      array (
        0 => 'Ahmadpur Sial',
        1 => 'Ahmedpur East',
        2 => 'Alipur Chatha',
        3 => 'Arifwala',
        4 => 'Attock Tehsil',
        5 => 'Baddomalhi',
        6 => 'Bahawalnagar',
        7 => 'Bahawalpur',
        8 => 'Bakhri Ahmad Khan',
        9 => 'Basirpur',
        10 => 'Basti Dosa',
        11 => 'Begowala',
        12 => 'Bhakkar',
        13 => 'Bhalwal',
        14 => 'Bhawana',
        15 => 'Bhera',
        16 => 'Bhopalwala',
        17 => 'Burewala',
        18 => 'Chak Azam Saffo',
        19 => 'Chak Jhumra',
        20 => 'Chak One Hundred Twenty Nine Left',
        21 => 'Chak Thirty-one -Eleven Left',
        22 => 'Chak Two Hundred Forty-Nine TDA',
        23 => 'Chakwal',
        24 => 'Chawinda',
        25 => 'Chichawatni',
        26 => 'Chiniot',
        27 => 'Chishtian',
        28 => 'Choa Saidanshah',
        29 => 'Chuhar Kana',
        30 => 'Chunian',
        31 => 'Daira Din Panah',
        32 => 'Dajal',
        33 => 'Dandot RS',
        34 => 'Darya Khan',
        35 => 'Daska',
        36 => 'Daud Khel',
        37 => 'Daultala',
        38 => 'Dera Ghazi Khan',
        39 => 'Dhanot',
        40 => 'Dhaunkal',
        41 => 'Dhok Awan',
        42 => 'Dijkot',
        43 => 'Dinan Bashnoian Wala',
        44 => 'Dinga',
        45 => 'Dipalpur',
        46 => 'Dullewala',
        47 => 'Dunga Bunga',
        48 => 'Dunyapur',
        49 => 'Eminabad',
        50 => 'Faisalabad',
        51 => 'Faqirwali',
        52 => 'Faruka',
        53 => 'Fazilpur',
        54 => 'Ferozewala',
        55 => 'Fort Abbas',
        56 => 'Garh Maharaja',
        57 => 'Gojra',
        58 => 'Gujar Khan',
        59 => 'Gujranwala',
        60 => 'Gujranwala Division',
        61 => 'Gujrat',
        62 => 'Hadali',
        63 => 'Hafizabad',
        64 => 'Harnoli',
        65 => 'Harunabad',
        66 => 'Hasan Abdal',
        67 => 'Hasilpur',
        68 => 'Haveli Lakha',
        69 => 'Hazro',
        70 => 'Hujra Shah Muqeem',
        71 => 'Jahanian Shah',
        72 => 'Jalalpur Jattan',
        73 => 'Jalalpur Pirwala',
        74 => 'Jampur',
        75 => 'Jand',
        76 => 'Jandiala Sher Khan',
        77 => 'Jaranwala',
        78 => 'Jatoi Shimali',
        79 => 'Jauharabad',
        80 => 'Jhang',
        81 => 'Jhang Sadar',
        82 => 'Jhawarian',
        83 => 'Jhelum',
        84 => 'Kabirwala',
        85 => 'Kahna Nau',
        86 => 'Kahuta',
        87 => 'Kalabagh',
        88 => 'Kalaswala',
        89 => 'Kaleke Mandi',
        90 => 'Kallar Kahar',
        91 => 'Kalur Kot',
        92 => 'Kamalia',
        93 => 'Kamar Mushani',
        94 => 'Kamoke',
        95 => 'Kamra',
        96 => 'Kanganpur',
        97 => 'Karor',
        98 => 'Kasur',
        99 => 'Keshupur',
        100 => 'Khairpur Tamiwali',
        101 => 'Khandowa',
        102 => 'Khanewal',
        103 => 'Khanga Dogran',
        104 => 'Khangarh',
        105 => 'Khanpur',
        106 => 'Kharian',
        107 => 'Khewra',
        108 => 'Khurrianwala',
        109 => 'Khushab',
        110 => 'Kohror Pakka',
        111 => 'Kot Addu Tehsil',
        112 => 'Kot Ghulam Muhammad',
        113 => 'Kot Mumin',
        114 => 'Kot Radha Kishan',
        115 => 'Kot Rajkour',
        116 => 'Kot Samaba',
        117 => 'Kot Sultan',
        118 => 'Kotli Loharan',
        119 => 'Kundian',
        120 => 'Kunjah',
        121 => 'Ladhewala Waraich',
        122 => 'Lahore',
        123 => 'Lala Musa',
        124 => 'Lalian',
        125 => 'Layyah',
        126 => 'Layyah District',
        127 => 'Liliani',
        128 => 'Lodhran',
        129 => 'Mailsi',
        130 => 'Malakwal',
        131 => 'Malakwal City',
        132 => 'Mamu Kanjan',
        133 => 'Mananwala',
        134 => 'Mandi Bahauddin',
        135 => 'Mandi Bahauddin District',
        136 => 'Mangla',
        137 => 'Mankera',
        138 => 'Mehmand Chak',
        139 => 'Mian Channun',
        140 => 'Mianke Mor',
        141 => 'Mianwali',
        142 => 'Minchinabad',
        143 => 'Mitha Tiwana',
        144 => 'Moza Shahwala',
        145 => 'Multan',
        146 => 'Multan District',
        147 => 'Muridke',
        148 => 'Murree',
        149 => 'Mustafabad',
        150 => 'Muzaffargarh',
        151 => 'Nankana Sahib',
        152 => 'Narang Mandi',
        153 => 'Narowal',
        154 => 'Naushahra Virkan',
        155 => 'Nazir Town',
        156 => 'Okara',
        157 => 'Pakki Shagwanwali',
        158 => 'Pakpattan',
        159 => 'Pasrur',
        160 => 'Pattoki',
        161 => 'Phalia',
        162 => 'Pind Dadan Khan',
        163 => 'Pindi Bhattian',
        164 => 'Pindi Gheb',
        165 => 'Pir Mahal',
        166 => 'Qadirpur Ran',
        167 => 'Qila Didar Singh',
        168 => 'Rabwah',
        169 => 'Rahim Yar Khan',
        170 => 'Rahimyar Khan District',
        171 => 'Raiwind',
        172 => 'Raja Jang',
        173 => 'Rajanpur',
        174 => 'Rasulnagar',
        175 => 'Rawalpindi',
        176 => 'Rawalpindi District',
        177 => 'Renala Khurd',
        178 => 'Rojhan',
        179 => 'Sadiqabad',
        180 => 'Sahiwal',
        181 => 'Sambrial',
        182 => 'Sangla Hill',
        183 => 'Sanjwal',
        184 => 'Sarai Alamgir',
        185 => 'Sarai Sidhu',
        186 => 'Sargodha',
        187 => 'Shahkot Tehsil',
        188 => 'Shahpur',
        189 => 'Shahr Sultan',
        190 => 'Shakargarh',
        191 => 'Sharqpur',
        192 => 'Sheikhupura',
        193 => 'Shorkot',
        194 => 'Shujaabad',
        195 => 'Sialkot',
        196 => 'Sillanwali',
        197 => 'Sodhra',
        198 => 'Sukheke Mandi',
        199 => 'Surkhpur',
        200 => 'Talagang',
        201 => 'Talamba',
        202 => 'Tandlianwala',
        203 => 'Taunsa',
        204 => 'Toba Tek Singh',
        205 => 'Umerkot',
        206 => 'Vihari',
        207 => 'Wah',
        208 => 'Warburton',
        209 => 'Wazirabad',
        210 => 'West Punjab',
        211 => 'Yazman',
        212 => 'Zafarwal',
        213 => 'Zahir Pir',
      ),
    ),
  ),
  'QA' => 
  array (
    'RA' => 
    array (
      'name' => 'Al Rayyan Municipality',
      'cities' => 
      array (
        0 => 'Ar Rayyān',
        1 => 'Umm Bāb',
      ),
    ),
    'SH' => 
    array (
      'name' => 'Al-Shahaniya',
      'cities' => 
      array (
        0 => 'Al Jumaylīyah',
        1 => 'Ash Shīḩānīyah',
        2 => 'Dukhān',
      ),
    ),
    'WA' => 
    array (
      'name' => 'Al Wakrah',
      'cities' => 
      array (
        0 => 'Al Wakrah',
        1 => 'Al Wukayr',
        2 => 'Musay&#039;īd',
      ),
    ),
    'MS' => 
    array (
      'name' => 'Madinat ash Shamal',
      'cities' => 
      array (
        0 => 'Ar Ruways',
        1 => 'Fuwayriţ',
        2 => 'Madīnat ash Shamāl',
      ),
    ),
    'DA' => 
    array (
      'name' => 'Doha',
      'cities' => 
      array (
        0 => 'Doha',
      ),
    ),
    'KH' => 
    array (
      'name' => 'Al Khor',
      'cities' => 
      array (
        0 => 'Al Ghuwayrīyah',
        1 => 'Al Khawr',
      ),
    ),
    'US' => 
    array (
      'name' => 'Umm Salal Municipality',
      'cities' => 
      array (
        0 => 'Umm Şalāl Muḩammad',
      ),
    ),
  ),
  'BI' => 
  array (
    'RM' => 
    array (
      'name' => 'Rumonge Province',
      'cities' => 
      array (
        0 => 'Rumonge',
      ),
    ),
    'MY' => 
    array (
      'name' => 'Muyinga Province',
      'cities' => 
      array (
        0 => 'Muyinga',
      ),
    ),
    'MW' => 
    array (
      'name' => 'Mwaro Province',
      'cities' => 
      array (
        0 => 'Mwaro',
      ),
    ),
    'MA' => 
    array (
      'name' => 'Makamba Province',
      'cities' => 
      array (
        0 => 'Makamba',
      ),
    ),
    'RT' => 
    array (
      'name' => 'Rutana Province',
      'cities' => 
      array (
        0 => 'Rutana',
      ),
    ),
    'CI' => 
    array (
      'name' => 'Cibitoke Province',
      'cities' => 
      array (
        0 => 'Cibitoke',
      ),
    ),
    'RY' => 
    array (
      'name' => 'Ruyigi Province',
      'cities' => 
      array (
        0 => 'Ruyigi',
      ),
    ),
    'KY' => 
    array (
      'name' => 'Kayanza Province',
      'cities' => 
      array (
        0 => 'Kayanza',
      ),
    ),
    'MU' => 
    array (
      'name' => 'Muramvya Province',
      'cities' => 
      array (
        0 => 'Muramvya',
      ),
    ),
    'KR' => 
    array (
      'name' => 'Karuzi Province',
      'cities' => 
      array (
        0 => 'Karuzi',
      ),
    ),
    'KI' => 
    array (
      'name' => 'Kirundo Province',
      'cities' => 
      array (
        0 => 'Kirundo',
      ),
    ),
    'BB' => 
    array (
      'name' => 'Bubanza Province',
      'cities' => 
      array (
        0 => 'Bubanza',
      ),
    ),
    'GI' => 
    array (
      'name' => 'Gitega Province',
      'cities' => 
      array (
        0 => 'Gitega',
      ),
    ),
    'BM' => 
    array (
      'name' => 'Bujumbura Mairie Province',
      'cities' => 
      array (
        0 => 'Bujumbura',
      ),
    ),
    'NG' => 
    array (
      'name' => 'Ngozi Province',
      'cities' => 
      array (
        0 => 'Ngozi',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Cankuzo Province',
      'cities' => 
      array (
        0 => 'Cankuzo',
      ),
    ),
    'BR' => 
    array (
      'name' => 'Bururi Province',
      'cities' => 
      array (
        0 => 'Bururi',
      ),
    ),
  ),
  'UY' => 
  array (
    'FS' => 
    array (
      'name' => 'Flores Department',
      'cities' => 
      array (
        0 => 'Trinidad',
      ),
    ),
    'SJ' => 
    array (
      'name' => 'San José Department',
      'cities' => 
      array (
        0 => 'Delta del Tigre',
        1 => 'Ecilda Paullier',
        2 => 'Libertad',
        3 => 'Puntas de Valdéz',
        4 => 'Rafael Perazza',
        5 => 'Rodríguez',
        6 => 'San José de Mayo',
      ),
    ),
    'AR' => 
    array (
      'name' => 'Artigas Department',
      'cities' => 
      array (
        0 => 'Artigas',
        1 => 'Baltasar Brum',
        2 => 'Bella Unión',
        3 => 'Las Piedras',
        4 => 'Tomás Gomensoro',
      ),
    ),
    'MA' => 
    array (
      'name' => 'Maldonado Department',
      'cities' => 
      array (
        0 => 'Aiguá',
        1 => 'Maldonado',
        2 => 'Pan de Azúcar',
        3 => 'Piriápolis',
        4 => 'Punta del Este',
        5 => 'San Carlos',
      ),
    ),
    'RV' => 
    array (
      'name' => 'Rivera Department',
      'cities' => 
      array (
        0 => 'Minas de Corrales',
        1 => 'Rivera',
        2 => 'Tranqueras',
        3 => 'Vichadero',
      ),
    ),
    'CO' => 
    array (
      'name' => 'Colonia Department',
      'cities' => 
      array (
        0 => 'Carmelo',
        1 => 'Colonia del Sacramento',
        2 => 'Florencio Sánchez',
        3 => 'Juan L. Lacaze',
        4 => 'Nueva Helvecia',
        5 => 'Nueva Palmira',
        6 => 'Ombúes de Lavalle',
        7 => 'Rosario',
        8 => 'Tarariras',
      ),
    ),
    'DU' => 
    array (
      'name' => 'Durazno Department',
      'cities' => 
      array (
        0 => 'Blanquillo',
        1 => 'Carlos Reyles',
        2 => 'Durazno',
        3 => 'La Paloma',
        4 => 'Santa Bernardina',
        5 => 'Sarandí del Yi',
        6 => 'Villa del Carmen',
      ),
    ),
    'RN' => 
    array (
      'name' => 'Río Negro Department',
      'cities' => 
      array (
        0 => 'Fray Bentos',
        1 => 'Nuevo Berlín',
        2 => 'San Javier',
        3 => 'Young',
      ),
    ),
    'CL' => 
    array (
      'name' => 'Cerro Largo Department',
      'cities' => 
      array (
        0 => 'Aceguá',
        1 => 'Isidoro Noblía',
        2 => 'Melo',
        3 => 'Río Branco',
        4 => 'Tupambaé',
      ),
    ),
    'PA' => 
    array (
      'name' => 'Paysandú Department',
      'cities' => 
      array (
        0 => 'Estación Porvenir',
        1 => 'Guichón',
        2 => 'Paysandú',
        3 => 'Piedras Coloradas',
        4 => 'Quebracho',
        5 => 'San Félix',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Canelones Department',
      'cities' => 
      array (
        0 => 'Aguas Corrientes',
        1 => 'Atlántida',
        2 => 'Barra de Carrasco',
        3 => 'Barros Blancos',
        4 => 'Canelones',
        5 => 'Colonia Nicolich',
        6 => 'Empalme Olmos',
        7 => 'Joaquín Suárez',
        8 => 'Juanicó',
        9 => 'La Floresta',
        10 => 'La Paz',
        11 => 'Las Piedras',
        12 => 'Las Toscas',
        13 => 'Los Cerrillos',
        14 => 'Migues',
        15 => 'Montes',
        16 => 'Pando',
        17 => 'Paso de Carrasco',
        18 => 'Progreso',
        19 => 'San Antonio',
        20 => 'San Bautista',
        21 => 'San Jacinto',
        22 => 'San Ramón',
        23 => 'Santa Lucía',
        24 => 'Santa Rosa',
        25 => 'Sauce',
        26 => 'Soca',
        27 => 'Tala',
        28 => 'Toledo',
      ),
    ),
    'TT' => 
    array (
      'name' => 'Treinta y Tres Department',
      'cities' => 
      array (
        0 => 'Santa Clara de Olimar',
        1 => 'Treinta y Tres',
        2 => 'Vergara',
        3 => 'Villa Sara',
      ),
    ),
    'LA' => 
    array (
      'name' => 'Lavalleja Department',
      'cities' => 
      array (
        0 => 'José Batlle y Ordóñez',
        1 => 'José Pedro Varela',
        2 => 'Mariscala',
        3 => 'Minas',
        4 => 'Solís de Mataojo',
      ),
    ),
    'RO' => 
    array (
      'name' => 'Rocha Department',
      'cities' => 
      array (
        0 => 'Castillos',
        1 => 'Cebollatí',
        2 => 'Chui',
        3 => 'Dieciocho de Julio',
        4 => 'La Paloma',
        5 => 'Lascano',
        6 => 'Rocha',
        7 => 'Velázquez',
      ),
    ),
    'FD' => 
    array (
      'name' => 'Florida Department',
      'cities' => 
      array (
        0 => '25 de Agosto',
        1 => '25 de Mayo',
        2 => 'Alejandro Gallinal',
        3 => 'Cardal',
        4 => 'Casupá',
        5 => 'Florida',
        6 => 'Sarandí Grande',
      ),
    ),
    'MO' => 
    array (
      'name' => 'Montevideo Department',
      'cities' => 
      array (
        0 => 'Montevideo',
        1 => 'Pajas Blancas',
        2 => 'Santiago Vázquez',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Soriano Department',
      'cities' => 
      array (
        0 => 'Cardona',
        1 => 'Dolores',
        2 => 'José Enrique Rodó',
        3 => 'Mercedes',
        4 => 'Palmitas',
        5 => 'Santa Catalina',
        6 => 'Villa Soriano',
      ),
    ),
    'SA' => 
    array (
      'name' => 'Salto Department',
      'cities' => 
      array (
        0 => 'Belén',
        1 => 'Salto',
        2 => 'Villa Constitución',
      ),
    ),
    'TA' => 
    array (
      'name' => 'Tacuarembó Department',
      'cities' => 
      array (
        0 => 'Curtina',
        1 => 'Paso de los Toros',
        2 => 'Tacuarembó',
      ),
    ),
  ),
  'EG' => 
  array (
    'KFS' => 
    array (
      'name' => 'Kafr el-Sheikh Governorate',
      'cities' => 
      array (
        0 => 'Al Ḩāmūl',
        1 => 'Disūq',
        2 => 'Fuwwah',
        3 => 'Kafr ash Shaykh',
        4 => 'Markaz Disūq',
        5 => 'Munshāt &#039;Alī Āghā',
        6 => 'Sīdī Sālim',
      ),
    ),
    'C' => 
    array (
      'name' => 'Cairo Governorate',
      'cities' => 
      array (
        0 => 'Cairo',
        1 => 'New Cairo',
        2 => 'Ḩalwān',
      ),
    ),
    'DT' => 
    array (
      'name' => 'Damietta Governorate',
      'cities' => 
      array (
        0 => 'Az Zarqā',
        1 => 'Damietta',
        2 => 'Fāraskūr',
      ),
    ),
    'ASN' => 
    array (
      'name' => 'Aswan Governorate',
      'cities' => 
      array (
        0 => 'Abu Simbel',
        1 => 'Aswan',
        2 => 'Idfū',
        3 => 'Kawm Umbū',
      ),
    ),
    'SHG' => 
    array (
      'name' => 'Sohag Governorate',
      'cities' => 
      array (
        0 => 'Akhmīm',
        1 => 'Al Balyanā',
        2 => 'Al Manshāh',
        3 => 'Jirjā',
        4 => 'Juhaynah',
        5 => 'Markaz Jirjā',
        6 => 'Markaz Sūhāj',
        7 => 'Sohag',
        8 => 'Ţahţā',
      ),
    ),
    'SIN' => 
    array (
      'name' => 'North Sinai Governorate',
      'cities' => 
      array (
        0 => 'Arish',
      ),
    ),
    'MNF' => 
    array (
      'name' => 'Monufia Governorate',
      'cities' => 
      array (
        0 => 'Al Bājūr',
        1 => 'Ash Shuhadā&#039;',
        2 => 'Ashmūn',
        3 => 'Munūf',
        4 => 'Quwaysinā',
        5 => 'Shibīn al Kawm',
        6 => 'Talā',
      ),
    ),
    'PTS' => 
    array (
      'name' => 'Port Said Governorate',
      'cities' => 
      array (
        0 => 'Port Said',
      ),
    ),
    'BNS' => 
    array (
      'name' => 'Beni Suef Governorate',
      'cities' => 
      array (
        0 => 'Al Fashn',
        1 => 'Banī Suwayf',
        2 => 'Būsh',
        3 => 'Sumusţā as Sulţānī',
      ),
    ),
    'MT' => 
    array (
      'name' => 'Matrouh Governorate',
      'cities' => 
      array (
        0 => 'Al &#039;Alamayn',
        1 => 'Mersa Matruh',
        2 => 'Siwa Oasis',
      ),
    ),
    'KB' => 
    array (
      'name' => 'Qalyubia Governorate',
      'cities' => 
      array (
        0 => 'Al Khānkah',
        1 => 'Al Qanāţir al Khayrīyah',
        2 => 'Banhā',
        3 => 'Qalyūb',
        4 => 'Shibīn al Qanāṭir',
        5 => 'Toukh',
      ),
    ),
    'SUZ' => 
    array (
      'name' => 'Suez Governorate',
      'cities' => 
      array (
        0 => 'Ain Sukhna',
        1 => 'Suez',
      ),
    ),
    'GH' => 
    array (
      'name' => 'Gharbia Governorate',
      'cities' => 
      array (
        0 => 'Al Maḩallah al Kubrá',
        1 => 'Basyūn',
        2 => 'Kafr az Zayyāt',
        3 => 'Quţūr',
        4 => 'Samannūd',
        5 => 'Tanda',
        6 => 'Zefta',
      ),
    ),
    'ALX' => 
    array (
      'name' => 'Alexandria Governorate',
      'cities' => 
      array (
        0 => 'Alexandria',
      ),
    ),
    'AST' => 
    array (
      'name' => 'Asyut Governorate',
      'cities' => 
      array (
        0 => 'Abnūb',
        1 => 'Abū Tīj',
        2 => 'Al Badārī',
        3 => 'Al Qūşīyah',
        4 => 'Asyūţ',
        5 => 'Dayrūţ',
        6 => 'Manfalūţ',
      ),
    ),
    'JS' => 
    array (
      'name' => 'South Sinai Governorate',
      'cities' => 
      array (
        0 => 'Dahab',
        1 => 'El-Tor',
        2 => 'Nuwaybi&#039;a',
        3 => 'Saint Catherine',
        4 => 'Sharm el-Sheikh',
      ),
    ),
    'FYM' => 
    array (
      'name' => 'Faiyum Governorate',
      'cities' => 
      array (
        0 => 'Al Fayyūm',
        1 => 'Al Wāsiţah',
        2 => 'Ibshawāy',
        3 => 'Iţsā',
        4 => 'Ţāmiyah',
      ),
    ),
    'GZ' => 
    array (
      'name' => 'Giza Governorate',
      'cities' => 
      array (
        0 => 'Al Bawīţī',
        1 => 'Al Ḩawāmidīyah',
        2 => 'Al &#039;Ayyāţ',
        3 => 'Awsīm',
        4 => 'Aş Şaff',
        5 => 'Giza',
        6 => 'Madīnat Sittah Uktūbar',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Red Sea Governorate',
      'cities' => 
      array (
        0 => 'Al Quşayr',
        1 => 'El Gouna',
        2 => 'Hurghada',
        3 => 'Makadi Bay',
        4 => 'Marsa Alam',
        5 => 'Ras Gharib',
        6 => 'Safaga',
      ),
    ),
    'BH' => 
    array (
      'name' => 'Beheira Governorate',
      'cities' => 
      array (
        0 => 'Abū al Maţāmīr',
        1 => 'Ad Dilinjāt',
        2 => 'Damanhūr',
        3 => 'Idkū',
        4 => 'Kafr ad Dawwār',
        5 => 'Kawm Ḩamādah',
        6 => 'Rosetta',
        7 => 'Ḩawsh &#039;Īsá',
      ),
    ),
    'LX' => 
    array (
      'name' => 'Luxor Governorate',
      'cities' => 
      array (
        0 => 'Luxor',
        1 => 'Markaz al Uqşur',
      ),
    ),
    'MN' => 
    array (
      'name' => 'Minya Governorate',
      'cities' => 
      array (
        0 => 'Abū Qurqāş',
        1 => 'Al Minyā',
        2 => 'Banī Mazār',
        3 => 'Dayr Mawās',
        4 => 'Mallawī',
        5 => 'Maţāy',
        6 => 'Samālūţ',
      ),
    ),
    'IS' => 
    array (
      'name' => 'Ismailia Governorate',
      'cities' => 
      array (
        0 => 'Ismailia',
      ),
    ),
    'DK' => 
    array (
      'name' => 'Dakahlia Governorate',
      'cities' => 
      array (
        0 => 'Ajā',
        1 => 'Al Jammālīyah',
        2 => 'Al Manzalah',
        3 => 'Al Manşūrah',
        4 => 'Al Maţarīyah',
        5 => 'Bilqās',
        6 => 'Dikirnis',
        7 => 'Minyat an Naşr',
        8 => 'Shirbīn',
        9 => 'Ţalkhā',
        10 => '&#039;Izbat al Burj',
      ),
    ),
    'WAD' => 
    array (
      'name' => 'New Valley Governorate',
      'cities' => 
      array (
        0 => 'Al Khārijah',
        1 => 'Qaşr al Farāfirah',
      ),
    ),
    'KN' => 
    array (
      'name' => 'Qena Governorate',
      'cities' => 
      array (
        0 => 'Dishnā',
        1 => 'Farshūţ',
        2 => 'Isnā',
        3 => 'Kousa',
        4 => 'Naja&#039; Ḥammādī',
        5 => 'Qinā',
      ),
    ),
  ),
  'MU' => 
  array (
    'AG' => 
    array (
      'name' => 'Agaléga',
      'cities' => 
      array (
        0 => 'Vingt Cinq',
      ),
    ),
    'RO' => 
    array (
      'name' => 'Rodrigues',
      'cities' => 
      array (
        0 => 'Baie aux Huîtres',
        1 => 'Port Mathurin',
      ),
    ),
    'PA' => 
    array (
      'name' => 'Pamplemousses District',
      'cities' => 
      array (
        0 => 'Arsenal',
        1 => 'Calebasses',
        2 => 'Congomah',
        3 => 'Crève Coeur',
        4 => 'Fond du Sac',
        5 => 'Le Hochet',
        6 => 'Long Mountain',
        7 => 'Morcellement Saint André',
        8 => 'Notre Dame',
        9 => 'Pamplemousses',
        10 => 'Plaine des Papayes',
        11 => 'Pointe aux Piments',
        12 => 'Terre Rouge',
        13 => 'Triolet',
      ),
    ),
    'CC' => 
    array (
      'name' => 'Cargados Carajos',
      'cities' => 
      array (
        0 => 'Cargados Carajos',
      ),
    ),
    'MO' => 
    array (
      'name' => 'Moka District',
      'cities' => 
      array (
        0 => 'Camp Thorel',
        1 => 'Dagotière',
        2 => 'Dubreuil',
        3 => 'Melrose',
        4 => 'Moka',
        5 => 'Pailles',
        6 => 'Providence',
        7 => 'Quartier Militaire',
        8 => 'Saint Pierre',
        9 => 'Verdun',
      ),
    ),
    'FL' => 
    array (
      'name' => 'Flacq District',
      'cities' => 
      array (
        0 => 'Bel Air Rivière Sèche',
        1 => 'Bon Accueil',
        2 => 'Brisée Verdière',
        3 => 'Camp Ithier',
        4 => 'Camp de Masque',
        5 => 'Centre de Flacq',
        6 => 'Clémencia',
        7 => 'Ecroignard',
        8 => 'Grande Rivière Sud Est',
        9 => 'Lalmatie',
        10 => 'Laventure',
        11 => 'Mare La Chaux',
        12 => 'Olivia',
        13 => 'Poste de Flacq',
        14 => 'Quatre Cocos',
        15 => 'Quatre Soeurs',
        16 => 'Queen Victoria',
        17 => 'Saint Julien',
        18 => 'Sebastopol',
      ),
    ),
    'SA' => 
    array (
      'name' => 'Savanne District',
      'cities' => 
      array (
        0 => 'Camp Diable',
        1 => 'Chamouny',
        2 => 'Chemin Grenier',
        3 => 'Grand Bois',
        4 => 'Rivière des Anguilles',
        5 => 'Saint Aubin',
        6 => 'Souillac',
        7 => 'Surinam',
      ),
    ),
    'BL' => 
    array (
      'name' => 'Rivière Noire District',
      'cities' => 
      array (
        0 => 'Albion',
        1 => 'Bambous',
        2 => 'Cascavelle',
        3 => 'Flic en Flac',
        4 => 'Grande Rivière Noire',
        5 => 'Gros Cailloux',
        6 => 'Petite Case Noyale',
        7 => 'Petite Rivière',
        8 => 'Tamarin',
      ),
    ),
    'PL' => 
    array (
      'name' => 'Port Louis District',
      'cities' => 
      array (
        0 => 'Port Louis',
      ),
    ),
    'RR' => 
    array (
      'name' => 'Rivière du Rempart District',
      'cities' => 
      array (
        0 => 'Amaury',
        1 => 'Cap Malheureux',
        2 => 'Cottage',
        3 => 'Espérance Trébuchet',
        4 => 'Goodlands',
        5 => 'Grand Baie',
        6 => 'Grand Gaube',
        7 => 'Mapou',
        8 => 'Petit Raffray',
        9 => 'Piton',
        10 => 'Plaines des Roches',
        11 => 'Rivière du Rempart',
        12 => 'Roche Terre',
        13 => 'Roches Noire',
        14 => 'The Vale',
      ),
    ),
    'PW' => 
    array (
      'name' => 'Plaines Wilhems District',
      'cities' => 
      array (
        0 => 'Beau Bassin-Rose Hill',
        1 => 'Curepipe',
        2 => 'Ebene',
        3 => 'Midlands',
        4 => 'Quatre Bornes',
        5 => 'Vacoas',
      ),
    ),
    'GP' => 
    array (
      'name' => 'Grand Port District',
      'cities' => 
      array (
        0 => 'Bambous Virieux',
        1 => 'Beau Vallon',
        2 => 'Bois des Amourettes',
        3 => 'Cluny',
        4 => 'Grand Sable',
        5 => 'Mahébourg',
        6 => 'New Grove',
        7 => 'Nouvelle France',
        8 => 'Plaine Magnien',
        9 => 'Rose Belle',
        10 => 'Saint Hubert',
      ),
    ),
  ),
  'MA' => 
  array (
    '02' => 
    array (
      'name' => 'Oriental',
      'cities' => 
      array (
        0 => 'Ahfir',
        1 => 'Al Aaroui',
        2 => 'Aïn Beni Mathar',
        3 => 'Berkane',
        4 => 'Bouarfa',
        5 => 'Debdou',
        6 => 'Driouch Province',
        7 => 'El Aïoun',
        8 => 'Figuig',
        9 => 'Guercif Province',
        10 => 'Jerada',
        11 => 'Madagh',
        12 => 'Midar',
        13 => 'Nador',
        14 => 'Oujda-Angad',
        15 => 'Saidia',
        16 => 'Selouane',
        17 => 'Taourirt',
        18 => 'Tiztoutine',
        19 => 'Zaïo',
      ),
    ),
    '08' => 
    array (
      'name' => 'Drâa-Tafilalet',
      'cities' => 
      array (
        0 => 'Agdz',
        1 => 'Alnif',
        2 => 'Aoufous',
        3 => 'Arfoud',
        4 => 'Errachidia',
        5 => 'Imilchil',
        6 => 'Jebel Tiskaouine',
        7 => 'Jorf',
        8 => 'Kelaat Mgouna',
        9 => 'Mhamid',
        10 => 'Midelt',
        11 => 'Ouarzazat',
        12 => 'Ouarzazate',
        13 => 'Reçani',
        14 => 'Taznakht',
        15 => 'Telouet',
        16 => 'Tinghir',
        17 => 'Tinghir Province',
        18 => 'Zagora',
      ),
    ),
    'ASZ' => 
    array (
      'name' => 'Assa-Zag Province',
      'cities' => 
      array (
        0 => 'Agadir',
        1 => 'Agadir Melloul',
        2 => 'Agadir-Ida-ou-Tnan',
        3 => 'Aoulouz',
        4 => 'Aourir',
        5 => 'Arazane',
        6 => 'Argana',
        7 => 'Bigoudine',
        8 => 'Chtouka-Ait-Baha',
        9 => 'Inezgane',
        10 => 'Inezgane-Ait Melloul',
        11 => 'Ouijjane',
        12 => 'Oulad Teïma',
        13 => 'Reggada',
        14 => 'Sidi Ifni',
        15 => 'Tadrart',
        16 => 'Tafraout',
        17 => 'Taghazout',
        18 => 'Taliouine',
        19 => 'Tamri',
        20 => 'Tanalt',
        21 => 'Taroudannt',
        22 => 'Taroudant',
        23 => 'Tarsouat',
        24 => 'Tata',
        25 => 'Tiznit',
      ),
    ),
    '06' => 
    array (
      'name' => 'Casablanca-Settat',
      'cities' => 
      array (
        0 => 'Azemmour',
        1 => 'Benslimane',
        2 => 'Berrechid',
        3 => 'Berrechid Province',
        4 => 'Boulaouane',
        5 => 'Bouskoura',
        6 => 'Bouznika',
        7 => 'Casablanca',
        8 => 'El Jadid',
        9 => 'El-Jadida',
        10 => 'Mediouna',
        11 => 'Mohammedia',
        12 => 'Nouaceur',
        13 => 'Oualidia',
        14 => 'Oulad Frej',
        15 => 'Settat',
        16 => 'Settat Province',
        17 => 'Sidi Bennour',
        18 => 'Sidi Smai&#039;il',
        19 => 'Tit Mellil',
        20 => 'Zawyat an Nwaçer',
      ),
    ),
    'KEN' => 
    array (
      'name' => 'Kénitra Province',
      'cities' => 
      array (
        0 => 'Arbaoua',
        1 => 'Had Kourt',
        2 => 'Kenitra',
        3 => 'Kenitra Province',
        4 => 'Khemisset',
        5 => 'Mechraa Bel Ksiri',
        6 => 'Oulmes',
        7 => 'Rabat',
        8 => 'Sale',
        9 => 'Sidi Bousber',
        10 => 'Sidi Qacem',
        11 => 'Sidi Redouane',
        12 => 'Sidi Slimane',
        13 => 'Sidi Yahia El Gharb',
        14 => 'Sidi-Kacem',
        15 => 'Skhirate',
        16 => 'Skhirate-Temara',
        17 => 'Souq Larb&#039;a al Gharb',
        18 => 'Temara',
        19 => 'Teroual',
        20 => 'Tiflet',
      ),
    ),
    'SAF' => 
    array (
      'name' => 'Safi Province',
      'cities' => 
      array (
        0 => 'Abadou',
        1 => 'Adassil',
        2 => 'Al-Haouz',
        3 => 'Bouabout',
        4 => 'Chichaoua',
        5 => 'Essaouira',
        6 => 'Kelaa-Des-Sraghna',
        7 => 'Marrakech',
        8 => 'Marrakesh',
        9 => 'Oukaïmedene',
        10 => 'Rehamna',
        11 => 'Safi',
        12 => 'Setti Fatma',
        13 => 'Sidi Rahhal',
        14 => 'Smimou',
        15 => 'Tamanar',
        16 => 'Taouloukoult',
        17 => 'Tidili Mesfioua',
        18 => 'Timezgadiouine',
        19 => 'Youssoufia',
        20 => 'Zerkten',
      ),
    ),
    '03' => 
    array (
      'name' => 'Fès-Meknès',
      'cities' => 
      array (
        0 => 'Aknoul',
        1 => 'Almis Marmoucha',
        2 => 'Azrou',
        3 => 'Aïn Leuh',
        4 => 'Bhalil',
        5 => 'Bouarouss',
        6 => 'Boulemane',
        7 => 'El Hajeb',
        8 => 'El-Hajeb',
        9 => 'Fes',
        10 => 'Fès',
        11 => 'Fès al Bali',
        12 => 'Galaz',
        13 => 'Ghouazi',
        14 => 'Guercif',
        15 => 'Ifrane',
        16 => 'Meknes',
        17 => 'Meknès',
        18 => 'Missour',
        19 => 'Moulay Bouchta',
        20 => 'Moulay-Yacoub',
        21 => 'Oued Amlil',
        22 => 'Oulad Tayeb',
        23 => 'Ourtzagh',
        24 => 'Sefrou',
        25 => 'Tahla',
        26 => 'Talzemt',
        27 => 'Taounate',
        28 => 'Taza',
        29 => 'Tmourghout',
      ),
    ),
    'KHN' => 
    array (
      'name' => 'Khénifra Province',
      'cities' => 
      array (
        0 => 'Aguelmous',
        1 => 'Al Fqih Ben Çalah',
        2 => 'Azilal',
        3 => 'Azilal Province',
        4 => 'Beni Mellal',
        5 => 'Beni-Mellal',
        6 => 'Boujniba',
        7 => 'Bzou',
        8 => 'Dar Ould Zidouh',
        9 => 'Demnate',
        10 => 'El Ksiba',
        11 => 'Fquih Ben Salah Province',
        12 => 'Ifrane',
        13 => 'Isseksi',
        14 => 'Itzer',
        15 => 'Kasba Tadla',
        16 => 'Kerrouchen',
        17 => 'Khenifra',
        18 => 'Khouribga',
        19 => 'Khouribga Province',
        20 => 'Midelt',
        21 => 'Ouaoula',
        22 => 'Oued Zem',
        23 => 'Sidi Jaber',
        24 => 'Timoulilt',
        25 => 'Zawyat ech Cheïkh',
      ),
    ),
    'OUD' => 
    array (
      'name' => 'Oued Ed-Dahab Province',
      'cities' => 
      array (
        0 => 'Aousserd',
        1 => 'Imlili',
        2 => 'Oued-Ed-Dahab',
      ),
    ),
    '01' => 
    array (
      'name' => 'Tanger-Tétouan-Al Hoceïma',
      'cities' => 
      array (
        0 => 'Al Hoceïma',
        1 => 'Al-Hoceima',
        2 => 'Asilah',
        3 => 'Bni Bouayach',
        4 => 'Brikcha',
        5 => 'Cap Negro II',
        6 => 'Chefchaouen Province',
        7 => 'Chefchaouene',
        8 => 'Derdara',
        9 => 'Fahs-Anjra',
        10 => 'Fnidek',
        11 => 'Imzouren',
        12 => 'Ksar El Kebir',
        13 => 'Larache',
        14 => 'M&#039;Diq-Fnideq',
        15 => 'Martil',
        16 => 'Oued Laou',
        17 => 'Ouezzane',
        18 => 'Ouezzane Province',
        19 => 'Senada',
        20 => 'Tamorot',
        21 => 'Tanger-Assilah',
        22 => 'Tangier',
        23 => 'Targuist',
        24 => 'Tetouan',
        25 => 'Tirhanimîne',
        26 => 'Tétouan',
        27 => 'Zinat',
        28 => 'Zoumi',
      ),
    ),
  ),
  'MZ' => 
  array (
    'P' => 
    array (
      'name' => 'Cabo Delgado Province',
      'cities' => 
      array (
        0 => 'Chiure',
        1 => 'Mocímboa',
        2 => 'Montepuez',
        3 => 'Pemba',
      ),
    ),
    'Q' => 
    array (
      'name' => 'Zambezia Province',
      'cities' => 
      array (
        0 => 'Alto Molócuè',
        1 => 'Chinde',
        2 => 'Quelimane',
      ),
    ),
    'G' => 
    array (
      'name' => 'Gaza Province',
      'cities' => 
      array (
        0 => 'Chibuto',
        1 => 'Chokwé',
        2 => 'Macia',
        3 => 'Xai-Xai',
      ),
    ),
    'I' => 
    array (
      'name' => 'Inhambane Province',
      'cities' => 
      array (
        0 => 'Inhambane',
        1 => 'Maxixe',
      ),
    ),
    'S' => 
    array (
      'name' => 'Sofala Province',
      'cities' => 
      array (
        0 => 'Beira',
        1 => 'Dondo',
        2 => 'Nhamatanda District',
      ),
    ),
    'L' => 
    array (
      'name' => 'Maputo Province',
      'cities' => 
      array (
        0 => 'Boane District',
        1 => 'Concelho de Matola',
        2 => 'Magude District',
        3 => 'Manhica',
        4 => 'Marracuene District',
        5 => 'Matola',
        6 => 'Matutiune District',
        7 => 'Moamba District',
        8 => 'Namaacha District',
        9 => 'Ressano Garcia',
      ),
    ),
    'A' => 
    array (
      'name' => 'Niassa Province',
      'cities' => 
      array (
        0 => 'Cuamba',
        1 => 'Lichinga',
        2 => 'Mandimba',
      ),
    ),
    'T' => 
    array (
      'name' => 'Tete Province',
      'cities' => 
      array (
        0 => 'Tete',
      ),
    ),
    'MPM' => 
    array (
      'name' => 'Maputo',
      'cities' => 
      array (
        0 => 'KaTembe',
        1 => 'Maputo',
      ),
    ),
    'N' => 
    array (
      'name' => 'Nampula Province',
      'cities' => 
      array (
        0 => 'António Enes',
        1 => 'Ilha de Moçambique',
        2 => 'Mutuáli',
        3 => 'Nacala',
        4 => 'Nampula',
      ),
    ),
    'B' => 
    array (
      'name' => 'Manica Province',
      'cities' => 
      array (
        0 => 'Chimoio',
      ),
    ),
  ),
  'MR' => 
  array (
    '01' => 
    array (
      'name' => 'Hodh Ech Chargui Region',
      'cities' => 
      array (
        0 => 'Néma',
      ),
    ),
    '05' => 
    array (
      'name' => 'Brakna Region',
      'cities' => 
      array (
        0 => 'Aleg',
        1 => '&#039;Elb el Jmel',
      ),
    ),
    '04' => 
    array (
      'name' => 'Gorgol Region',
      'cities' => 
      array (
        0 => 'Kaédi',
      ),
    ),
    '07' => 
    array (
      'name' => 'Adrar Region',
      'cities' => 
      array (
        0 => 'Atar',
        1 => 'Chingueṭṭi',
      ),
    ),
    '08' => 
    array (
      'name' => 'Dakhlet Nouadhibou',
      'cities' => 
      array (
        0 => 'Nouadhibou',
      ),
    ),
    '06' => 
    array (
      'name' => 'Trarza Region',
      'cities' => 
      array (
        0 => 'Rosso',
        1 => 'Tékane',
      ),
    ),
    '03' => 
    array (
      'name' => 'Assaba Region',
      'cities' => 
      array (
        0 => 'Barkéwol',
        1 => 'Kiffa',
      ),
    ),
    '02' => 
    array (
      'name' => 'Hodh El Gharbi Region',
      'cities' => 
      array (
        0 => 'Aioun',
      ),
    ),
  ),
  'TT' => 
  array (
    'WTO' => 
    array (
      'name' => 'Western Tobago',
      'cities' => 
      array (
        0 => 'Rio Claro',
      ),
    ),
    'CTT' => 
    array (
      'name' => 'Couva-Tabaquite-Talparo Regional Corporation',
      'cities' => 
      array (
        0 => 'Couva',
        1 => 'Tabaquite',
      ),
    ),
    'ETO' => 
    array (
      'name' => 'Eastern Tobago',
      'cities' => 
      array (
        0 => 'Scarborough',
      ),
    ),
    'SJL' => 
    array (
      'name' => 'San Juan-Laventille Regional Corporation',
      'cities' => 
      array (
        0 => 'Laventille',
      ),
    ),
    'TUP' => 
    array (
      'name' => 'Tunapuna-Piarco Regional Corporation',
      'cities' => 
      array (
        0 => 'Arouca',
        1 => 'Paradise',
        2 => 'Tunapuna',
      ),
    ),
    'SFO' => 
    array (
      'name' => 'San Fernando',
      'cities' => 
      array (
        0 => 'Marabella',
        1 => 'Mon Repos',
        2 => 'San Fernando',
      ),
    ),
    'PTF' => 
    array (
      'name' => 'Point Fortin',
      'cities' => 
      array (
        0 => 'Point Fortin',
      ),
    ),
    'SGE' => 
    array (
      'name' => 'Sangre Grande Regional Corporation',
      'cities' => 
      array (
        0 => 'Sangre Grande',
      ),
    ),
    'ARI' => 
    array (
      'name' => 'Arima',
      'cities' => 
      array (
        0 => 'Arima',
      ),
    ),
    'POS' => 
    array (
      'name' => 'Port of Spain',
      'cities' => 
      array (
        0 => 'Mucurapo',
        1 => 'Port of Spain',
      ),
    ),
    'SIP' => 
    array (
      'name' => 'Siparia Regional Corporation',
      'cities' => 
      array (
        0 => 'Siparia',
        1 => 'Ward of Siparia',
      ),
    ),
    'PED' => 
    array (
      'name' => 'Penal-Debe Regional Corporation',
      'cities' => 
      array (
        0 => 'Debe',
        1 => 'Peñal',
      ),
    ),
    'CHA' => 
    array (
      'name' => 'Chaguanas',
      'cities' => 
      array (
        0 => 'Chaguanas',
        1 => 'Ward of Chaguanas',
      ),
    ),
    'DMN' => 
    array (
      'name' => 'Diego Martin Regional Corporation',
      'cities' => 
      array (
        0 => 'Petit Valley',
        1 => 'Ward of Diego Martin',
      ),
    ),
    'PRT' => 
    array (
      'name' => 'Princes Town Regional Corporation',
      'cities' => 
      array (
        0 => 'Princes Town',
      ),
    ),
  ),
  'TM' => 
  array (
    'M' => 
    array (
      'name' => 'Mary Region',
      'cities' => 
      array (
        0 => 'Bayramaly',
        1 => 'Mary',
        2 => 'Serhetabat',
        3 => 'Seydi',
        4 => 'Yolöten',
      ),
    ),
    'L' => 
    array (
      'name' => 'Lebap Region',
      'cities' => 
      array (
        0 => 'Atamyrat',
        1 => 'Farap',
        2 => 'Gazojak',
        3 => 'Gowurdak',
        4 => 'Saýat',
        5 => 'Türkmenabat',
      ),
    ),
    'S' => 
    array (
      'name' => 'Ashgabat',
      'cities' => 
      array (
        0 => 'Ashgabat',
      ),
    ),
    'B' => 
    array (
      'name' => 'Balkan Region',
      'cities' => 
      array (
        0 => 'Balkanabat',
        1 => 'Bereket',
        2 => 'Gumdag',
        3 => 'Magtymguly',
        4 => 'Serdar',
        5 => 'Türkmenbaşy',
      ),
    ),
    'D' => 
    array (
      'name' => 'Daşoguz Region',
      'cities' => 
      array (
        0 => 'Akdepe',
        1 => 'Boldumsaz',
        2 => 'Daşoguz',
        3 => 'Köneürgench',
        4 => 'Tagta',
        5 => 'Yylanly',
      ),
    ),
    'A' => 
    array (
      'name' => 'Ahal Region',
      'cities' => 
      array (
        0 => 'Abadan',
        1 => 'Annau',
        2 => 'Arçabil',
        3 => 'Baharly',
        4 => 'Kaka',
        5 => 'Tejen',
      ),
    ),
  ),
  'BO' => 
  array (
    'B' => 
    array (
      'name' => 'Beni Department',
      'cities' => 
      array (
        0 => 'Guayaramerín',
        1 => 'Provincia Cercado',
        2 => 'Provincia General José Ballivián',
        3 => 'Provincia Iténez',
        4 => 'Provincia Mamoré',
        5 => 'Provincia Marbán',
        6 => 'Provincia Moxos',
        7 => 'Provincia Vaca Diez',
        8 => 'Provincia Yacuma',
        9 => 'Reyes',
        10 => 'Riberalta',
        11 => 'Rurrenabaque',
        12 => 'San Borja',
        13 => 'San Ramón',
        14 => 'Santa Ana de Yacuma',
        15 => 'Santa Rosa',
        16 => 'Trinidad',
      ),
    ),
    'O' => 
    array (
      'name' => 'Oruro Department',
      'cities' => 
      array (
        0 => 'Challapata',
        1 => 'Huanuni',
        2 => 'Litoral de Atacama',
        3 => 'Machacamarca',
        4 => 'Nor Carangas Province',
        5 => 'Oruro',
        6 => 'Poopó',
        7 => 'Provincia Avaroa',
        8 => 'Provincia Carangas',
        9 => 'Provincia Cercado',
        10 => 'Provincia Ladislao Cabrera',
        11 => 'Provincia Pantaleón Dalence',
        12 => 'Provincia Poopó',
        13 => 'Provincia Sabaya',
        14 => 'Provincia Sajama',
        15 => 'Provincia San Pedro de Totora',
        16 => 'Provincia Saucari',
        17 => 'Provincia Tomás Barron',
        18 => 'Puerto de Mejillones',
        19 => 'Sebastian Pagador Province',
        20 => 'Sud Carangas Province',
        21 => 'Totoral',
      ),
    ),
    'S' => 
    array (
      'name' => 'Santa Cruz Department',
      'cities' => 
      array (
        0 => 'Abapó',
        1 => 'Ascención de Guarayos',
        2 => 'Ascensión',
        3 => 'Boyuibe',
        4 => 'Buena Vista',
        5 => 'Camiri',
        6 => 'Charagua',
        7 => 'Comarapa',
        8 => 'Concepción',
        9 => 'Cotoca',
        10 => 'German Busch',
        11 => 'Guarayos',
        12 => 'Jorochito',
        13 => 'La Bélgica',
        14 => 'Limoncito',
        15 => 'Los Negros',
        16 => 'Mairana',
        17 => 'Mineros',
        18 => 'Montero',
        19 => 'Okinawa Número Uno',
        20 => 'Pailón',
        21 => 'Paurito',
        22 => 'Portachuelo',
        23 => 'Provincia Andrés Ibáñez',
        24 => 'Provincia Chiquitos',
        25 => 'Provincia Cordillera',
        26 => 'Provincia Florida',
        27 => 'Provincia Ichilo',
        28 => 'Provincia Manuel María Caballero',
        29 => 'Provincia Santiesteban',
        30 => 'Provincia Sara',
        31 => 'Provincia Vallegrande',
        32 => 'Provincia Velasco',
        33 => 'Provincia Warnes',
        34 => 'Provincia Ángel Sandoval',
        35 => 'Provincia Ñuflo de Chávez',
        36 => 'Puerto Quijarro',
        37 => 'Puesto de Pailas',
        38 => 'Roboré',
        39 => 'Samaipata',
        40 => 'San Carlos',
        41 => 'San Ignacio de Velasco',
        42 => 'San Juan del Surutú',
        43 => 'San Julian',
        44 => 'San Matías',
        45 => 'San Pedro',
        46 => 'Santa Cruz de la Sierra',
        47 => 'Santa Rita',
        48 => 'Santa Rosa del Sara',
        49 => 'Santiago del Torno',
        50 => 'Urubichá',
        51 => 'Vallegrande',
        52 => 'Villa Yapacaní',
        53 => 'Warnes',
      ),
    ),
    'T' => 
    array (
      'name' => 'Tarija Department',
      'cities' => 
      array (
        0 => 'Bermejo',
        1 => 'Entre Ríos',
        2 => 'Provincia Arce',
        3 => 'Provincia Avilez',
        4 => 'Provincia Cercado',
        5 => 'Provincia Gran Chaco',
        6 => 'Provincia Méndez',
        7 => 'Provincia O&#039;Connor',
        8 => 'Tarija',
        9 => 'Villamontes',
        10 => 'Yacuiba',
      ),
    ),
    'N' => 
    array (
      'name' => 'Pando Department',
      'cities' => 
      array (
        0 => 'Cobija',
        1 => 'Provincia Abuná',
        2 => 'Provincia General Federico Román',
        3 => 'Provincia Madre de Dios',
        4 => 'Provincia Manuripi',
        5 => 'Provincia Nicolás Suárez',
      ),
    ),
    'L' => 
    array (
      'name' => 'La Paz Department',
      'cities' => 
      array (
        0 => 'Achacachi',
        1 => 'Amarete',
        2 => 'Batallas',
        3 => 'Caranavi',
        4 => 'Chulumani',
        5 => 'Colquiri',
        6 => 'Coripata',
        7 => 'Coroico',
        8 => 'Curahuara de Carangas',
        9 => 'Eucaliptus',
        10 => 'Guanay',
        11 => 'Huarina',
        12 => 'Huatajata',
        13 => 'José Manuel Pando',
        14 => 'La Paz',
        15 => 'Lahuachaca',
        16 => 'Mapiri',
        17 => 'Patacamaya',
        18 => 'Provincia Aroma',
        19 => 'Provincia Bautista Saavedra',
        20 => 'Provincia Camacho',
        21 => 'Provincia Franz Tamayo',
        22 => 'Provincia Gualberto Villarroel',
        23 => 'Provincia Ingavi',
        24 => 'Provincia Inquisivi',
        25 => 'Provincia Iturralde',
        26 => 'Provincia Larecaja',
        27 => 'Provincia Loayza',
        28 => 'Provincia Los Andes',
        29 => 'Provincia Manco Kapac',
        30 => 'Provincia Murillo',
        31 => 'Provincia Muñecas',
        32 => 'Provincia Nor Yungas',
        33 => 'Provincia Omasuyos',
        34 => 'Provincia Pacajes',
        35 => 'Provincia Sud Yungas',
        36 => 'Quime',
        37 => 'San Pablo',
        38 => 'San Pedro',
        39 => 'Sorata',
        40 => 'Tiahuanaco',
        41 => 'Viloco',
        42 => 'Yumani',
      ),
    ),
    'C' => 
    array (
      'name' => 'Cochabamba Department',
      'cities' => 
      array (
        0 => 'Aiquile',
        1 => 'Arani',
        2 => 'Bolivar',
        3 => 'Capinota',
        4 => 'Chimoré',
        5 => 'Cliza',
        6 => 'Cochabamba',
        7 => 'Colchani',
        8 => 'Colomi',
        9 => 'Independencia',
        10 => 'Irpa Irpa',
        11 => 'Mizque',
        12 => 'Provincia Arani',
        13 => 'Provincia Arque',
        14 => 'Provincia Ayopaya',
        15 => 'Provincia Campero',
        16 => 'Provincia Capinota',
        17 => 'Provincia Carrasco',
        18 => 'Provincia Cercado',
        19 => 'Provincia Chaparé',
        20 => 'Provincia Esteban Arce',
        21 => 'Provincia Germán Jordán',
        22 => 'Provincia Mizque',
        23 => 'Provincia Punata',
        24 => 'Provincia Quillacollo',
        25 => 'Provincia Tapacarí',
        26 => 'Punata',
        27 => 'Quillacollo',
        28 => 'Sacaba',
        29 => 'Sipe Sipe',
        30 => 'Tarata',
        31 => 'Tiquipaya',
        32 => 'Tiraque Province',
        33 => 'Totora',
      ),
    ),
    'H' => 
    array (
      'name' => 'Chuquisaca Department',
      'cities' => 
      array (
        0 => 'Camargo',
        1 => 'Monteagudo',
        2 => 'Padilla',
        3 => 'Provincia Azurduy',
        4 => 'Provincia Belisario Boeto',
        5 => 'Provincia Hernando Siles',
        6 => 'Provincia Luis Calvo',
        7 => 'Provincia Nor Cinti',
        8 => 'Provincia Oropeza',
        9 => 'Provincia Sud Cinti',
        10 => 'Provincia Tomina',
        11 => 'Provincia Yamparáez',
        12 => 'Provincia Zudáñez',
        13 => 'Sucre',
        14 => 'Tarabuco',
      ),
    ),
    'P' => 
    array (
      'name' => 'Potosí Department',
      'cities' => 
      array (
        0 => 'Atocha',
        1 => 'Betanzos',
        2 => 'Colchani',
        3 => 'Colquechaca',
        4 => 'Enrique Baldivieso',
        5 => 'Llallagua',
        6 => 'Potosí',
        7 => 'Provincia Alonzo de Ibáñez',
        8 => 'Provincia Charcas',
        9 => 'Provincia Chayanta',
        10 => 'Provincia Daniel Campos',
        11 => 'Provincia General Bilbao',
        12 => 'Provincia Linares',
        13 => 'Provincia Modesto Omiste',
        14 => 'Provincia Nor Chichas',
        15 => 'Provincia Nor Lípez',
        16 => 'Provincia Quijarro',
        17 => 'Provincia Rafael Bustillo',
        18 => 'Provincia Saavedra',
        19 => 'Provincia Sud Chichas',
        20 => 'Provincia Sud Lípez',
        21 => 'Provincia Tomás Frías',
        22 => 'Santa Bárbara',
        23 => 'Tupiza',
        24 => 'Uyuni',
        25 => 'Villazón',
      ),
    ),
  ),
  'VC' => 
  array (
    '04' => 
    array (
      'name' => 'Saint George Parish',
      'cities' => 
      array (
        0 => 'Kingstown',
        1 => 'Kingstown Park',
      ),
    ),
    '05' => 
    array (
      'name' => 'Saint Patrick Parish',
      'cities' => 
      array (
        0 => 'Barrouallie',
      ),
    ),
    '02' => 
    array (
      'name' => 'Saint Andrew Parish',
      'cities' => 
      array (
        0 => 'Layou',
      ),
    ),
    '03' => 
    array (
      'name' => 'Saint David Parish',
      'cities' => 
      array (
        0 => 'Chateaubelair',
      ),
    ),
    '06' => 
    array (
      'name' => 'Grenadines Parish',
      'cities' => 
      array (
        0 => 'Port Elizabeth',
      ),
    ),
    '01' => 
    array (
      'name' => 'Charlotte Parish',
      'cities' => 
      array (
        0 => 'Biabou',
        1 => 'Byera Village',
        2 => 'Georgetown',
      ),
    ),
  ),
  'AE' => 
  array (
    'SH' => 
    array (
      'name' => 'Sharjah Emirate',
      'cities' => 
      array (
        0 => 'Adh Dhayd',
        1 => 'Al Batayih',
        2 => 'Al Hamriyah',
        3 => 'Al Madam',
        4 => 'Dhaid',
        5 => 'Dibba Al Hesn',
        6 => 'Kalba',
        7 => 'Khawr Fakkān',
        8 => 'Khor Fakkan',
        9 => 'Milehah',
        10 => 'Murbaḩ',
        11 => 'Sharjah',
      ),
    ),
    'DU' => 
    array (
      'name' => 'Dubai',
      'cities' => 
      array (
        0 => 'Dubai',
      ),
    ),
    'UQ' => 
    array (
      'name' => 'Umm al-Quwain',
      'cities' => 
      array (
        0 => 'Umm AL Quwain',
        1 => 'Umm Al Quwain City',
      ),
    ),
    'FU' => 
    array (
      'name' => 'Fujairah',
      'cities' => 
      array (
        0 => 'Al Fujairah City',
        1 => 'Al Fujairah Municipality',
        2 => 'Dibba Al Fujairah Municipality',
        3 => 'Dibba Al-Fujairah',
        4 => 'Dibba Al-Hisn',
        5 => 'Reef Al Fujairah City',
      ),
    ),
    'RK' => 
    array (
      'name' => 'Ras al-Khaimah',
      'cities' => 
      array (
        0 => 'Ras Al Khaimah',
        1 => 'Ras Al Khaimah City',
      ),
    ),
    'AJ' => 
    array (
      'name' => 'Ajman Emirate',
      'cities' => 
      array (
        0 => 'Ajman',
        1 => 'Ajman City',
        2 => 'Manama',
        3 => 'Masfout',
      ),
    ),
    'AZ' => 
    array (
      'name' => 'Abu Dhabi Emirate',
      'cities' => 
      array (
        0 => 'Abu Dhabi Island and Internal Islands City',
        1 => 'Abu Dhabi Municipality',
        2 => 'Al Ain City',
        3 => 'Al Ain Municipality',
        4 => 'Al Dhafra',
        5 => 'Al Shamkhah City',
        6 => 'Ar Ruways',
        7 => 'Bani Yas City',
        8 => 'Khalifah A City',
        9 => 'Musaffah',
        10 => 'Muzayri&#039;',
        11 => 'Zayed City',
      ),
    ),
  ),
  'TJ' => 
  array (
    'RA' => 
    array (
      'name' => 'Districts of Republican Subordination',
      'cities' => 
      array (
        0 => 'Darband',
        1 => 'Hisor',
        2 => 'Karakenja',
        3 => 'Khodzha-Maston',
        4 => 'Novobod',
        5 => 'Obigarm',
        6 => 'Rasht',
        7 => 'Roghun',
        8 => 'Shahrinav',
        9 => 'Tagob',
        10 => 'Tursunzoda',
        11 => 'Vahdat',
        12 => 'Vahdat District',
        13 => 'Varzob',
        14 => 'Varzob District',
      ),
    ),
    'KT' => 
    array (
      'name' => 'Khatlon Province',
      'cities' => 
      array (
        0 => 'Abdurahmoni Jomí',
        1 => 'Boshchorbogh',
        2 => 'Bŭstonqal&#039;a',
        3 => 'Chubek',
        4 => 'Danghara',
        5 => 'Dŭstí',
        6 => 'Farkhor',
        7 => 'Gharavŭtí',
        8 => 'Jilikŭl',
        9 => 'Kirov',
        10 => 'Kolkhozobod',
        11 => 'Kŭlob',
        12 => 'Moskovskiy',
        13 => 'Mŭ&#039;minobod',
        14 => 'Nohiyai Kolkhozobod',
        15 => 'Nohiyai Panj',
        16 => 'Nohiyai Vakhsh',
        17 => 'Norak',
        18 => 'Orzu',
        19 => 'Panj',
        20 => 'Qŭrghonteppa',
        21 => 'Shahritus',
        22 => 'Sovet',
        23 => 'Tartiki',
        24 => 'Vakhsh',
        25 => 'Vose&#039;',
        26 => 'Yovon',
      ),
    ),
    'GB' => 
    array (
      'name' => 'Gorno-Badakhshan Autonomous Province',
      'cities' => 
      array (
        0 => 'Ishqoshim',
        1 => 'Khorugh',
        2 => 'Murghob',
        3 => 'Nohiyai Shughnon',
      ),
    ),
    'SU' => 
    array (
      'name' => 'Sughd Province',
      'cities' => 
      array (
        0 => 'Adrasmon',
        1 => 'Ayní',
        2 => 'Bŭston',
        3 => 'Chkalov',
        4 => 'Ghafurov',
        5 => 'Isfara',
        6 => 'Istaravshan',
        7 => 'Khŭjand',
        8 => 'Kim',
        9 => 'Konibodom',
        10 => 'Konsoy',
        11 => 'Neftobod',
        12 => 'Nohiyai Konibodom',
        13 => 'Nov',
        14 => 'Oltintopkan',
        15 => 'Pakhtakoron',
        16 => 'Palos',
        17 => 'Panjakent',
        18 => 'Proletar',
        19 => 'Quruqsoy',
        20 => 'Shaydon',
        21 => 'Shŭrob',
        22 => 'Taboshar',
        23 => 'Vorukh',
      ),
    ),
  ),
  'TW' => 
  array (
    'ILA' => 
    array (
      'name' => 'Yilan County',
      'cities' => 
      array (
        0 => 'Yilan',
      ),
    ),
    'PEN' => 
    array (
      'name' => 'Penghu County',
      'cities' => 
      array (
        0 => 'Magong',
        1 => 'Penghu County',
      ),
    ),
    'CHA' => 
    array (
      'name' => 'Changhua County',
      'cities' => 
      array (
        0 => 'Changhua',
        1 => 'Yuanlin',
      ),
    ),
    'PIF' => 
    array (
      'name' => 'Pingtung County',
      'cities' => 
      array (
        0 => 'Donggang',
        1 => 'Hengchun',
        2 => 'Pingtung',
      ),
    ),
    'TXG' => 
    array (
      'name' => 'Taichung',
      'cities' => 
      array (
        0 => 'Taichung',
        1 => 'Taichung City',
      ),
    ),
    'NAN' => 
    array (
      'name' => 'Nantou County',
      'cities' => 
      array (
        0 => 'Lugu',
        1 => 'Nantou',
        2 => 'Puli',
        3 => 'Zhongxing New Village',
      ),
    ),
    'CYI' => 
    array (
      'name' => 'Chiayi County',
      'cities' => 
      array (
        0 => 'Chiayi',
        1 => 'Pizitou',
      ),
    ),
    'TTT' => 
    array (
      'name' => 'Taitung County',
      'cities' => 
      array (
        0 => 'Taitung',
        1 => 'Taitung City',
      ),
    ),
    'HUA' => 
    array (
      'name' => 'Hualien County',
      'cities' => 
      array (
        0 => 'Hualien',
        1 => 'Hualien City',
      ),
    ),
    'KHH' => 
    array (
      'name' => 'Kaohsiung',
      'cities' => 
      array (
        0 => 'Kaohsiung',
      ),
    ),
    'MIA' => 
    array (
      'name' => 'Miaoli County',
      'cities' => 
      array (
        0 => 'Miaoli',
      ),
    ),
    'KIN' => 
    array (
      'name' => 'Kinmen',
      'cities' => 
      array (
        0 => 'Jincheng',
        1 => 'Kinmen County',
      ),
    ),
    'YUN' => 
    array (
      'name' => 'Yunlin County',
      'cities' => 
      array (
        0 => 'Douliu',
        1 => 'Yunlin',
      ),
    ),
    'HSZ' => 
    array (
      'name' => 'Hsinchu',
      'cities' => 
      array (
        0 => 'Hsinchu County',
      ),
    ),
    'CYQ' => 
    array (
      'name' => 'Chiayi City',
      'cities' => 
      array (
        0 => 'Chiayi County',
      ),
    ),
    'TAO' => 
    array (
      'name' => 'Taoyuan City',
      'cities' => 
      array (
        0 => 'Daxi',
        1 => 'Taoyuan',
        2 => 'Taoyuan City',
      ),
    ),
    'LIE' => 
    array (
      'name' => 'Lienchiang County',
      'cities' => 
      array (
        0 => 'Lienchiang',
        1 => 'Nangan',
      ),
    ),
    'TNN' => 
    array (
      'name' => 'Tainan',
      'cities' => 
      array (
        0 => 'Tainan',
        1 => 'Yujing',
      ),
    ),
    'TPE' => 
    array (
      'name' => 'Taipei',
      'cities' => 
      array (
        0 => 'Banqiao',
        1 => 'Jiufen',
        2 => 'Taipei',
        3 => 'Taipei City',
      ),
    ),
    'HSQ' => 
    array (
      'name' => 'Hsinchu County',
      'cities' => 
      array (
        0 => 'Hsinchu',
      ),
    ),
  ),
  'ER' => 
  array (
    'SK' => 
    array (
      'name' => 'Northern Red Sea Region',
      'cities' => 
      array (
        0 => 'Massawa',
      ),
    ),
    'AN' => 
    array (
      'name' => 'Anseba Region',
      'cities' => 
      array (
        0 => 'Keren',
      ),
    ),
    'MA' => 
    array (
      'name' => 'Maekel Region',
      'cities' => 
      array (
        0 => 'Asmara',
      ),
    ),
    'DU' => 
    array (
      'name' => 'Debub Region',
      'cities' => 
      array (
        0 => 'Adi Keyh',
        1 => 'Dek&#039;emhāre',
        2 => 'Mendefera',
      ),
    ),
    'GB' => 
    array (
      'name' => 'Gash-Barka Region',
      'cities' => 
      array (
        0 => 'Ak&#039;ordat',
        1 => 'Barentu',
        2 => 'Teseney',
      ),
    ),
    'DK' => 
    array (
      'name' => 'Southern Red Sea Region',
      'cities' => 
      array (
        0 => 'Assab',
        1 => 'Edd',
      ),
    ),
  ),
  'GQ' => 
  array (
    'KN' => 
    array (
      'name' => 'Kié-Ntem Province',
      'cities' => 
      array (
        0 => 'Ebebiyin',
        1 => 'Mikomeseng',
        2 => 'Ncue',
        3 => 'Nsang',
      ),
    ),
    'WN' => 
    array (
      'name' => 'Wele-Nzas Province',
      'cities' => 
      array (
        0 => 'Aconibe',
        1 => 'Ayene',
        2 => 'Añisoc',
        3 => 'Mengomeyén',
        4 => 'Mongomo',
        5 => 'Nsok',
      ),
    ),
    'LI' => 
    array (
      'name' => 'Litoral Province',
      'cities' => 
      array (
        0 => 'Bata',
        1 => 'Bitica',
        2 => 'Cogo',
        3 => 'Machinda',
        4 => 'Mbini',
        5 => 'Río Campo',
      ),
    ),
    'BS' => 
    array (
      'name' => 'Bioko Sur Province',
      'cities' => 
      array (
        0 => 'Luba',
      ),
    ),
    'AN' => 
    array (
      'name' => 'Annobón Province',
      'cities' => 
      array (
        0 => 'San Antonio de Palé',
      ),
    ),
    'CS' => 
    array (
      'name' => 'Centro Sur Province',
      'cities' => 
      array (
        0 => 'Acurenam',
        1 => 'Bicurga',
        2 => 'Evinayong',
      ),
    ),
    'BN' => 
    array (
      'name' => 'Bioko Norte Province',
      'cities' => 
      array (
        0 => 'Malabo',
        1 => 'Rebola',
        2 => 'Santiago de Baney',
      ),
    ),
  ),
);