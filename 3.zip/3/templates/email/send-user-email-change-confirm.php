<?php
/**
 * Template for the "Confirm Email Change Email".
 * 
 * Whether to send the user an email to confirm email change.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-email-change-confirm.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo esc_html(
		sprintf( 
			/*translators: %s: User's display name.*/
		__( 'Howdy %s,', 'describr' ),
		$args['user']->display_name
		)) . "\r\n\r\n"; ?></td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="margin: 1em 0; padding: 0;"><?php echo esc_html( __( 'You recently requested to have the email address on your account changed.', 'describr' ) ) . "\r\n\r\n"; ?></p>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		###HTMLCONFIRM_EMAIL_CHANGE:
		<div style="padding: 20px 0; margin: 0;">
			<?php 
	        echo wp_kses_post( $this->btn( $args['url'], __( 'Confirm Email Change', 'describr' ), 'confirm_user_email_change' ) );
		    ?>
	    </div>
        ###HTMLCONFIRM_EMAIL_CHANGE
        ###TEXTCONFIRM_EMAIL_CHANGE:
        <?php
        echo esc_html(sprintf(
        	/*translators: %s: Confirm email change URL.*/
        	__( 'To confirm this change, please click on the following link: %s.', 'describr' ), 
        	$args['url'] 
        ) ) . "\r\n\r\n";
        ?>
        ###TEXTCONFIRM_EMAIL_CHANGE
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
        <p style="padding: 0; margin: 1em 0;"><?php echo esc_html( __( 'You can safely ignore and delete this email if you do not want to take this action.', 'describr' ) ) . "\r\n"; ?></p>
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );
