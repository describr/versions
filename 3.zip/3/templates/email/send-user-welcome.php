<?php
/**
 * Template for the "Welcome Email".
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-welcome.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo wp_kses_post(sprintf(
		/*translators: %s: Site's title.*/
		__( 'Thanks for signing up for a %s account!', 'describr' ),
		"<strong>{$args['blogname']}</strong>"
	)) . "\r\n\r\n"; ?>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="margin: 1em 0; padding: 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Username.*/
		    __( '<strong>Username:</strong> %s', 'describr' ),
		    $args['user']->user_login
		)) . "\r\n\r\n"; ?></p>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline;">
		<p style="margin: 1em 0; padding: 0;"><?php echo wp_kses_post(
		sprintf( 
			/*translators: %s: Email address.*/
		    __( '<strong>Email:</strong> %s', 'describr' ),
		    $args['user']->user_email
		)) . "\r\n"; ?>
		</p>
	</td>
</tr>
<?php
$this->login_btn();

$this->get_template( 'footer', $args );