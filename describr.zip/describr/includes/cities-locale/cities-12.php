<?php
/**
 * An array of translated states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'HN' => 
  array (
    'CH' => 
    array (
      'name' => 'Choluteca Department',
      'cities' => 
      array (
        0 => 'Apacilagua',
        1 => 'Choluteca',
        2 => 'Ciudad Choluteca',
        3 => 'Concepción de María',
        4 => 'Corpus',
        5 => 'Duyure',
        6 => 'El Corpus',
        7 => 'El Obraje',
        8 => 'El Puente',
        9 => 'El Triunfo',
        10 => 'Los Llanitos',
        11 => 'Marcovia',
        12 => 'Monjarás',
        13 => 'Morolica',
        14 => 'Namasigüe',
        15 => 'Orocuina',
        16 => 'Pespire',
        17 => 'San Antonio de Flores',
        18 => 'San Isidro',
        19 => 'San Jerónimo',
        20 => 'San José',
        21 => 'San José de Las Conchas',
        22 => 'San Marcos de Colón',
        23 => 'Santa Ana de Yusguare',
        24 => 'Santa Cruz',
      ),
    ),
    'CM' => 
    array (
      'name' => 'Comayagua Department',
      'cities' => 
      array (
        0 => 'Aguas del Padre',
        1 => 'Ajuterique',
        2 => 'Cerro Blanco',
        3 => 'Comayagua',
        4 => 'Concepción de Guasistagua',
        5 => 'El Agua Dulcita',
        6 => 'El Porvenir',
        7 => 'El Rancho',
        8 => 'El Rincón',
        9 => 'El Rosario',
        10 => 'El Sauce',
        11 => 'El Socorro',
        12 => 'Esquías',
        13 => 'Flores',
        14 => 'Humuya',
        15 => 'Jamalteca',
        16 => 'La Libertad',
        17 => 'La Trinidad',
        18 => 'Lamaní',
        19 => 'Las Lajas',
        20 => 'Lejamaní',
        21 => 'Meámbar',
        22 => 'Minas de Oro',
        23 => 'Ojos de Agua',
        24 => 'Potrerillos',
        25 => 'Río Bonito',
        26 => 'San Antonio de la Cuesta',
        27 => 'San Jerónimo',
        28 => 'San José de Comayagua',
        29 => 'San José del Potrero',
        30 => 'San Luis',
        31 => 'San Sebastián',
        32 => 'Siguatepeque',
        33 => 'Taulabé',
        34 => 'Valle de Ángeles',
        35 => 'Villa de San Antonio',
      ),
    ),
    'EP' => 
    array (
      'name' => 'El Paraíso Department',
      'cities' => 
      array (
        0 => 'Alauca',
        1 => 'Araulí',
        2 => 'Cuyalí',
        3 => 'Danlí',
        4 => 'El Benque',
        5 => 'El Chichicaste',
        6 => 'El Obraje',
        7 => 'El Paraíso',
        8 => 'Güinope',
        9 => 'Jacaleapa',
        10 => 'Jutiapa',
        11 => 'Las Trojes',
        12 => 'Las Ánimas',
        13 => 'Liure',
        14 => 'Morocelí',
        15 => 'Municipio de Texiguat',
        16 => 'Ojo de Agua',
        17 => 'Oropolí',
        18 => 'Potrerillos',
        19 => 'Quebrada Larga',
        20 => 'San Antonio de Flores',
        21 => 'San Diego',
        22 => 'San Lucas',
        23 => 'San Matías',
        24 => 'Santa Cruz',
        25 => 'Soledad',
        26 => 'Teupasenti',
        27 => 'Texíguat',
        28 => 'Trojes',
        29 => 'Vado Ancho',
        30 => 'Yauyupe',
        31 => 'Yuscarán',
      ),
    ),
    'IN' => 
    array (
      'name' => 'Intibucá Department',
      'cities' => 
      array (
        0 => 'Camasca',
        1 => 'Colomoncagua',
        2 => 'Concepción',
        3 => 'Dolores',
        4 => 'Intibucá',
        5 => 'Jesús de Otoro',
        6 => 'Jiquinlaca',
        7 => 'La Esperanza',
        8 => 'Magdalena',
        9 => 'Masaguara',
        10 => 'San Antonio',
        11 => 'San Francisco de Opalaca',
        12 => 'San Isidro',
        13 => 'San Juan',
        14 => 'San Marcos de la Sierra',
        15 => 'San Miguelito',
        16 => 'Santa Lucía',
        17 => 'Yamaranguila',
      ),
    ),
    'IB' => 
    array (
      'name' => 'Bay Islands Department',
      'cities' => 
      array (
        0 => 'Coxen Hole',
        1 => 'French Harbor',
        2 => 'Guanaja',
        3 => 'José Santos Guardiola',
        4 => 'Roatán',
        5 => 'Sandy Bay',
        6 => 'Savannah Bight',
        7 => 'Utila',
      ),
    ),
    'CR' => 
    array (
      'name' => 'Cortés Department',
      'cities' => 
      array (
        0 => 'Agua Azul',
        1 => 'Agua Azul Rancho',
        2 => 'Armenta',
        3 => 'Baja Mar',
        4 => 'Baracoa',
        5 => 'Bejuco',
        6 => 'Casa Quemada',
        7 => 'Cañaveral',
        8 => 'Chivana',
        9 => 'Choloma',
        10 => 'Chotepe',
        11 => 'Cofradía',
        12 => 'Cuyamel',
        13 => 'El Llano',
        14 => 'El Marañón',
        15 => 'El Milagro',
        16 => 'El Olivar',
        17 => 'El Perico',
        18 => 'El Plan',
        19 => 'El Porvenir',
        20 => 'El Rancho',
        21 => 'El Tigre',
        22 => 'El Zapotal del Norte',
        23 => 'La Guama',
        24 => 'La Huesa',
        25 => 'La Jutosa',
        26 => 'La Lima',
        27 => 'La Sabana',
        28 => 'Los Caminos',
        29 => 'Los Naranjos',
        30 => 'Monterrey',
        31 => 'Nuevo Chamelecón',
        32 => 'Omoa',
        33 => 'Oropéndolas',
        34 => 'Peña Blanca',
        35 => 'Pimienta',
        36 => 'Pimienta Vieja',
        37 => 'Potrerillos',
        38 => 'Pueblo Nuevo',
        39 => 'Puerto Alto',
        40 => 'Puerto Cortez',
        41 => 'Puerto Cortés',
        42 => 'Quebrada Seca',
        43 => 'Río Blanquito',
        44 => 'Río Chiquito',
        45 => 'Río Lindo',
        46 => 'San Antonio de Cortés',
        47 => 'San Buenaventura',
        48 => 'San Francisco de Yojoa',
        49 => 'San José del Boquerón',
        50 => 'San Manuel',
        51 => 'San Pedro Sula',
        52 => 'Santa Cruz de Yojoa',
        53 => 'Santa Elena',
        54 => 'Travesía',
        55 => 'Villanueva',
      ),
    ),
    'AT' => 
    array (
      'name' => 'Atlántida Department',
      'cities' => 
      array (
        0 => 'Arizona',
        1 => 'Atenas de San Cristóbal',
        2 => 'Corozal',
        3 => 'El Pino',
        4 => 'El Porvenir',
        5 => 'El Triunfo de la Cruz',
        6 => 'Esparta',
        7 => 'Jutiapa',
        8 => 'La Ceiba',
        9 => 'La Masica',
        10 => 'La Unión',
        11 => 'Mezapa',
        12 => 'Nueva Armenia',
        13 => 'Sambo Creek',
        14 => 'San Antonio',
        15 => 'San Francisco',
        16 => 'San Juan Pueblo',
        17 => 'Santa Ana',
        18 => 'Tela',
        19 => 'Tornabé',
      ),
    ),
    'GD' => 
    array (
      'name' => 'Gracias a Dios Department',
      'cities' => 
      array (
        0 => 'Ahuas',
        1 => 'Auas',
        2 => 'Auka',
        3 => 'Barra Patuca',
        4 => 'Brus Laguna',
        5 => 'Iralaya',
        6 => 'Juan Francisco Bulnes',
        7 => 'Paptalaya',
        8 => 'Puerto Lempira',
        9 => 'Villeda Morales',
        10 => 'Wampusirpi',
        11 => 'Wawina',
      ),
    ),
    'CP' => 
    array (
      'name' => 'Copán Department',
      'cities' => 
      array (
        0 => 'Agua Caliente',
        1 => 'Buenos Aires',
        2 => 'Cabañas',
        3 => 'Chalmeca',
        4 => 'Concepción',
        5 => 'Concepción de la Barranca',
        6 => 'Copán',
        7 => 'Copán Ruinas',
        8 => 'Corquín',
        9 => 'Cucuyagua',
        10 => 'Dolores',
        11 => 'Dulce Nombre',
        12 => 'El Corpus',
        13 => 'El Ocotón',
        14 => 'El Paraíso',
        15 => 'Florida',
        16 => 'La Entrada',
        17 => 'La Jigua',
        18 => 'La Playona',
        19 => 'La Unión',
        20 => 'La Zumbadora',
        21 => 'Los Tangos',
        22 => 'Nueva Arcadia',
        23 => 'Ojos de Agua',
        24 => 'Pueblo Nuevo',
        25 => 'Quezailica',
        26 => 'San Agustín',
        27 => 'San Antonio',
        28 => 'San Jerónimo',
        29 => 'San Joaquín',
        30 => 'San José',
        31 => 'San José de Copán',
        32 => 'San Juan de Opoa',
        33 => 'San Juan de Planes',
        34 => 'San Nicolás',
        35 => 'San Pedro de Copán',
        36 => 'Santa Rita',
        37 => 'Santa Rita, Copan',
        38 => 'Santa Rosa de Copán',
        39 => 'Trinidad de Copán',
        40 => 'Veracruz',
      ),
    ),
    'OL' => 
    array (
      'name' => 'Olancho Department',
      'cities' => 
      array (
        0 => 'Arimís',
        1 => 'Campamento',
        2 => 'Catacamas',
        3 => 'Concordia',
        4 => 'Dulce Nombre de Culmí',
        5 => 'El Guayabito',
        6 => 'El Rosario',
        7 => 'El Rusio',
        8 => 'Esquipulas del Norte',
        9 => 'Gualaco',
        10 => 'Guarizama',
        11 => 'Guata',
        12 => 'Guayape',
        13 => 'Jano',
        14 => 'Juticalpa',
        15 => 'Jutiquile',
        16 => 'La Concepción',
        17 => 'La Estancia',
        18 => 'La Guata',
        19 => 'La Unión',
        20 => 'Laguna Seca',
        21 => 'Mangulile',
        22 => 'Manto',
        23 => 'Municipio de San Francisco de La Paz',
        24 => 'Patuca',
        25 => 'Punuare',
        26 => 'Salamá',
        27 => 'San Esteban',
        28 => 'San Francisco de Becerra',
        29 => 'San Francisco de la Paz',
        30 => 'San José de Río Tinto',
        31 => 'San Nicolás',
        32 => 'Santa María del Real',
        33 => 'Silca',
        34 => 'Yocón',
        35 => 'Zopilotepe',
      ),
    ),
    'CL' => 
    array (
      'name' => 'Colón Department',
      'cities' => 
      array (
        0 => 'Balfate',
        1 => 'Bonito Oriental',
        2 => 'Corocito',
        3 => 'Cusuna',
        4 => 'Elíxir',
        5 => 'Francia',
        6 => 'Iriona',
        7 => 'Jericó',
        8 => 'La Brea',
        9 => 'La Esperanza',
        10 => 'Limón',
        11 => 'Municipio de Sabá',
        12 => 'Prieta',
        13 => 'Puerto Castilla',
        14 => 'Punta Piedra',
        15 => 'Quebrada de Arena',
        16 => 'Río Esteban',
        17 => 'Sabá',
        18 => 'Salamá',
        19 => 'Santa Fe',
        20 => 'Santa Rosa de Aguán',
        21 => 'Sonaguera',
        22 => 'Taujica',
        23 => 'Tocoa',
        24 => 'Trujillo',
        25 => 'Zamora',
      ),
    ),
    'FM' => 
    array (
      'name' => 'Francisco Morazán Department',
      'cities' => 
      array (
        0 => 'Agalteca',
        1 => 'Alubarén',
        2 => 'Cedros',
        3 => 'Cerro Grande',
        4 => 'Cofradía',
        5 => 'Curarén',
        6 => 'Distrito Central',
        7 => 'El Chimbo',
        8 => 'El Escanito',
        9 => 'El Escaño de Tepale',
        10 => 'El Guante',
        11 => 'El Guantillo',
        12 => 'El Guapinol',
        13 => 'El Lolo',
        14 => 'El Pedernal',
        15 => 'El Porvenir',
        16 => 'El Suyatal',
        17 => 'El Tablón',
        18 => 'El Terrero',
        19 => 'Guaimaca',
        20 => 'La Ermita',
        21 => 'La Libertad',
        22 => 'La Venta',
        23 => 'Lepaterique',
        24 => 'Maraita',
        25 => 'Marale',
        26 => 'Mata de Plátano',
        27 => 'Mateo',
        28 => 'Nueva Armenia',
        29 => 'Ojojona',
        30 => 'Orica',
        31 => 'Quebradas',
        32 => 'Reitoca',
        33 => 'Río Abajo',
        34 => 'Sabanagrande',
        35 => 'San Antonio de Oriente',
        36 => 'San Buenaventura',
        37 => 'San Ignacio',
        38 => 'San Juan de Flores',
        39 => 'San Miguelito',
        40 => 'Santa Ana',
        41 => 'Santa Lucía',
        42 => 'Talanga',
        43 => 'Tatumbla',
        44 => 'Tegucigalpa',
        45 => 'Támara',
        46 => 'Valle de Ángeles',
        47 => 'Vallecillo',
        48 => 'Villa Nueva',
        49 => 'Villa de San Francisco',
        50 => 'Yaguacire',
        51 => 'Zambrano',
      ),
    ),
    'SB' => 
    array (
      'name' => 'Santa Bárbara Department',
      'cities' => 
      array (
        0 => 'Agualote',
        1 => 'Arada',
        2 => 'Atima',
        3 => 'Azacualpa',
        4 => 'Berlín',
        5 => 'Callejones',
        6 => 'Camalote',
        7 => 'Casa Quemada',
        8 => 'Ceguaca',
        9 => 'Chinda',
        10 => 'Concepción del Norte',
        11 => 'Concepción del Sur',
        12 => 'Correderos',
        13 => 'El Ciruelo',
        14 => 'El Corozal',
        15 => 'El Mochito',
        16 => 'El Níspero',
        17 => 'Guacamaya',
        18 => 'Gualala',
        19 => 'Gualjoco',
        20 => 'Ilama',
        21 => 'Joconal',
        22 => 'La Flecha',
        23 => 'Laguna Verde',
        24 => 'Las Vegas',
        25 => 'Las Vegas, Santa Barbara',
        26 => 'Loma Alta',
        27 => 'Macuelizo',
        28 => 'Naco',
        29 => 'Naranjito',
        30 => 'Nueva Frontera',
        31 => 'Nueva Jalapa',
        32 => 'Nuevo Celilac',
        33 => 'Petoa',
        34 => 'Pinalejo',
        35 => 'Protección',
        36 => 'Quimistán',
        37 => 'San Francisco de Ojuera',
        38 => 'San José de Colinas',
        39 => 'San José de Tarros',
        40 => 'San Luis',
        41 => 'San Luis de Planes',
        42 => 'San Marcos',
        43 => 'San Nicolás',
        44 => 'San Pedro Zacapa',
        45 => 'San Vicente Centenario',
        46 => 'Santa Bárbara',
        47 => 'Santa Rita',
        48 => 'Sula',
        49 => 'Tras Cerros',
        50 => 'Trinidad',
      ),
    ),
    'LE' => 
    array (
      'name' => 'Lempira Department',
      'cities' => 
      array (
        0 => 'Belén',
        1 => 'Candelaria',
        2 => 'Cololaca',
        3 => 'El Achiotal',
        4 => 'Erandique',
        5 => 'Gracias',
        6 => 'Gualcince',
        7 => 'Guarita',
        8 => 'La Campa',
        9 => 'La Iguala',
        10 => 'La Libertad',
        11 => 'La Unión',
        12 => 'La Virtud',
        13 => 'Las Flores',
        14 => 'Las Tejeras',
        15 => 'Lepaera',
        16 => 'Mapulaca',
        17 => 'Piraera',
        18 => 'San Andrés',
        19 => 'San Francisco',
        20 => 'San Juan Guarita',
        21 => 'San Manuel Colohete',
        22 => 'San Marcos de Caiquin',
        23 => 'San Rafael',
        24 => 'San Sebastián',
        25 => 'Santa Cruz',
        26 => 'Talgua',
        27 => 'Tambla',
        28 => 'Taragual',
        29 => 'Tomalá',
        30 => 'Valladolid',
        31 => 'Virginia',
      ),
    ),
    'VA' => 
    array (
      'name' => 'Valle Department',
      'cities' => 
      array (
        0 => 'Agua Fría',
        1 => 'Alianza',
        2 => 'Amapala',
        3 => 'Aramecina',
        4 => 'Caridad',
        5 => 'El Cubolero',
        6 => 'El Tular',
        7 => 'Goascorán',
        8 => 'Jícaro Galán',
        9 => 'La Alianza',
        10 => 'La Criba',
        11 => 'Langue',
        12 => 'Nacaome',
        13 => 'San Francisco de Coray',
        14 => 'San Lorenzo',
      ),
    ),
    'OC' => 
    array (
      'name' => 'Ocotepeque Department',
      'cities' => 
      array (
        0 => 'Antigua Ocotepeque',
        1 => 'Belén Gualcho',
        2 => 'Concepción',
        3 => 'Dolores Merendón',
        4 => 'El Tránsito',
        5 => 'Fraternidad',
        6 => 'La Encarnación',
        7 => 'La Labor',
        8 => 'Lucerna',
        9 => 'Mercedes',
        10 => 'Nueva Ocotepeque',
        11 => 'San Fernando',
        12 => 'San Francisco de Cones',
        13 => 'San Francisco del Valle',
        14 => 'San Jorge',
        15 => 'San Marcos',
        16 => 'Santa Fe',
        17 => 'Santa Lucía',
        18 => 'Sensenti',
        19 => 'Sinuapa',
        20 => 'Yaruchel',
      ),
    ),
    'YO' => 
    array (
      'name' => 'Yoro Department',
      'cities' => 
      array (
        0 => 'Agua Blanca Sur',
        1 => 'Arenal',
        2 => 'Armenia',
        3 => 'Ayapa',
        4 => 'Bálsamo Oriental',
        5 => 'Carbajales',
        6 => 'Coyoles Central',
        7 => 'El Bálsamo',
        8 => 'El Juncal',
        9 => 'El Negrito',
        10 => 'El Ocote',
        11 => 'El Progreso',
        12 => 'Guaimitas',
        13 => 'Jocón',
        14 => 'La Estancia',
        15 => 'La Guacamaya',
        16 => 'La Mina',
        17 => 'La Rosa',
        18 => 'La Sarrosa',
        19 => 'La Trinidad',
        20 => 'Las Vegas',
        21 => 'Lomitas',
        22 => 'Mojimán',
        23 => 'Morazán',
        24 => 'Nombre de Jesús',
        25 => 'Nueva Esperanza',
        26 => 'Ocote Paulino',
        27 => 'Olanchito',
        28 => 'Paujiles',
        29 => 'Punta Ocote',
        30 => 'San Antonio',
        31 => 'San José',
        32 => 'Santa Rita',
        33 => 'Subirana',
        34 => 'Sulaco',
        35 => 'Teguajinal',
        36 => 'Tepusteca',
        37 => 'Toyós',
        38 => 'Trojas',
        39 => 'Victoria',
        40 => 'Yorito',
        41 => 'Yoro',
      ),
    ),
    'LP' => 
    array (
      'name' => 'La Paz Department',
      'cities' => 
      array (
        0 => 'Aguanqueterique',
        1 => 'Cabañas',
        2 => 'Cane',
        3 => 'Chinacla',
        4 => 'Guajiquiro',
        5 => 'La Paz',
        6 => 'Lauterique',
        7 => 'Los Planes',
        8 => 'Marcala',
        9 => 'Mercedes de Oriente',
        10 => 'Opatoro',
        11 => 'San Antonio del Norte',
        12 => 'San José',
        13 => 'San Juan',
        14 => 'San Pedro de Tutule',
        15 => 'Santa Ana',
        16 => 'Santa Elena',
        17 => 'Santa María',
        18 => 'Santiago Puringla',
        19 => 'Tepanguare',
        20 => 'Yarula',
        21 => 'Yarumela',
      ),
    ),
  ),
  'NZ' => 
  array (
    'NTL' => 
    array (
      'name' => 'Northland Region',
      'cities' => 
      array (
        0 => 'Ahipara',
        1 => 'Dargaville',
        2 => 'Far North District',
        3 => 'Kaipara District',
        4 => 'Kaitaia',
        5 => 'Kawakawa',
        6 => 'Kerikeri',
        7 => 'Maungatapere',
        8 => 'Moerewa',
        9 => 'Ngunguru',
        10 => 'Paihia',
        11 => 'Ruakaka',
        12 => 'Taipa',
        13 => 'Waimate North',
        14 => 'Whangarei',
      ),
    ),
    'MWT' => 
    array (
      'name' => 'Manawatu-Wanganui Region',
      'cities' => 
      array (
        0 => 'Bulls',
        1 => 'Foxton',
        2 => 'Horowhenua District',
        3 => 'Levin',
        4 => 'Manawatu District',
        5 => 'Palmerston North',
        6 => 'Waiouru',
        7 => 'Wanganui',
      ),
    ),
    'WKO' => 
    array (
      'name' => 'Waikato Region',
      'cities' => 
      array (
        0 => 'Cambridge',
        1 => 'Coromandel',
        2 => 'Hamilton',
        3 => 'Matamata',
        4 => 'Ngaruawahia',
        5 => 'Ngatea',
        6 => 'Otorohanga',
        7 => 'Paeroa',
        8 => 'Raglan',
        9 => 'South Waikato District',
        10 => 'Tairua',
        11 => 'Taupo',
        12 => 'Te Kauwhata',
        13 => 'Thames',
        14 => 'Tokoroa',
        15 => 'Turangi',
        16 => 'Waihi',
        17 => 'Whangamata',
        18 => 'Whitianga',
      ),
    ),
    'OTA' => 
    array (
      'name' => 'Otago Region',
      'cities' => 
      array (
        0 => 'Arrowtown',
        1 => 'Balclutha',
        2 => 'Clutha District',
        3 => 'Cromwell',
        4 => 'Dunedin',
        5 => 'Kingston',
        6 => 'Milton',
        7 => 'Oamaru',
        8 => 'Papatowai',
        9 => 'Portobello',
        10 => 'Queenstown',
        11 => 'Wanaka',
      ),
    ),
    'MBH' => 
    array (
      'name' => 'Marlborough Region',
      'cities' => 
      array (
        0 => 'Blenheim',
        1 => 'Picton',
      ),
    ),
    'WTC' => 
    array (
      'name' => 'West Coast Region',
      'cities' => 
      array (
        0 => 'Greymouth',
        1 => 'Hokitika',
        2 => 'Westport',
      ),
    ),
    'WGN' => 
    array (
      'name' => 'Wellington Region',
      'cities' => 
      array (
        0 => 'Brooklyn',
        1 => 'Castlepoint',
        2 => 'Kapiti Coast District',
        3 => 'Kelburn',
        4 => 'Khandallah',
        5 => 'Lower Hutt',
        6 => 'Masterton',
        7 => 'Otaki',
        8 => 'Paraparaumu',
        9 => 'Petone',
        10 => 'Porirua',
        11 => 'South Wairarapa District',
        12 => 'Upper Hutt',
        13 => 'Waipawa',
        14 => 'Wellington',
        15 => 'Wellington City',
      ),
    ),
    'CAN' => 
    array (
      'name' => 'Canterbury Region',
      'cities' => 
      array (
        0 => 'Amberley',
        1 => 'Ashburton',
        2 => 'Ashburton District',
        3 => 'Burnham',
        4 => 'Christchurch',
        5 => 'Christchurch City',
        6 => 'Darfield',
        7 => 'Geraldine',
        8 => 'Kaiapoi',
        9 => 'Leeston',
        10 => 'Lincoln',
        11 => 'Mackenzie District',
        12 => 'Methven',
        13 => 'Oxford',
        14 => 'Pleasant Point',
        15 => 'Prebbleton',
        16 => 'Rakaia',
        17 => 'Rolleston',
        18 => 'Selwyn District',
        19 => 'Timaru',
        20 => 'Timaru District',
        21 => 'Tinwald',
        22 => 'Waimakariri District',
        23 => 'Woodend',
      ),
    ),
    'CIT' => 
    array (
      'name' => 'Chatham Islands',
      'cities' => 
      array (
        0 => 'Waitangi',
      ),
    ),
    'GIS' => 
    array (
      'name' => 'Gisborne District',
      'cities' => 
      array (
        0 => 'Gisborne',
      ),
    ),
    'TKI' => 
    array (
      'name' => 'Taranaki Region',
      'cities' => 
      array (
        0 => 'Eltham',
        1 => 'Hawera',
        2 => 'New Plymouth',
        3 => 'New Plymouth District',
        4 => 'Opunake',
        5 => 'Patea',
        6 => 'South Taranaki District',
        7 => 'Waitara',
      ),
    ),
    'NSN' => 
    array (
      'name' => 'Nelson Region',
      'cities' => 
      array (
        0 => 'Nelson',
      ),
    ),
    'STL' => 
    array (
      'name' => 'Southland Region',
      'cities' => 
      array (
        0 => 'Bluff',
        1 => 'Gore',
        2 => 'Invercargill',
        3 => 'Riverton',
        4 => 'Southland District',
        5 => 'Te Anau',
        6 => 'Winton',
      ),
    ),
    'AUK' => 
    array (
      'name' => 'Auckland Region',
      'cities' => 
      array (
        0 => 'Auckland',
        1 => 'Mangere',
        2 => 'Manukau City',
        3 => 'Muriwai Beach',
        4 => 'Murrays Bay',
        5 => 'North Shore',
        6 => 'Pakuranga',
        7 => 'Papakura',
        8 => 'Parakai',
        9 => 'Pukekohe East',
        10 => 'Red Hill',
        11 => 'Rosebank',
        12 => 'Rothesay Bay',
        13 => 'Takanini',
        14 => 'Tamaki',
        15 => 'Titirangi',
        16 => 'Waitakere',
        17 => 'Waiuku',
        18 => 'Warkworth',
        19 => 'Wellsford',
        20 => 'Wiri',
      ),
    ),
    'TAS' => 
    array (
      'name' => 'Tasman District',
      'cities' => 
      array (
        0 => 'Brightwater',
        1 => 'Mapua',
        2 => 'Motueka',
        3 => 'Richmond',
        4 => 'Takaka',
        5 => 'Wakefield',
      ),
    ),
    'BOP' => 
    array (
      'name' => 'Bay of Plenty Region',
      'cities' => 
      array (
        0 => 'Edgecumbe',
        1 => 'Katikati',
        2 => 'Kawerau',
        3 => 'Maketu',
        4 => 'Murupara',
        5 => 'Opotiki',
        6 => 'Rotorua',
        7 => 'Tauranga',
        8 => 'Waihi Beach',
        9 => 'Whakatane',
      ),
    ),
    'HKB' => 
    array (
      'name' => 'Hawke&#039;s Bay Region',
      'cities' => 
      array (
        0 => 'Hastings',
        1 => 'Napier',
        2 => 'Taradale',
        3 => 'Wairoa',
      ),
    ),
  ),
  'DM' => 
  array (
    '05' => 
    array (
      'name' => 'Saint John Parish',
      'cities' => 
      array (
        0 => 'Portsmouth',
      ),
    ),
    '08' => 
    array (
      'name' => 'Saint Mark Parish',
      'cities' => 
      array (
        0 => 'Soufrière',
      ),
    ),
    '03' => 
    array (
      'name' => 'Saint David Parish',
      'cities' => 
      array (
        0 => 'Castle Bruce',
        1 => 'Rosalie',
      ),
    ),
    '04' => 
    array (
      'name' => 'Saint George Parish',
      'cities' => 
      array (
        0 => 'Roseau',
      ),
    ),
    '09' => 
    array (
      'name' => 'Saint Patrick Parish',
      'cities' => 
      array (
        0 => 'Berekua',
        1 => 'La Plaine',
      ),
    ),
    '02' => 
    array (
      'name' => 'Saint Andrew Parish',
      'cities' => 
      array (
        0 => 'Calibishie',
        1 => 'Marigot',
        2 => 'Wesley',
        3 => 'Woodford Hill',
      ),
    ),
    '07' => 
    array (
      'name' => 'Saint Luke Parish',
      'cities' => 
      array (
        0 => 'Pointe Michel',
      ),
    ),
    '06' => 
    array (
      'name' => 'Saint Joseph Parish',
      'cities' => 
      array (
        0 => 'Saint Joseph',
        1 => 'Salisbury',
      ),
    ),
  ),
  'DO' => 
  array (
    '08' => 
    array (
      'name' => 'El Seibo Province',
      'cities' => 
      array (
        0 => 'Miches',
        1 => 'Pedro Sánchez',
        2 => 'Santa Cruz de El Seibo',
      ),
    ),
    '04' => 
    array (
      'name' => 'Barahona Province',
      'cities' => 
      array (
        0 => 'Cabral',
        1 => 'Cachón',
        2 => 'Canoa',
        3 => 'El Peñón',
        4 => 'Enriquillo',
        5 => 'Fundación',
        6 => 'Jaquimeyes',
        7 => 'La Ciénaga',
        8 => 'Las Salinas',
        9 => 'Paraíso',
        10 => 'Pescadería',
        11 => 'Polo',
        12 => 'Santa Cruz de Barahona',
        13 => 'Vicente Noble',
      ),
    ),
    '01' => 
    array (
      'name' => 'Distrito Nacional',
      'cities' => 
      array (
        0 => 'Bella Vista',
        1 => 'Ciudad Nueva',
        2 => 'Cristo Rey',
        3 => 'Ensanche Luperón',
        4 => 'La Agustina',
        5 => 'La Julia',
        6 => 'San Carlos',
        7 => 'Santo Domingo',
        8 => 'Villa Consuelo',
        9 => 'Villa Francisca',
      ),
    ),
    '09' => 
    array (
      'name' => 'Espaillat Province',
      'cities' => 
      array (
        0 => 'Cayetano Germosén',
        1 => 'Gaspar Hernández',
        2 => 'Jamao al Norte',
        3 => 'Joba Arriba',
        4 => 'Juan López Abajo',
        5 => 'Moca',
        6 => 'San Víctor Arriba',
        7 => 'Veragua Arriba',
      ),
    ),
    '03' => 
    array (
      'name' => 'Baoruco Province',
      'cities' => 
      array (
        0 => 'El Palmar',
        1 => 'Galván',
        2 => 'La Uvilla',
        3 => 'Los Ríos',
        4 => 'Neiba',
        5 => 'Tamayo',
        6 => 'Villa Jaragua',
      ),
    ),
    '05' => 
    array (
      'name' => 'Dajabón Province',
      'cities' => 
      array (
        0 => 'Dajabón',
        1 => 'El Pino',
        2 => 'Loma de Cabrera',
        3 => 'Partido',
        4 => 'Restauración',
      ),
    ),
    '06' => 
    array (
      'name' => 'Duarte Province',
      'cities' => 
      array (
        0 => 'Agua Santa del Yuna',
        1 => 'Arenoso',
        2 => 'Castillo',
        3 => 'Hostos',
        4 => 'Las Guáranas',
        5 => 'Pimentel',
        6 => 'San Francisco de Macorís',
        7 => 'Villa Riva',
      ),
    ),
    '02' => 
    array (
      'name' => 'Azua Province',
      'cities' => 
      array (
        0 => 'Azua',
        1 => 'El Guayabal',
        2 => 'Estebanía',
        3 => 'Las Charcas',
        4 => 'Padre Las Casas',
        5 => 'Palmar de Ocoa',
        6 => 'Peralta',
        7 => 'Pueblo Viejo',
        8 => 'Sabana Yegua',
        9 => 'Tábara Arriba',
        10 => 'Villarpando',
        11 => 'Yayas de Viajama',
      ),
    ),
  ),
  'HT' => 
  array (
    'ND' => 
    array (
      'name' => 'Nord',
      'cities' => 
      array (
        0 => 'Acul du Nord',
        1 => 'Arrondissement de Plaisance',
        2 => 'Arrondissement de la Grande Rivière du Nord',
        3 => 'Arrondissement du Borgne',
        4 => 'Bahon',
        5 => 'Borgne',
        6 => 'Dondon',
        7 => 'Grande Rivière du Nord',
        8 => 'Lenbe',
        9 => 'Limonade',
        10 => 'Milot',
        11 => 'Okap',
        12 => 'Pignon',
        13 => 'Pilate',
        14 => 'Plaine du Nord',
        15 => 'Plaisance',
        16 => 'Port-Margot',
        17 => 'Quartier Morin',
        18 => 'Ranquitte',
        19 => 'Saint-Raphaël',
      ),
    ),
    'NI' => 
    array (
      'name' => 'Nippes',
      'cities' => 
      array (
        0 => 'Ansavo',
        1 => 'Baradères',
        2 => 'Miragoâne',
        3 => 'Petit Trou de Nippes',
      ),
    ),
    'GA' => 
    array (
      'name' => 'Grand&#039;Anse',
      'cities' => 
      array (
        0 => 'Anse-à-Veau',
        1 => 'Chambellan',
        2 => 'Corail',
        3 => 'Dame-Marie',
        4 => 'Jeremi',
        5 => 'Jérémie',
        6 => 'Les Abricots',
        7 => 'Les Irois',
        8 => 'Moron',
        9 => 'Petite Rivière de Nippes',
      ),
    ),
    'OU' => 
    array (
      'name' => 'Ouest',
      'cities' => 
      array (
        0 => 'Anse à Galets',
        1 => 'Arcahaie',
        2 => 'Arrondissement de Croix des Bouquets',
        3 => 'Arrondissement de Léogâne',
        4 => 'Arrondissement de Port-au-Prince',
        5 => 'Cabaret',
        6 => 'Carrefour',
        7 => 'Cornillon',
        8 => 'Croix-des-Bouquets',
        9 => 'Delmas 73',
        10 => 'Fond Parisien',
        11 => 'Fonds Verrettes',
        12 => 'Grangwav',
        13 => 'Gressier',
        14 => 'Kenscoff',
        15 => 'Lagonav',
        16 => 'Léogâne',
        17 => 'Port-au-Prince',
        18 => 'Pétionville',
        19 => 'Thomazeau',
        20 => 'Tigwav',
      ),
    ),
    'NE' => 
    array (
      'name' => 'Nord-Est',
      'cities' => 
      array (
        0 => 'Arrondissement de Fort Liberté',
        1 => 'Arrondissement du Trou du Nord',
        2 => 'Caracol',
        3 => 'Carice',
        4 => 'Dérac',
        5 => 'Ferrier',
        6 => 'Fort Liberté',
        7 => 'Montòrganize',
        8 => 'Ouanaminthe',
        9 => 'Perches',
        10 => 'Phaëton',
        11 => 'Trou du Nord',
        12 => 'Wanament',
      ),
    ),
    'SD' => 
    array (
      'name' => 'Sud',
      'cities' => 
      array (
        0 => 'Aquin',
        1 => 'Arrondissement de Port-Salut',
        2 => 'Arrondissement des Cayes',
        3 => 'Cavaillon',
        4 => 'Chantal',
        5 => 'Chardonnière',
        6 => 'Fond des Blancs',
        7 => 'Koto',
        8 => 'Les Anglais',
        9 => 'Les Cayes',
        10 => 'Port-à-Piment',
        11 => 'Roche-à-Bateau',
        12 => 'Saint-Louis du Sud',
        13 => 'Tiburon',
        14 => 'Torbeck',
      ),
    ),
    'AR' => 
    array (
      'name' => 'Artibonite',
      'cities' => 
      array (
        0 => 'Anse Rouge',
        1 => 'Arrondissement de Saint-Marc',
        2 => 'Dessalines',
        3 => 'Désarmes',
        4 => 'Ennery',
        5 => 'Gonaïves',
        6 => 'Grande Saline',
        7 => 'Gros Morne',
        8 => 'Marmelade',
        9 => 'Saint-Marc',
        10 => 'Verrettes',
      ),
    ),
    'SE' => 
    array (
      'name' => 'Sud-Est',
      'cities' => 
      array (
        0 => 'Anse-à-Pitre',
        1 => 'Arrondissement de Bainet',
        2 => 'Arrondissement de Jacmel',
        3 => 'Belle-Anse',
        4 => 'Cayes-Jacmel',
        5 => 'Jacmel',
        6 => 'Kotdefè',
        7 => 'Marigot',
        8 => 'Thiotte',
      ),
    ),
    'CE' => 
    array (
      'name' => 'Centre',
      'cities' => 
      array (
        0 => 'Arrondissement de Cerca La Source',
        1 => 'Cerca la Source',
        2 => 'Hinche',
        3 => 'Lascahobas',
        4 => 'Mayisad',
        5 => 'Mirebalais',
        6 => 'Thomassique',
        7 => 'Thomonde',
      ),
    ),
    'NO' => 
    array (
      'name' => 'Nord-Ouest',
      'cities' => 
      array (
        0 => 'Arcahaie',
        1 => 'Arrondissement de Port-de-Paix',
        2 => 'Arrondissement de Saint-Louis du Nord',
        3 => 'Arrondissement du Môle Saint-Nicolas',
        4 => 'Baie de Henne',
        5 => 'Bombardopolis',
        6 => 'Fond Bassin Bleu',
        7 => 'Jean-Rabel',
        8 => 'Môle Saint-Nicolas',
        9 => 'Petite Anse',
        10 => 'Port-de-Paix',
        11 => 'Saint-Louis du Nord',
        12 => 'Ti Port-de-Paix',
      ),
    ),
  ),
  'SV' => 
  array (
    'SV' => 
    array (
      'name' => 'San Vicente Department',
      'cities' => 
      array (
        0 => 'Apastepeque',
        1 => 'San Sebastián',
        2 => 'San Vicente',
      ),
    ),
    'SA' => 
    array (
      'name' => 'Santa Ana Department',
      'cities' => 
      array (
        0 => 'Candelaria de La Frontera',
        1 => 'Chalchuapa',
        2 => 'Coatepeque',
        3 => 'El Congo',
        4 => 'Metapán',
        5 => 'Santa Ana',
        6 => 'Texistepeque',
      ),
    ),
    'US' => 
    array (
      'name' => 'Usulután Department',
      'cities' => 
      array (
        0 => 'Berlín',
        1 => 'Concepción Batres',
        2 => 'Jiquilisco',
        3 => 'Jucuapa',
        4 => 'Jucuarán',
        5 => 'Ozatlán',
        6 => 'Puerto El Triunfo',
        7 => 'San Agustín',
        8 => 'Santa Elena',
        9 => 'Santiago de María',
        10 => 'Usulután',
      ),
    ),
    'MO' => 
    array (
      'name' => 'Morazán Department',
      'cities' => 
      array (
        0 => 'Cacaopera',
        1 => 'Corinto',
        2 => 'Guatajiagua',
        3 => 'Jocoro',
        4 => 'San Francisco',
        5 => 'Sociedad',
      ),
    ),
    'CH' => 
    array (
      'name' => 'Chalatenango Department',
      'cities' => 
      array (
        0 => 'Chalatenango',
        1 => 'Nueva Concepción',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Cabañas Department',
      'cities' => 
      array (
        0 => 'Sensuntepeque',
        1 => 'Victoria',
      ),
    ),
    'SS' => 
    array (
      'name' => 'San Salvador Department',
      'cities' => 
      array (
        0 => 'Aguilares',
        1 => 'Apopa',
        2 => 'Ayutuxtepeque',
        3 => 'Cuscatancingo',
        4 => 'Delgado',
        5 => 'El Paisnal',
        6 => 'Guazapa',
        7 => 'Ilopango',
        8 => 'Mejicanos',
        9 => 'Panchimalco',
        10 => 'Rosario de Mora',
        11 => 'San Marcos',
        12 => 'San Salvador',
        13 => 'Santo Tomás',
        14 => 'Soyapango',
        15 => 'Tonacatepeque',
      ),
    ),
    'LI' => 
    array (
      'name' => 'La Libertad Department',
      'cities' => 
      array (
        0 => 'Antiguo Cuscatlán',
        1 => 'Ciudad Arce',
        2 => 'La Libertad',
        3 => 'Nuevo Cuscatlán',
        4 => 'Quezaltepeque',
        5 => 'San Juan Opico',
        6 => 'San Pablo Tacachico',
        7 => 'Santa Tecla',
        8 => 'Zaragoza',
      ),
    ),
    'SM' => 
    array (
      'name' => 'San Miguel Department',
      'cities' => 
      array (
        0 => 'Chapeltique',
        1 => 'Chinameca',
        2 => 'Chirilagua',
        3 => 'Ciudad Barrios',
        4 => 'El Tránsito',
        5 => 'Lolotique',
        6 => 'Moncagua',
        7 => 'Nueva Guadalupe',
        8 => 'San Miguel',
        9 => 'San Rafael Oriente',
        10 => 'Sesori',
      ),
    ),
    'PA' => 
    array (
      'name' => 'La Paz Department',
      'cities' => 
      array (
        0 => 'El Rosario',
        1 => 'Olocuilta',
        2 => 'San Pedro Masahuat',
        3 => 'Santiago Nonualco',
        4 => 'Zacatecoluca',
      ),
    ),
    'CU' => 
    array (
      'name' => 'Cuscatlán Department',
      'cities' => 
      array (
        0 => 'Cojutepeque',
        1 => 'San Martín',
        2 => 'Suchitoto',
        3 => 'Tecoluca',
        4 => 'Tenancingo',
      ),
    ),
    'UN' => 
    array (
      'name' => 'La Unión Department',
      'cities' => 
      array (
        0 => 'Anamorós',
        1 => 'Conchagua',
        2 => 'Intipucá',
        3 => 'La Unión',
        4 => 'Nueva Esparta',
        5 => 'Pasaquina',
        6 => 'San Alejo',
        7 => 'Santa Rosa de Lima',
      ),
    ),
    'AH' => 
    array (
      'name' => 'Ahuachapán Department',
      'cities' => 
      array (
        0 => 'Ahuachapán',
        1 => 'Atiquizaya',
        2 => 'Concepción de Ataco',
        3 => 'Guaymango',
        4 => 'Jujutla',
        5 => 'San Francisco Menéndez',
        6 => 'Tacuba',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Sonsonate Department',
      'cities' => 
      array (
        0 => 'Acajutla',
        1 => 'Armenia',
        2 => 'Izalco',
        3 => 'Juayúa',
        4 => 'Nahuizalco',
        5 => 'San Antonio del Monte',
        6 => 'Sonsonate',
        7 => 'Sonzacate',
      ),
    ),
  ),
  'SI' => 
  array (
    '058' => 
    array (
      'name' => 'Lenart Municipality',
      'cities' => 
      array (
        0 => 'Lenart v Slov. Goricah',
      ),
    ),
    '092' => 
    array (
      'name' => 'Podčetrtek Municipality',
      'cities' => 
      array (
        0 => 'Podčetrtek',
      ),
    ),
    '045' => 
    array (
      'name' => 'Kidričevo Municipality',
      'cities' => 
      array (
        0 => 'Kidričevo',
      ),
    ),
    '015' => 
    array (
      'name' => 'Črenšovci Municipality',
      'cities' => 
      array (
        0 => 'Črenšovci',
      ),
    ),
    '036' => 
    array (
      'name' => 'Idrija Municipality',
      'cities' => 
      array (
        0 => 'Idrija',
        1 => 'Spodnja Idrija',
      ),
    ),
    '069' => 
    array (
      'name' => 'Majšperk Municipality',
      'cities' => 
      array (
        0 => 'Majšperk',
      ),
    ),
    '066' => 
    array (
      'name' => 'Loški Potok Municipality',
      'cities' => 
      array (
        0 => 'Hrib-Loški Potok',
      ),
    ),
    '023' => 
    array (
      'name' => 'Domžale Municipality',
      'cities' => 
      array (
        0 => 'Dob',
        1 => 'Domžale',
        2 => 'Radomlje',
        3 => 'Vir',
      ),
    ),
    '013' => 
    array (
      'name' => 'Cerknica Municipality',
      'cities' => 
      array (
        0 => 'Cerknica',
        1 => 'Rakek',
      ),
    ),
    '008' => 
    array (
      'name' => 'Brezovica Municipality',
      'cities' => 
      array (
        0 => 'Brezovica pri Ljubljani',
        1 => 'Notranje Gorice',
        2 => 'Opština Ljubljana-Vič-Rudnik',
        3 => 'Rečica ob Savinji',
        4 => 'Vnanje Gorice',
      ),
    ),
    '019' => 
    array (
      'name' => 'Divača Municipality',
      'cities' => 
      array (
        0 => 'Divača',
      ),
    ),
    '077' => 
    array (
      'name' => 'Moravče Municipality',
      'cities' => 
      array (
        0 => 'Moravče',
      ),
    ),
    '089' => 
    array (
      'name' => 'Pesnica Municipality',
      'cities' => 
      array (
        0 => 'Pesnica pri Mariboru',
      ),
    ),
    '022' => 
    array (
      'name' => 'Dol pri Ljubljani Municipality',
      'cities' => 
      array (
        0 => 'Dol pri Ljubljani',
      ),
    ),
    '065' => 
    array (
      'name' => 'Loška Dolina Municipality',
      'cities' => 
      array (
        0 => 'Leskova Dolina',
      ),
    ),
    '082' => 
    array (
      'name' => 'Naklo Municipality',
      'cities' => 
      array (
        0 => 'Naklo',
      ),
    ),
    '014' => 
    array (
      'name' => 'Cerkno Municipality',
      'cities' => 
      array (
        0 => 'Cerkno',
      ),
    ),
    '043' => 
    array (
      'name' => 'Kamnik Municipality',
      'cities' => 
      array (
        0 => 'Kamnik',
        1 => 'Mekinje',
        2 => 'Šmarca',
      ),
    ),
    '006' => 
    array (
      'name' => 'Bovec Municipality',
      'cities' => 
      array (
        0 => 'Bovec',
        1 => 'Mirna',
      ),
    ),
    '001' => 
    array (
      'name' => 'Ajdovščina Municipality',
      'cities' => 
      array (
        0 => 'Ajdovščina',
        1 => 'Cirkulane',
        2 => 'Lokavec',
      ),
    ),
    '091' => 
    array (
      'name' => 'Pivka Municipality',
      'cities' => 
      array (
        0 => 'Pivka',
      ),
    ),
    '051' => 
    array (
      'name' => 'Kozje Municipality',
      'cities' => 
      array (
        0 => 'Kozje',
      ),
    ),
    '079' => 
    array (
      'name' => 'Mozirje Municipality',
      'cities' => 
      array (
        0 => 'Mozirje',
      ),
    ),
    '011' => 
    array (
      'name' => 'City Municipality of Celje',
      'cities' => 
      array (
        0 => 'Celje',
        1 => 'Ljubečna',
        2 => 'Trnovlje pri Celju',
      ),
    ),
    '099' => 
    array (
      'name' => 'Radeče Municipality',
      'cities' => 
      array (
        0 => 'Radeče',
      ),
    ),
    '055' => 
    array (
      'name' => 'Kungota',
      'cities' => 
      array (
        0 => 'Zgornja Kungota',
      ),
    ),
    '088' => 
    array (
      'name' => 'Osilnica Municipality',
      'cities' => 
      array (
        0 => 'Osilnica',
      ),
    ),
    '005' => 
    array (
      'name' => 'Borovnica Municipality',
      'cities' => 
      array (
        0 => 'Borovnica',
        1 => 'Makole',
      ),
    ),
    '090' => 
    array (
      'name' => 'Piran Municipality',
      'cities' => 
      array (
        0 => 'Lucija',
        1 => 'Piran',
        2 => 'Portorož',
        3 => 'Seča',
      ),
    ),
    '003' => 
    array (
      'name' => 'Bled Municipality',
      'cities' => 
      array (
        0 => 'Bled',
        1 => 'Kostanjevica na Krki',
        2 => 'Zasip',
      ),
    ),
    '098' => 
    array (
      'name' => 'Rače–Fram Municipality',
      'cities' => 
      array (
        0 => 'Fram',
        1 => 'Morje',
        2 => 'Rače',
      ),
    ),
    '084' => 
    array (
      'name' => 'Nova Gorica City Municipality',
      'cities' => 
      array (
        0 => 'Kromberk',
        1 => 'Nova Gorica',
        2 => 'Prvačina',
        3 => 'Solkan',
        4 => 'Šempas',
      ),
    ),
    '081' => 
    array (
      'name' => 'Muta Municipality',
      'cities' => 
      array (
        0 => 'Muta',
      ),
    ),
    '028' => 
    array (
      'name' => 'Gorišnica Municipality',
      'cities' => 
      array (
        0 => 'Gorišnica',
      ),
    ),
    '056' => 
    array (
      'name' => 'Kuzma Municipality',
      'cities' => 
      array (
        0 => 'Kuzma',
      ),
    ),
    '076' => 
    array (
      'name' => 'Mislinja Municipality',
      'cities' => 
      array (
        0 => 'Mislinja',
      ),
    ),
    '026' => 
    array (
      'name' => 'Duplek Municipality',
      'cities' => 
      array (
        0 => 'Spodnji Duplek',
        1 => 'Zgornji Duplek',
      ),
    ),
    '009' => 
    array (
      'name' => 'Brežice Municipality',
      'cities' => 
      array (
        0 => 'Brežice',
        1 => 'Poljčane',
      ),
    ),
    '020' => 
    array (
      'name' => 'Dobrepolje Municipality',
      'cities' => 
      array (
        0 => 'Videm',
      ),
    ),
    '078' => 
    array (
      'name' => 'Moravske Toplice Municipality',
      'cities' => 
      array (
        0 => 'Moravske Toplice',
      ),
    ),
    '067' => 
    array (
      'name' => 'Luče Municipality',
      'cities' => 
      array (
        0 => 'Luče',
      ),
    ),
    '075' => 
    array (
      'name' => 'Miren–Kostanjevica Municipality',
      'cities' => 
      array (
        0 => 'Bilje',
        1 => 'Miren',
      ),
    ),
    '087' => 
    array (
      'name' => 'Ormož Municipality',
      'cities' => 
      array (
        0 => 'Ormož',
      ),
    ),
    '033' => 
    array (
      'name' => 'Šalovci Municipality',
      'cities' => 
      array (
        0 => 'Šalovci',
      ),
    ),
    '059' => 
    array (
      'name' => 'Lendava Municipality',
      'cities' => 
      array (
        0 => 'Lendava',
      ),
    ),
    '044' => 
    array (
      'name' => 'Kanal ob Soči Municipality',
      'cities' => 
      array (
        0 => 'Deskle',
        1 => 'Kanal',
      ),
    ),
    '096' => 
    array (
      'name' => 'Ptuj City Municipality',
      'cities' => 
      array (
        0 => 'Ptuj',
      ),
    ),
    '016' => 
    array (
      'name' => 'Črna na Koroškem Municipality',
      'cities' => 
      array (
        0 => 'Črna na Koroškem',
      ),
    ),
    '093' => 
    array (
      'name' => 'Podvelka Municipality',
      'cities' => 
      array (
        0 => 'Podvelka',
      ),
    ),
    '085' => 
    array (
      'name' => 'City Municipality of Novo Mesto',
      'cities' => 
      array (
        0 => 'Novo Mesto',
      ),
    ),
    '007' => 
    array (
      'name' => 'Brda Municipality',
      'cities' => 
      array (
        0 => 'Dobrovo',
        1 => 'Mokronog',
      ),
    ),
    '070' => 
    array (
      'name' => 'Maribor City Municipality',
      'cities' => 
      array (
        0 => 'Bresternica',
        1 => 'Kamnica',
        2 => 'Limbuš',
        3 => 'Maribor',
        4 => 'Pekre',
        5 => 'Razvanje',
      ),
    ),
    '046' => 
    array (
      'name' => 'Kobarid Municipality',
      'cities' => 
      array (
        0 => 'Kobarid',
      ),
    ),
    '074' => 
    array (
      'name' => 'Mežica Municipality',
      'cities' => 
      array (
        0 => 'Mežica',
      ),
    ),
    '042' => 
    array (
      'name' => 'Juršinci Municipality',
      'cities' => 
      array (
        0 => 'Juršinci',
      ),
    ),
    '061' => 
    array (
      'name' => 'Ljubljana City Municipality',
      'cities' => 
      array (
        0 => 'Dravlje District',
        1 => 'Jarše District',
        2 => 'Ljubljana',
        3 => 'Opčina Ljubljana-Bežigrad',
        4 => 'Opština Ljubljana-Center',
        5 => 'Opština Ljubljana-Moste-Polje',
        6 => 'Rožnik District',
        7 => 'Sostro District',
        8 => 'Trnovo District',
        9 => 'Vič District',
        10 => 'Šentvid District',
      ),
    ),
    '031' => 
    array (
      'name' => 'Gornji Petrovci Municipality',
      'cities' => 
      array (
        0 => 'Gornji Petrovci',
      ),
    ),
    '004' => 
    array (
      'name' => 'Bohinj Municipality',
      'cities' => 
      array (
        0 => 'Bohinjska Bistrica',
        1 => 'Dragomer',
        2 => 'Log pri Brezovici',
      ),
    ),
    '037' => 
    array (
      'name' => 'Ig Municipality',
      'cities' => 
      array (
        0 => 'Ig',
      ),
    ),
    '052' => 
    array (
      'name' => 'Kranj City Municipality',
      'cities' => 
      array (
        0 => 'Britof',
        1 => 'Golnik',
        2 => 'Kokrica',
        3 => 'Kranj',
        4 => 'Mlaka pri Kranju',
        5 => 'Zgornje Bitnje',
      ),
    ),
    '097' => 
    array (
      'name' => 'Puconci Municipality',
      'cities' => 
      array (
        0 => 'Puconci',
      ),
    ),
    '024' => 
    array (
      'name' => 'Dornava Municipality',
      'cities' => 
      array (
        0 => 'Dornava',
      ),
    ),
    '017' => 
    array (
      'name' => 'Črnomelj Municipality',
      'cities' => 
      array (
        0 => 'Črnomelj',
      ),
    ),
    '027' => 
    array (
      'name' => 'Gorenja Vas–Poljane Municipality',
      'cities' => 
      array (
        0 => 'Gorenja Vas',
      ),
    ),
    '062' => 
    array (
      'name' => 'Ljubno Municipality',
      'cities' => 
      array (
        0 => 'Ljubno ob Savinji',
      ),
    ),
    '002' => 
    array (
      'name' => 'Beltinci Municipality',
      'cities' => 
      array (
        0 => 'Beltinci',
        1 => 'Gančani',
        2 => 'Lipovci',
        3 => 'Zgornje Gorje',
      ),
    ),
    '068' => 
    array (
      'name' => 'Lukovica Municipality',
      'cities' => 
      array (
        0 => 'Lukovica pri Domžalah',
      ),
    ),
    '095' => 
    array (
      'name' => 'Preddvor Municipality',
      'cities' => 
      array (
        0 => 'Preddvor',
      ),
    ),
    '018' => 
    array (
      'name' => 'Destrnik Municipality',
      'cities' => 
      array (
        0 => 'Destrnik',
      ),
    ),
    '039' => 
    array (
      'name' => 'Ivančna Gorica Municipality',
      'cities' => 
      array (
        0 => 'Ivančna Gorica',
        1 => 'Šentvid pri Stični',
      ),
    ),
    '021' => 
    array (
      'name' => 'Dobrova–Polhov Gradec Municipality',
      'cities' => 
      array (
        0 => 'Dobrova',
      ),
    ),
    '012' => 
    array (
      'name' => 'Cerklje na Gorenjskem Municipality',
      'cities' => 
      array (
        0 => 'Cerklje na Gorenjskem',
      ),
    ),
    '010' => 
    array (
      'name' => 'Tišina Municipality',
      'cities' => 
      array (
        0 => 'Tišina',
      ),
    ),
    '080' => 
    array (
      'name' => 'Murska Sobota City Municipality',
      'cities' => 
      array (
        0 => 'Bakovci',
        1 => 'Krog',
        2 => 'Murska Sobota',
        3 => 'Rakičan',
        4 => 'Černelavci',
      ),
    ),
    '054' => 
    array (
      'name' => 'Municipality of Krško',
      'cities' => 
      array (
        0 => 'Krško',
        1 => 'Leskovec pri Krškem',
        2 => 'Senovo',
      ),
    ),
    '049' => 
    array (
      'name' => 'Komen Municipality',
      'cities' => 
      array (
        0 => 'Komen',
      ),
    ),
    '050' => 
    array (
      'name' => 'Koper City Municipality',
      'cities' => 
      array (
        0 => 'Dekani',
        1 => 'Hrvatini',
        2 => 'Koper',
        3 => 'Pobegi',
        4 => 'Prade',
        5 => 'Spodnje Škofije',
        6 => 'Sv. Anton',
      ),
    ),
    '086' => 
    array (
      'name' => 'Odranci Municipality',
      'cities' => 
      array (
        0 => 'Odranci',
      ),
    ),
    '035' => 
    array (
      'name' => 'Hrpelje–Kozina Municipality',
      'cities' => 
      array (
        0 => 'Kozina',
      ),
    ),
    '040' => 
    array (
      'name' => 'Izola Municipality',
      'cities' => 
      array (
        0 => 'Izola',
        1 => 'Jagodje',
      ),
    ),
    '073' => 
    array (
      'name' => 'Metlika Municipality',
      'cities' => 
      array (
        0 => 'Metlika',
      ),
    ),
    '047' => 
    array (
      'name' => 'Kobilje Municipality',
      'cities' => 
      array (
        0 => 'Kobilje',
      ),
    ),
    '083' => 
    array (
      'name' => 'Nazarje Municipality',
      'cities' => 
      array (
        0 => 'Nazarje',
      ),
    ),
    '094' => 
    array (
      'name' => 'Postojna Municipality',
      'cities' => 
      array (
        0 => 'Postojna',
      ),
    ),
    '048' => 
    array (
      'name' => 'Kočevje Municipality',
      'cities' => 
      array (
        0 => 'Kočevje',
      ),
    ),
    '032' => 
    array (
      'name' => 'Grosuplje Municipality',
      'cities' => 
      array (
        0 => 'Grosuplje',
        1 => 'Šmarje-Sap',
      ),
    ),
    '041' => 
    array (
      'name' => 'Jesenice Municipality',
      'cities' => 
      array (
        0 => 'Hrušica',
        1 => 'Jesenice',
        2 => 'Koroška Bela',
        3 => 'Slovenski Javornik',
      ),
    ),
    '057' => 
    array (
      'name' => 'Laško Municipality',
      'cities' => 
      array (
        0 => 'Laško',
      ),
    ),
    '030' => 
    array (
      'name' => 'Gornji Grad Municipality',
      'cities' => 
      array (
        0 => 'Gornji Grad',
      ),
    ),
    '053' => 
    array (
      'name' => 'Kranjska Gora Municipality',
      'cities' => 
      array (
        0 => 'Kranjska Gora',
        1 => 'Mojstrana',
      ),
    ),
    '034' => 
    array (
      'name' => 'Hrastnik Municipality',
      'cities' => 
      array (
        0 => 'Dol pri Hrastniku',
        1 => 'Hrastnik',
      ),
    ),
    '029' => 
    array (
      'name' => 'Gornja Radgona Municipality',
      'cities' => 
      array (
        0 => 'Gornja Radgona',
      ),
    ),
    '038' => 
    array (
      'name' => 'Municipality of Ilirska Bistrica',
      'cities' => 
      array (
        0 => 'Ilirska Bistrica',
      ),
    ),
    '025' => 
    array (
      'name' => 'Dravograd Municipality',
      'cities' => 
      array (
        0 => 'Dravograd',
      ),
    ),
    '060' => 
    array (
      'name' => 'Litija Municipality',
      'cities' => 
      array (
        0 => 'Litija',
      ),
    ),
    '072' => 
    array (
      'name' => 'Mengeš Municipality',
      'cities' => 
      array (
        0 => 'Mengeš',
        1 => 'Preserje pri Radomljah',
      ),
    ),
    '071' => 
    array (
      'name' => 'Medvode Municipality',
      'cities' => 
      array (
        0 => 'Medvode',
        1 => 'Opština [historical] Ljubljana-Šiška',
        2 => 'Zgornje Pirniče',
      ),
    ),
    '064' => 
    array (
      'name' => 'Logatec Municipality',
      'cities' => 
      array (
        0 => 'Logatec',
      ),
    ),
    '063' => 
    array (
      'name' => 'Ljutomer Municipality',
      'cities' => 
      array (
        0 => 'Ljutomer',
      ),
    ),
  ),
  'SK' => 
  array (
    'BC' => 
    array (
      'name' => 'Banská Bystrica Region',
      'cities' => 
      array (
        0 => 'Banská Bystrica',
        1 => 'Banská Štiavnica',
        2 => 'Brezno',
        3 => 'Detva',
        4 => 'Dudince',
        5 => 'Fiľakovo',
        6 => 'Hriňová',
        7 => 'Hrochoť,Slovakia',
        8 => 'Kováčová',
        9 => 'Kremnica',
        10 => 'Krupina',
        11 => 'Lučenec',
        12 => 'Nová Baňa',
        13 => 'Okres Banská Bystrica',
        14 => 'Okres Banská Štiavnica',
        15 => 'Okres Brezno',
        16 => 'Okres Detva',
        17 => 'Okres Krupina',
        18 => 'Okres Lučenec',
        19 => 'Okres Poltár',
        20 => 'Okres Revúca',
        21 => 'Okres Veľký Krtíš',
        22 => 'Okres Zvolen',
        23 => 'Okres Žarnovica',
        24 => 'Okres Žiar nad Hronom',
        25 => 'Poltár',
        26 => 'Revúca',
        27 => 'Rimavská Sobota',
        28 => 'Svätý Anton',
        29 => 'Tisovec',
        30 => 'Veľký Krtíš',
        31 => 'Zvolen',
        32 => 'Čierny Balog',
        33 => 'Žarnovica',
        34 => 'Žiar nad Hronom',
      ),
    ),
    'KI' => 
    array (
      'name' => 'Košice Region',
      'cities' => 
      array (
        0 => 'Dobšiná',
        1 => 'Gelnica',
        2 => 'Kavečany',
        3 => 'Košice',
        4 => 'Košice I',
        5 => 'Košice II',
        6 => 'Košice III',
        7 => 'Košice IV',
        8 => 'Krompachy',
        9 => 'Medzev',
        10 => 'Michalovce',
        11 => 'Moldava nad Bodvou',
        12 => 'Okres Gelnica',
        13 => 'Okres Kosice-okolie',
        14 => 'Okres Michalovce',
        15 => 'Okres Rožňava',
        16 => 'Okres Sobrance',
        17 => 'Okres Spišská Nová Ves',
        18 => 'Okres Trebišov',
        19 => 'Rožňava',
        20 => 'Sečovce',
        21 => 'Sobrance',
        22 => 'Spišská Nová Ves',
        23 => 'Strážske',
        24 => 'Trebišov',
        25 => 'Vinné',
        26 => 'Čierna nad Tisou',
        27 => 'Žehra',
      ),
    ),
    'PV' => 
    array (
      'name' => 'Prešov Region',
      'cities' => 
      array (
        0 => 'Bardejov',
        1 => 'Chlmec',
        2 => 'Giraltovce',
        3 => 'Humenné',
        4 => 'Kežmarok',
        5 => 'Levoča',
        6 => 'Lipany',
        7 => 'Medzilaborce',
        8 => 'Nová Lesná',
        9 => 'Okres Bardejov',
        10 => 'Okres Humenné',
        11 => 'Okres Kežmarok',
        12 => 'Okres Levoča',
        13 => 'Okres Medzilaborce',
        14 => 'Okres Poprad',
        15 => 'Okres Prešov',
        16 => 'Okres Sabinov',
        17 => 'Okres Snina',
        18 => 'Okres Stará Ĺubovňa',
        19 => 'Okres Stropkov',
        20 => 'Okres Svidník',
        21 => 'Okres Vranov nad Topľou',
        22 => 'Podolínec',
        23 => 'Poprad',
        24 => 'Prešov',
        25 => 'Sabinov',
        26 => 'Snina',
        27 => 'Spišská Belá',
        28 => 'Spišské Podhradie',
        29 => 'Stará Ľubovňa',
        30 => 'Stropkov',
        31 => 'Svidník',
        32 => 'Svit',
        33 => 'Vranov nad Topľou',
        34 => 'Vrbov',
        35 => 'Vysoké Tatry',
        36 => 'Vyšné Ružbachy',
        37 => 'Ľubica',
        38 => 'Štrba',
        39 => 'Ždiar',
      ),
    ),
    'TA' => 
    array (
      'name' => 'Trnava Region',
      'cities' => 
      array (
        0 => 'Dunajská Streda',
        1 => 'Gabčíkovo',
        2 => 'Galanta',
        3 => 'Gbely',
        4 => 'Hlohovec',
        5 => 'Holíč',
        6 => 'Leopoldov',
        7 => 'Okres Dunajská Streda',
        8 => 'Okres Galanta',
        9 => 'Okres Hlohovec',
        10 => 'Okres Piešťany',
        11 => 'Okres Senica',
        12 => 'Okres Skalica',
        13 => 'Okres Trnava',
        14 => 'Piešťany',
        15 => 'Senica',
        16 => 'Skalica',
        17 => 'Sládkovičovo',
        18 => 'Smolenice',
        19 => 'Trnava',
        20 => 'Veľký Meder',
        21 => 'Vrbové',
        22 => 'Šamorín',
      ),
    ),
    'BL' => 
    array (
      'name' => 'Bratislava Region',
      'cities' => 
      array (
        0 => 'Bratislava',
        1 => 'Bratislava - Vajnory',
        2 => 'Dunajská Lužná',
        3 => 'Ivanka pri Dunaji',
        4 => 'Malacky',
        5 => 'Marianka',
        6 => 'Modra',
        7 => 'Okres Bratislava I',
        8 => 'Okres Bratislava II',
        9 => 'Okres Bratislava III',
        10 => 'Okres Bratislava IV',
        11 => 'Okres Bratislava V',
        12 => 'Okres Malacky',
        13 => 'Okres Pezinok',
        14 => 'Okres Senec',
        15 => 'Pezinok',
        16 => 'Senec',
        17 => 'Stupava',
        18 => 'Svätý Jur',
        19 => 'Vinosady',
      ),
    ),
    'NI' => 
    array (
      'name' => 'Nitra Region',
      'cities' => 
      array (
        0 => 'Hurbanovo',
        1 => 'Kolárovo',
        2 => 'Komárno',
        3 => 'Levice',
        4 => 'Nitra',
        5 => 'Nové Zámky',
        6 => 'Okres Komárno',
        7 => 'Okres Levice',
        8 => 'Okres Nitra',
        9 => 'Okres Nové Zámky',
        10 => 'Okres Topoľčany',
        11 => 'Okres Zlaté Moravce',
        12 => 'Okres Šaľa',
        13 => 'Svodín',
        14 => 'Tlmače',
        15 => 'Topoľčany',
        16 => 'Vráble',
        17 => 'Zlaté Moravce',
        18 => 'Šahy',
        19 => 'Šaľa',
        20 => 'Štúrovo',
        21 => 'Šurany',
        22 => 'Želiezovce',
      ),
    ),
    'TC' => 
    array (
      'name' => 'Trenčín Region',
      'cities' => 
      array (
        0 => 'Bojnice',
        1 => 'Brezová pod Bradlom',
        2 => 'Bánovce nad Bebravou',
        3 => 'Dubnica nad Váhom',
        4 => 'Handlová',
        5 => 'Ilava',
        6 => 'Lehota pod Vtáčnikom',
        7 => 'Myjava',
        8 => 'Nemšová',
        9 => 'Nová Dubnica',
        10 => 'Nováky',
        11 => 'Nové Mesto nad Váhom',
        12 => 'Okres Bánovce nad Bebravou',
        13 => 'Okres Ilava',
        14 => 'Okres Myjava',
        15 => 'Okres Nové Mesto nad Váhom',
        16 => 'Okres Partizánske',
        17 => 'Okres Považská Bystrica',
        18 => 'Okres Prievidza',
        19 => 'Okres Púchov',
        20 => 'Okres Trenčín',
        21 => 'Partizánske',
        22 => 'Považská Bystrica',
        23 => 'Prievidza',
        24 => 'Púchov',
        25 => 'Stará Turá',
        26 => 'Trenčianske Teplice',
        27 => 'Trenčín',
        28 => 'Čachtice',
      ),
    ),
    'ZI' => 
    array (
      'name' => 'Žilina Region',
      'cities' => 
      array (
        0 => 'Bytča',
        1 => 'Dolný Kubín',
        2 => 'Hybe',
        3 => 'Krasňany',
        4 => 'Kysucké Nové Mesto',
        5 => 'Liptovský Hrádok',
        6 => 'Liptovský Mikuláš',
        7 => 'Lúčky',
        8 => 'Martin',
        9 => 'Nižná',
        10 => 'Námestovo',
        11 => 'Okres Bytča',
        12 => 'Okres Dolný Kubín',
        13 => 'Okres Kysucké Nové Mesto',
        14 => 'Okres Liptovský Mikuláš',
        15 => 'Okres Martin',
        16 => 'Okres Namestovo',
        17 => 'Okres Ružomberok',
        18 => 'Okres Turčianske Teplice',
        19 => 'Okres Tvrdošín',
        20 => 'Okres Čadca',
        21 => 'Okres Žilina',
        22 => 'Oravská Lesná',
        23 => 'Oravský Podzámok',
        24 => 'Pribylina',
        25 => 'Rajec',
        26 => 'Ružomberok',
        27 => 'Terchová',
        28 => 'Trstená',
        29 => 'Turzovka',
        30 => 'Turčianske Teplice',
        31 => 'Tvrdošín',
        32 => 'Vrútky',
        33 => 'Čadca',
        34 => 'Žilina',
      ),
    ),
  ),
  'MD' => 
  array (
    'CM' => 
    array (
      'name' => 'Cimișlia District',
      'cities' => 
      array (
        0 => 'Cimişlia',
      ),
    ),
    'OR' => 
    array (
      'name' => 'Orhei District',
      'cities' => 
      array (
        0 => 'Orhei',
      ),
    ),
    'BD' => 
    array (
      'name' => 'Bender Municipality',
      'cities' => 
      array (
        0 => 'Bender',
      ),
    ),
    'NI' => 
    array (
      'name' => 'Nisporeni District',
      'cities' => 
      array (
        0 => 'Nisporeni',
      ),
    ),
    'SI' => 
    array (
      'name' => 'Sîngerei District',
      'cities' => 
      array (
        0 => 'Bilicenii Vechi',
        1 => 'Biruinţa',
        2 => 'Sîngerei',
      ),
    ),
    'CS' => 
    array (
      'name' => 'Căușeni District',
      'cities' => 
      array (
        0 => 'Chiţcani',
        1 => 'Căuşeni',
      ),
    ),
    'CL' => 
    array (
      'name' => 'Călărași District',
      'cities' => 
      array (
        0 => 'Călăraşi',
      ),
    ),
    'GL' => 
    array (
      'name' => 'Glodeni District',
      'cities' => 
      array (
        0 => 'Glodeni',
      ),
    ),
    'AN' => 
    array (
      'name' => 'Anenii Noi District',
      'cities' => 
      array (
        0 => 'Anenii Noi',
        1 => 'Varniţa',
      ),
    ),
    'IA' => 
    array (
      'name' => 'Ialoveni District',
      'cities' => 
      array (
        0 => 'Ialoveni',
      ),
    ),
    'FL' => 
    array (
      'name' => 'Florești District',
      'cities' => 
      array (
        0 => 'Floreşti',
        1 => 'Ghindești',
        2 => 'Mărculeşti',
      ),
    ),
    'TE' => 
    array (
      'name' => 'Telenești District',
      'cities' => 
      array (
        0 => 'Mîndreşti',
        1 => 'Teleneşti',
      ),
    ),
    'TA' => 
    array (
      'name' => 'Taraclia District',
      'cities' => 
      array (
        0 => 'Taraclia',
        1 => 'Tvardița',
      ),
    ),
    'CU' => 
    array (
      'name' => 'Chișinău Municipality',
      'cities' => 
      array (
        0 => 'Chisinau',
        1 => 'Ciorescu',
        2 => 'Cricova',
        3 => 'Stăuceni',
        4 => 'Sîngera',
        5 => 'Vadul lui Vodă',
        6 => 'Vatra',
      ),
    ),
    'SO' => 
    array (
      'name' => 'Soroca District',
      'cities' => 
      array (
        0 => 'Soroca',
      ),
    ),
    'BR' => 
    array (
      'name' => 'Briceni District',
      'cities' => 
      array (
        0 => 'Briceni',
      ),
    ),
    'RI' => 
    array (
      'name' => 'Rîșcani District',
      'cities' => 
      array (
        0 => 'Rîşcani',
      ),
    ),
    'ST' => 
    array (
      'name' => 'Strășeni District',
      'cities' => 
      array (
        0 => 'Bucovăţ',
        1 => 'Strășeni',
      ),
    ),
    'SV' => 
    array (
      'name' => 'Ștefan Vodă District',
      'cities' => 
      array (
        0 => 'Ştefan Vodă',
      ),
    ),
    'BS' => 
    array (
      'name' => 'Basarabeasca District',
      'cities' => 
      array (
        0 => 'Basarabeasca',
      ),
    ),
    'CT' => 
    array (
      'name' => 'Cantemir District',
      'cities' => 
      array (
        0 => 'Cantemir',
        1 => 'Iargara',
        2 => 'Vişniovca',
      ),
    ),
    'FA' => 
    array (
      'name' => 'Fălești District',
      'cities' => 
      array (
        0 => 'Fălești',
      ),
    ),
    'HI' => 
    array (
      'name' => 'Hîncești District',
      'cities' => 
      array (
        0 => 'Dancu',
        1 => 'Hînceşti',
      ),
    ),
    'DU' => 
    array (
      'name' => 'Dubăsari District',
      'cities' => 
      array (
        0 => 'Cocieri',
        1 => 'Ustia',
      ),
    ),
    'DO' => 
    array (
      'name' => 'Dondușeni District',
      'cities' => 
      array (
        0 => 'Briceni',
        1 => 'Donduşeni',
      ),
    ),
    'GA' => 
    array (
      'name' => 'Gagauzia',
      'cities' => 
      array (
        0 => 'Bugeac',
        1 => 'Ceadîr-Lunga',
        2 => 'Comrat',
        3 => 'Vulcăneşti',
      ),
    ),
    'UN' => 
    array (
      'name' => 'Ungheni District',
      'cities' => 
      array (
        0 => 'Ungheni',
      ),
    ),
    'ED' => 
    array (
      'name' => 'Edineț District',
      'cities' => 
      array (
        0 => 'Edineţ',
      ),
    ),
    'SD' => 
    array (
      'name' => 'Șoldănești District',
      'cities' => 
      array (
        0 => 'Şoldăneşti',
      ),
    ),
    'OC' => 
    array (
      'name' => 'Ocnița District',
      'cities' => 
      array (
        0 => 'Ocniţa',
        1 => 'Otaci',
      ),
    ),
    'CR' => 
    array (
      'name' => 'Criuleni District',
      'cities' => 
      array (
        0 => 'Criuleni',
      ),
    ),
    'CA' => 
    array (
      'name' => 'Cahul District',
      'cities' => 
      array (
        0 => 'Cahul',
        1 => 'Giurgiuleşti',
      ),
    ),
    'DR' => 
    array (
      'name' => 'Drochia District',
      'cities' => 
      array (
        0 => 'Drochia',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Bălți Municipality',
      'cities' => 
      array (
        0 => 'Bălţi',
      ),
    ),
    'RE' => 
    array (
      'name' => 'Rezina District',
      'cities' => 
      array (
        0 => 'Rezina',
        1 => 'Saharna',
      ),
    ),
    'SN' => 
    array (
      'name' => 'Transnistria autonomous territorial unit',
      'cities' => 
      array (
        0 => 'Camenca',
        1 => 'Crasnoe',
        2 => 'Dnestrovsc',
        3 => 'Dubăsari',
        4 => 'Hryhoriopol',
        5 => 'Maiac',
        6 => 'Pervomaisc',
        7 => 'Rîbniţa',
        8 => 'Slobozia',
        9 => 'Tiraspol',
        10 => 'Tiraspolul Nou',
      ),
    ),
  ),
  'LV' => 
  array (
    '086' => 
    array (
      'name' => 'Salacgrīva Municipality',
      'cities' => 
      array (
        0 => 'Ainaži',
        1 => 'Salacgrīva',
      ),
    ),
    '064' => 
    array (
      'name' => 'Naukšēni Municipality',
      'cities' => 
      array (
        0 => 'Naukšēni',
      ),
    ),
    '036' => 
    array (
      'name' => 'Ilūkste Municipality',
      'cities' => 
      array (
        0 => 'Ilūkste',
      ),
    ),
    '033' => 
    array (
      'name' => 'Gulbene Municipality',
      'cities' => 
      array (
        0 => 'Gulbene',
      ),
    ),
    '056' => 
    array (
      'name' => 'Līvāni Municipality',
      'cities' => 
      array (
        0 => 'Līvāni',
      ),
    ),
    '087' => 
    array (
      'name' => 'Salaspils Municipality',
      'cities' => 
      array (
        0 => 'Salaspils',
      ),
    ),
    '083' => 
    array (
      'name' => 'Rundāle Municipality',
      'cities' => 
      array (
        0 => 'Pilsrundāle',
      ),
    ),
    '072' => 
    array (
      'name' => 'Pļaviņas Municipality',
      'cities' => 
      array (
        0 => 'Pļaviņas',
      ),
    ),
    '090' => 
    array (
      'name' => 'Sēja Municipality',
      'cities' => 
      array (
        0 => 'Engure',
        1 => 'Tukums',
      ),
    ),
    '023' => 
    array (
      'name' => 'Cibla Municipality',
      'cities' => 
      array (
        0 => 'Cibla',
      ),
    ),
    '051' => 
    array (
      'name' => 'Ķegums Municipality',
      'cities' => 
      array (
        0 => 'Ķegums',
      ),
    ),
    '021' => 
    array (
      'name' => 'Cesvaine Municipality',
      'cities' => 
      array (
        0 => 'Cesvaine',
      ),
    ),
    '092' => 
    array (
      'name' => 'Skrīveri Municipality',
      'cities' => 
      array (
        0 => 'Skrīveri',
      ),
    ),
    '067' => 
    array (
      'name' => 'Ogre Municipality',
      'cities' => 
      array (
        0 => 'Jumprava',
        1 => 'Ogre',
      ),
    ),
    '068' => 
    array (
      'name' => 'Olaine Municipality',
      'cities' => 
      array (
        0 => 'Olaine',
      ),
    ),
    '054' => 
    array (
      'name' => 'Limbaži Municipality',
      'cities' => 
      array (
        0 => 'Limbaži',
      ),
    ),
    '057' => 
    array (
      'name' => 'Lubāna Municipality',
      'cities' => 
      array (
        0 => 'Lubāna',
      ),
    ),
    '043' => 
    array (
      'name' => 'Kandava Municipality',
      'cities' => 
      array (
        0 => 'Kandava',
      ),
    ),
    'VEN' => 
    array (
      'name' => 'Ventspils',
      'cities' => 
      array (
        0 => 'Ventspils',
      ),
    ),
    '082' => 
    array (
      'name' => 'Rugāji Municipality',
      'cities' => 
      array (
        0 => 'Rugāji',
      ),
    ),
    '041' => 
    array (
      'name' => 'Jelgava Municipality',
      'cities' => 
      array (
        0 => 'Tīreļi',
      ),
    ),
    '084' => 
    array (
      'name' => 'Rūjiena Municipality',
      'cities' => 
      array (
        0 => 'Rūjiena',
      ),
    ),
    '012' => 
    array (
      'name' => 'Babīte Municipality',
      'cities' => 
      array (
        0 => 'Piņķi',
      ),
    ),
    '027' => 
    array (
      'name' => 'Dundaga Municipality',
      'cities' => 
      array (
        0 => 'Dundaga',
      ),
    ),
    '074' => 
    array (
      'name' => 'Priekule Municipality',
      'cities' => 
      array (
        0 => 'Priekule',
      ),
    ),
    '065' => 
    array (
      'name' => 'Nereta Municipality',
      'cities' => 
      array (
        0 => 'Nereta',
      ),
    ),
    '059' => 
    array (
      'name' => 'Madona Municipality',
      'cities' => 
      array (
        0 => 'Madona',
      ),
    ),
    '052' => 
    array (
      'name' => 'Ķekava Municipality',
      'cities' => 
      array (
        0 => 'Baloži',
        1 => 'Ķekava',
      ),
    ),
    '066' => 
    array (
      'name' => 'Nīca Municipality',
      'cities' => 
      array (
        0 => 'Nīca',
      ),
    ),
    '026' => 
    array (
      'name' => 'Dobele Municipality',
      'cities' => 
      array (
        0 => 'Dobele',
      ),
    ),
    '042' => 
    array (
      'name' => 'Jēkabpils Municipality',
      'cities' => 
      array (
        0 => 'Jēkabpils',
        1 => 'Krustpils',
      ),
    ),
    '088' => 
    array (
      'name' => 'Saldus Municipality',
      'cities' => 
      array (
        0 => 'Saldus',
      ),
    ),
    '079' => 
    array (
      'name' => 'Roja Municipality',
      'cities' => 
      array (
        0 => 'Roja',
      ),
    ),
    '034' => 
    array (
      'name' => 'Iecava Municipality',
      'cities' => 
      array (
        0 => 'Iecava',
      ),
    ),
    '069' => 
    array (
      'name' => 'Ozolnieki Municipality',
      'cities' => 
      array (
        0 => 'Ozolnieki',
      ),
    ),
    '089' => 
    array (
      'name' => 'Saulkrasti Municipality',
      'cities' => 
      array (
        0 => 'Saulkrasti',
      ),
    ),
    '030' => 
    array (
      'name' => 'Ērgļi Municipality',
      'cities' => 
      array (
        0 => 'Ērgļi',
      ),
    ),
    '001' => 
    array (
      'name' => 'Aglona Municipality',
      'cities' => 
      array (
        0 => 'Aglona',
      ),
    ),
    'JUR' => 
    array (
      'name' => 'Jūrmala',
      'cities' => 
      array (
        0 => 'Jūrmala',
      ),
    ),
    '093' => 
    array (
      'name' => 'Skrunda Municipality',
      'cities' => 
      array (
        0 => 'Skrunda',
      ),
    ),
    '029' => 
    array (
      'name' => 'Engure Municipality',
      'cities' => 
      array (
        0 => 'Smārde',
      ),
    ),
    '037' => 
    array (
      'name' => 'Inčukalns Municipality',
      'cities' => 
      array (
        0 => 'Inčukalns',
        1 => 'Vangaži',
      ),
    ),
    '062' => 
    array (
      'name' => 'Mārupe Municipality',
      'cities' => 
      array (
        0 => 'Mārupe',
      ),
    ),
    '046' => 
    array (
      'name' => 'Koknese Municipality',
      'cities' => 
      array (
        0 => 'Koknese',
      ),
    ),
    '044' => 
    array (
      'name' => 'Kārsava Municipality',
      'cities' => 
      array (
        0 => 'Kārsava',
      ),
    ),
    '020' => 
    array (
      'name' => 'Carnikava Municipality',
      'cities' => 
      array (
        0 => 'Carnikava',
      ),
    ),
    '009' => 
    array (
      'name' => 'Ape Municipality',
      'cities' => 
      array (
        0 => 'Ape',
      ),
    ),
    '028' => 
    array (
      'name' => 'Durbe Municipality',
      'cities' => 
      array (
        0 => 'Lieģi',
      ),
    ),
    '097' => 
    array (
      'name' => 'Talsi Municipality',
      'cities' => 
      array (
        0 => 'Sabile',
        1 => 'Stende',
        2 => 'Talsi',
        3 => 'Valdemārpils',
      ),
    ),
    'LPX' => 
    array (
      'name' => 'Liepāja',
      'cities' => 
      array (
        0 => 'Karosta',
        1 => 'Liepāja',
      ),
    ),
    '061' => 
    array (
      'name' => 'Mālpils Municipality',
      'cities' => 
      array (
        0 => 'Mālpils',
      ),
    ),
    '094' => 
    array (
      'name' => 'Smiltene Municipality',
      'cities' => 
      array (
        0 => 'Smiltene',
      ),
    ),
    '016' => 
    array (
      'name' => 'Bauska Municipality',
      'cities' => 
      array (
        0 => 'Bauska',
      ),
    ),
    '071' => 
    array (
      'name' => 'Pāvilosta Municipality',
      'cities' => 
      array (
        0 => 'Pāvilosta',
      ),
    ),
    '018' => 
    array (
      'name' => 'Brocēni Municipality',
      'cities' => 
      array (
        0 => 'Brocēni',
      ),
    ),
    '022' => 
    array (
      'name' => 'Cēsis Municipality',
      'cities' => 
      array (
        0 => 'Cēsis',
      ),
    ),
    '032' => 
    array (
      'name' => 'Grobiņa Municipality',
      'cities' => 
      array (
        0 => 'Grobiņa',
      ),
    ),
    '017' => 
    array (
      'name' => 'Beverīna Municipality',
      'cities' => 
      array (
        0 => 'Mūrmuiža',
      ),
    ),
    '002' => 
    array (
      'name' => 'Aizkraukle Municipality',
      'cities' => 
      array (
        0 => 'Aizkraukle',
      ),
    ),
    'VMR' => 
    array (
      'name' => 'Valmiera',
      'cities' => 
      array (
        0 => 'Valmiera',
      ),
    ),
    '047' => 
    array (
      'name' => 'Krāslava Municipality',
      'cities' => 
      array (
        0 => 'Krāslava',
      ),
    ),
    '038' => 
    array (
      'name' => 'Jaunjelgava Municipality',
      'cities' => 
      array (
        0 => 'Jaunjelgava',
      ),
    ),
    '091' => 
    array (
      'name' => 'Sigulda Municipality',
      'cities' => 
      array (
        0 => 'Sigulda',
      ),
    ),
    '095' => 
    array (
      'name' => 'Stopiņi Municipality',
      'cities' => 
      array (
        0 => 'Ulbroka',
      ),
    ),
    '076' => 
    array (
      'name' => 'Rauna Municipality',
      'cities' => 
      array (
        0 => 'Rauna',
      ),
    ),
    '098' => 
    array (
      'name' => 'Tērvete Municipality',
      'cities' => 
      array (
        0 => 'Tērvete',
        1 => 'Zelmeņi',
      ),
    ),
    '010' => 
    array (
      'name' => 'Auce Municipality',
      'cities' => 
      array (
        0 => 'Auce',
      ),
    ),
    '013' => 
    array (
      'name' => 'Baldone Municipality',
      'cities' => 
      array (
        0 => 'Baldone',
      ),
    ),
    '073' => 
    array (
      'name' => 'Preiļi Municipality',
      'cities' => 
      array (
        0 => 'Jaunaglona',
        1 => 'Preiļi',
      ),
    ),
    '005' => 
    array (
      'name' => 'Aloja Municipality',
      'cities' => 
      array (
        0 => 'Aloja',
        1 => 'Staicele',
      ),
    ),
    '006' => 
    array (
      'name' => 'Alsunga Municipality',
      'cities' => 
      array (
        0 => 'Alsunga',
      ),
    ),
    '007' => 
    array (
      'name' => 'Alūksne Municipality',
      'cities' => 
      array (
        0 => 'Alūksne',
      ),
    ),
    '055' => 
    array (
      'name' => 'Līgatne Municipality',
      'cities' => 
      array (
        0 => 'Līgatne',
      ),
    ),
    '040' => 
    array (
      'name' => 'Jaunpils Municipality',
      'cities' => 
      array (
        0 => 'Jaunpils',
      ),
    ),
    '050' => 
    array (
      'name' => 'Kuldīga Municipality',
      'cities' => 
      array (
        0 => 'Kuldīga',
      ),
    ),
    'RIX' => 
    array (
      'name' => 'Riga',
      'cities' => 
      array (
        0 => 'Bolderaja',
        1 => 'Daugavgrīva',
        2 => 'Jaunciems',
        3 => 'Mežaparks',
        4 => 'Riga',
      ),
    ),
    '025' => 
    array (
      'name' => 'Daugavpils Municipality',
      'cities' => 
      array (
        0 => 'Daugavpils',
      ),
    ),
    '080' => 
    array (
      'name' => 'Ropaži Municipality',
      'cities' => 
      array (
        0 => 'Ropaži',
      ),
    ),
    '096' => 
    array (
      'name' => 'Strenči Municipality',
      'cities' => 
      array (
        0 => 'Seda',
        1 => 'Strenči',
      ),
    ),
    '045' => 
    array (
      'name' => 'Kocēni Municipality',
      'cities' => 
      array (
        0 => 'Kocēni',
      ),
    ),
    '003' => 
    array (
      'name' => 'Aizpute Municipality',
      'cities' => 
      array (
        0 => 'Aizpute',
      ),
    ),
    '014' => 
    array (
      'name' => 'Baltinava Municipality',
      'cities' => 
      array (
        0 => 'Baltinava',
      ),
    ),
    '004' => 
    array (
      'name' => 'Aknīste Municipality',
      'cities' => 
      array (
        0 => 'Aknīste',
      ),
    ),
    'JEL' => 
    array (
      'name' => 'Jelgava',
      'cities' => 
      array (
        0 => 'Jelgava',
      ),
    ),
    '058' => 
    array (
      'name' => 'Ludza Municipality',
      'cities' => 
      array (
        0 => 'Ludza',
      ),
    ),
    '078' => 
    array (
      'name' => 'Riebiņi Municipality',
      'cities' => 
      array (
        0 => 'Riebiņi',
      ),
    ),
    '081' => 
    array (
      'name' => 'Rucava Municipality',
      'cities' => 
      array (
        0 => 'Rucava',
      ),
    ),
    '024' => 
    array (
      'name' => 'Dagda Municipality',
      'cities' => 
      array (
        0 => 'Dagda',
      ),
    ),
    '015' => 
    array (
      'name' => 'Balvi Municipality',
      'cities' => 
      array (
        0 => 'Balvi',
      ),
    ),
    '075' => 
    array (
      'name' => 'Priekuļi Municipality',
      'cities' => 
      array (
        0 => 'Priekuļi',
      ),
    ),
    '070' => 
    array (
      'name' => 'Pārgauja Municipality',
      'cities' => 
      array (
        0 => 'Stalbe',
      ),
    ),
    'REZ' => 
    array (
      'name' => 'Rēzekne',
      'cities' => 
      array (
        0 => 'Rēzekne',
      ),
    ),
    '031' => 
    array (
      'name' => 'Garkalne Municipality',
      'cities' => 
      array (
        0 => 'Garkalne',
      ),
    ),
    '035' => 
    array (
      'name' => 'Ikšķile Municipality',
      'cities' => 
      array (
        0 => 'Ikšķile',
      ),
    ),
    '053' => 
    array (
      'name' => 'Lielvārde Municipality',
      'cities' => 
      array (
        0 => 'Lielvārde',
      ),
    ),
    '060' => 
    array (
      'name' => 'Mazsalaca Municipality',
      'cities' => 
      array (
        0 => 'Mazsalaca',
      ),
    ),
  ),
  'TL' => 
  array (
    'VI' => 
    array (
      'name' => 'Viqueque Municipality',
      'cities' => 
      array (
        0 => 'Lacluta',
        1 => 'Ossu',
        2 => 'Uatocarabau',
        3 => 'Uatolari',
        4 => 'Viqueque',
      ),
    ),
    'LI' => 
    array (
      'name' => 'Liquiçá Municipality',
      'cities' => 
      array (
        0 => 'Bazartete',
        1 => 'Likisá',
        2 => 'Maubara',
      ),
    ),
    'ER' => 
    array (
      'name' => 'Ermera District',
      'cities' => 
      array (
        0 => 'Ermera Villa',
        1 => 'Gleno',
        2 => 'Hatulia',
        3 => 'Letefoho',
        4 => 'Railaco',
      ),
    ),
    'MT' => 
    array (
      'name' => 'Manatuto District',
      'cities' => 
      array (
        0 => 'Barique',
        1 => 'Laclo',
        2 => 'Laclubar',
        3 => 'Manatuto',
        4 => 'Manatutu',
        5 => 'Soibada',
      ),
    ),
    'AN' => 
    array (
      'name' => 'Ainaro Municipality',
      'cities' => 
      array (
        0 => 'Ainaro',
        1 => 'Hato-Udo',
      ),
    ),
    'MF' => 
    array (
      'name' => 'Manufahi Municipality',
      'cities' => 
      array (
        0 => 'Alas',
        1 => 'Fatuberliu',
        2 => 'Same',
        3 => 'Turiscai',
      ),
    ),
    'AL' => 
    array (
      'name' => 'Aileu municipality',
      'cities' => 
      array (
        0 => 'Aileu',
        1 => 'Lequidoe',
        2 => 'Remexio',
      ),
    ),
    'BA' => 
    array (
      'name' => 'Baucau Municipality',
      'cities' => 
      array (
        0 => 'Baguia',
        1 => 'Baucau',
        2 => 'Baukau',
        3 => 'Laga',
        4 => 'Quelicai',
        5 => 'Vemasse',
        6 => 'Venilale',
      ),
    ),
    'CO' => 
    array (
      'name' => 'Cova Lima Municipality',
      'cities' => 
      array (
        0 => 'Fatumean',
        1 => 'Fohorem',
        2 => 'Maucatar',
        3 => 'Suai',
        4 => 'Tilomar',
      ),
    ),
    'LA' => 
    array (
      'name' => 'Lautém Municipality',
      'cities' => 
      array (
        0 => 'Iliomar',
        1 => 'Lautem',
        2 => 'Lospalos',
        3 => 'Luro',
        4 => 'Tutuala',
      ),
    ),
    'DI' => 
    array (
      'name' => 'Dili municipality',
      'cities' => 
      array (
        0 => 'Atauro Island',
        1 => 'Cristo Rei',
        2 => 'Dili',
        3 => 'Metinaro',
      ),
    ),
    'BO' => 
    array (
      'name' => 'Bobonaro Municipality',
      'cities' => 
      array (
        0 => 'Maliana',
      ),
    ),
  ),
  'PW' => 
  array (
    '004' => 
    array (
      'name' => 'Airai',
      'cities' => 
      array (
        0 => 'Ngetkib',
      ),
    ),
    '050' => 
    array (
      'name' => 'Hatohobei',
      'cities' => 
      array (
        0 => 'Tobi Village',
      ),
    ),
    '010' => 
    array (
      'name' => 'Angaur',
      'cities' => 
      array (
        0 => 'Angaur State',
      ),
    ),
    '002' => 
    array (
      'name' => 'Aimeliik',
      'cities' => 
      array (
        0 => 'Ngchemiangel',
      ),
    ),
  ),
  'SG' => 
  array (
    '01' => 
    array (
      'name' => 'Central Singapore Community Development Council',
      'cities' => 
      array (
        0 => 'Singapore',
      ),
    ),
    '03' => 
    array (
      'name' => 'North West Community Development Council',
      'cities' => 
      array (
        0 => 'Woodlands',
      ),
    ),
  ),
  'NR' => 
  array (
    '01' => 
    array (
      'name' => 'Aiwo District',
      'cities' => 
      array (
        0 => 'Arijejen',
      ),
    ),
    '02' => 
    array (
      'name' => 'Anabar District',
      'cities' => 
      array (
        0 => 'Anabar',
      ),
    ),
    '05' => 
    array (
      'name' => 'Baiti District',
      'cities' => 
      array (
        0 => 'Baiti',
      ),
    ),
  ),
  'UA' => 
  array (
    '05' => 
    array (
      'name' => 'Vinnytsia Oblast',
      'cities' => 
      array (
        0 => 'Bar',
        1 => 'Barskiy Rayon',
        2 => 'Bershad',
        3 => 'Brailiv',
        4 => 'Bratslav',
        5 => 'Chechelnyk',
        6 => 'Chernivets&#039;kyy Rayon',
        7 => 'Chernivtsi',
        8 => 'Dashiv',
        9 => 'Haisyn',
        10 => 'Illintsi',
        11 => 'Kalynivka',
        12 => 'Khmilnyk',
        13 => 'Klembivka',
        14 => 'Kopayhorod',
        15 => 'Kozyatyn',
        16 => 'Kryzhopil&#039;',
        17 => 'Ladyzhyn',
        18 => 'Lityn',
        19 => 'Lityns&#039;kyy Rayon',
        20 => 'Lypovets&#039;kyy Rayon',
        21 => 'Mohyliv-Podilskyi',
        22 => 'Murafa',
        23 => 'Murovani Kurylivtsi',
        24 => 'Nemyriv',
        25 => 'Nova Pryluka',
        26 => 'Obodivka',
        27 => 'Orativ',
        28 => 'Pavlivka',
        29 => 'Pohrebyshche',
        30 => 'Pohrebyshchens&#039;kyy Rayon',
        31 => 'Serebriya',
        32 => 'Sharhorod',
        33 => 'Sobolivka',
        34 => 'Sutysky',
        35 => 'Teplyk',
        36 => 'Tomashpil&#039;',
        37 => 'Torkanivka',
        38 => 'Tsybulevka',
        39 => 'Tulchyn',
        40 => 'Turbiv',
        41 => 'Tyvriv',
        42 => 'Ulaniv',
        43 => 'Vapnyarka',
        44 => 'Vendychany',
        45 => 'Vinnitskiy Rayon',
        46 => 'Vinnytsia',
        47 => 'Viytivka',
        48 => 'Voronovytsya',
        49 => 'Yampil&#039;',
        50 => 'Zhmerynka',
      ),
    ),
    '09' => 
    array (
      'name' => 'Luhansk Oblast',
      'cities' => 
      array (
        0 => 'Alchevs&#039;k',
        1 => 'Alchevs&#039;ka Mis&#039;krada',
        2 => 'Antratsyt',
        3 => 'Antratsytivs&#039;kyy Rayon',
        4 => 'Artemivs&#039;k',
        5 => 'Bayrachky',
        6 => 'Bile',
        7 => 'Bilohorivka',
        8 => 'Bilokurakyne',
        9 => 'Bilovods&#039;k',
        10 => 'Biryukove',
        11 => 'Bryanka',
        12 => 'Buran',
        13 => 'Chervonopartyzans&#039;k',
        14 => 'Chornukhyne',
        15 => 'Dovzhanskyy Rayon',
        16 => 'Hirs&#039;ke',
        17 => 'Kadiyivka',
        18 => 'Kirovs&#039;k',
        19 => 'Kirovs&#039;ka Mis&#039;krada',
        20 => 'Klenovyy',
        21 => 'Krasnyy Kut',
        22 => 'Krasnyy Luch',
        23 => 'Kreminna',
        24 => 'Kripens&#039;kyy',
        25 => 'Lenina',
        26 => 'Lozno-Oleksandrivka',
        27 => 'Luhansk',
        28 => 'Luhans&#039;ka Mis&#039;krada',
        29 => 'Lutuhyne',
        30 => 'Lutuhyns&#039;kyy Rayon',
        31 => 'Lysychans&#039;k',
        32 => 'Makariv Yar',
        33 => 'Markivka',
        34 => 'Millerovo',
        35 => 'Milove',
        36 => 'Miusyns&#039;k',
        37 => 'Molodohvardiys&#039;k',
        38 => 'Novopskov',
        39 => 'Nyzhnya Duvanka',
        40 => 'Pavlivka',
        41 => 'Pereval&#039;s&#039;k',
        42 => 'Pervomays&#039;k',
        43 => 'Popasna',
        44 => 'Pryvillya',
        45 => 'Roven&#039;ky',
        46 => 'Rozkishne',
        47 => 'Rubizhans&#039;ka Mis&#039;krada',
        48 => 'Rubizhne',
        49 => 'Shchastya',
        50 => 'Simeykyne',
        51 => 'Slov`yanoserbsk',
        52 => 'Sorokyne',
        53 => 'Sorokyns&#039;kyi Rayon',
        54 => 'Stanytsya Luhans&#039;ka',
        55 => 'Starobil&#039;s&#039;k',
        56 => 'Svatove',
        57 => 'Sverdlovs&#039;k',
        58 => 'Sverdlovs&#039;ka Mis&#039;krada',
        59 => 'Syevyerodonets&#039;k',
        60 => 'Teple',
        61 => 'Toshkivka',
        62 => 'Tr&#039;okhizbenka',
        63 => 'Uralo-Kavkaz',
        64 => 'Uspenka',
        65 => 'Zalesnoye',
        66 => 'Zoryns&#039;k',
        67 => 'Zymohiria',
      ),
    ),
    '07' => 
    array (
      'name' => 'Volyn Oblast',
      'cities' => 
      array (
        0 => 'Berestechko',
        1 => 'Blahodatne',
        2 => 'Horokhiv',
        3 => 'Hołoby',
        4 => 'Kamin-Kashyrskyi',
        5 => 'Kivertsi',
        6 => 'Kovel',
        7 => 'Kovel&#039;s&#039;ka Mis&#039;krada',
        8 => 'Liuboml',
        9 => 'Lokachi',
        10 => 'Lukiv',
        11 => 'Lutsk',
        12 => 'Lyubeshivs&#039;kyy Rayon',
        13 => 'Lyuboml&#039;s&#039;kyy Rayon',
        14 => 'Manevychi',
        15 => 'Manevyts&#039;kyy Rayon',
        16 => 'Novovolyns&#039;k',
        17 => 'Nuyno',
        18 => 'Olyka',
        19 => 'Pishcha',
        20 => 'Rakiv Lis',
        21 => 'Ratne',
        22 => 'Ratnivs&#039;kyy Rayon',
        23 => 'Rozhyshche',
        24 => 'Shats&#039;k',
        25 => 'Shats&#039;kyy Rayon',
        26 => 'Stara Vyzhivka',
        27 => 'Svityaz&#039;',
        28 => 'Volodymyr-Volynskyi',
      ),
    ),
  ),
  'BG' => 
  array (
    '07' => 
    array (
      'name' => 'Gabrovo Province',
      'cities' => 
      array (
        0 => 'Dryanovo',
        1 => 'Gabrovo',
        2 => 'Obshtina Dryanovo',
        3 => 'Obshtina Gabrovo',
        4 => 'Obshtina Sevlievo',
        5 => 'Obshtina Tryavna',
        6 => 'Sevlievo',
        7 => 'Tryavna',
      ),
    ),
    '05' => 
    array (
      'name' => 'Vidin Province',
      'cities' => 
      array (
        0 => 'Belogradchik',
        1 => 'Boynitsa',
        2 => 'Bregovo',
        3 => 'Chuprene',
        4 => 'Dimovo',
        5 => 'Drenovets',
        6 => 'Dunavtsi',
        7 => 'Gramada',
        8 => 'Kula',
        9 => 'Makresh',
        10 => 'Novo Selo',
        11 => 'Obshtina Belogradchik',
        12 => 'Obshtina Boynitsa',
        13 => 'Obshtina Dimovo',
        14 => 'Obshtina Gramada',
        15 => 'Obshtina Kula',
        16 => 'Obshtina Ruzhintsi',
        17 => 'Obshtina Vidin',
        18 => 'Ruzhintsi',
        19 => 'Vidin',
      ),
    ),
    '01' => 
    array (
      'name' => 'Blagoevgrad Province',
      'cities' => 
      array (
        0 => 'Bansko',
        1 => 'Belitsa',
        2 => 'Blagoevgrad',
        3 => 'Garmen',
        4 => 'Gotse Delchev',
        5 => 'Hadzhidimovo',
        6 => 'Kolarovo',
        7 => 'Kresna',
        8 => 'Obshtina Bansko',
        9 => 'Obshtina Belitsa',
        10 => 'Obshtina Blagoevgrad',
        11 => 'Obshtina Garmen',
        12 => 'Obshtina Gotse Delchev',
        13 => 'Obshtina Kresna',
        14 => 'Obshtina Petrich',
        15 => 'Obshtina Razlog',
        16 => 'Obshtina Sandanski',
        17 => 'Obshtina Satovcha',
        18 => 'Obshtina Simitli',
        19 => 'Obshtina Strumyani',
        20 => 'Obshtina Yakoruda',
        21 => 'Petrich',
        22 => 'Razlog',
        23 => 'Sandanski',
        24 => 'Satovcha',
        25 => 'Simitli',
        26 => 'Stara Kresna',
        27 => 'Strumyani',
        28 => 'Yakoruda',
      ),
    ),
    '09' => 
    array (
      'name' => 'Kardzhali Province',
      'cities' => 
      array (
        0 => 'Ardino',
        1 => 'Dzhebel',
        2 => 'Kardzhali',
        3 => 'Kirkovo',
        4 => 'Krumovgrad',
        5 => 'Obshtina Ardino',
        6 => 'Obshtina Chernoochene',
        7 => 'Obshtina Dzhebel',
        8 => 'Obshtina Kardzhali',
        9 => 'Obshtina Kirkovo',
        10 => 'Obshtina Momchilgrad',
      ),
    ),
    '04' => 
    array (
      'name' => 'Veliko Tarnovo Province',
      'cities' => 
      array (
        0 => 'Byala Cherkva',
        1 => 'Debelets',
        2 => 'Elena',
        3 => 'Gorna Oryahovitsa',
        4 => 'Kilifarevo',
        5 => 'Lyaskovets',
        6 => 'Obshtina Elena',
        7 => 'Obshtina Gorna Oryahovitsa',
        8 => 'Obshtina Lyaskovets',
        9 => 'Obshtina Pavlikeni',
        10 => 'Obshtina Polski Trambesh',
        11 => 'Obshtina Strazhitsa',
        12 => 'Obshtina Suhindol',
        13 => 'Obshtina Svishtov',
        14 => 'Obshtina Veliko Tŭrnovo',
        15 => 'Obshtina Zlataritsa',
        16 => 'Parvomaytsi',
        17 => 'Pavlikeni',
        18 => 'Polski Trambesh',
        19 => 'Strazhitsa',
        20 => 'Suhindol',
        21 => 'Svishtov',
        22 => 'Veliko Tŭrnovo',
        23 => 'Zlataritsa',
      ),
    ),
    '06' => 
    array (
      'name' => 'Vratsa Province',
      'cities' => 
      array (
        0 => 'Borovan',
        1 => 'Byala Slatina',
        2 => 'Hayredin',
        3 => 'Kozloduy',
        4 => 'Krivodol',
        5 => 'Mezdra',
        6 => 'Mizia',
        7 => 'Obshtina Borovan',
        8 => 'Obshtina Hayredin',
        9 => 'Obshtina Kozloduy',
        10 => 'Obshtina Krivodol',
        11 => 'Obshtina Mezdra',
        12 => 'Obshtina Mizia',
        13 => 'Obshtina Oryahovo',
        14 => 'Obshtina Roman',
        15 => 'Obshtina Vratsa',
        16 => 'Oryahovo',
        17 => 'Roman',
        18 => 'Vratsa',
      ),
    ),
    '02' => 
    array (
      'name' => 'Burgas Province',
      'cities' => 
      array (
        0 => 'Aheloy',
        1 => 'Ahtopol',
        2 => 'Aytos',
        3 => 'Bata',
        4 => 'Burgas',
        5 => 'Chernomorets',
        6 => 'Kameno',
        7 => 'Karnobat',
        8 => 'Kiten',
        9 => 'Malko Tarnovo',
        10 => 'Nesebar',
        11 => 'Obshtina Aytos',
        12 => 'Obshtina Burgas',
        13 => 'Obshtina Kameno',
        14 => 'Obshtina Karnobat',
        15 => 'Obshtina Malko Tarnovo',
        16 => 'Obshtina Nesebar',
        17 => 'Obshtina Pomorie',
        18 => 'Obshtina Primorsko',
        19 => 'Obshtina Sozopol',
        20 => 'Obshtina Sungurlare',
        21 => 'Obzor',
        22 => 'Pomorie',
        23 => 'Primorsko',
        24 => 'Ravda',
        25 => 'Ruen',
        26 => 'Sarafovo',
        27 => 'Sozopol',
        28 => 'Sredets',
        29 => 'Sungurlare',
        30 => 'Sveti Vlas',
        31 => 'Tsarevo',
      ),
    ),
    '03' => 
    array (
      'name' => 'Varna Province',
      'cities' => 
      array (
        0 => 'Aksakovo',
        1 => 'Asparuhovo',
        2 => 'Balgarevo',
        3 => 'Beloslav',
        4 => 'Byala',
        5 => 'Dalgopol',
        6 => 'Devnya',
        7 => 'Dolni Chiflik',
        8 => 'Kiten',
        9 => 'Obshtina Aksakovo',
        10 => 'Obshtina Avren',
        11 => 'Obshtina Beloslav',
        12 => 'Obshtina Byala',
        13 => 'Obshtina Dalgopol',
        14 => 'Obshtina Devnya',
        15 => 'Obshtina Dolni Chiflik',
        16 => 'Obshtina Provadia',
        17 => 'Obshtina Suvorovo',
        18 => 'Obshtina Valchidol',
        19 => 'Obshtina Varna',
        20 => 'Obshtina Vetrino',
        21 => 'Provadia',
        22 => 'Suvorovo',
        23 => 'Valchidol',
        24 => 'Varna',
        25 => 'Vetrino',
        26 => 'Zlatni Pyasatsi',
      ),
    ),
    '08' => 
    array (
      'name' => 'Dobrich Province',
      'cities' => 
      array (
        0 => 'Balchik',
        1 => 'Dobrich',
        2 => 'General Toshevo',
        3 => 'Kavarna',
        4 => 'Krushari',
        5 => 'Obshtina Balchik',
        6 => 'Obshtina Dobrich',
        7 => 'Obshtina Dobrich-Selska',
        8 => 'Obshtina General Toshevo',
        9 => 'Obshtina Kavarna',
        10 => 'Obshtina Krushari',
        11 => 'Obshtina Shabla',
        12 => 'Obshtina Tervel',
        13 => 'Shabla',
        14 => 'Tervel',
      ),
    ),
  ),
);