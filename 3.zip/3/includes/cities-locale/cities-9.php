<?php
/**
 * An array of translated states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'LS' => 
  array (
    'E' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mafeteng District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mafeteng', 'describr' ),
      ),
    ),
    'F' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mohale&#039;s Hoek District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mohale&#039;s Hoek', 'describr' ),
      ),
    ),
    'J' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mokhotlong District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mokhotlong', 'describr' ),
      ),
    ),
    'H' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qacha&#039;s Nek District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Qacha&#039;s Nek', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Leribe District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Leribe', 'describr' ),
        1 => /*translators: City.*/ __( 'Maputsoe', 'describr' ),
      ),
    ),
    'G' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Quthing District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Quthing', 'describr' ),
      ),
    ),
    'A' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maseru District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Maseru', 'describr' ),
        1 => /*translators: City.*/ __( 'Nako', 'describr' ),
      ),
    ),
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Butha-Buthe District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Butha-Buthe', 'describr' ),
      ),
    ),
    'D' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Berea District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Teyateyaneng', 'describr' ),
      ),
    ),
    'K' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Thaba-Tseka District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Thaba-Tseka', 'describr' ),
      ),
    ),
  ),
  'LR' => 
  array (
    'MO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Montserrado County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bensonville', 'describr' ),
        1 => /*translators: City.*/ __( 'Monrovia', 'describr' ),
      ),
    ),
    'RI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'River Cess County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cestos City', 'describr' ),
      ),
    ),
    'BG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bong County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gbarnga', 'describr' ),
      ),
    ),
    'SI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sinoe County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Greenville', 'describr' ),
      ),
    ),
    'CM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand Cape Mount County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Robertsport', 'describr' ),
      ),
    ),
    'LO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lofa County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Voinjama', 'describr' ),
      ),
    ),
    'RG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'River Gee County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fish Town', 'describr' ),
      ),
    ),
    'GG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand Gedeh County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Zwedru', 'describr' ),
      ),
    ),
    'GB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand Bassa County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Buchanan', 'describr' ),
      ),
    ),
    'BM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bomi County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tubmanburg', 'describr' ),
      ),
    ),
    'MY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maryland County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Harper', 'describr' ),
      ),
    ),
    'MG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Margibi County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kakata', 'describr' ),
      ),
    ),
    'GP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gbarpolu County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bopolu', 'describr' ),
      ),
    ),
    'GK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand Kru County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barclayville', 'describr' ),
      ),
    ),
    'NI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nimba', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ganta', 'describr' ),
        1 => /*translators: City.*/ __( 'New Yekepa', 'describr' ),
        2 => /*translators: City.*/ __( 'Sanniquellie', 'describr' ),
      ),
    ),
  ),
  'OM' => 
  array (
    'ZA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ad Dhahirah Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Yanqul', 'describr' ),
        1 => /*translators: City.*/ __( '&#039;Ibrī', 'describr' ),
      ),
    ),
    'BS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Batinah North Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Khābūrah', 'describr' ),
        1 => /*translators: City.*/ __( 'As Suwayq', 'describr' ),
        2 => /*translators: City.*/ __( 'Liwá', 'describr' ),
        3 => /*translators: City.*/ __( 'Shināş', 'describr' ),
        4 => /*translators: City.*/ __( 'Sohar', 'describr' ),
        5 => /*translators: City.*/ __( 'Şaḩam', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Batinah Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barkā&#039;', 'describr' ),
        1 => /*translators: City.*/ __( 'Bayt al &#039;Awābī', 'describr' ),
        2 => /*translators: City.*/ __( 'Oman Smart Future City', 'describr' ),
        3 => /*translators: City.*/ __( 'Rustaq', 'describr' ),
      ),
    ),
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ash Sharqiyah Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sur', 'describr' ),
      ),
    ),
    'MU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Musandam Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dib Dibba', 'describr' ),
        1 => /*translators: City.*/ __( 'Khasab', 'describr' ),
        2 => /*translators: City.*/ __( 'Madḩā&#039; al Jadīdah', 'describr' ),
      ),
    ),
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Muscat Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bawshar', 'describr' ),
        1 => /*translators: City.*/ __( 'Muscat', 'describr' ),
        2 => /*translators: City.*/ __( 'Seeb', 'describr' ),
      ),
    ),
    'WU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Wusta Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Haymā&#039;', 'describr' ),
      ),
    ),
    'ZU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dhofar Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Şalālah', 'describr' ),
      ),
    ),
    'DA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ad Dakhiliyah Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adam', 'describr' ),
        1 => /*translators: City.*/ __( 'Bahlā&#039;', 'describr' ),
        2 => /*translators: City.*/ __( 'Bidbid', 'describr' ),
        3 => /*translators: City.*/ __( 'Izkī', 'describr' ),
        4 => /*translators: City.*/ __( 'Nizwá', 'describr' ),
        5 => /*translators: City.*/ __( 'Sufālat Samā&#039;il', 'describr' ),
      ),
    ),
    'BU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Buraimi Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Buraymī', 'describr' ),
      ),
    ),
  ),
  'BW' => 
  array (
    'GH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ghanzi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dekar', 'describr' ),
        1 => /*translators: City.*/ __( 'Ghanzi', 'describr' ),
      ),
    ),
    'KL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kgatleng District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bokaa', 'describr' ),
        1 => /*translators: City.*/ __( 'Mmathubudukwane', 'describr' ),
        2 => /*translators: City.*/ __( 'Mochudi', 'describr' ),
        3 => /*translators: City.*/ __( 'Pilane', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kanye', 'describr' ),
        1 => /*translators: City.*/ __( 'Khakhea', 'describr' ),
        2 => /*translators: City.*/ __( 'Mosopa', 'describr' ),
        3 => /*translators: City.*/ __( 'Sekoma', 'describr' ),
      ),
    ),
    'SE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'South-East District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gaborone', 'describr' ),
        1 => /*translators: City.*/ __( 'Janeng', 'describr' ),
        2 => /*translators: City.*/ __( 'Kopong', 'describr' ),
        3 => /*translators: City.*/ __( 'Otse', 'describr' ),
        4 => /*translators: City.*/ __( 'Ramotswa', 'describr' ),
      ),
    ),
    'NW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North-West District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Maun', 'describr' ),
        1 => /*translators: City.*/ __( 'Nokaneng', 'describr' ),
        2 => /*translators: City.*/ __( 'Pandamatenga', 'describr' ),
        3 => /*translators: City.*/ __( 'Sehithwa', 'describr' ),
        4 => /*translators: City.*/ __( 'Shakawe', 'describr' ),
      ),
    ),
    'KG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kgalagadi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hukuntsi', 'describr' ),
        1 => /*translators: City.*/ __( 'Kang', 'describr' ),
        2 => /*translators: City.*/ __( 'Lehututu', 'describr' ),
        3 => /*translators: City.*/ __( 'Manyana', 'describr' ),
        4 => /*translators: City.*/ __( 'Tshabong', 'describr' ),
        5 => /*translators: City.*/ __( 'Werda', 'describr' ),
      ),
    ),
    'CE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gobojango', 'describr' ),
        1 => /*translators: City.*/ __( 'Gweta', 'describr' ),
        2 => /*translators: City.*/ __( 'Kalamare', 'describr' ),
        3 => /*translators: City.*/ __( 'Letlhakane', 'describr' ),
        4 => /*translators: City.*/ __( 'Letsheng', 'describr' ),
        5 => /*translators: City.*/ __( 'Maapi', 'describr' ),
        6 => /*translators: City.*/ __( 'Machaneng', 'describr' ),
        7 => /*translators: City.*/ __( 'Mahalapye', 'describr' ),
        8 => /*translators: City.*/ __( 'Makobeng', 'describr' ),
        9 => /*translators: City.*/ __( 'Makwata', 'describr' ),
        10 => /*translators: City.*/ __( 'Mathakola', 'describr' ),
        11 => /*translators: City.*/ __( 'Mathambgwane', 'describr' ),
        12 => /*translators: City.*/ __( 'Mathathane', 'describr' ),
        13 => /*translators: City.*/ __( 'Maunatlala', 'describr' ),
        14 => /*translators: City.*/ __( 'Mogapi', 'describr' ),
        15 => /*translators: City.*/ __( 'Moijabana', 'describr' ),
        16 => /*translators: City.*/ __( 'Mookane', 'describr' ),
        17 => /*translators: City.*/ __( 'Mopipi', 'describr' ),
        18 => /*translators: City.*/ __( 'Mosetse', 'describr' ),
        19 => /*translators: City.*/ __( 'Nata', 'describr' ),
        20 => /*translators: City.*/ __( 'Orapa', 'describr' ),
        21 => /*translators: City.*/ __( 'Palapye', 'describr' ),
        22 => /*translators: City.*/ __( 'Pilikwe', 'describr' ),
        23 => /*translators: City.*/ __( 'Rakops', 'describr' ),
        24 => /*translators: City.*/ __( 'Ramokgonami', 'describr' ),
        25 => /*translators: City.*/ __( 'Ratholo', 'describr' ),
        26 => /*translators: City.*/ __( 'Sefophe', 'describr' ),
        27 => /*translators: City.*/ __( 'Serowe', 'describr' ),
        28 => /*translators: City.*/ __( 'Sua', 'describr' ),
        29 => /*translators: City.*/ __( 'Tamasane', 'describr' ),
        30 => /*translators: City.*/ __( 'Tobane', 'describr' ),
        31 => /*translators: City.*/ __( 'Tonota', 'describr' ),
      ),
    ),
    'NE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North-East District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dukwe', 'describr' ),
        1 => /*translators: City.*/ __( 'Makaleng', 'describr' ),
        2 => /*translators: City.*/ __( 'Masunga', 'describr' ),
        3 => /*translators: City.*/ __( 'Sebina', 'describr' ),
      ),
    ),
    'KW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kweneng District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Botlhapatlou', 'describr' ),
        1 => /*translators: City.*/ __( 'Dutlwe', 'describr' ),
        2 => /*translators: City.*/ __( 'Gabane', 'describr' ),
        3 => /*translators: City.*/ __( 'Gaphatshwe', 'describr' ),
        4 => /*translators: City.*/ __( 'Khudumelapye', 'describr' ),
        5 => /*translators: City.*/ __( 'Lenchwe Le Tau', 'describr' ),
        6 => /*translators: City.*/ __( 'Letlhakeng', 'describr' ),
        7 => /*translators: City.*/ __( 'Metsemotlhaba', 'describr' ),
        8 => /*translators: City.*/ __( 'Mmopone', 'describr' ),
        9 => /*translators: City.*/ __( 'Mogoditshane', 'describr' ),
        10 => /*translators: City.*/ __( 'Molepolole', 'describr' ),
        11 => /*translators: City.*/ __( 'Nkoyaphiri', 'describr' ),
        12 => /*translators: City.*/ __( 'Thamaga', 'describr' ),
      ),
    ),
  ),
  'BJ' => 
  array (
    'CO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Collines Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Comé', 'describr' ),
        1 => /*translators: City.*/ __( 'Dassa-Zoumé', 'describr' ),
        2 => /*translators: City.*/ __( 'Savalou', 'describr' ),
        3 => /*translators: City.*/ __( 'Savé', 'describr' ),
      ),
    ),
    'KO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kouffo Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Djakotomey', 'describr' ),
        1 => /*translators: City.*/ __( 'Dogbo', 'describr' ),
      ),
    ),
    'DO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Donga Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bassila', 'describr' ),
        1 => /*translators: City.*/ __( 'Commune of Djougou', 'describr' ),
        2 => /*translators: City.*/ __( 'Djougou', 'describr' ),
      ),
    ),
    'ZO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zou Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abomey', 'describr' ),
        1 => /*translators: City.*/ __( 'Bohicon', 'describr' ),
        2 => /*translators: City.*/ __( 'Commune of Agbangnizoun', 'describr' ),
        3 => /*translators: City.*/ __( 'Cové', 'describr' ),
      ),
    ),
    'PL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Plateau Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kétou', 'describr' ),
        1 => /*translators: City.*/ __( 'Pobé', 'describr' ),
        2 => /*translators: City.*/ __( 'Sakété', 'describr' ),
      ),
    ),
    'MO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mono Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Commune of Athieme', 'describr' ),
        1 => /*translators: City.*/ __( 'Lokossa', 'describr' ),
      ),
    ),
    'AK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Atakora Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Guilmaro', 'describr' ),
        1 => /*translators: City.*/ __( 'Natitingou', 'describr' ),
        2 => /*translators: City.*/ __( 'Tanguieta', 'describr' ),
        3 => /*translators: City.*/ __( 'Tanguiéta', 'describr' ),
      ),
    ),
    'AL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Alibori Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banikoara', 'describr' ),
        1 => /*translators: City.*/ __( 'Kandi', 'describr' ),
        2 => /*translators: City.*/ __( 'Malanville', 'describr' ),
      ),
    ),
    'BO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Borgou Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bembèrèkè', 'describr' ),
        1 => /*translators: City.*/ __( 'Bétérou', 'describr' ),
        2 => /*translators: City.*/ __( 'Nikki', 'describr' ),
        3 => /*translators: City.*/ __( 'Parakou', 'describr' ),
        4 => /*translators: City.*/ __( 'Tchaourou', 'describr' ),
      ),
    ),
    'AQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Atlantique Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abomey-Calavi', 'describr' ),
        1 => /*translators: City.*/ __( 'Allada', 'describr' ),
        2 => /*translators: City.*/ __( 'Hinvi', 'describr' ),
        3 => /*translators: City.*/ __( 'Hévié', 'describr' ),
        4 => /*translators: City.*/ __( 'Ouidah', 'describr' ),
      ),
    ),
    'OU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ouémé Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Porto-Novo', 'describr' ),
      ),
    ),
    'LI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Littoral Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cotonou', 'describr' ),
      ),
    ),
  ),
  'MW' => 
  array (
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chipoka', 'describr' ),
        1 => /*translators: City.*/ __( 'Dedza', 'describr' ),
        2 => /*translators: City.*/ __( 'Dedza District', 'describr' ),
        3 => /*translators: City.*/ __( 'Dowa', 'describr' ),
        4 => /*translators: City.*/ __( 'Dowa District', 'describr' ),
        5 => /*translators: City.*/ __( 'Kasungu', 'describr' ),
        6 => /*translators: City.*/ __( 'Kasungu District', 'describr' ),
        7 => /*translators: City.*/ __( 'Lilongwe', 'describr' ),
        8 => /*translators: City.*/ __( 'Lilongwe District', 'describr' ),
        9 => /*translators: City.*/ __( 'Mchinji', 'describr' ),
        10 => /*translators: City.*/ __( 'Mchinji District', 'describr' ),
        11 => /*translators: City.*/ __( 'Mponela', 'describr' ),
        12 => /*translators: City.*/ __( 'Nkhotakota', 'describr' ),
        13 => /*translators: City.*/ __( 'Nkhotakota District', 'describr' ),
        14 => /*translators: City.*/ __( 'Ntcheu', 'describr' ),
        15 => /*translators: City.*/ __( 'Ntcheu District', 'describr' ),
        16 => /*translators: City.*/ __( 'Ntchisi', 'describr' ),
        17 => /*translators: City.*/ __( 'Ntchisi District', 'describr' ),
        18 => /*translators: City.*/ __( 'Salima', 'describr' ),
        19 => /*translators: City.*/ __( 'Salima District', 'describr' ),
      ),
    ),
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chitipa', 'describr' ),
        1 => /*translators: City.*/ __( 'Chitipa District', 'describr' ),
        2 => /*translators: City.*/ __( 'Karonga', 'describr' ),
        3 => /*translators: City.*/ __( 'Karonga District', 'describr' ),
        4 => /*translators: City.*/ __( 'Likoma District', 'describr' ),
        5 => /*translators: City.*/ __( 'Livingstonia', 'describr' ),
        6 => /*translators: City.*/ __( 'Mzimba', 'describr' ),
        7 => /*translators: City.*/ __( 'Mzimba District', 'describr' ),
        8 => /*translators: City.*/ __( 'Mzuzu', 'describr' ),
        9 => /*translators: City.*/ __( 'Nkhata Bay', 'describr' ),
        10 => /*translators: City.*/ __( 'Nkhata Bay District', 'describr' ),
        11 => /*translators: City.*/ __( 'Rumphi', 'describr' ),
        12 => /*translators: City.*/ __( 'Rumphi District', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balaka', 'describr' ),
        1 => /*translators: City.*/ __( 'Balaka District', 'describr' ),
        2 => /*translators: City.*/ __( 'Blantyre', 'describr' ),
        3 => /*translators: City.*/ __( 'Blantyre District', 'describr' ),
        4 => /*translators: City.*/ __( 'Chikwawa', 'describr' ),
        5 => /*translators: City.*/ __( 'Chikwawa District', 'describr' ),
        6 => /*translators: City.*/ __( 'Chiradzulu', 'describr' ),
        7 => /*translators: City.*/ __( 'Chiradzulu District', 'describr' ),
        8 => /*translators: City.*/ __( 'Liwonde', 'describr' ),
        9 => /*translators: City.*/ __( 'Luchenza', 'describr' ),
        10 => /*translators: City.*/ __( 'Machinga', 'describr' ),
        11 => /*translators: City.*/ __( 'Machinga District', 'describr' ),
        12 => /*translators: City.*/ __( 'Mangochi', 'describr' ),
        13 => /*translators: City.*/ __( 'Mangochi District', 'describr' ),
        14 => /*translators: City.*/ __( 'Monkey Bay', 'describr' ),
        15 => /*translators: City.*/ __( 'Mulanje', 'describr' ),
        16 => /*translators: City.*/ __( 'Mulanje District', 'describr' ),
        17 => /*translators: City.*/ __( 'Mwanza', 'describr' ),
        18 => /*translators: City.*/ __( 'Mwanza District', 'describr' ),
        19 => /*translators: City.*/ __( 'Neno District', 'describr' ),
        20 => /*translators: City.*/ __( 'Nsanje', 'describr' ),
        21 => /*translators: City.*/ __( 'Nsanje District', 'describr' ),
        22 => /*translators: City.*/ __( 'Phalombe', 'describr' ),
        23 => /*translators: City.*/ __( 'Phalombe District', 'describr' ),
        24 => /*translators: City.*/ __( 'Thyolo', 'describr' ),
        25 => /*translators: City.*/ __( 'Thyolo District', 'describr' ),
        26 => /*translators: City.*/ __( 'Zomba', 'describr' ),
        27 => /*translators: City.*/ __( 'Zomba District', 'describr' ),
      ),
    ),
  ),
  'BF' => 
  array (
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre-Ouest Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Goulouré', 'describr' ),
        1 => /*translators: City.*/ __( 'Kokologo', 'describr' ),
        2 => /*translators: City.*/ __( 'Koudougou', 'describr' ),
        3 => /*translators: City.*/ __( 'Léo', 'describr' ),
        4 => /*translators: City.*/ __( 'Pitmoaga', 'describr' ),
        5 => /*translators: City.*/ __( 'Province de la Sissili', 'describr' ),
        6 => /*translators: City.*/ __( 'Province du Boulkiemdé', 'describr' ),
        7 => /*translators: City.*/ __( 'Province du Sanguié', 'describr' ),
        8 => /*translators: City.*/ __( 'Province du Ziro', 'describr' ),
        9 => /*translators: City.*/ __( 'Réo', 'describr' ),
        10 => /*translators: City.*/ __( 'Sapouy', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre-Nord Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Boulsa', 'describr' ),
        1 => /*translators: City.*/ __( 'Kaya', 'describr' ),
        2 => /*translators: City.*/ __( 'Kongoussi', 'describr' ),
        3 => /*translators: City.*/ __( 'Province du Bam', 'describr' ),
        4 => /*translators: City.*/ __( 'Province du Namentenga', 'describr' ),
        5 => /*translators: City.*/ __( 'Province du Sanmatenga', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kadiogo Province', 'describr' ),
        1 => /*translators: City.*/ __( 'Ouagadougou', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Boucle du Mouhoun Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barani', 'describr' ),
        1 => /*translators: City.*/ __( 'Boromo', 'describr' ),
        2 => /*translators: City.*/ __( 'Dédougou', 'describr' ),
        3 => /*translators: City.*/ __( 'Nouna', 'describr' ),
        4 => /*translators: City.*/ __( 'Province de la Kossi', 'describr' ),
        5 => /*translators: City.*/ __( 'Province des Balé', 'describr' ),
        6 => /*translators: City.*/ __( 'Province des Banwa', 'describr' ),
        7 => /*translators: City.*/ __( 'Province du Mouhoun', 'describr' ),
        8 => /*translators: City.*/ __( 'Province du Nayala', 'describr' ),
        9 => /*translators: City.*/ __( 'Province du Sourou', 'describr' ),
        10 => /*translators: City.*/ __( 'Salanso', 'describr' ),
        11 => /*translators: City.*/ __( 'Toma', 'describr' ),
        12 => /*translators: City.*/ __( 'Tougan', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre-Sud Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bazega Province', 'describr' ),
        1 => /*translators: City.*/ __( 'Kombissiri', 'describr' ),
        2 => /*translators: City.*/ __( 'Manga', 'describr' ),
        3 => /*translators: City.*/ __( 'Nahouri Province', 'describr' ),
        4 => /*translators: City.*/ __( 'Pô', 'describr' ),
        5 => /*translators: City.*/ __( 'Zoundweogo Province', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cascades Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banfora', 'describr' ),
        1 => /*translators: City.*/ __( 'Province de la Comoé', 'describr' ),
        2 => /*translators: City.*/ __( 'Province de la Léraba', 'describr' ),
        3 => /*translators: City.*/ __( 'Sindou', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Est Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bogandé', 'describr' ),
        1 => /*translators: City.*/ __( 'Diapaga', 'describr' ),
        2 => /*translators: City.*/ __( 'Fada N&#039;gourma', 'describr' ),
        3 => /*translators: City.*/ __( 'Gayéri', 'describr' ),
        4 => /*translators: City.*/ __( 'Gnagna Province', 'describr' ),
        5 => /*translators: City.*/ __( 'Pama', 'describr' ),
        6 => /*translators: City.*/ __( 'Province de la Komandjoari', 'describr' ),
        7 => /*translators: City.*/ __( 'Province de la Kompienga', 'describr' ),
        8 => /*translators: City.*/ __( 'Province de la Tapoa', 'describr' ),
        9 => /*translators: City.*/ __( 'Province du Gourma', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre-Est Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Garango', 'describr' ),
        1 => /*translators: City.*/ __( 'Koupéla', 'describr' ),
        2 => /*translators: City.*/ __( 'Kouritenga Province', 'describr' ),
        3 => /*translators: City.*/ __( 'Ouargaye', 'describr' ),
        4 => /*translators: City.*/ __( 'Province du Boulgou', 'describr' ),
        5 => /*translators: City.*/ __( 'Province du Koulpélogo', 'describr' ),
        6 => /*translators: City.*/ __( 'Tenkodogo', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hauts-Bassins Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bobo-Dioulasso', 'describr' ),
        1 => /*translators: City.*/ __( 'Houndé', 'describr' ),
        2 => /*translators: City.*/ __( 'Province du Houet', 'describr' ),
        3 => /*translators: City.*/ __( 'Province du Kénédougou', 'describr' ),
        4 => /*translators: City.*/ __( 'Province du Tuy', 'describr' ),
      ),
    ),
  ),
  'PK' => 
  array (
    'IS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Islamabad Capital Territory', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Islamabad', 'describr' ),
      ),
    ),
    'GB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gilgit-Baltistan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barishal', 'describr' ),
        1 => /*translators: City.*/ __( 'Gilgit', 'describr' ),
        2 => /*translators: City.*/ __( 'Skardu', 'describr' ),
      ),
    ),
    'KP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khyber Pakhtunkhwa', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abbottabad', 'describr' ),
        1 => /*translators: City.*/ __( 'Akora', 'describr' ),
        2 => /*translators: City.*/ __( 'Aman Garh', 'describr' ),
        3 => /*translators: City.*/ __( 'Amirabad', 'describr' ),
        4 => /*translators: City.*/ __( 'Ashanagro Koto', 'describr' ),
        5 => /*translators: City.*/ __( 'Baffa', 'describr' ),
        6 => /*translators: City.*/ __( 'Bannu', 'describr' ),
        7 => /*translators: City.*/ __( 'Bat Khela', 'describr' ),
        8 => /*translators: City.*/ __( 'Battagram', 'describr' ),
        9 => /*translators: City.*/ __( 'Battagram District', 'describr' ),
        10 => /*translators: City.*/ __( 'Buner District', 'describr' ),
        11 => /*translators: City.*/ __( 'Charsadda', 'describr' ),
        12 => /*translators: City.*/ __( 'Cherat Cantonement', 'describr' ),
        13 => /*translators: City.*/ __( 'Chitral', 'describr' ),
        14 => /*translators: City.*/ __( 'Dera Ismail Khan', 'describr' ),
        15 => /*translators: City.*/ __( 'Dera Ismāīl Khān District', 'describr' ),
        16 => /*translators: City.*/ __( 'Doaba', 'describr' ),
        17 => /*translators: City.*/ __( 'Hangu', 'describr' ),
        18 => /*translators: City.*/ __( 'Haripur', 'describr' ),
        19 => /*translators: City.*/ __( 'Havelian', 'describr' ),
        20 => /*translators: City.*/ __( 'Kakad Wari Dir Upper', 'describr' ),
        21 => /*translators: City.*/ __( 'Karak', 'describr' ),
        22 => /*translators: City.*/ __( 'Khalabat', 'describr' ),
        23 => /*translators: City.*/ __( 'Kohat', 'describr' ),
        24 => /*translators: City.*/ __( 'Kulachi', 'describr' ),
        25 => /*translators: City.*/ __( 'Lachi', 'describr' ),
        26 => /*translators: City.*/ __( 'Lakki', 'describr' ),
        27 => /*translators: City.*/ __( 'Mansehra', 'describr' ),
        28 => /*translators: City.*/ __( 'Mardan', 'describr' ),
        29 => /*translators: City.*/ __( 'Mingora', 'describr' ),
        30 => /*translators: City.*/ __( 'Noorabad', 'describr' ),
        31 => /*translators: City.*/ __( 'Nowshera', 'describr' ),
        32 => /*translators: City.*/ __( 'Nowshera Cantonment', 'describr' ),
        33 => /*translators: City.*/ __( 'Pabbi', 'describr' ),
        34 => /*translators: City.*/ __( 'Paharpur', 'describr' ),
        35 => /*translators: City.*/ __( 'Peshawar', 'describr' ),
        36 => /*translators: City.*/ __( 'Risalpur Cantonment', 'describr' ),
        37 => /*translators: City.*/ __( 'Sarai Naurang', 'describr' ),
        38 => /*translators: City.*/ __( 'Shabqadar', 'describr' ),
        39 => /*translators: City.*/ __( 'Shingli Bala', 'describr' ),
        40 => /*translators: City.*/ __( 'Shorkot', 'describr' ),
        41 => /*translators: City.*/ __( 'Swabi', 'describr' ),
        42 => /*translators: City.*/ __( 'Tangi', 'describr' ),
        43 => /*translators: City.*/ __( 'Tank', 'describr' ),
        44 => /*translators: City.*/ __( 'Thal', 'describr' ),
        45 => /*translators: City.*/ __( 'Topi', 'describr' ),
        46 => /*translators: City.*/ __( 'Upper Dir', 'describr' ),
        47 => /*translators: City.*/ __( 'Utmanzai', 'describr' ),
        48 => /*translators: City.*/ __( 'Zaida', 'describr' ),
      ),
    ),
    'JK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Azad Kashmir', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bhimbar', 'describr' ),
        1 => /*translators: City.*/ __( 'Kotli', 'describr' ),
        2 => /*translators: City.*/ __( 'Kotli District', 'describr' ),
        3 => /*translators: City.*/ __( 'Mirpur District', 'describr' ),
        4 => /*translators: City.*/ __( 'Muzaffarābād', 'describr' ),
        5 => /*translators: City.*/ __( 'New Mirpur', 'describr' ),
        6 => /*translators: City.*/ __( 'Rawala Kot', 'describr' ),
      ),
    ),
    'TA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Federally Administered Tribal Areas', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alizai', 'describr' ),
        1 => /*translators: City.*/ __( 'Gulishah Kach', 'describr' ),
        2 => /*translators: City.*/ __( 'Landi Kotal', 'describr' ),
        3 => /*translators: City.*/ __( 'Miran Shah', 'describr' ),
        4 => /*translators: City.*/ __( 'North Wazīristān Agency', 'describr' ),
        5 => /*translators: City.*/ __( 'Shinpokh', 'describr' ),
        6 => /*translators: City.*/ __( 'South Wazīristān Agency', 'describr' ),
        7 => /*translators: City.*/ __( 'Wana', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balochistan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alik Ghund', 'describr' ),
        1 => /*translators: City.*/ __( 'Awārān District', 'describr' ),
        2 => /*translators: City.*/ __( 'Barkhan', 'describr' ),
        3 => /*translators: City.*/ __( 'Bela', 'describr' ),
        4 => /*translators: City.*/ __( 'Bhag', 'describr' ),
        5 => /*translators: City.*/ __( 'Bārkhān District', 'describr' ),
        6 => /*translators: City.*/ __( 'Chaman', 'describr' ),
        7 => /*translators: City.*/ __( 'Chowki Jamali', 'describr' ),
        8 => /*translators: City.*/ __( 'Chāgai District', 'describr' ),
        9 => /*translators: City.*/ __( 'Dadhar', 'describr' ),
        10 => /*translators: City.*/ __( 'Dalbandin', 'describr' ),
        11 => /*translators: City.*/ __( 'Dera Bugti', 'describr' ),
        12 => /*translators: City.*/ __( 'Dera Bugti District', 'describr' ),
        13 => /*translators: City.*/ __( 'Duki', 'describr' ),
        14 => /*translators: City.*/ __( 'Gadani', 'describr' ),
        15 => /*translators: City.*/ __( 'Garhi Khairo', 'describr' ),
        16 => /*translators: City.*/ __( 'Gwadar', 'describr' ),
        17 => /*translators: City.*/ __( 'Harnai', 'describr' ),
        18 => /*translators: City.*/ __( 'Jhal Magsi District', 'describr' ),
        19 => /*translators: City.*/ __( 'Jiwani', 'describr' ),
        20 => /*translators: City.*/ __( 'Jāfarābād District', 'describr' ),
        21 => /*translators: City.*/ __( 'Kalat', 'describr' ),
        22 => /*translators: City.*/ __( 'Kalāt District', 'describr' ),
        23 => /*translators: City.*/ __( 'Khadan Khak', 'describr' ),
        24 => /*translators: City.*/ __( 'Kharan', 'describr' ),
        25 => /*translators: City.*/ __( 'Khuzdar', 'describr' ),
        26 => /*translators: City.*/ __( 'Khuzdār District', 'describr' ),
        27 => /*translators: City.*/ __( 'Khārān District', 'describr' ),
        28 => /*translators: City.*/ __( 'Kohlu', 'describr' ),
        29 => /*translators: City.*/ __( 'Kot Malik Barkhurdar', 'describr' ),
        30 => /*translators: City.*/ __( 'Lasbela District', 'describr' ),
        31 => /*translators: City.*/ __( 'Loralai', 'describr' ),
        32 => /*translators: City.*/ __( 'Loralai District', 'describr' ),
        33 => /*translators: City.*/ __( 'Mach', 'describr' ),
        34 => /*translators: City.*/ __( 'Mastung', 'describr' ),
        35 => /*translators: City.*/ __( 'Mastung District', 'describr' ),
        36 => /*translators: City.*/ __( 'Mehrabpur', 'describr' ),
        37 => /*translators: City.*/ __( 'Mūsa Khel District', 'describr' ),
        38 => /*translators: City.*/ __( 'Nasīrābād District', 'describr' ),
        39 => /*translators: City.*/ __( 'Nushki', 'describr' ),
        40 => /*translators: City.*/ __( 'Ormara', 'describr' ),
        41 => /*translators: City.*/ __( 'Panjgūr District', 'describr' ),
        42 => /*translators: City.*/ __( 'Pasni', 'describr' ),
        43 => /*translators: City.*/ __( 'Pishin', 'describr' ),
        44 => /*translators: City.*/ __( 'Qila Saifullāh District', 'describr' ),
        45 => /*translators: City.*/ __( 'Quetta', 'describr' ),
        46 => /*translators: City.*/ __( 'Quetta District', 'describr' ),
        47 => /*translators: City.*/ __( 'Sibi', 'describr' ),
        48 => /*translators: City.*/ __( 'Sohbatpur', 'describr' ),
        49 => /*translators: City.*/ __( 'Surab', 'describr' ),
        50 => /*translators: City.*/ __( 'Turbat', 'describr' ),
        51 => /*translators: City.*/ __( 'Usta Muhammad', 'describr' ),
        52 => /*translators: City.*/ __( 'Uthal', 'describr' ),
        53 => /*translators: City.*/ __( 'Zhob', 'describr' ),
        54 => /*translators: City.*/ __( 'Zhob District', 'describr' ),
        55 => /*translators: City.*/ __( 'Ziarat', 'describr' ),
        56 => /*translators: City.*/ __( 'Ziārat District', 'describr' ),
      ),
    ),
    'SD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sindh', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adilpur', 'describr' ),
        1 => /*translators: City.*/ __( 'Badin', 'describr' ),
        2 => /*translators: City.*/ __( 'Bagarji', 'describr' ),
        3 => /*translators: City.*/ __( 'Bandhi', 'describr' ),
        4 => /*translators: City.*/ __( 'Berani', 'describr' ),
        5 => /*translators: City.*/ __( 'Bhan', 'describr' ),
        6 => /*translators: City.*/ __( 'Bhiria', 'describr' ),
        7 => /*translators: City.*/ __( 'Bhit Shah', 'describr' ),
        8 => /*translators: City.*/ __( 'Bozdar Wada', 'describr' ),
        9 => /*translators: City.*/ __( 'Bulri', 'describr' ),
        10 => /*translators: City.*/ __( 'Chak', 'describr' ),
        11 => /*translators: City.*/ __( 'Chamber', 'describr' ),
        12 => /*translators: City.*/ __( 'Chhor', 'describr' ),
        13 => /*translators: City.*/ __( 'Chuhar Jamali', 'describr' ),
        14 => /*translators: City.*/ __( 'Dadu', 'describr' ),
        15 => /*translators: City.*/ __( 'Daromehar', 'describr' ),
        16 => /*translators: City.*/ __( 'Darya Khan Marri', 'describr' ),
        17 => /*translators: City.*/ __( 'Daulatpur', 'describr' ),
        18 => /*translators: City.*/ __( 'Daur', 'describr' ),
        19 => /*translators: City.*/ __( 'Dhoro Naro', 'describr' ),
        20 => /*translators: City.*/ __( 'Digri', 'describr' ),
        21 => /*translators: City.*/ __( 'Diplo', 'describr' ),
        22 => /*translators: City.*/ __( 'Dokri', 'describr' ),
        23 => /*translators: City.*/ __( 'Gambat', 'describr' ),
        24 => /*translators: City.*/ __( 'Garhiyasin', 'describr' ),
        25 => /*translators: City.*/ __( 'Gharo', 'describr' ),
        26 => /*translators: City.*/ __( 'Ghauspur', 'describr' ),
        27 => /*translators: City.*/ __( 'Ghotki', 'describr' ),
        28 => /*translators: City.*/ __( 'Goth Garelo', 'describr' ),
        29 => /*translators: City.*/ __( 'Goth Phulji', 'describr' ),
        30 => /*translators: City.*/ __( 'Goth Radhan', 'describr' ),
        31 => /*translators: City.*/ __( 'Hala', 'describr' ),
        32 => /*translators: City.*/ __( 'Hingorja', 'describr' ),
        33 => /*translators: City.*/ __( 'Hyderabad', 'describr' ),
        34 => /*translators: City.*/ __( 'Islamkot', 'describr' ),
        35 => /*translators: City.*/ __( 'Jacobabad', 'describr' ),
        36 => /*translators: City.*/ __( 'Jamshoro', 'describr' ),
        37 => /*translators: City.*/ __( 'Jati', 'describr' ),
        38 => /*translators: City.*/ __( 'Jhol', 'describr' ),
        39 => /*translators: City.*/ __( 'Johi', 'describr' ),
        40 => /*translators: City.*/ __( 'Jām Sāhib', 'describr' ),
        41 => /*translators: City.*/ __( 'Kadhan', 'describr' ),
        42 => /*translators: City.*/ __( 'Kambar', 'describr' ),
        43 => /*translators: City.*/ __( 'Kandhkot', 'describr' ),
        44 => /*translators: City.*/ __( 'Kandiari', 'describr' ),
        45 => /*translators: City.*/ __( 'Kandiaro', 'describr' ),
        46 => /*translators: City.*/ __( 'Karachi', 'describr' ),
        47 => /*translators: City.*/ __( 'Karaundi', 'describr' ),
        48 => /*translators: City.*/ __( 'Kario Ghanwar', 'describr' ),
        49 => /*translators: City.*/ __( 'Kashmor', 'describr' ),
        50 => /*translators: City.*/ __( 'Keti Bandar', 'describr' ),
        51 => /*translators: City.*/ __( 'Khadro', 'describr' ),
        52 => /*translators: City.*/ __( 'Khairpur', 'describr' ),
        53 => /*translators: City.*/ __( 'Khairpur Mir&#039;s', 'describr' ),
        54 => /*translators: City.*/ __( 'Khairpur Nathan Shah', 'describr' ),
        55 => /*translators: City.*/ __( 'Khanpur Mahar', 'describr' ),
        56 => /*translators: City.*/ __( 'Kot Diji', 'describr' ),
        57 => /*translators: City.*/ __( 'Kotri', 'describr' ),
        58 => /*translators: City.*/ __( 'Kunri', 'describr' ),
        59 => /*translators: City.*/ __( 'Lakhi', 'describr' ),
        60 => /*translators: City.*/ __( 'Larkana', 'describr' ),
        61 => /*translators: City.*/ __( 'Madeji', 'describr' ),
        62 => /*translators: City.*/ __( 'Malir Cantonment', 'describr' ),
        63 => /*translators: City.*/ __( 'Matiari', 'describr' ),
        64 => /*translators: City.*/ __( 'Matli', 'describr' ),
        65 => /*translators: City.*/ __( 'Mehar', 'describr' ),
        66 => /*translators: City.*/ __( 'Miro Khan', 'describr' ),
        67 => /*translators: City.*/ __( 'Mirpur Bhtoro', 'describr' ),
        68 => /*translators: City.*/ __( 'Mirpur Khas', 'describr' ),
        69 => /*translators: City.*/ __( 'Mirpur Mathelo', 'describr' ),
        70 => /*translators: City.*/ __( 'Mirpur Sakro', 'describr' ),
        71 => /*translators: City.*/ __( 'Mirwah Gorchani', 'describr' ),
        72 => /*translators: City.*/ __( 'Mithi', 'describr' ),
        73 => /*translators: City.*/ __( 'Moro', 'describr' ),
        74 => /*translators: City.*/ __( 'Nabisar', 'describr' ),
        75 => /*translators: City.*/ __( 'Nasirabad', 'describr' ),
        76 => /*translators: City.*/ __( 'Naudero', 'describr' ),
        77 => /*translators: City.*/ __( 'Naukot', 'describr' ),
        78 => /*translators: City.*/ __( 'Naushahro Firoz', 'describr' ),
        79 => /*translators: City.*/ __( 'Nawabshah', 'describr' ),
        80 => /*translators: City.*/ __( 'New Bādāh', 'describr' ),
        81 => /*translators: City.*/ __( 'Pad Idan', 'describr' ),
        82 => /*translators: City.*/ __( 'Pano Aqil', 'describr' ),
        83 => /*translators: City.*/ __( 'Pir Jo Goth', 'describr' ),
        84 => /*translators: City.*/ __( 'Pithoro', 'describr' ),
        85 => /*translators: City.*/ __( 'Rajo Khanani', 'describr' ),
        86 => /*translators: City.*/ __( 'Ranipur', 'describr' ),
        87 => /*translators: City.*/ __( 'Ratodero', 'describr' ),
        88 => /*translators: City.*/ __( 'Rohri', 'describr' ),
        89 => /*translators: City.*/ __( 'Rustam', 'describr' ),
        90 => /*translators: City.*/ __( 'Sakrand', 'describr' ),
        91 => /*translators: City.*/ __( 'Samaro', 'describr' ),
        92 => /*translators: City.*/ __( 'Sanghar', 'describr' ),
        93 => /*translators: City.*/ __( 'Sann', 'describr' ),
        94 => /*translators: City.*/ __( 'Sehwan', 'describr' ),
        95 => /*translators: City.*/ __( 'Setharja Old', 'describr' ),
        96 => /*translators: City.*/ __( 'Shahdad Kot', 'describr' ),
        97 => /*translators: City.*/ __( 'Shahdadpur', 'describr' ),
        98 => /*translators: City.*/ __( 'Shahpur Chakar', 'describr' ),
        99 => /*translators: City.*/ __( 'Shikarpur', 'describr' ),
        100 => /*translators: City.*/ __( 'Sinjhoro', 'describr' ),
        101 => /*translators: City.*/ __( 'Sobhodero', 'describr' ),
        102 => /*translators: City.*/ __( 'Sukkur', 'describr' ),
        103 => /*translators: City.*/ __( 'Sīta Road', 'describr' ),
        104 => /*translators: City.*/ __( 'Talhar', 'describr' ),
        105 => /*translators: City.*/ __( 'Tando Adam', 'describr' ),
        106 => /*translators: City.*/ __( 'Tando Allahyar', 'describr' ),
        107 => /*translators: City.*/ __( 'Tando Bago', 'describr' ),
        108 => /*translators: City.*/ __( 'Tando Jam', 'describr' ),
        109 => /*translators: City.*/ __( 'Tando Mitha Khan', 'describr' ),
        110 => /*translators: City.*/ __( 'Tando Muhammad Khan', 'describr' ),
        111 => /*translators: City.*/ __( 'Tangwani', 'describr' ),
        112 => /*translators: City.*/ __( 'Tharu Shah', 'describr' ),
        113 => /*translators: City.*/ __( 'Thatta', 'describr' ),
        114 => /*translators: City.*/ __( 'Thul', 'describr' ),
        115 => /*translators: City.*/ __( 'Ubauro', 'describr' ),
        116 => /*translators: City.*/ __( 'Umarkot', 'describr' ),
        117 => /*translators: City.*/ __( 'Umerkot District', 'describr' ),
        118 => /*translators: City.*/ __( 'Warah', 'describr' ),
      ),
    ),
    'PB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Punjab', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ahmadpur Sial', 'describr' ),
        1 => /*translators: City.*/ __( 'Ahmedpur East', 'describr' ),
        2 => /*translators: City.*/ __( 'Alipur Chatha', 'describr' ),
        3 => /*translators: City.*/ __( 'Arifwala', 'describr' ),
        4 => /*translators: City.*/ __( 'Attock Tehsil', 'describr' ),
        5 => /*translators: City.*/ __( 'Baddomalhi', 'describr' ),
        6 => /*translators: City.*/ __( 'Bahawalnagar', 'describr' ),
        7 => /*translators: City.*/ __( 'Bahawalpur', 'describr' ),
        8 => /*translators: City.*/ __( 'Bakhri Ahmad Khan', 'describr' ),
        9 => /*translators: City.*/ __( 'Basirpur', 'describr' ),
        10 => /*translators: City.*/ __( 'Basti Dosa', 'describr' ),
        11 => /*translators: City.*/ __( 'Begowala', 'describr' ),
        12 => /*translators: City.*/ __( 'Bhakkar', 'describr' ),
        13 => /*translators: City.*/ __( 'Bhalwal', 'describr' ),
        14 => /*translators: City.*/ __( 'Bhawana', 'describr' ),
        15 => /*translators: City.*/ __( 'Bhera', 'describr' ),
        16 => /*translators: City.*/ __( 'Bhopalwala', 'describr' ),
        17 => /*translators: City.*/ __( 'Burewala', 'describr' ),
        18 => /*translators: City.*/ __( 'Chak Azam Saffo', 'describr' ),
        19 => /*translators: City.*/ __( 'Chak Jhumra', 'describr' ),
        20 => /*translators: City.*/ __( 'Chak One Hundred Twenty Nine Left', 'describr' ),
        21 => /*translators: City.*/ __( 'Chak Thirty-one -Eleven Left', 'describr' ),
        22 => /*translators: City.*/ __( 'Chak Two Hundred Forty-Nine TDA', 'describr' ),
        23 => /*translators: City.*/ __( 'Chakwal', 'describr' ),
        24 => /*translators: City.*/ __( 'Chawinda', 'describr' ),
        25 => /*translators: City.*/ __( 'Chichawatni', 'describr' ),
        26 => /*translators: City.*/ __( 'Chiniot', 'describr' ),
        27 => /*translators: City.*/ __( 'Chishtian', 'describr' ),
        28 => /*translators: City.*/ __( 'Choa Saidanshah', 'describr' ),
        29 => /*translators: City.*/ __( 'Chuhar Kana', 'describr' ),
        30 => /*translators: City.*/ __( 'Chunian', 'describr' ),
        31 => /*translators: City.*/ __( 'Daira Din Panah', 'describr' ),
        32 => /*translators: City.*/ __( 'Dajal', 'describr' ),
        33 => /*translators: City.*/ __( 'Dandot RS', 'describr' ),
        34 => /*translators: City.*/ __( 'Darya Khan', 'describr' ),
        35 => /*translators: City.*/ __( 'Daska', 'describr' ),
        36 => /*translators: City.*/ __( 'Daud Khel', 'describr' ),
        37 => /*translators: City.*/ __( 'Daultala', 'describr' ),
        38 => /*translators: City.*/ __( 'Dera Ghazi Khan', 'describr' ),
        39 => /*translators: City.*/ __( 'Dhanot', 'describr' ),
        40 => /*translators: City.*/ __( 'Dhaunkal', 'describr' ),
        41 => /*translators: City.*/ __( 'Dhok Awan', 'describr' ),
        42 => /*translators: City.*/ __( 'Dijkot', 'describr' ),
        43 => /*translators: City.*/ __( 'Dinan Bashnoian Wala', 'describr' ),
        44 => /*translators: City.*/ __( 'Dinga', 'describr' ),
        45 => /*translators: City.*/ __( 'Dipalpur', 'describr' ),
        46 => /*translators: City.*/ __( 'Dullewala', 'describr' ),
        47 => /*translators: City.*/ __( 'Dunga Bunga', 'describr' ),
        48 => /*translators: City.*/ __( 'Dunyapur', 'describr' ),
        49 => /*translators: City.*/ __( 'Eminabad', 'describr' ),
        50 => /*translators: City.*/ __( 'Faisalabad', 'describr' ),
        51 => /*translators: City.*/ __( 'Faqirwali', 'describr' ),
        52 => /*translators: City.*/ __( 'Faruka', 'describr' ),
        53 => /*translators: City.*/ __( 'Fazilpur', 'describr' ),
        54 => /*translators: City.*/ __( 'Ferozewala', 'describr' ),
        55 => /*translators: City.*/ __( 'Fort Abbas', 'describr' ),
        56 => /*translators: City.*/ __( 'Garh Maharaja', 'describr' ),
        57 => /*translators: City.*/ __( 'Gojra', 'describr' ),
        58 => /*translators: City.*/ __( 'Gujar Khan', 'describr' ),
        59 => /*translators: City.*/ __( 'Gujranwala', 'describr' ),
        60 => /*translators: City.*/ __( 'Gujranwala Division', 'describr' ),
        61 => /*translators: City.*/ __( 'Gujrat', 'describr' ),
        62 => /*translators: City.*/ __( 'Hadali', 'describr' ),
        63 => /*translators: City.*/ __( 'Hafizabad', 'describr' ),
        64 => /*translators: City.*/ __( 'Harnoli', 'describr' ),
        65 => /*translators: City.*/ __( 'Harunabad', 'describr' ),
        66 => /*translators: City.*/ __( 'Hasan Abdal', 'describr' ),
        67 => /*translators: City.*/ __( 'Hasilpur', 'describr' ),
        68 => /*translators: City.*/ __( 'Haveli Lakha', 'describr' ),
        69 => /*translators: City.*/ __( 'Hazro', 'describr' ),
        70 => /*translators: City.*/ __( 'Hujra Shah Muqeem', 'describr' ),
        71 => /*translators: City.*/ __( 'Jahanian Shah', 'describr' ),
        72 => /*translators: City.*/ __( 'Jalalpur Jattan', 'describr' ),
        73 => /*translators: City.*/ __( 'Jalalpur Pirwala', 'describr' ),
        74 => /*translators: City.*/ __( 'Jampur', 'describr' ),
        75 => /*translators: City.*/ __( 'Jand', 'describr' ),
        76 => /*translators: City.*/ __( 'Jandiala Sher Khan', 'describr' ),
        77 => /*translators: City.*/ __( 'Jaranwala', 'describr' ),
        78 => /*translators: City.*/ __( 'Jatoi Shimali', 'describr' ),
        79 => /*translators: City.*/ __( 'Jauharabad', 'describr' ),
        80 => /*translators: City.*/ __( 'Jhang', 'describr' ),
        81 => /*translators: City.*/ __( 'Jhang Sadar', 'describr' ),
        82 => /*translators: City.*/ __( 'Jhawarian', 'describr' ),
        83 => /*translators: City.*/ __( 'Jhelum', 'describr' ),
        84 => /*translators: City.*/ __( 'Kabirwala', 'describr' ),
        85 => /*translators: City.*/ __( 'Kahna Nau', 'describr' ),
        86 => /*translators: City.*/ __( 'Kahuta', 'describr' ),
        87 => /*translators: City.*/ __( 'Kalabagh', 'describr' ),
        88 => /*translators: City.*/ __( 'Kalaswala', 'describr' ),
        89 => /*translators: City.*/ __( 'Kaleke Mandi', 'describr' ),
        90 => /*translators: City.*/ __( 'Kallar Kahar', 'describr' ),
        91 => /*translators: City.*/ __( 'Kalur Kot', 'describr' ),
        92 => /*translators: City.*/ __( 'Kamalia', 'describr' ),
        93 => /*translators: City.*/ __( 'Kamar Mushani', 'describr' ),
        94 => /*translators: City.*/ __( 'Kamoke', 'describr' ),
        95 => /*translators: City.*/ __( 'Kamra', 'describr' ),
        96 => /*translators: City.*/ __( 'Kanganpur', 'describr' ),
        97 => /*translators: City.*/ __( 'Karor', 'describr' ),
        98 => /*translators: City.*/ __( 'Kasur', 'describr' ),
        99 => /*translators: City.*/ __( 'Keshupur', 'describr' ),
        100 => /*translators: City.*/ __( 'Khairpur Tamiwali', 'describr' ),
        101 => /*translators: City.*/ __( 'Khandowa', 'describr' ),
        102 => /*translators: City.*/ __( 'Khanewal', 'describr' ),
        103 => /*translators: City.*/ __( 'Khanga Dogran', 'describr' ),
        104 => /*translators: City.*/ __( 'Khangarh', 'describr' ),
        105 => /*translators: City.*/ __( 'Khanpur', 'describr' ),
        106 => /*translators: City.*/ __( 'Kharian', 'describr' ),
        107 => /*translators: City.*/ __( 'Khewra', 'describr' ),
        108 => /*translators: City.*/ __( 'Khurrianwala', 'describr' ),
        109 => /*translators: City.*/ __( 'Khushab', 'describr' ),
        110 => /*translators: City.*/ __( 'Kohror Pakka', 'describr' ),
        111 => /*translators: City.*/ __( 'Kot Addu Tehsil', 'describr' ),
        112 => /*translators: City.*/ __( 'Kot Ghulam Muhammad', 'describr' ),
        113 => /*translators: City.*/ __( 'Kot Mumin', 'describr' ),
        114 => /*translators: City.*/ __( 'Kot Radha Kishan', 'describr' ),
        115 => /*translators: City.*/ __( 'Kot Rajkour', 'describr' ),
        116 => /*translators: City.*/ __( 'Kot Samaba', 'describr' ),
        117 => /*translators: City.*/ __( 'Kot Sultan', 'describr' ),
        118 => /*translators: City.*/ __( 'Kotli Loharan', 'describr' ),
        119 => /*translators: City.*/ __( 'Kundian', 'describr' ),
        120 => /*translators: City.*/ __( 'Kunjah', 'describr' ),
        121 => /*translators: City.*/ __( 'Ladhewala Waraich', 'describr' ),
        122 => /*translators: City.*/ __( 'Lahore', 'describr' ),
        123 => /*translators: City.*/ __( 'Lala Musa', 'describr' ),
        124 => /*translators: City.*/ __( 'Lalian', 'describr' ),
        125 => /*translators: City.*/ __( 'Layyah', 'describr' ),
        126 => /*translators: City.*/ __( 'Layyah District', 'describr' ),
        127 => /*translators: City.*/ __( 'Liliani', 'describr' ),
        128 => /*translators: City.*/ __( 'Lodhran', 'describr' ),
        129 => /*translators: City.*/ __( 'Mailsi', 'describr' ),
        130 => /*translators: City.*/ __( 'Malakwal', 'describr' ),
        131 => /*translators: City.*/ __( 'Malakwal City', 'describr' ),
        132 => /*translators: City.*/ __( 'Mamu Kanjan', 'describr' ),
        133 => /*translators: City.*/ __( 'Mananwala', 'describr' ),
        134 => /*translators: City.*/ __( 'Mandi Bahauddin', 'describr' ),
        135 => /*translators: City.*/ __( 'Mandi Bahauddin District', 'describr' ),
        136 => /*translators: City.*/ __( 'Mangla', 'describr' ),
        137 => /*translators: City.*/ __( 'Mankera', 'describr' ),
        138 => /*translators: City.*/ __( 'Mehmand Chak', 'describr' ),
        139 => /*translators: City.*/ __( 'Mian Channun', 'describr' ),
        140 => /*translators: City.*/ __( 'Mianke Mor', 'describr' ),
        141 => /*translators: City.*/ __( 'Mianwali', 'describr' ),
        142 => /*translators: City.*/ __( 'Minchinabad', 'describr' ),
        143 => /*translators: City.*/ __( 'Mitha Tiwana', 'describr' ),
        144 => /*translators: City.*/ __( 'Moza Shahwala', 'describr' ),
        145 => /*translators: City.*/ __( 'Multan', 'describr' ),
        146 => /*translators: City.*/ __( 'Multan District', 'describr' ),
        147 => /*translators: City.*/ __( 'Muridke', 'describr' ),
        148 => /*translators: City.*/ __( 'Murree', 'describr' ),
        149 => /*translators: City.*/ __( 'Mustafabad', 'describr' ),
        150 => /*translators: City.*/ __( 'Muzaffargarh', 'describr' ),
        151 => /*translators: City.*/ __( 'Nankana Sahib', 'describr' ),
        152 => /*translators: City.*/ __( 'Narang Mandi', 'describr' ),
        153 => /*translators: City.*/ __( 'Narowal', 'describr' ),
        154 => /*translators: City.*/ __( 'Naushahra Virkan', 'describr' ),
        155 => /*translators: City.*/ __( 'Nazir Town', 'describr' ),
        156 => /*translators: City.*/ __( 'Okara', 'describr' ),
        157 => /*translators: City.*/ __( 'Pakki Shagwanwali', 'describr' ),
        158 => /*translators: City.*/ __( 'Pakpattan', 'describr' ),
        159 => /*translators: City.*/ __( 'Pasrur', 'describr' ),
        160 => /*translators: City.*/ __( 'Pattoki', 'describr' ),
        161 => /*translators: City.*/ __( 'Phalia', 'describr' ),
        162 => /*translators: City.*/ __( 'Pind Dadan Khan', 'describr' ),
        163 => /*translators: City.*/ __( 'Pindi Bhattian', 'describr' ),
        164 => /*translators: City.*/ __( 'Pindi Gheb', 'describr' ),
        165 => /*translators: City.*/ __( 'Pir Mahal', 'describr' ),
        166 => /*translators: City.*/ __( 'Qadirpur Ran', 'describr' ),
        167 => /*translators: City.*/ __( 'Qila Didar Singh', 'describr' ),
        168 => /*translators: City.*/ __( 'Rabwah', 'describr' ),
        169 => /*translators: City.*/ __( 'Rahim Yar Khan', 'describr' ),
        170 => /*translators: City.*/ __( 'Rahimyar Khan District', 'describr' ),
        171 => /*translators: City.*/ __( 'Raiwind', 'describr' ),
        172 => /*translators: City.*/ __( 'Raja Jang', 'describr' ),
        173 => /*translators: City.*/ __( 'Rajanpur', 'describr' ),
        174 => /*translators: City.*/ __( 'Rasulnagar', 'describr' ),
        175 => /*translators: City.*/ __( 'Rawalpindi', 'describr' ),
        176 => /*translators: City.*/ __( 'Rawalpindi District', 'describr' ),
        177 => /*translators: City.*/ __( 'Renala Khurd', 'describr' ),
        178 => /*translators: City.*/ __( 'Rojhan', 'describr' ),
        179 => /*translators: City.*/ __( 'Sadiqabad', 'describr' ),
        180 => /*translators: City.*/ __( 'Sahiwal', 'describr' ),
        181 => /*translators: City.*/ __( 'Sambrial', 'describr' ),
        182 => /*translators: City.*/ __( 'Sangla Hill', 'describr' ),
        183 => /*translators: City.*/ __( 'Sanjwal', 'describr' ),
        184 => /*translators: City.*/ __( 'Sarai Alamgir', 'describr' ),
        185 => /*translators: City.*/ __( 'Sarai Sidhu', 'describr' ),
        186 => /*translators: City.*/ __( 'Sargodha', 'describr' ),
        187 => /*translators: City.*/ __( 'Shahkot Tehsil', 'describr' ),
        188 => /*translators: City.*/ __( 'Shahpur', 'describr' ),
        189 => /*translators: City.*/ __( 'Shahr Sultan', 'describr' ),
        190 => /*translators: City.*/ __( 'Shakargarh', 'describr' ),
        191 => /*translators: City.*/ __( 'Sharqpur', 'describr' ),
        192 => /*translators: City.*/ __( 'Sheikhupura', 'describr' ),
        193 => /*translators: City.*/ __( 'Shorkot', 'describr' ),
        194 => /*translators: City.*/ __( 'Shujaabad', 'describr' ),
        195 => /*translators: City.*/ __( 'Sialkot', 'describr' ),
        196 => /*translators: City.*/ __( 'Sillanwali', 'describr' ),
        197 => /*translators: City.*/ __( 'Sodhra', 'describr' ),
        198 => /*translators: City.*/ __( 'Sukheke Mandi', 'describr' ),
        199 => /*translators: City.*/ __( 'Surkhpur', 'describr' ),
        200 => /*translators: City.*/ __( 'Talagang', 'describr' ),
        201 => /*translators: City.*/ __( 'Talamba', 'describr' ),
        202 => /*translators: City.*/ __( 'Tandlianwala', 'describr' ),
        203 => /*translators: City.*/ __( 'Taunsa', 'describr' ),
        204 => /*translators: City.*/ __( 'Toba Tek Singh', 'describr' ),
        205 => /*translators: City.*/ __( 'Umerkot', 'describr' ),
        206 => /*translators: City.*/ __( 'Vihari', 'describr' ),
        207 => /*translators: City.*/ __( 'Wah', 'describr' ),
        208 => /*translators: City.*/ __( 'Warburton', 'describr' ),
        209 => /*translators: City.*/ __( 'Wazirabad', 'describr' ),
        210 => /*translators: City.*/ __( 'West Punjab', 'describr' ),
        211 => /*translators: City.*/ __( 'Yazman', 'describr' ),
        212 => /*translators: City.*/ __( 'Zafarwal', 'describr' ),
        213 => /*translators: City.*/ __( 'Zahir Pir', 'describr' ),
      ),
    ),
  ),
  'QA' => 
  array (
    'RA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Rayyan Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ar Rayyān', 'describr' ),
        1 => /*translators: City.*/ __( 'Umm Bāb', 'describr' ),
      ),
    ),
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al-Shahaniya', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Jumaylīyah', 'describr' ),
        1 => /*translators: City.*/ __( 'Ash Shīḩānīyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Dukhān', 'describr' ),
      ),
    ),
    'WA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Wakrah', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Wakrah', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Wukayr', 'describr' ),
        2 => /*translators: City.*/ __( 'Musay&#039;īd', 'describr' ),
      ),
    ),
    'MS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Madinat ash Shamal', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ar Ruways', 'describr' ),
        1 => /*translators: City.*/ __( 'Fuwayriţ', 'describr' ),
        2 => /*translators: City.*/ __( 'Madīnat ash Shamāl', 'describr' ),
      ),
    ),
    'DA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Doha', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Doha', 'describr' ),
      ),
    ),
    'KH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Al Khor', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Ghuwayrīyah', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Khawr', 'describr' ),
      ),
    ),
    'US' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Umm Salal Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Umm Şalāl Muḩammad', 'describr' ),
      ),
    ),
  ),
  'BI' => 
  array (
    'RM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rumonge Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rumonge', 'describr' ),
      ),
    ),
    'MY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Muyinga Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muyinga', 'describr' ),
      ),
    ),
    'MW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mwaro Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mwaro', 'describr' ),
      ),
    ),
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Makamba Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Makamba', 'describr' ),
      ),
    ),
    'RT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rutana Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rutana', 'describr' ),
      ),
    ),
    'CI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cibitoke Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cibitoke', 'describr' ),
      ),
    ),
    'RY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ruyigi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ruyigi', 'describr' ),
      ),
    ),
    'KY' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kayanza Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kayanza', 'describr' ),
      ),
    ),
    'MU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Muramvya Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muramvya', 'describr' ),
      ),
    ),
    'KR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Karuzi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Karuzi', 'describr' ),
      ),
    ),
    'KI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kirundo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kirundo', 'describr' ),
      ),
    ),
    'BB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bubanza Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bubanza', 'describr' ),
      ),
    ),
    'GI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gitega Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gitega', 'describr' ),
      ),
    ),
    'BM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bujumbura Mairie Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bujumbura', 'describr' ),
      ),
    ),
    'NG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ngozi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ngozi', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cankuzo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cankuzo', 'describr' ),
      ),
    ),
    'BR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bururi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bururi', 'describr' ),
      ),
    ),
  ),
  'UY' => 
  array (
    'FS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Flores Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Trinidad', 'describr' ),
      ),
    ),
    'SJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San José Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Delta del Tigre', 'describr' ),
        1 => /*translators: City.*/ __( 'Ecilda Paullier', 'describr' ),
        2 => /*translators: City.*/ __( 'Libertad', 'describr' ),
        3 => /*translators: City.*/ __( 'Puntas de Valdéz', 'describr' ),
        4 => /*translators: City.*/ __( 'Rafael Perazza', 'describr' ),
        5 => /*translators: City.*/ __( 'Rodríguez', 'describr' ),
        6 => /*translators: City.*/ __( 'San José de Mayo', 'describr' ),
      ),
    ),
    'AR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Artigas Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Artigas', 'describr' ),
        1 => /*translators: City.*/ __( 'Baltasar Brum', 'describr' ),
        2 => /*translators: City.*/ __( 'Bella Unión', 'describr' ),
        3 => /*translators: City.*/ __( 'Las Piedras', 'describr' ),
        4 => /*translators: City.*/ __( 'Tomás Gomensoro', 'describr' ),
      ),
    ),
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maldonado Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aiguá', 'describr' ),
        1 => /*translators: City.*/ __( 'Maldonado', 'describr' ),
        2 => /*translators: City.*/ __( 'Pan de Azúcar', 'describr' ),
        3 => /*translators: City.*/ __( 'Piriápolis', 'describr' ),
        4 => /*translators: City.*/ __( 'Punta del Este', 'describr' ),
        5 => /*translators: City.*/ __( 'San Carlos', 'describr' ),
      ),
    ),
    'RV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rivera Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Minas de Corrales', 'describr' ),
        1 => /*translators: City.*/ __( 'Rivera', 'describr' ),
        2 => /*translators: City.*/ __( 'Tranqueras', 'describr' ),
        3 => /*translators: City.*/ __( 'Vichadero', 'describr' ),
      ),
    ),
    'CO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Colonia Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Carmelo', 'describr' ),
        1 => /*translators: City.*/ __( 'Colonia del Sacramento', 'describr' ),
        2 => /*translators: City.*/ __( 'Florencio Sánchez', 'describr' ),
        3 => /*translators: City.*/ __( 'Juan L. Lacaze', 'describr' ),
        4 => /*translators: City.*/ __( 'Nueva Helvecia', 'describr' ),
        5 => /*translators: City.*/ __( 'Nueva Palmira', 'describr' ),
        6 => /*translators: City.*/ __( 'Ombúes de Lavalle', 'describr' ),
        7 => /*translators: City.*/ __( 'Rosario', 'describr' ),
        8 => /*translators: City.*/ __( 'Tarariras', 'describr' ),
      ),
    ),
    'DU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Durazno Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Blanquillo', 'describr' ),
        1 => /*translators: City.*/ __( 'Carlos Reyles', 'describr' ),
        2 => /*translators: City.*/ __( 'Durazno', 'describr' ),
        3 => /*translators: City.*/ __( 'La Paloma', 'describr' ),
        4 => /*translators: City.*/ __( 'Santa Bernardina', 'describr' ),
        5 => /*translators: City.*/ __( 'Sarandí del Yi', 'describr' ),
        6 => /*translators: City.*/ __( 'Villa del Carmen', 'describr' ),
      ),
    ),
    'RN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Río Negro Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fray Bentos', 'describr' ),
        1 => /*translators: City.*/ __( 'Nuevo Berlín', 'describr' ),
        2 => /*translators: City.*/ __( 'San Javier', 'describr' ),
        3 => /*translators: City.*/ __( 'Young', 'describr' ),
      ),
    ),
    'CL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cerro Largo Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aceguá', 'describr' ),
        1 => /*translators: City.*/ __( 'Isidoro Noblía', 'describr' ),
        2 => /*translators: City.*/ __( 'Melo', 'describr' ),
        3 => /*translators: City.*/ __( 'Río Branco', 'describr' ),
        4 => /*translators: City.*/ __( 'Tupambaé', 'describr' ),
      ),
    ),
    'PA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Paysandú Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Estación Porvenir', 'describr' ),
        1 => /*translators: City.*/ __( 'Guichón', 'describr' ),
        2 => /*translators: City.*/ __( 'Paysandú', 'describr' ),
        3 => /*translators: City.*/ __( 'Piedras Coloradas', 'describr' ),
        4 => /*translators: City.*/ __( 'Quebracho', 'describr' ),
        5 => /*translators: City.*/ __( 'San Félix', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Canelones Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aguas Corrientes', 'describr' ),
        1 => /*translators: City.*/ __( 'Atlántida', 'describr' ),
        2 => /*translators: City.*/ __( 'Barra de Carrasco', 'describr' ),
        3 => /*translators: City.*/ __( 'Barros Blancos', 'describr' ),
        4 => /*translators: City.*/ __( 'Canelones', 'describr' ),
        5 => /*translators: City.*/ __( 'Colonia Nicolich', 'describr' ),
        6 => /*translators: City.*/ __( 'Empalme Olmos', 'describr' ),
        7 => /*translators: City.*/ __( 'Joaquín Suárez', 'describr' ),
        8 => /*translators: City.*/ __( 'Juanicó', 'describr' ),
        9 => /*translators: City.*/ __( 'La Floresta', 'describr' ),
        10 => /*translators: City.*/ __( 'La Paz', 'describr' ),
        11 => /*translators: City.*/ __( 'Las Piedras', 'describr' ),
        12 => /*translators: City.*/ __( 'Las Toscas', 'describr' ),
        13 => /*translators: City.*/ __( 'Los Cerrillos', 'describr' ),
        14 => /*translators: City.*/ __( 'Migues', 'describr' ),
        15 => /*translators: City.*/ __( 'Montes', 'describr' ),
        16 => /*translators: City.*/ __( 'Pando', 'describr' ),
        17 => /*translators: City.*/ __( 'Paso de Carrasco', 'describr' ),
        18 => /*translators: City.*/ __( 'Progreso', 'describr' ),
        19 => /*translators: City.*/ __( 'San Antonio', 'describr' ),
        20 => /*translators: City.*/ __( 'San Bautista', 'describr' ),
        21 => /*translators: City.*/ __( 'San Jacinto', 'describr' ),
        22 => /*translators: City.*/ __( 'San Ramón', 'describr' ),
        23 => /*translators: City.*/ __( 'Santa Lucía', 'describr' ),
        24 => /*translators: City.*/ __( 'Santa Rosa', 'describr' ),
        25 => /*translators: City.*/ __( 'Sauce', 'describr' ),
        26 => /*translators: City.*/ __( 'Soca', 'describr' ),
        27 => /*translators: City.*/ __( 'Tala', 'describr' ),
        28 => /*translators: City.*/ __( 'Toledo', 'describr' ),
      ),
    ),
    'TT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Treinta y Tres Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Santa Clara de Olimar', 'describr' ),
        1 => /*translators: City.*/ __( 'Treinta y Tres', 'describr' ),
        2 => /*translators: City.*/ __( 'Vergara', 'describr' ),
        3 => /*translators: City.*/ __( 'Villa Sara', 'describr' ),
      ),
    ),
    'LA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lavalleja Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'José Batlle y Ordóñez', 'describr' ),
        1 => /*translators: City.*/ __( 'José Pedro Varela', 'describr' ),
        2 => /*translators: City.*/ __( 'Mariscala', 'describr' ),
        3 => /*translators: City.*/ __( 'Minas', 'describr' ),
        4 => /*translators: City.*/ __( 'Solís de Mataojo', 'describr' ),
      ),
    ),
    'RO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rocha Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Castillos', 'describr' ),
        1 => /*translators: City.*/ __( 'Cebollatí', 'describr' ),
        2 => /*translators: City.*/ __( 'Chui', 'describr' ),
        3 => /*translators: City.*/ __( 'Dieciocho de Julio', 'describr' ),
        4 => /*translators: City.*/ __( 'La Paloma', 'describr' ),
        5 => /*translators: City.*/ __( 'Lascano', 'describr' ),
        6 => /*translators: City.*/ __( 'Rocha', 'describr' ),
        7 => /*translators: City.*/ __( 'Velázquez', 'describr' ),
      ),
    ),
    'FD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Florida Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( '25 de Agosto', 'describr' ),
        1 => /*translators: City.*/ __( '25 de Mayo', 'describr' ),
        2 => /*translators: City.*/ __( 'Alejandro Gallinal', 'describr' ),
        3 => /*translators: City.*/ __( 'Cardal', 'describr' ),
        4 => /*translators: City.*/ __( 'Casupá', 'describr' ),
        5 => /*translators: City.*/ __( 'Florida', 'describr' ),
        6 => /*translators: City.*/ __( 'Sarandí Grande', 'describr' ),
      ),
    ),
    'MO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Montevideo Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Montevideo', 'describr' ),
        1 => /*translators: City.*/ __( 'Pajas Blancas', 'describr' ),
        2 => /*translators: City.*/ __( 'Santiago Vázquez', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Soriano Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cardona', 'describr' ),
        1 => /*translators: City.*/ __( 'Dolores', 'describr' ),
        2 => /*translators: City.*/ __( 'José Enrique Rodó', 'describr' ),
        3 => /*translators: City.*/ __( 'Mercedes', 'describr' ),
        4 => /*translators: City.*/ __( 'Palmitas', 'describr' ),
        5 => /*translators: City.*/ __( 'Santa Catalina', 'describr' ),
        6 => /*translators: City.*/ __( 'Villa Soriano', 'describr' ),
      ),
    ),
    'SA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Salto Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belén', 'describr' ),
        1 => /*translators: City.*/ __( 'Salto', 'describr' ),
        2 => /*translators: City.*/ __( 'Villa Constitución', 'describr' ),
      ),
    ),
    'TA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tacuarembó Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Curtina', 'describr' ),
        1 => /*translators: City.*/ __( 'Paso de los Toros', 'describr' ),
        2 => /*translators: City.*/ __( 'Tacuarembó', 'describr' ),
      ),
    ),
  ),
  'EG' => 
  array (
    'KFS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kafr el-Sheikh Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Ḩāmūl', 'describr' ),
        1 => /*translators: City.*/ __( 'Disūq', 'describr' ),
        2 => /*translators: City.*/ __( 'Fuwwah', 'describr' ),
        3 => /*translators: City.*/ __( 'Kafr ash Shaykh', 'describr' ),
        4 => /*translators: City.*/ __( 'Markaz Disūq', 'describr' ),
        5 => /*translators: City.*/ __( 'Munshāt &#039;Alī Āghā', 'describr' ),
        6 => /*translators: City.*/ __( 'Sīdī Sālim', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cairo Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cairo', 'describr' ),
        1 => /*translators: City.*/ __( 'New Cairo', 'describr' ),
        2 => /*translators: City.*/ __( 'Ḩalwān', 'describr' ),
      ),
    ),
    'DT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Damietta Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Az Zarqā', 'describr' ),
        1 => /*translators: City.*/ __( 'Damietta', 'describr' ),
        2 => /*translators: City.*/ __( 'Fāraskūr', 'describr' ),
      ),
    ),
    'ASN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aswan Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abu Simbel', 'describr' ),
        1 => /*translators: City.*/ __( 'Aswan', 'describr' ),
        2 => /*translators: City.*/ __( 'Idfū', 'describr' ),
        3 => /*translators: City.*/ __( 'Kawm Umbū', 'describr' ),
      ),
    ),
    'SHG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sohag Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akhmīm', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Balyanā', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Manshāh', 'describr' ),
        3 => /*translators: City.*/ __( 'Jirjā', 'describr' ),
        4 => /*translators: City.*/ __( 'Juhaynah', 'describr' ),
        5 => /*translators: City.*/ __( 'Markaz Jirjā', 'describr' ),
        6 => /*translators: City.*/ __( 'Markaz Sūhāj', 'describr' ),
        7 => /*translators: City.*/ __( 'Sohag', 'describr' ),
        8 => /*translators: City.*/ __( 'Ţahţā', 'describr' ),
      ),
    ),
    'SIN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North Sinai Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arish', 'describr' ),
      ),
    ),
    'MNF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Monufia Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Bājūr', 'describr' ),
        1 => /*translators: City.*/ __( 'Ash Shuhadā&#039;', 'describr' ),
        2 => /*translators: City.*/ __( 'Ashmūn', 'describr' ),
        3 => /*translators: City.*/ __( 'Munūf', 'describr' ),
        4 => /*translators: City.*/ __( 'Quwaysinā', 'describr' ),
        5 => /*translators: City.*/ __( 'Shibīn al Kawm', 'describr' ),
        6 => /*translators: City.*/ __( 'Talā', 'describr' ),
      ),
    ),
    'PTS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Port Said Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Port Said', 'describr' ),
      ),
    ),
    'BNS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beni Suef Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Fashn', 'describr' ),
        1 => /*translators: City.*/ __( 'Banī Suwayf', 'describr' ),
        2 => /*translators: City.*/ __( 'Būsh', 'describr' ),
        3 => /*translators: City.*/ __( 'Sumusţā as Sulţānī', 'describr' ),
      ),
    ),
    'MT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Matrouh Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al &#039;Alamayn', 'describr' ),
        1 => /*translators: City.*/ __( 'Mersa Matruh', 'describr' ),
        2 => /*translators: City.*/ __( 'Siwa Oasis', 'describr' ),
      ),
    ),
    'KB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qalyubia Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Khānkah', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Qanāţir al Khayrīyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Banhā', 'describr' ),
        3 => /*translators: City.*/ __( 'Qalyūb', 'describr' ),
        4 => /*translators: City.*/ __( 'Shibīn al Qanāṭir', 'describr' ),
        5 => /*translators: City.*/ __( 'Toukh', 'describr' ),
      ),
    ),
    'SUZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Suez Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ain Sukhna', 'describr' ),
        1 => /*translators: City.*/ __( 'Suez', 'describr' ),
      ),
    ),
    'GH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gharbia Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Maḩallah al Kubrá', 'describr' ),
        1 => /*translators: City.*/ __( 'Basyūn', 'describr' ),
        2 => /*translators: City.*/ __( 'Kafr az Zayyāt', 'describr' ),
        3 => /*translators: City.*/ __( 'Quţūr', 'describr' ),
        4 => /*translators: City.*/ __( 'Samannūd', 'describr' ),
        5 => /*translators: City.*/ __( 'Tanda', 'describr' ),
        6 => /*translators: City.*/ __( 'Zefta', 'describr' ),
      ),
    ),
    'ALX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Alexandria Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alexandria', 'describr' ),
      ),
    ),
    'AST' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Asyut Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abnūb', 'describr' ),
        1 => /*translators: City.*/ __( 'Abū Tīj', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Badārī', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Qūşīyah', 'describr' ),
        4 => /*translators: City.*/ __( 'Asyūţ', 'describr' ),
        5 => /*translators: City.*/ __( 'Dayrūţ', 'describr' ),
        6 => /*translators: City.*/ __( 'Manfalūţ', 'describr' ),
      ),
    ),
    'JS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'South Sinai Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dahab', 'describr' ),
        1 => /*translators: City.*/ __( 'El-Tor', 'describr' ),
        2 => /*translators: City.*/ __( 'Nuwaybi&#039;a', 'describr' ),
        3 => /*translators: City.*/ __( 'Saint Catherine', 'describr' ),
        4 => /*translators: City.*/ __( 'Sharm el-Sheikh', 'describr' ),
      ),
    ),
    'FYM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Faiyum Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Fayyūm', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Wāsiţah', 'describr' ),
        2 => /*translators: City.*/ __( 'Ibshawāy', 'describr' ),
        3 => /*translators: City.*/ __( 'Iţsā', 'describr' ),
        4 => /*translators: City.*/ __( 'Ţāmiyah', 'describr' ),
      ),
    ),
    'GZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Giza Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Bawīţī', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Ḩawāmidīyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Al &#039;Ayyāţ', 'describr' ),
        3 => /*translators: City.*/ __( 'Awsīm', 'describr' ),
        4 => /*translators: City.*/ __( 'Aş Şaff', 'describr' ),
        5 => /*translators: City.*/ __( 'Giza', 'describr' ),
        6 => /*translators: City.*/ __( 'Madīnat Sittah Uktūbar', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Red Sea Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Quşayr', 'describr' ),
        1 => /*translators: City.*/ __( 'El Gouna', 'describr' ),
        2 => /*translators: City.*/ __( 'Hurghada', 'describr' ),
        3 => /*translators: City.*/ __( 'Makadi Bay', 'describr' ),
        4 => /*translators: City.*/ __( 'Marsa Alam', 'describr' ),
        5 => /*translators: City.*/ __( 'Ras Gharib', 'describr' ),
        6 => /*translators: City.*/ __( 'Safaga', 'describr' ),
      ),
    ),
    'BH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beheira Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abū al Maţāmīr', 'describr' ),
        1 => /*translators: City.*/ __( 'Ad Dilinjāt', 'describr' ),
        2 => /*translators: City.*/ __( 'Damanhūr', 'describr' ),
        3 => /*translators: City.*/ __( 'Idkū', 'describr' ),
        4 => /*translators: City.*/ __( 'Kafr ad Dawwār', 'describr' ),
        5 => /*translators: City.*/ __( 'Kawm Ḩamādah', 'describr' ),
        6 => /*translators: City.*/ __( 'Rosetta', 'describr' ),
        7 => /*translators: City.*/ __( 'Ḩawsh &#039;Īsá', 'describr' ),
      ),
    ),
    'LX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luxor Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luxor', 'describr' ),
        1 => /*translators: City.*/ __( 'Markaz al Uqşur', 'describr' ),
      ),
    ),
    'MN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Minya Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abū Qurqāş', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Minyā', 'describr' ),
        2 => /*translators: City.*/ __( 'Banī Mazār', 'describr' ),
        3 => /*translators: City.*/ __( 'Dayr Mawās', 'describr' ),
        4 => /*translators: City.*/ __( 'Mallawī', 'describr' ),
        5 => /*translators: City.*/ __( 'Maţāy', 'describr' ),
        6 => /*translators: City.*/ __( 'Samālūţ', 'describr' ),
      ),
    ),
    'IS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ismailia Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ismailia', 'describr' ),
      ),
    ),
    'DK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dakahlia Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajā', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Jammālīyah', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Manzalah', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Manşūrah', 'describr' ),
        4 => /*translators: City.*/ __( 'Al Maţarīyah', 'describr' ),
        5 => /*translators: City.*/ __( 'Bilqās', 'describr' ),
        6 => /*translators: City.*/ __( 'Dikirnis', 'describr' ),
        7 => /*translators: City.*/ __( 'Minyat an Naşr', 'describr' ),
        8 => /*translators: City.*/ __( 'Shirbīn', 'describr' ),
        9 => /*translators: City.*/ __( 'Ţalkhā', 'describr' ),
        10 => /*translators: City.*/ __( '&#039;Izbat al Burj', 'describr' ),
      ),
    ),
    'WAD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'New Valley Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Khārijah', 'describr' ),
        1 => /*translators: City.*/ __( 'Qaşr al Farāfirah', 'describr' ),
      ),
    ),
    'KN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Qena Governorate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dishnā', 'describr' ),
        1 => /*translators: City.*/ __( 'Farshūţ', 'describr' ),
        2 => /*translators: City.*/ __( 'Isnā', 'describr' ),
        3 => /*translators: City.*/ __( 'Kousa', 'describr' ),
        4 => /*translators: City.*/ __( 'Naja&#039; Ḥammādī', 'describr' ),
        5 => /*translators: City.*/ __( 'Qinā', 'describr' ),
      ),
    ),
  ),
  'MU' => 
  array (
    'AG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Agaléga', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Vingt Cinq', 'describr' ),
      ),
    ),
    'RO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rodrigues', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baie aux Huîtres', 'describr' ),
        1 => /*translators: City.*/ __( 'Port Mathurin', 'describr' ),
      ),
    ),
    'PA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pamplemousses District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arsenal', 'describr' ),
        1 => /*translators: City.*/ __( 'Calebasses', 'describr' ),
        2 => /*translators: City.*/ __( 'Congomah', 'describr' ),
        3 => /*translators: City.*/ __( 'Crève Coeur', 'describr' ),
        4 => /*translators: City.*/ __( 'Fond du Sac', 'describr' ),
        5 => /*translators: City.*/ __( 'Le Hochet', 'describr' ),
        6 => /*translators: City.*/ __( 'Long Mountain', 'describr' ),
        7 => /*translators: City.*/ __( 'Morcellement Saint André', 'describr' ),
        8 => /*translators: City.*/ __( 'Notre Dame', 'describr' ),
        9 => /*translators: City.*/ __( 'Pamplemousses', 'describr' ),
        10 => /*translators: City.*/ __( 'Plaine des Papayes', 'describr' ),
        11 => /*translators: City.*/ __( 'Pointe aux Piments', 'describr' ),
        12 => /*translators: City.*/ __( 'Terre Rouge', 'describr' ),
        13 => /*translators: City.*/ __( 'Triolet', 'describr' ),
      ),
    ),
    'CC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cargados Carajos', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cargados Carajos', 'describr' ),
      ),
    ),
    'MO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Moka District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camp Thorel', 'describr' ),
        1 => /*translators: City.*/ __( 'Dagotière', 'describr' ),
        2 => /*translators: City.*/ __( 'Dubreuil', 'describr' ),
        3 => /*translators: City.*/ __( 'Melrose', 'describr' ),
        4 => /*translators: City.*/ __( 'Moka', 'describr' ),
        5 => /*translators: City.*/ __( 'Pailles', 'describr' ),
        6 => /*translators: City.*/ __( 'Providence', 'describr' ),
        7 => /*translators: City.*/ __( 'Quartier Militaire', 'describr' ),
        8 => /*translators: City.*/ __( 'Saint Pierre', 'describr' ),
        9 => /*translators: City.*/ __( 'Verdun', 'describr' ),
      ),
    ),
    'FL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Flacq District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bel Air Rivière Sèche', 'describr' ),
        1 => /*translators: City.*/ __( 'Bon Accueil', 'describr' ),
        2 => /*translators: City.*/ __( 'Brisée Verdière', 'describr' ),
        3 => /*translators: City.*/ __( 'Camp Ithier', 'describr' ),
        4 => /*translators: City.*/ __( 'Camp de Masque', 'describr' ),
        5 => /*translators: City.*/ __( 'Centre de Flacq', 'describr' ),
        6 => /*translators: City.*/ __( 'Clémencia', 'describr' ),
        7 => /*translators: City.*/ __( 'Ecroignard', 'describr' ),
        8 => /*translators: City.*/ __( 'Grande Rivière Sud Est', 'describr' ),
        9 => /*translators: City.*/ __( 'Lalmatie', 'describr' ),
        10 => /*translators: City.*/ __( 'Laventure', 'describr' ),
        11 => /*translators: City.*/ __( 'Mare La Chaux', 'describr' ),
        12 => /*translators: City.*/ __( 'Olivia', 'describr' ),
        13 => /*translators: City.*/ __( 'Poste de Flacq', 'describr' ),
        14 => /*translators: City.*/ __( 'Quatre Cocos', 'describr' ),
        15 => /*translators: City.*/ __( 'Quatre Soeurs', 'describr' ),
        16 => /*translators: City.*/ __( 'Queen Victoria', 'describr' ),
        17 => /*translators: City.*/ __( 'Saint Julien', 'describr' ),
        18 => /*translators: City.*/ __( 'Sebastopol', 'describr' ),
      ),
    ),
    'SA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Savanne District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camp Diable', 'describr' ),
        1 => /*translators: City.*/ __( 'Chamouny', 'describr' ),
        2 => /*translators: City.*/ __( 'Chemin Grenier', 'describr' ),
        3 => /*translators: City.*/ __( 'Grand Bois', 'describr' ),
        4 => /*translators: City.*/ __( 'Rivière des Anguilles', 'describr' ),
        5 => /*translators: City.*/ __( 'Saint Aubin', 'describr' ),
        6 => /*translators: City.*/ __( 'Souillac', 'describr' ),
        7 => /*translators: City.*/ __( 'Surinam', 'describr' ),
      ),
    ),
    'BL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rivière Noire District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Albion', 'describr' ),
        1 => /*translators: City.*/ __( 'Bambous', 'describr' ),
        2 => /*translators: City.*/ __( 'Cascavelle', 'describr' ),
        3 => /*translators: City.*/ __( 'Flic en Flac', 'describr' ),
        4 => /*translators: City.*/ __( 'Grande Rivière Noire', 'describr' ),
        5 => /*translators: City.*/ __( 'Gros Cailloux', 'describr' ),
        6 => /*translators: City.*/ __( 'Petite Case Noyale', 'describr' ),
        7 => /*translators: City.*/ __( 'Petite Rivière', 'describr' ),
        8 => /*translators: City.*/ __( 'Tamarin', 'describr' ),
      ),
    ),
    'PL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Port Louis District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Port Louis', 'describr' ),
      ),
    ),
    'RR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rivière du Rempart District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amaury', 'describr' ),
        1 => /*translators: City.*/ __( 'Cap Malheureux', 'describr' ),
        2 => /*translators: City.*/ __( 'Cottage', 'describr' ),
        3 => /*translators: City.*/ __( 'Espérance Trébuchet', 'describr' ),
        4 => /*translators: City.*/ __( 'Goodlands', 'describr' ),
        5 => /*translators: City.*/ __( 'Grand Baie', 'describr' ),
        6 => /*translators: City.*/ __( 'Grand Gaube', 'describr' ),
        7 => /*translators: City.*/ __( 'Mapou', 'describr' ),
        8 => /*translators: City.*/ __( 'Petit Raffray', 'describr' ),
        9 => /*translators: City.*/ __( 'Piton', 'describr' ),
        10 => /*translators: City.*/ __( 'Plaines des Roches', 'describr' ),
        11 => /*translators: City.*/ __( 'Rivière du Rempart', 'describr' ),
        12 => /*translators: City.*/ __( 'Roche Terre', 'describr' ),
        13 => /*translators: City.*/ __( 'Roches Noire', 'describr' ),
        14 => /*translators: City.*/ __( 'The Vale', 'describr' ),
      ),
    ),
    'PW' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Plaines Wilhems District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beau Bassin-Rose Hill', 'describr' ),
        1 => /*translators: City.*/ __( 'Curepipe', 'describr' ),
        2 => /*translators: City.*/ __( 'Ebene', 'describr' ),
        3 => /*translators: City.*/ __( 'Midlands', 'describr' ),
        4 => /*translators: City.*/ __( 'Quatre Bornes', 'describr' ),
        5 => /*translators: City.*/ __( 'Vacoas', 'describr' ),
      ),
    ),
    'GP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand Port District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bambous Virieux', 'describr' ),
        1 => /*translators: City.*/ __( 'Beau Vallon', 'describr' ),
        2 => /*translators: City.*/ __( 'Bois des Amourettes', 'describr' ),
        3 => /*translators: City.*/ __( 'Cluny', 'describr' ),
        4 => /*translators: City.*/ __( 'Grand Sable', 'describr' ),
        5 => /*translators: City.*/ __( 'Mahébourg', 'describr' ),
        6 => /*translators: City.*/ __( 'New Grove', 'describr' ),
        7 => /*translators: City.*/ __( 'Nouvelle France', 'describr' ),
        8 => /*translators: City.*/ __( 'Plaine Magnien', 'describr' ),
        9 => /*translators: City.*/ __( 'Rose Belle', 'describr' ),
        10 => /*translators: City.*/ __( 'Saint Hubert', 'describr' ),
      ),
    ),
  ),
  'MA' => 
  array (
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oriental', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ahfir', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Aaroui', 'describr' ),
        2 => /*translators: City.*/ __( 'Aïn Beni Mathar', 'describr' ),
        3 => /*translators: City.*/ __( 'Berkane', 'describr' ),
        4 => /*translators: City.*/ __( 'Bouarfa', 'describr' ),
        5 => /*translators: City.*/ __( 'Debdou', 'describr' ),
        6 => /*translators: City.*/ __( 'Driouch Province', 'describr' ),
        7 => /*translators: City.*/ __( 'El Aïoun', 'describr' ),
        8 => /*translators: City.*/ __( 'Figuig', 'describr' ),
        9 => /*translators: City.*/ __( 'Guercif Province', 'describr' ),
        10 => /*translators: City.*/ __( 'Jerada', 'describr' ),
        11 => /*translators: City.*/ __( 'Madagh', 'describr' ),
        12 => /*translators: City.*/ __( 'Midar', 'describr' ),
        13 => /*translators: City.*/ __( 'Nador', 'describr' ),
        14 => /*translators: City.*/ __( 'Oujda-Angad', 'describr' ),
        15 => /*translators: City.*/ __( 'Saidia', 'describr' ),
        16 => /*translators: City.*/ __( 'Selouane', 'describr' ),
        17 => /*translators: City.*/ __( 'Taourirt', 'describr' ),
        18 => /*translators: City.*/ __( 'Tiztoutine', 'describr' ),
        19 => /*translators: City.*/ __( 'Zaïo', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Drâa-Tafilalet', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agdz', 'describr' ),
        1 => /*translators: City.*/ __( 'Alnif', 'describr' ),
        2 => /*translators: City.*/ __( 'Aoufous', 'describr' ),
        3 => /*translators: City.*/ __( 'Arfoud', 'describr' ),
        4 => /*translators: City.*/ __( 'Errachidia', 'describr' ),
        5 => /*translators: City.*/ __( 'Imilchil', 'describr' ),
        6 => /*translators: City.*/ __( 'Jebel Tiskaouine', 'describr' ),
        7 => /*translators: City.*/ __( 'Jorf', 'describr' ),
        8 => /*translators: City.*/ __( 'Kelaat Mgouna', 'describr' ),
        9 => /*translators: City.*/ __( 'Mhamid', 'describr' ),
        10 => /*translators: City.*/ __( 'Midelt', 'describr' ),
        11 => /*translators: City.*/ __( 'Ouarzazat', 'describr' ),
        12 => /*translators: City.*/ __( 'Ouarzazate', 'describr' ),
        13 => /*translators: City.*/ __( 'Reçani', 'describr' ),
        14 => /*translators: City.*/ __( 'Taznakht', 'describr' ),
        15 => /*translators: City.*/ __( 'Telouet', 'describr' ),
        16 => /*translators: City.*/ __( 'Tinghir', 'describr' ),
        17 => /*translators: City.*/ __( 'Tinghir Province', 'describr' ),
        18 => /*translators: City.*/ __( 'Zagora', 'describr' ),
      ),
    ),
    'ASZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Assa-Zag Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agadir', 'describr' ),
        1 => /*translators: City.*/ __( 'Agadir Melloul', 'describr' ),
        2 => /*translators: City.*/ __( 'Agadir-Ida-ou-Tnan', 'describr' ),
        3 => /*translators: City.*/ __( 'Aoulouz', 'describr' ),
        4 => /*translators: City.*/ __( 'Aourir', 'describr' ),
        5 => /*translators: City.*/ __( 'Arazane', 'describr' ),
        6 => /*translators: City.*/ __( 'Argana', 'describr' ),
        7 => /*translators: City.*/ __( 'Bigoudine', 'describr' ),
        8 => /*translators: City.*/ __( 'Chtouka-Ait-Baha', 'describr' ),
        9 => /*translators: City.*/ __( 'Inezgane', 'describr' ),
        10 => /*translators: City.*/ __( 'Inezgane-Ait Melloul', 'describr' ),
        11 => /*translators: City.*/ __( 'Ouijjane', 'describr' ),
        12 => /*translators: City.*/ __( 'Oulad Teïma', 'describr' ),
        13 => /*translators: City.*/ __( 'Reggada', 'describr' ),
        14 => /*translators: City.*/ __( 'Sidi Ifni', 'describr' ),
        15 => /*translators: City.*/ __( 'Tadrart', 'describr' ),
        16 => /*translators: City.*/ __( 'Tafraout', 'describr' ),
        17 => /*translators: City.*/ __( 'Taghazout', 'describr' ),
        18 => /*translators: City.*/ __( 'Taliouine', 'describr' ),
        19 => /*translators: City.*/ __( 'Tamri', 'describr' ),
        20 => /*translators: City.*/ __( 'Tanalt', 'describr' ),
        21 => /*translators: City.*/ __( 'Taroudannt', 'describr' ),
        22 => /*translators: City.*/ __( 'Taroudant', 'describr' ),
        23 => /*translators: City.*/ __( 'Tarsouat', 'describr' ),
        24 => /*translators: City.*/ __( 'Tata', 'describr' ),
        25 => /*translators: City.*/ __( 'Tiznit', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Casablanca-Settat', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Azemmour', 'describr' ),
        1 => /*translators: City.*/ __( 'Benslimane', 'describr' ),
        2 => /*translators: City.*/ __( 'Berrechid', 'describr' ),
        3 => /*translators: City.*/ __( 'Berrechid Province', 'describr' ),
        4 => /*translators: City.*/ __( 'Boulaouane', 'describr' ),
        5 => /*translators: City.*/ __( 'Bouskoura', 'describr' ),
        6 => /*translators: City.*/ __( 'Bouznika', 'describr' ),
        7 => /*translators: City.*/ __( 'Casablanca', 'describr' ),
        8 => /*translators: City.*/ __( 'El Jadid', 'describr' ),
        9 => /*translators: City.*/ __( 'El-Jadida', 'describr' ),
        10 => /*translators: City.*/ __( 'Mediouna', 'describr' ),
        11 => /*translators: City.*/ __( 'Mohammedia', 'describr' ),
        12 => /*translators: City.*/ __( 'Nouaceur', 'describr' ),
        13 => /*translators: City.*/ __( 'Oualidia', 'describr' ),
        14 => /*translators: City.*/ __( 'Oulad Frej', 'describr' ),
        15 => /*translators: City.*/ __( 'Settat', 'describr' ),
        16 => /*translators: City.*/ __( 'Settat Province', 'describr' ),
        17 => /*translators: City.*/ __( 'Sidi Bennour', 'describr' ),
        18 => /*translators: City.*/ __( 'Sidi Smai&#039;il', 'describr' ),
        19 => /*translators: City.*/ __( 'Tit Mellil', 'describr' ),
        20 => /*translators: City.*/ __( 'Zawyat an Nwaçer', 'describr' ),
      ),
    ),
    'KEN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kénitra Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arbaoua', 'describr' ),
        1 => /*translators: City.*/ __( 'Had Kourt', 'describr' ),
        2 => /*translators: City.*/ __( 'Kenitra', 'describr' ),
        3 => /*translators: City.*/ __( 'Kenitra Province', 'describr' ),
        4 => /*translators: City.*/ __( 'Khemisset', 'describr' ),
        5 => /*translators: City.*/ __( 'Mechraa Bel Ksiri', 'describr' ),
        6 => /*translators: City.*/ __( 'Oulmes', 'describr' ),
        7 => /*translators: City.*/ __( 'Rabat', 'describr' ),
        8 => /*translators: City.*/ __( 'Sale', 'describr' ),
        9 => /*translators: City.*/ __( 'Sidi Bousber', 'describr' ),
        10 => /*translators: City.*/ __( 'Sidi Qacem', 'describr' ),
        11 => /*translators: City.*/ __( 'Sidi Redouane', 'describr' ),
        12 => /*translators: City.*/ __( 'Sidi Slimane', 'describr' ),
        13 => /*translators: City.*/ __( 'Sidi Yahia El Gharb', 'describr' ),
        14 => /*translators: City.*/ __( 'Sidi-Kacem', 'describr' ),
        15 => /*translators: City.*/ __( 'Skhirate', 'describr' ),
        16 => /*translators: City.*/ __( 'Skhirate-Temara', 'describr' ),
        17 => /*translators: City.*/ __( 'Souq Larb&#039;a al Gharb', 'describr' ),
        18 => /*translators: City.*/ __( 'Temara', 'describr' ),
        19 => /*translators: City.*/ __( 'Teroual', 'describr' ),
        20 => /*translators: City.*/ __( 'Tiflet', 'describr' ),
      ),
    ),
    'SAF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Safi Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abadou', 'describr' ),
        1 => /*translators: City.*/ __( 'Adassil', 'describr' ),
        2 => /*translators: City.*/ __( 'Al-Haouz', 'describr' ),
        3 => /*translators: City.*/ __( 'Bouabout', 'describr' ),
        4 => /*translators: City.*/ __( 'Chichaoua', 'describr' ),
        5 => /*translators: City.*/ __( 'Essaouira', 'describr' ),
        6 => /*translators: City.*/ __( 'Kelaa-Des-Sraghna', 'describr' ),
        7 => /*translators: City.*/ __( 'Marrakech', 'describr' ),
        8 => /*translators: City.*/ __( 'Marrakesh', 'describr' ),
        9 => /*translators: City.*/ __( 'Oukaïmedene', 'describr' ),
        10 => /*translators: City.*/ __( 'Rehamna', 'describr' ),
        11 => /*translators: City.*/ __( 'Safi', 'describr' ),
        12 => /*translators: City.*/ __( 'Setti Fatma', 'describr' ),
        13 => /*translators: City.*/ __( 'Sidi Rahhal', 'describr' ),
        14 => /*translators: City.*/ __( 'Smimou', 'describr' ),
        15 => /*translators: City.*/ __( 'Tamanar', 'describr' ),
        16 => /*translators: City.*/ __( 'Taouloukoult', 'describr' ),
        17 => /*translators: City.*/ __( 'Tidili Mesfioua', 'describr' ),
        18 => /*translators: City.*/ __( 'Timezgadiouine', 'describr' ),
        19 => /*translators: City.*/ __( 'Youssoufia', 'describr' ),
        20 => /*translators: City.*/ __( 'Zerkten', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fès-Meknès', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aknoul', 'describr' ),
        1 => /*translators: City.*/ __( 'Almis Marmoucha', 'describr' ),
        2 => /*translators: City.*/ __( 'Azrou', 'describr' ),
        3 => /*translators: City.*/ __( 'Aïn Leuh', 'describr' ),
        4 => /*translators: City.*/ __( 'Bhalil', 'describr' ),
        5 => /*translators: City.*/ __( 'Bouarouss', 'describr' ),
        6 => /*translators: City.*/ __( 'Boulemane', 'describr' ),
        7 => /*translators: City.*/ __( 'El Hajeb', 'describr' ),
        8 => /*translators: City.*/ __( 'El-Hajeb', 'describr' ),
        9 => /*translators: City.*/ __( 'Fes', 'describr' ),
        10 => /*translators: City.*/ __( 'Fès', 'describr' ),
        11 => /*translators: City.*/ __( 'Fès al Bali', 'describr' ),
        12 => /*translators: City.*/ __( 'Galaz', 'describr' ),
        13 => /*translators: City.*/ __( 'Ghouazi', 'describr' ),
        14 => /*translators: City.*/ __( 'Guercif', 'describr' ),
        15 => /*translators: City.*/ __( 'Ifrane', 'describr' ),
        16 => /*translators: City.*/ __( 'Meknes', 'describr' ),
        17 => /*translators: City.*/ __( 'Meknès', 'describr' ),
        18 => /*translators: City.*/ __( 'Missour', 'describr' ),
        19 => /*translators: City.*/ __( 'Moulay Bouchta', 'describr' ),
        20 => /*translators: City.*/ __( 'Moulay-Yacoub', 'describr' ),
        21 => /*translators: City.*/ __( 'Oued Amlil', 'describr' ),
        22 => /*translators: City.*/ __( 'Oulad Tayeb', 'describr' ),
        23 => /*translators: City.*/ __( 'Ourtzagh', 'describr' ),
        24 => /*translators: City.*/ __( 'Sefrou', 'describr' ),
        25 => /*translators: City.*/ __( 'Tahla', 'describr' ),
        26 => /*translators: City.*/ __( 'Talzemt', 'describr' ),
        27 => /*translators: City.*/ __( 'Taounate', 'describr' ),
        28 => /*translators: City.*/ __( 'Taza', 'describr' ),
        29 => /*translators: City.*/ __( 'Tmourghout', 'describr' ),
      ),
    ),
    'KHN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khénifra Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aguelmous', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Fqih Ben Çalah', 'describr' ),
        2 => /*translators: City.*/ __( 'Azilal', 'describr' ),
        3 => /*translators: City.*/ __( 'Azilal Province', 'describr' ),
        4 => /*translators: City.*/ __( 'Beni Mellal', 'describr' ),
        5 => /*translators: City.*/ __( 'Beni-Mellal', 'describr' ),
        6 => /*translators: City.*/ __( 'Boujniba', 'describr' ),
        7 => /*translators: City.*/ __( 'Bzou', 'describr' ),
        8 => /*translators: City.*/ __( 'Dar Ould Zidouh', 'describr' ),
        9 => /*translators: City.*/ __( 'Demnate', 'describr' ),
        10 => /*translators: City.*/ __( 'El Ksiba', 'describr' ),
        11 => /*translators: City.*/ __( 'Fquih Ben Salah Province', 'describr' ),
        12 => /*translators: City.*/ __( 'Ifrane', 'describr' ),
        13 => /*translators: City.*/ __( 'Isseksi', 'describr' ),
        14 => /*translators: City.*/ __( 'Itzer', 'describr' ),
        15 => /*translators: City.*/ __( 'Kasba Tadla', 'describr' ),
        16 => /*translators: City.*/ __( 'Kerrouchen', 'describr' ),
        17 => /*translators: City.*/ __( 'Khenifra', 'describr' ),
        18 => /*translators: City.*/ __( 'Khouribga', 'describr' ),
        19 => /*translators: City.*/ __( 'Khouribga Province', 'describr' ),
        20 => /*translators: City.*/ __( 'Midelt', 'describr' ),
        21 => /*translators: City.*/ __( 'Ouaoula', 'describr' ),
        22 => /*translators: City.*/ __( 'Oued Zem', 'describr' ),
        23 => /*translators: City.*/ __( 'Sidi Jaber', 'describr' ),
        24 => /*translators: City.*/ __( 'Timoulilt', 'describr' ),
        25 => /*translators: City.*/ __( 'Zawyat ech Cheïkh', 'describr' ),
      ),
    ),
    'OUD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oued Ed-Dahab Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aousserd', 'describr' ),
        1 => /*translators: City.*/ __( 'Imlili', 'describr' ),
        2 => /*translators: City.*/ __( 'Oued-Ed-Dahab', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tanger-Tétouan-Al Hoceïma', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Hoceïma', 'describr' ),
        1 => /*translators: City.*/ __( 'Al-Hoceima', 'describr' ),
        2 => /*translators: City.*/ __( 'Asilah', 'describr' ),
        3 => /*translators: City.*/ __( 'Bni Bouayach', 'describr' ),
        4 => /*translators: City.*/ __( 'Brikcha', 'describr' ),
        5 => /*translators: City.*/ __( 'Cap Negro II', 'describr' ),
        6 => /*translators: City.*/ __( 'Chefchaouen Province', 'describr' ),
        7 => /*translators: City.*/ __( 'Chefchaouene', 'describr' ),
        8 => /*translators: City.*/ __( 'Derdara', 'describr' ),
        9 => /*translators: City.*/ __( 'Fahs-Anjra', 'describr' ),
        10 => /*translators: City.*/ __( 'Fnidek', 'describr' ),
        11 => /*translators: City.*/ __( 'Imzouren', 'describr' ),
        12 => /*translators: City.*/ __( 'Ksar El Kebir', 'describr' ),
        13 => /*translators: City.*/ __( 'Larache', 'describr' ),
        14 => /*translators: City.*/ __( 'M&#039;Diq-Fnideq', 'describr' ),
        15 => /*translators: City.*/ __( 'Martil', 'describr' ),
        16 => /*translators: City.*/ __( 'Oued Laou', 'describr' ),
        17 => /*translators: City.*/ __( 'Ouezzane', 'describr' ),
        18 => /*translators: City.*/ __( 'Ouezzane Province', 'describr' ),
        19 => /*translators: City.*/ __( 'Senada', 'describr' ),
        20 => /*translators: City.*/ __( 'Tamorot', 'describr' ),
        21 => /*translators: City.*/ __( 'Tanger-Assilah', 'describr' ),
        22 => /*translators: City.*/ __( 'Tangier', 'describr' ),
        23 => /*translators: City.*/ __( 'Targuist', 'describr' ),
        24 => /*translators: City.*/ __( 'Tetouan', 'describr' ),
        25 => /*translators: City.*/ __( 'Tirhanimîne', 'describr' ),
        26 => /*translators: City.*/ __( 'Tétouan', 'describr' ),
        27 => /*translators: City.*/ __( 'Zinat', 'describr' ),
        28 => /*translators: City.*/ __( 'Zoumi', 'describr' ),
      ),
    ),
  ),
  'MZ' => 
  array (
    'P' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cabo Delgado Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chiure', 'describr' ),
        1 => /*translators: City.*/ __( 'Mocímboa', 'describr' ),
        2 => /*translators: City.*/ __( 'Montepuez', 'describr' ),
        3 => /*translators: City.*/ __( 'Pemba', 'describr' ),
      ),
    ),
    'Q' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Zambezia Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alto Molócuè', 'describr' ),
        1 => /*translators: City.*/ __( 'Chinde', 'describr' ),
        2 => /*translators: City.*/ __( 'Quelimane', 'describr' ),
      ),
    ),
    'G' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gaza Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chibuto', 'describr' ),
        1 => /*translators: City.*/ __( 'Chokwé', 'describr' ),
        2 => /*translators: City.*/ __( 'Macia', 'describr' ),
        3 => /*translators: City.*/ __( 'Xai-Xai', 'describr' ),
      ),
    ),
    'I' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Inhambane Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Inhambane', 'describr' ),
        1 => /*translators: City.*/ __( 'Maxixe', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sofala Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beira', 'describr' ),
        1 => /*translators: City.*/ __( 'Dondo', 'describr' ),
        2 => /*translators: City.*/ __( 'Nhamatanda District', 'describr' ),
      ),
    ),
    'L' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maputo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Boane District', 'describr' ),
        1 => /*translators: City.*/ __( 'Concelho de Matola', 'describr' ),
        2 => /*translators: City.*/ __( 'Magude District', 'describr' ),
        3 => /*translators: City.*/ __( 'Manhica', 'describr' ),
        4 => /*translators: City.*/ __( 'Marracuene District', 'describr' ),
        5 => /*translators: City.*/ __( 'Matola', 'describr' ),
        6 => /*translators: City.*/ __( 'Matutiune District', 'describr' ),
        7 => /*translators: City.*/ __( 'Moamba District', 'describr' ),
        8 => /*translators: City.*/ __( 'Namaacha District', 'describr' ),
        9 => /*translators: City.*/ __( 'Ressano Garcia', 'describr' ),
      ),
    ),
    'A' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Niassa Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cuamba', 'describr' ),
        1 => /*translators: City.*/ __( 'Lichinga', 'describr' ),
        2 => /*translators: City.*/ __( 'Mandimba', 'describr' ),
      ),
    ),
    'T' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tete Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tete', 'describr' ),
      ),
    ),
    'MPM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maputo', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'KaTembe', 'describr' ),
        1 => /*translators: City.*/ __( 'Maputo', 'describr' ),
      ),
    ),
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nampula Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'António Enes', 'describr' ),
        1 => /*translators: City.*/ __( 'Ilha de Moçambique', 'describr' ),
        2 => /*translators: City.*/ __( 'Mutuáli', 'describr' ),
        3 => /*translators: City.*/ __( 'Nacala', 'describr' ),
        4 => /*translators: City.*/ __( 'Nampula', 'describr' ),
      ),
    ),
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manica Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chimoio', 'describr' ),
      ),
    ),
  ),
  'MR' => 
  array (
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hodh Ech Chargui Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Néma', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brakna Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aleg', 'describr' ),
        1 => /*translators: City.*/ __( '&#039;Elb el Jmel', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gorgol Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kaédi', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Adrar Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Atar', 'describr' ),
        1 => /*translators: City.*/ __( 'Chingueṭṭi', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dakhlet Nouadhibou', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nouadhibou', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Trarza Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rosso', 'describr' ),
        1 => /*translators: City.*/ __( 'Tékane', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Assaba Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barkéwol', 'describr' ),
        1 => /*translators: City.*/ __( 'Kiffa', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hodh El Gharbi Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aioun', 'describr' ),
      ),
    ),
  ),
  'TT' => 
  array (
    'WTO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Western Tobago', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rio Claro', 'describr' ),
      ),
    ),
    'CTT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Couva-Tabaquite-Talparo Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Couva', 'describr' ),
        1 => /*translators: City.*/ __( 'Tabaquite', 'describr' ),
      ),
    ),
    'ETO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Eastern Tobago', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Scarborough', 'describr' ),
      ),
    ),
    'SJL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Juan-Laventille Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Laventille', 'describr' ),
      ),
    ),
    'TUP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tunapuna-Piarco Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arouca', 'describr' ),
        1 => /*translators: City.*/ __( 'Paradise', 'describr' ),
        2 => /*translators: City.*/ __( 'Tunapuna', 'describr' ),
      ),
    ),
    'SFO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Fernando', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Marabella', 'describr' ),
        1 => /*translators: City.*/ __( 'Mon Repos', 'describr' ),
        2 => /*translators: City.*/ __( 'San Fernando', 'describr' ),
      ),
    ),
    'PTF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Point Fortin', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Point Fortin', 'describr' ),
      ),
    ),
    'SGE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sangre Grande Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sangre Grande', 'describr' ),
      ),
    ),
    'ARI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Arima', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arima', 'describr' ),
      ),
    ),
    'POS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Port of Spain', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mucurapo', 'describr' ),
        1 => /*translators: City.*/ __( 'Port of Spain', 'describr' ),
      ),
    ),
    'SIP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Siparia Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Siparia', 'describr' ),
        1 => /*translators: City.*/ __( 'Ward of Siparia', 'describr' ),
      ),
    ),
    'PED' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Penal-Debe Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Debe', 'describr' ),
        1 => /*translators: City.*/ __( 'Peñal', 'describr' ),
      ),
    ),
    'CHA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chaguanas', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chaguanas', 'describr' ),
        1 => /*translators: City.*/ __( 'Ward of Chaguanas', 'describr' ),
      ),
    ),
    'DMN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Diego Martin Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Petit Valley', 'describr' ),
        1 => /*translators: City.*/ __( 'Ward of Diego Martin', 'describr' ),
      ),
    ),
    'PRT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Princes Town Regional Corporation', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Princes Town', 'describr' ),
      ),
    ),
  ),
  'TM' => 
  array (
    'M' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mary Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bayramaly', 'describr' ),
        1 => /*translators: City.*/ __( 'Mary', 'describr' ),
        2 => /*translators: City.*/ __( 'Serhetabat', 'describr' ),
        3 => /*translators: City.*/ __( 'Seydi', 'describr' ),
        4 => /*translators: City.*/ __( 'Yolöten', 'describr' ),
      ),
    ),
    'L' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lebap Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Atamyrat', 'describr' ),
        1 => /*translators: City.*/ __( 'Farap', 'describr' ),
        2 => /*translators: City.*/ __( 'Gazojak', 'describr' ),
        3 => /*translators: City.*/ __( 'Gowurdak', 'describr' ),
        4 => /*translators: City.*/ __( 'Saýat', 'describr' ),
        5 => /*translators: City.*/ __( 'Türkmenabat', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ashgabat', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ashgabat', 'describr' ),
      ),
    ),
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balkan Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balkanabat', 'describr' ),
        1 => /*translators: City.*/ __( 'Bereket', 'describr' ),
        2 => /*translators: City.*/ __( 'Gumdag', 'describr' ),
        3 => /*translators: City.*/ __( 'Magtymguly', 'describr' ),
        4 => /*translators: City.*/ __( 'Serdar', 'describr' ),
        5 => /*translators: City.*/ __( 'Türkmenbaşy', 'describr' ),
      ),
    ),
    'D' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Daşoguz Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Akdepe', 'describr' ),
        1 => /*translators: City.*/ __( 'Boldumsaz', 'describr' ),
        2 => /*translators: City.*/ __( 'Daşoguz', 'describr' ),
        3 => /*translators: City.*/ __( 'Köneürgench', 'describr' ),
        4 => /*translators: City.*/ __( 'Tagta', 'describr' ),
        5 => /*translators: City.*/ __( 'Yylanly', 'describr' ),
      ),
    ),
    'A' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ahal Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abadan', 'describr' ),
        1 => /*translators: City.*/ __( 'Annau', 'describr' ),
        2 => /*translators: City.*/ __( 'Arçabil', 'describr' ),
        3 => /*translators: City.*/ __( 'Baharly', 'describr' ),
        4 => /*translators: City.*/ __( 'Kaka', 'describr' ),
        5 => /*translators: City.*/ __( 'Tejen', 'describr' ),
      ),
    ),
  ),
  'BO' => 
  array (
    'B' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beni Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Guayaramerín', 'describr' ),
        1 => /*translators: City.*/ __( 'Provincia Cercado', 'describr' ),
        2 => /*translators: City.*/ __( 'Provincia General José Ballivián', 'describr' ),
        3 => /*translators: City.*/ __( 'Provincia Iténez', 'describr' ),
        4 => /*translators: City.*/ __( 'Provincia Mamoré', 'describr' ),
        5 => /*translators: City.*/ __( 'Provincia Marbán', 'describr' ),
        6 => /*translators: City.*/ __( 'Provincia Moxos', 'describr' ),
        7 => /*translators: City.*/ __( 'Provincia Vaca Diez', 'describr' ),
        8 => /*translators: City.*/ __( 'Provincia Yacuma', 'describr' ),
        9 => /*translators: City.*/ __( 'Reyes', 'describr' ),
        10 => /*translators: City.*/ __( 'Riberalta', 'describr' ),
        11 => /*translators: City.*/ __( 'Rurrenabaque', 'describr' ),
        12 => /*translators: City.*/ __( 'San Borja', 'describr' ),
        13 => /*translators: City.*/ __( 'San Ramón', 'describr' ),
        14 => /*translators: City.*/ __( 'Santa Ana de Yacuma', 'describr' ),
        15 => /*translators: City.*/ __( 'Santa Rosa', 'describr' ),
        16 => /*translators: City.*/ __( 'Trinidad', 'describr' ),
      ),
    ),
    'O' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Oruro Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Challapata', 'describr' ),
        1 => /*translators: City.*/ __( 'Huanuni', 'describr' ),
        2 => /*translators: City.*/ __( 'Litoral de Atacama', 'describr' ),
        3 => /*translators: City.*/ __( 'Machacamarca', 'describr' ),
        4 => /*translators: City.*/ __( 'Nor Carangas Province', 'describr' ),
        5 => /*translators: City.*/ __( 'Oruro', 'describr' ),
        6 => /*translators: City.*/ __( 'Poopó', 'describr' ),
        7 => /*translators: City.*/ __( 'Provincia Avaroa', 'describr' ),
        8 => /*translators: City.*/ __( 'Provincia Carangas', 'describr' ),
        9 => /*translators: City.*/ __( 'Provincia Cercado', 'describr' ),
        10 => /*translators: City.*/ __( 'Provincia Ladislao Cabrera', 'describr' ),
        11 => /*translators: City.*/ __( 'Provincia Pantaleón Dalence', 'describr' ),
        12 => /*translators: City.*/ __( 'Provincia Poopó', 'describr' ),
        13 => /*translators: City.*/ __( 'Provincia Sabaya', 'describr' ),
        14 => /*translators: City.*/ __( 'Provincia Sajama', 'describr' ),
        15 => /*translators: City.*/ __( 'Provincia San Pedro de Totora', 'describr' ),
        16 => /*translators: City.*/ __( 'Provincia Saucari', 'describr' ),
        17 => /*translators: City.*/ __( 'Provincia Tomás Barron', 'describr' ),
        18 => /*translators: City.*/ __( 'Puerto de Mejillones', 'describr' ),
        19 => /*translators: City.*/ __( 'Sebastian Pagador Province', 'describr' ),
        20 => /*translators: City.*/ __( 'Sud Carangas Province', 'describr' ),
        21 => /*translators: City.*/ __( 'Totoral', 'describr' ),
      ),
    ),
    'S' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Santa Cruz Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abapó', 'describr' ),
        1 => /*translators: City.*/ __( 'Ascención de Guarayos', 'describr' ),
        2 => /*translators: City.*/ __( 'Ascensión', 'describr' ),
        3 => /*translators: City.*/ __( 'Boyuibe', 'describr' ),
        4 => /*translators: City.*/ __( 'Buena Vista', 'describr' ),
        5 => /*translators: City.*/ __( 'Camiri', 'describr' ),
        6 => /*translators: City.*/ __( 'Charagua', 'describr' ),
        7 => /*translators: City.*/ __( 'Comarapa', 'describr' ),
        8 => /*translators: City.*/ __( 'Concepción', 'describr' ),
        9 => /*translators: City.*/ __( 'Cotoca', 'describr' ),
        10 => /*translators: City.*/ __( 'German Busch', 'describr' ),
        11 => /*translators: City.*/ __( 'Guarayos', 'describr' ),
        12 => /*translators: City.*/ __( 'Jorochito', 'describr' ),
        13 => /*translators: City.*/ __( 'La Bélgica', 'describr' ),
        14 => /*translators: City.*/ __( 'Limoncito', 'describr' ),
        15 => /*translators: City.*/ __( 'Los Negros', 'describr' ),
        16 => /*translators: City.*/ __( 'Mairana', 'describr' ),
        17 => /*translators: City.*/ __( 'Mineros', 'describr' ),
        18 => /*translators: City.*/ __( 'Montero', 'describr' ),
        19 => /*translators: City.*/ __( 'Okinawa Número Uno', 'describr' ),
        20 => /*translators: City.*/ __( 'Pailón', 'describr' ),
        21 => /*translators: City.*/ __( 'Paurito', 'describr' ),
        22 => /*translators: City.*/ __( 'Portachuelo', 'describr' ),
        23 => /*translators: City.*/ __( 'Provincia Andrés Ibáñez', 'describr' ),
        24 => /*translators: City.*/ __( 'Provincia Chiquitos', 'describr' ),
        25 => /*translators: City.*/ __( 'Provincia Cordillera', 'describr' ),
        26 => /*translators: City.*/ __( 'Provincia Florida', 'describr' ),
        27 => /*translators: City.*/ __( 'Provincia Ichilo', 'describr' ),
        28 => /*translators: City.*/ __( 'Provincia Manuel María Caballero', 'describr' ),
        29 => /*translators: City.*/ __( 'Provincia Santiesteban', 'describr' ),
        30 => /*translators: City.*/ __( 'Provincia Sara', 'describr' ),
        31 => /*translators: City.*/ __( 'Provincia Vallegrande', 'describr' ),
        32 => /*translators: City.*/ __( 'Provincia Velasco', 'describr' ),
        33 => /*translators: City.*/ __( 'Provincia Warnes', 'describr' ),
        34 => /*translators: City.*/ __( 'Provincia Ángel Sandoval', 'describr' ),
        35 => /*translators: City.*/ __( 'Provincia Ñuflo de Chávez', 'describr' ),
        36 => /*translators: City.*/ __( 'Puerto Quijarro', 'describr' ),
        37 => /*translators: City.*/ __( 'Puesto de Pailas', 'describr' ),
        38 => /*translators: City.*/ __( 'Roboré', 'describr' ),
        39 => /*translators: City.*/ __( 'Samaipata', 'describr' ),
        40 => /*translators: City.*/ __( 'San Carlos', 'describr' ),
        41 => /*translators: City.*/ __( 'San Ignacio de Velasco', 'describr' ),
        42 => /*translators: City.*/ __( 'San Juan del Surutú', 'describr' ),
        43 => /*translators: City.*/ __( 'San Julian', 'describr' ),
        44 => /*translators: City.*/ __( 'San Matías', 'describr' ),
        45 => /*translators: City.*/ __( 'San Pedro', 'describr' ),
        46 => /*translators: City.*/ __( 'Santa Cruz de la Sierra', 'describr' ),
        47 => /*translators: City.*/ __( 'Santa Rita', 'describr' ),
        48 => /*translators: City.*/ __( 'Santa Rosa del Sara', 'describr' ),
        49 => /*translators: City.*/ __( 'Santiago del Torno', 'describr' ),
        50 => /*translators: City.*/ __( 'Urubichá', 'describr' ),
        51 => /*translators: City.*/ __( 'Vallegrande', 'describr' ),
        52 => /*translators: City.*/ __( 'Villa Yapacaní', 'describr' ),
        53 => /*translators: City.*/ __( 'Warnes', 'describr' ),
      ),
    ),
    'T' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tarija Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bermejo', 'describr' ),
        1 => /*translators: City.*/ __( 'Entre Ríos', 'describr' ),
        2 => /*translators: City.*/ __( 'Provincia Arce', 'describr' ),
        3 => /*translators: City.*/ __( 'Provincia Avilez', 'describr' ),
        4 => /*translators: City.*/ __( 'Provincia Cercado', 'describr' ),
        5 => /*translators: City.*/ __( 'Provincia Gran Chaco', 'describr' ),
        6 => /*translators: City.*/ __( 'Provincia Méndez', 'describr' ),
        7 => /*translators: City.*/ __( 'Provincia O&#039;Connor', 'describr' ),
        8 => /*translators: City.*/ __( 'Tarija', 'describr' ),
        9 => /*translators: City.*/ __( 'Villamontes', 'describr' ),
        10 => /*translators: City.*/ __( 'Yacuiba', 'describr' ),
      ),
    ),
    'N' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pando Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cobija', 'describr' ),
        1 => /*translators: City.*/ __( 'Provincia Abuná', 'describr' ),
        2 => /*translators: City.*/ __( 'Provincia General Federico Román', 'describr' ),
        3 => /*translators: City.*/ __( 'Provincia Madre de Dios', 'describr' ),
        4 => /*translators: City.*/ __( 'Provincia Manuripi', 'describr' ),
        5 => /*translators: City.*/ __( 'Provincia Nicolás Suárez', 'describr' ),
      ),
    ),
    'L' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Paz Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Achacachi', 'describr' ),
        1 => /*translators: City.*/ __( 'Amarete', 'describr' ),
        2 => /*translators: City.*/ __( 'Batallas', 'describr' ),
        3 => /*translators: City.*/ __( 'Caranavi', 'describr' ),
        4 => /*translators: City.*/ __( 'Chulumani', 'describr' ),
        5 => /*translators: City.*/ __( 'Colquiri', 'describr' ),
        6 => /*translators: City.*/ __( 'Coripata', 'describr' ),
        7 => /*translators: City.*/ __( 'Coroico', 'describr' ),
        8 => /*translators: City.*/ __( 'Curahuara de Carangas', 'describr' ),
        9 => /*translators: City.*/ __( 'Eucaliptus', 'describr' ),
        10 => /*translators: City.*/ __( 'Guanay', 'describr' ),
        11 => /*translators: City.*/ __( 'Huarina', 'describr' ),
        12 => /*translators: City.*/ __( 'Huatajata', 'describr' ),
        13 => /*translators: City.*/ __( 'José Manuel Pando', 'describr' ),
        14 => /*translators: City.*/ __( 'La Paz', 'describr' ),
        15 => /*translators: City.*/ __( 'Lahuachaca', 'describr' ),
        16 => /*translators: City.*/ __( 'Mapiri', 'describr' ),
        17 => /*translators: City.*/ __( 'Patacamaya', 'describr' ),
        18 => /*translators: City.*/ __( 'Provincia Aroma', 'describr' ),
        19 => /*translators: City.*/ __( 'Provincia Bautista Saavedra', 'describr' ),
        20 => /*translators: City.*/ __( 'Provincia Camacho', 'describr' ),
        21 => /*translators: City.*/ __( 'Provincia Franz Tamayo', 'describr' ),
        22 => /*translators: City.*/ __( 'Provincia Gualberto Villarroel', 'describr' ),
        23 => /*translators: City.*/ __( 'Provincia Ingavi', 'describr' ),
        24 => /*translators: City.*/ __( 'Provincia Inquisivi', 'describr' ),
        25 => /*translators: City.*/ __( 'Provincia Iturralde', 'describr' ),
        26 => /*translators: City.*/ __( 'Provincia Larecaja', 'describr' ),
        27 => /*translators: City.*/ __( 'Provincia Loayza', 'describr' ),
        28 => /*translators: City.*/ __( 'Provincia Los Andes', 'describr' ),
        29 => /*translators: City.*/ __( 'Provincia Manco Kapac', 'describr' ),
        30 => /*translators: City.*/ __( 'Provincia Murillo', 'describr' ),
        31 => /*translators: City.*/ __( 'Provincia Muñecas', 'describr' ),
        32 => /*translators: City.*/ __( 'Provincia Nor Yungas', 'describr' ),
        33 => /*translators: City.*/ __( 'Provincia Omasuyos', 'describr' ),
        34 => /*translators: City.*/ __( 'Provincia Pacajes', 'describr' ),
        35 => /*translators: City.*/ __( 'Provincia Sud Yungas', 'describr' ),
        36 => /*translators: City.*/ __( 'Quime', 'describr' ),
        37 => /*translators: City.*/ __( 'San Pablo', 'describr' ),
        38 => /*translators: City.*/ __( 'San Pedro', 'describr' ),
        39 => /*translators: City.*/ __( 'Sorata', 'describr' ),
        40 => /*translators: City.*/ __( 'Tiahuanaco', 'describr' ),
        41 => /*translators: City.*/ __( 'Viloco', 'describr' ),
        42 => /*translators: City.*/ __( 'Yumani', 'describr' ),
      ),
    ),
    'C' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cochabamba Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aiquile', 'describr' ),
        1 => /*translators: City.*/ __( 'Arani', 'describr' ),
        2 => /*translators: City.*/ __( 'Bolivar', 'describr' ),
        3 => /*translators: City.*/ __( 'Capinota', 'describr' ),
        4 => /*translators: City.*/ __( 'Chimoré', 'describr' ),
        5 => /*translators: City.*/ __( 'Cliza', 'describr' ),
        6 => /*translators: City.*/ __( 'Cochabamba', 'describr' ),
        7 => /*translators: City.*/ __( 'Colchani', 'describr' ),
        8 => /*translators: City.*/ __( 'Colomi', 'describr' ),
        9 => /*translators: City.*/ __( 'Independencia', 'describr' ),
        10 => /*translators: City.*/ __( 'Irpa Irpa', 'describr' ),
        11 => /*translators: City.*/ __( 'Mizque', 'describr' ),
        12 => /*translators: City.*/ __( 'Provincia Arani', 'describr' ),
        13 => /*translators: City.*/ __( 'Provincia Arque', 'describr' ),
        14 => /*translators: City.*/ __( 'Provincia Ayopaya', 'describr' ),
        15 => /*translators: City.*/ __( 'Provincia Campero', 'describr' ),
        16 => /*translators: City.*/ __( 'Provincia Capinota', 'describr' ),
        17 => /*translators: City.*/ __( 'Provincia Carrasco', 'describr' ),
        18 => /*translators: City.*/ __( 'Provincia Cercado', 'describr' ),
        19 => /*translators: City.*/ __( 'Provincia Chaparé', 'describr' ),
        20 => /*translators: City.*/ __( 'Provincia Esteban Arce', 'describr' ),
        21 => /*translators: City.*/ __( 'Provincia Germán Jordán', 'describr' ),
        22 => /*translators: City.*/ __( 'Provincia Mizque', 'describr' ),
        23 => /*translators: City.*/ __( 'Provincia Punata', 'describr' ),
        24 => /*translators: City.*/ __( 'Provincia Quillacollo', 'describr' ),
        25 => /*translators: City.*/ __( 'Provincia Tapacarí', 'describr' ),
        26 => /*translators: City.*/ __( 'Punata', 'describr' ),
        27 => /*translators: City.*/ __( 'Quillacollo', 'describr' ),
        28 => /*translators: City.*/ __( 'Sacaba', 'describr' ),
        29 => /*translators: City.*/ __( 'Sipe Sipe', 'describr' ),
        30 => /*translators: City.*/ __( 'Tarata', 'describr' ),
        31 => /*translators: City.*/ __( 'Tiquipaya', 'describr' ),
        32 => /*translators: City.*/ __( 'Tiraque Province', 'describr' ),
        33 => /*translators: City.*/ __( 'Totora', 'describr' ),
      ),
    ),
    'H' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chuquisaca Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camargo', 'describr' ),
        1 => /*translators: City.*/ __( 'Monteagudo', 'describr' ),
        2 => /*translators: City.*/ __( 'Padilla', 'describr' ),
        3 => /*translators: City.*/ __( 'Provincia Azurduy', 'describr' ),
        4 => /*translators: City.*/ __( 'Provincia Belisario Boeto', 'describr' ),
        5 => /*translators: City.*/ __( 'Provincia Hernando Siles', 'describr' ),
        6 => /*translators: City.*/ __( 'Provincia Luis Calvo', 'describr' ),
        7 => /*translators: City.*/ __( 'Provincia Nor Cinti', 'describr' ),
        8 => /*translators: City.*/ __( 'Provincia Oropeza', 'describr' ),
        9 => /*translators: City.*/ __( 'Provincia Sud Cinti', 'describr' ),
        10 => /*translators: City.*/ __( 'Provincia Tomina', 'describr' ),
        11 => /*translators: City.*/ __( 'Provincia Yamparáez', 'describr' ),
        12 => /*translators: City.*/ __( 'Provincia Zudáñez', 'describr' ),
        13 => /*translators: City.*/ __( 'Sucre', 'describr' ),
        14 => /*translators: City.*/ __( 'Tarabuco', 'describr' ),
      ),
    ),
    'P' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Potosí Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Atocha', 'describr' ),
        1 => /*translators: City.*/ __( 'Betanzos', 'describr' ),
        2 => /*translators: City.*/ __( 'Colchani', 'describr' ),
        3 => /*translators: City.*/ __( 'Colquechaca', 'describr' ),
        4 => /*translators: City.*/ __( 'Enrique Baldivieso', 'describr' ),
        5 => /*translators: City.*/ __( 'Llallagua', 'describr' ),
        6 => /*translators: City.*/ __( 'Potosí', 'describr' ),
        7 => /*translators: City.*/ __( 'Provincia Alonzo de Ibáñez', 'describr' ),
        8 => /*translators: City.*/ __( 'Provincia Charcas', 'describr' ),
        9 => /*translators: City.*/ __( 'Provincia Chayanta', 'describr' ),
        10 => /*translators: City.*/ __( 'Provincia Daniel Campos', 'describr' ),
        11 => /*translators: City.*/ __( 'Provincia General Bilbao', 'describr' ),
        12 => /*translators: City.*/ __( 'Provincia Linares', 'describr' ),
        13 => /*translators: City.*/ __( 'Provincia Modesto Omiste', 'describr' ),
        14 => /*translators: City.*/ __( 'Provincia Nor Chichas', 'describr' ),
        15 => /*translators: City.*/ __( 'Provincia Nor Lípez', 'describr' ),
        16 => /*translators: City.*/ __( 'Provincia Quijarro', 'describr' ),
        17 => /*translators: City.*/ __( 'Provincia Rafael Bustillo', 'describr' ),
        18 => /*translators: City.*/ __( 'Provincia Saavedra', 'describr' ),
        19 => /*translators: City.*/ __( 'Provincia Sud Chichas', 'describr' ),
        20 => /*translators: City.*/ __( 'Provincia Sud Lípez', 'describr' ),
        21 => /*translators: City.*/ __( 'Provincia Tomás Frías', 'describr' ),
        22 => /*translators: City.*/ __( 'Santa Bárbara', 'describr' ),
        23 => /*translators: City.*/ __( 'Tupiza', 'describr' ),
        24 => /*translators: City.*/ __( 'Uyuni', 'describr' ),
        25 => /*translators: City.*/ __( 'Villazón', 'describr' ),
      ),
    ),
  ),
  'VC' => 
  array (
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint George Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kingstown', 'describr' ),
        1 => /*translators: City.*/ __( 'Kingstown Park', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Patrick Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barrouallie', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Andrew Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Layou', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint David Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chateaubelair', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grenadines Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Port Elizabeth', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Charlotte Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Biabou', 'describr' ),
        1 => /*translators: City.*/ __( 'Byera Village', 'describr' ),
        2 => /*translators: City.*/ __( 'Georgetown', 'describr' ),
      ),
    ),
  ),
  'AE' => 
  array (
    'SH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sharjah Emirate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adh Dhayd', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Batayih', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Hamriyah', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Madam', 'describr' ),
        4 => /*translators: City.*/ __( 'Dhaid', 'describr' ),
        5 => /*translators: City.*/ __( 'Dibba Al Hesn', 'describr' ),
        6 => /*translators: City.*/ __( 'Kalba', 'describr' ),
        7 => /*translators: City.*/ __( 'Khawr Fakkān', 'describr' ),
        8 => /*translators: City.*/ __( 'Khor Fakkan', 'describr' ),
        9 => /*translators: City.*/ __( 'Milehah', 'describr' ),
        10 => /*translators: City.*/ __( 'Murbaḩ', 'describr' ),
        11 => /*translators: City.*/ __( 'Sharjah', 'describr' ),
      ),
    ),
    'DU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dubai', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dubai', 'describr' ),
      ),
    ),
    'UQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Umm al-Quwain', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Umm AL Quwain', 'describr' ),
        1 => /*translators: City.*/ __( 'Umm Al Quwain City', 'describr' ),
      ),
    ),
    'FU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fujairah', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Al Fujairah City', 'describr' ),
        1 => /*translators: City.*/ __( 'Al Fujairah Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Dibba Al Fujairah Municipality', 'describr' ),
        3 => /*translators: City.*/ __( 'Dibba Al-Fujairah', 'describr' ),
        4 => /*translators: City.*/ __( 'Dibba Al-Hisn', 'describr' ),
        5 => /*translators: City.*/ __( 'Reef Al Fujairah City', 'describr' ),
      ),
    ),
    'RK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ras al-Khaimah', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ras Al Khaimah', 'describr' ),
        1 => /*translators: City.*/ __( 'Ras Al Khaimah City', 'describr' ),
      ),
    ),
    'AJ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ajman Emirate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajman', 'describr' ),
        1 => /*translators: City.*/ __( 'Ajman City', 'describr' ),
        2 => /*translators: City.*/ __( 'Manama', 'describr' ),
        3 => /*translators: City.*/ __( 'Masfout', 'describr' ),
      ),
    ),
    'AZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Abu Dhabi Emirate', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abu Dhabi Island and Internal Islands City', 'describr' ),
        1 => /*translators: City.*/ __( 'Abu Dhabi Municipality', 'describr' ),
        2 => /*translators: City.*/ __( 'Al Ain City', 'describr' ),
        3 => /*translators: City.*/ __( 'Al Ain Municipality', 'describr' ),
        4 => /*translators: City.*/ __( 'Al Dhafra', 'describr' ),
        5 => /*translators: City.*/ __( 'Al Shamkhah City', 'describr' ),
        6 => /*translators: City.*/ __( 'Ar Ruways', 'describr' ),
        7 => /*translators: City.*/ __( 'Bani Yas City', 'describr' ),
        8 => /*translators: City.*/ __( 'Khalifah A City', 'describr' ),
        9 => /*translators: City.*/ __( 'Musaffah', 'describr' ),
        10 => /*translators: City.*/ __( 'Muzayri&#039;', 'describr' ),
        11 => /*translators: City.*/ __( 'Zayed City', 'describr' ),
      ),
    ),
  ),
  'TJ' => 
  array (
    'RA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Districts of Republican Subordination', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Darband', 'describr' ),
        1 => /*translators: City.*/ __( 'Hisor', 'describr' ),
        2 => /*translators: City.*/ __( 'Karakenja', 'describr' ),
        3 => /*translators: City.*/ __( 'Khodzha-Maston', 'describr' ),
        4 => /*translators: City.*/ __( 'Novobod', 'describr' ),
        5 => /*translators: City.*/ __( 'Obigarm', 'describr' ),
        6 => /*translators: City.*/ __( 'Rasht', 'describr' ),
        7 => /*translators: City.*/ __( 'Roghun', 'describr' ),
        8 => /*translators: City.*/ __( 'Shahrinav', 'describr' ),
        9 => /*translators: City.*/ __( 'Tagob', 'describr' ),
        10 => /*translators: City.*/ __( 'Tursunzoda', 'describr' ),
        11 => /*translators: City.*/ __( 'Vahdat', 'describr' ),
        12 => /*translators: City.*/ __( 'Vahdat District', 'describr' ),
        13 => /*translators: City.*/ __( 'Varzob', 'describr' ),
        14 => /*translators: City.*/ __( 'Varzob District', 'describr' ),
      ),
    ),
    'KT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Khatlon Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Abdurahmoni Jomí', 'describr' ),
        1 => /*translators: City.*/ __( 'Boshchorbogh', 'describr' ),
        2 => /*translators: City.*/ __( 'Bŭstonqal&#039;a', 'describr' ),
        3 => /*translators: City.*/ __( 'Chubek', 'describr' ),
        4 => /*translators: City.*/ __( 'Danghara', 'describr' ),
        5 => /*translators: City.*/ __( 'Dŭstí', 'describr' ),
        6 => /*translators: City.*/ __( 'Farkhor', 'describr' ),
        7 => /*translators: City.*/ __( 'Gharavŭtí', 'describr' ),
        8 => /*translators: City.*/ __( 'Jilikŭl', 'describr' ),
        9 => /*translators: City.*/ __( 'Kirov', 'describr' ),
        10 => /*translators: City.*/ __( 'Kolkhozobod', 'describr' ),
        11 => /*translators: City.*/ __( 'Kŭlob', 'describr' ),
        12 => /*translators: City.*/ __( 'Moskovskiy', 'describr' ),
        13 => /*translators: City.*/ __( 'Mŭ&#039;minobod', 'describr' ),
        14 => /*translators: City.*/ __( 'Nohiyai Kolkhozobod', 'describr' ),
        15 => /*translators: City.*/ __( 'Nohiyai Panj', 'describr' ),
        16 => /*translators: City.*/ __( 'Nohiyai Vakhsh', 'describr' ),
        17 => /*translators: City.*/ __( 'Norak', 'describr' ),
        18 => /*translators: City.*/ __( 'Orzu', 'describr' ),
        19 => /*translators: City.*/ __( 'Panj', 'describr' ),
        20 => /*translators: City.*/ __( 'Qŭrghonteppa', 'describr' ),
        21 => /*translators: City.*/ __( 'Shahritus', 'describr' ),
        22 => /*translators: City.*/ __( 'Sovet', 'describr' ),
        23 => /*translators: City.*/ __( 'Tartiki', 'describr' ),
        24 => /*translators: City.*/ __( 'Vakhsh', 'describr' ),
        25 => /*translators: City.*/ __( 'Vose&#039;', 'describr' ),
        26 => /*translators: City.*/ __( 'Yovon', 'describr' ),
      ),
    ),
    'GB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gorno-Badakhshan Autonomous Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ishqoshim', 'describr' ),
        1 => /*translators: City.*/ __( 'Khorugh', 'describr' ),
        2 => /*translators: City.*/ __( 'Murghob', 'describr' ),
        3 => /*translators: City.*/ __( 'Nohiyai Shughnon', 'describr' ),
      ),
    ),
    'SU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sughd Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adrasmon', 'describr' ),
        1 => /*translators: City.*/ __( 'Ayní', 'describr' ),
        2 => /*translators: City.*/ __( 'Bŭston', 'describr' ),
        3 => /*translators: City.*/ __( 'Chkalov', 'describr' ),
        4 => /*translators: City.*/ __( 'Ghafurov', 'describr' ),
        5 => /*translators: City.*/ __( 'Isfara', 'describr' ),
        6 => /*translators: City.*/ __( 'Istaravshan', 'describr' ),
        7 => /*translators: City.*/ __( 'Khŭjand', 'describr' ),
        8 => /*translators: City.*/ __( 'Kim', 'describr' ),
        9 => /*translators: City.*/ __( 'Konibodom', 'describr' ),
        10 => /*translators: City.*/ __( 'Konsoy', 'describr' ),
        11 => /*translators: City.*/ __( 'Neftobod', 'describr' ),
        12 => /*translators: City.*/ __( 'Nohiyai Konibodom', 'describr' ),
        13 => /*translators: City.*/ __( 'Nov', 'describr' ),
        14 => /*translators: City.*/ __( 'Oltintopkan', 'describr' ),
        15 => /*translators: City.*/ __( 'Pakhtakoron', 'describr' ),
        16 => /*translators: City.*/ __( 'Palos', 'describr' ),
        17 => /*translators: City.*/ __( 'Panjakent', 'describr' ),
        18 => /*translators: City.*/ __( 'Proletar', 'describr' ),
        19 => /*translators: City.*/ __( 'Quruqsoy', 'describr' ),
        20 => /*translators: City.*/ __( 'Shaydon', 'describr' ),
        21 => /*translators: City.*/ __( 'Shŭrob', 'describr' ),
        22 => /*translators: City.*/ __( 'Taboshar', 'describr' ),
        23 => /*translators: City.*/ __( 'Vorukh', 'describr' ),
      ),
    ),
  ),
  'TW' => 
  array (
    'ILA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yilan County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Yilan', 'describr' ),
      ),
    ),
    'PEN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Penghu County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Magong', 'describr' ),
        1 => /*translators: City.*/ __( 'Penghu County', 'describr' ),
      ),
    ),
    'CHA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Changhua County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Changhua', 'describr' ),
        1 => /*translators: City.*/ __( 'Yuanlin', 'describr' ),
      ),
    ),
    'PIF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pingtung County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Donggang', 'describr' ),
        1 => /*translators: City.*/ __( 'Hengchun', 'describr' ),
        2 => /*translators: City.*/ __( 'Pingtung', 'describr' ),
      ),
    ),
    'TXG' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taichung', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Taichung', 'describr' ),
        1 => /*translators: City.*/ __( 'Taichung City', 'describr' ),
      ),
    ),
    'NAN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nantou County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lugu', 'describr' ),
        1 => /*translators: City.*/ __( 'Nantou', 'describr' ),
        2 => /*translators: City.*/ __( 'Puli', 'describr' ),
        3 => /*translators: City.*/ __( 'Zhongxing New Village', 'describr' ),
      ),
    ),
    'CYI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chiayi County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chiayi', 'describr' ),
        1 => /*translators: City.*/ __( 'Pizitou', 'describr' ),
      ),
    ),
    'TTT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taitung County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Taitung', 'describr' ),
        1 => /*translators: City.*/ __( 'Taitung City', 'describr' ),
      ),
    ),
    'HUA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hualien County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hualien', 'describr' ),
        1 => /*translators: City.*/ __( 'Hualien City', 'describr' ),
      ),
    ),
    'KHH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kaohsiung', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kaohsiung', 'describr' ),
      ),
    ),
    'MIA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Miaoli County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Miaoli', 'describr' ),
      ),
    ),
    'KIN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kinmen', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jincheng', 'describr' ),
        1 => /*translators: City.*/ __( 'Kinmen County', 'describr' ),
      ),
    ),
    'YUN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yunlin County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Douliu', 'describr' ),
        1 => /*translators: City.*/ __( 'Yunlin', 'describr' ),
      ),
    ),
    'HSZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hsinchu', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hsinchu County', 'describr' ),
      ),
    ),
    'CYQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chiayi City', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chiayi County', 'describr' ),
      ),
    ),
    'TAO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taoyuan City', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Daxi', 'describr' ),
        1 => /*translators: City.*/ __( 'Taoyuan', 'describr' ),
        2 => /*translators: City.*/ __( 'Taoyuan City', 'describr' ),
      ),
    ),
    'LIE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lienchiang County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lienchiang', 'describr' ),
        1 => /*translators: City.*/ __( 'Nangan', 'describr' ),
      ),
    ),
    'TNN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tainan', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tainan', 'describr' ),
        1 => /*translators: City.*/ __( 'Yujing', 'describr' ),
      ),
    ),
    'TPE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taipei', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banqiao', 'describr' ),
        1 => /*translators: City.*/ __( 'Jiufen', 'describr' ),
        2 => /*translators: City.*/ __( 'Taipei', 'describr' ),
        3 => /*translators: City.*/ __( 'Taipei City', 'describr' ),
      ),
    ),
    'HSQ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hsinchu County', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hsinchu', 'describr' ),
      ),
    ),
  ),
  'ER' => 
  array (
    'SK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northern Red Sea Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Massawa', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anseba Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Keren', 'describr' ),
      ),
    ),
    'MA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maekel Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Asmara', 'describr' ),
      ),
    ),
    'DU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Debub Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Adi Keyh', 'describr' ),
        1 => /*translators: City.*/ __( 'Dek&#039;emhāre', 'describr' ),
        2 => /*translators: City.*/ __( 'Mendefera', 'describr' ),
      ),
    ),
    'GB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gash-Barka Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ak&#039;ordat', 'describr' ),
        1 => /*translators: City.*/ __( 'Barentu', 'describr' ),
        2 => /*translators: City.*/ __( 'Teseney', 'describr' ),
      ),
    ),
    'DK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southern Red Sea Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Assab', 'describr' ),
        1 => /*translators: City.*/ __( 'Edd', 'describr' ),
      ),
    ),
  ),
  'GQ' => 
  array (
    'KN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kié-Ntem Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ebebiyin', 'describr' ),
        1 => /*translators: City.*/ __( 'Mikomeseng', 'describr' ),
        2 => /*translators: City.*/ __( 'Ncue', 'describr' ),
        3 => /*translators: City.*/ __( 'Nsang', 'describr' ),
      ),
    ),
    'WN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Wele-Nzas Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aconibe', 'describr' ),
        1 => /*translators: City.*/ __( 'Ayene', 'describr' ),
        2 => /*translators: City.*/ __( 'Añisoc', 'describr' ),
        3 => /*translators: City.*/ __( 'Mengomeyén', 'describr' ),
        4 => /*translators: City.*/ __( 'Mongomo', 'describr' ),
        5 => /*translators: City.*/ __( 'Nsok', 'describr' ),
      ),
    ),
    'LI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Litoral Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bata', 'describr' ),
        1 => /*translators: City.*/ __( 'Bitica', 'describr' ),
        2 => /*translators: City.*/ __( 'Cogo', 'describr' ),
        3 => /*translators: City.*/ __( 'Machinda', 'describr' ),
        4 => /*translators: City.*/ __( 'Mbini', 'describr' ),
        5 => /*translators: City.*/ __( 'Río Campo', 'describr' ),
      ),
    ),
    'BS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bioko Sur Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luba', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Annobón Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'San Antonio de Palé', 'describr' ),
      ),
    ),
    'CS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centro Sur Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acurenam', 'describr' ),
        1 => /*translators: City.*/ __( 'Bicurga', 'describr' ),
        2 => /*translators: City.*/ __( 'Evinayong', 'describr' ),
      ),
    ),
    'BN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bioko Norte Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Malabo', 'describr' ),
        1 => /*translators: City.*/ __( 'Rebola', 'describr' ),
        2 => /*translators: City.*/ __( 'Santiago de Baney', 'describr' ),
      ),
    ),
  ),
);