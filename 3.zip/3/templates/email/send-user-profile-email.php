<?php
/**
 * Template for "User-to-user Email".
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-profile-email.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$this->get_template( 'header', $args );
?>
<tr>
	<td>
		<table role="presentation" style="border-collapse: collapse; border: 0; width: 100%;">
			<tr>
				<th scope="row" style="padding: 1em 0.5em 1em 0; vertical-align: baseline; border: 0; text-align: left;"><?php esc_html_e( 'User:', 'describr' ) . ' '; ?></th>
	            <td style="padding: 1em 0 1em 0.5em; vertical-align: baseline; border: 0; text-align: left;"><?php echo esc_html( $args['sender_name'] ) . "\r\n"; ?></td>
			</tr>
			<tr>
				<th scope="row" style="padding: 1em 0.5em 1em 0; vertical-align: baseline; border: 0; text-align: left;"><?php echo esc_html_x( 'Message:', 'email', 'describr' ) . ' '; ?></th>
				<td style="padding: 1em 0 1em 0.5em; vertical-align: baseline; border: 0; text-align: left;"><?php echo wp_kses_post( $this->make_clickable( $args['message'], $slug, $args ) ) . "\r\n"; ?></td>
			</tr>
		</table>
	</td>
</tr>
<tr>
	<td style="padding: 0; vertical-align: baseline; border: 0;">
		###HTMLREPLY:
        <div style="padding: 20px 0; margin: 0;"><?php echo $this->btn( $args['reply_url'], _x( 'Reply', 'email', 'describr' ), 'reply' ); ?></div>
        ###HTMLREPLY
        ###TEXTREPLY:
        <?php
        /*translators: %s: Reply URL.*/
        echo "\r\n" . esc_html( sprintf( _x( 'To reply to this message, visit the following address: %s.', 'email', 'describr' ), $args['reply_url'] ) ) . "\r\n";
        ?>
        ###TEXTREPLY
	</td>
</tr>
<?php
$this->get_template( 'footer', $args );