=== Describr: User Profile on the Front End ===
Contributors: profiletoggler
Tags: user profiles, users, front end, member, registration
Requires at least: 4.7
Tested up to: 6.8
Requires PHP: 8.4
Stable tag: 3.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The best plugin for front-end user profiles.

== Description == 

Describr displays user profiles on the front end. Including uploading and changing profile photos, users can update profile fields and account settings on the front end. Describr gives administrators the ability to grant users the capability to delete their accounts on the front end.

Major features in Describr include:

* Users can view and update their profiles on the front end.
* Users can upload profile pictures on the front end.
* Users can manage their account settings on the front end.
* Administrator can make a user an important person.
* Administrator can disable fields and tabs.
* Administrator can add multiple administrator emails.
* Administrator can grant users the capability to delete their profiles on the front end.
* Administrator can change users' status.
* Administrator can make users inactive.
* Administrator can send users a link to confirm their accounts.
* Administrator can manage Describr from the Settings tab on the back end.
* Administrator can grant capabilities to roles and remove capabilities from roles.
* Administrator can include a password field on WordPress' registration form (single site only).
* Multisite support.
* Fully translatable.

== Installation ==

Upload the Describr plugin to your blog and activate it.

...You're done!

= Plugin Support =

Like This Plugin? You can show your support by [rating the plugin](https://wordpress.org/support/plugin/describr/reviews/?filter=5#new-post).

== Links to Noncompressed Source Code for JavaScript Files ==

1. [jquery-ui](https://github.com/jquery/jquery-ui)
2. [libphonenumber-js](https://github.com/catamphetamine/libphonenumber-js) 

== Changelog ==

= 3.0.1 =
*Release Date - 15 October 2025*

###Changed

* User is valid if no status exists.
* Replaced single quotes with double quotes in JavaScript files.
* Changed the name of the JavaScript property to delete the profile picture from "delete" to "deletePicture".
* Changed the name of the JavaScript property to assign the profile picture from "assign" to "assignPicture".
* Removed the `describr.events` method in `assets/js/main.js`.
* Checked if the post exists when retrieving the attachment ID for a profile photo in `includes/class-avatar.php`.
* Restored the current blog before any returning in `includes/class-upload-photo.php`.
* Uncommented `describr_messages_keys` user meta in `includes/class-user.php` so that users can reply to messages.

###Added

* Front-end profile photo is audited if it is deleted by a user.
* Function `describr_avatar_rating` to retrieve the avatar's rating.
* Function `describr_print_profile_picture_rating_modal` to print profile picture rating modal.
* `Popper.js` to display popups in the admin interface.
* The ability to rate avatar on the front end.
* Additional placeholders in email templates.


