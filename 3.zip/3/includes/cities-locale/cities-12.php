<?php
/**
 * An array of translated states and cities.
 * Outputs to the browser and is used to suggest
 * "city, state" when the user searches for a city.
 *
 * @package Describr
 * @since 3.0
 */

//Exit if called directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

return array(
  'HN' => 
  array (
    'CH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Choluteca Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Apacilagua', 'describr' ),
        1 => /*translators: City.*/ __( 'Choluteca', 'describr' ),
        2 => /*translators: City.*/ __( 'Ciudad Choluteca', 'describr' ),
        3 => /*translators: City.*/ __( 'Concepción de María', 'describr' ),
        4 => /*translators: City.*/ __( 'Corpus', 'describr' ),
        5 => /*translators: City.*/ __( 'Duyure', 'describr' ),
        6 => /*translators: City.*/ __( 'El Corpus', 'describr' ),
        7 => /*translators: City.*/ __( 'El Obraje', 'describr' ),
        8 => /*translators: City.*/ __( 'El Puente', 'describr' ),
        9 => /*translators: City.*/ __( 'El Triunfo', 'describr' ),
        10 => /*translators: City.*/ __( 'Los Llanitos', 'describr' ),
        11 => /*translators: City.*/ __( 'Marcovia', 'describr' ),
        12 => /*translators: City.*/ __( 'Monjarás', 'describr' ),
        13 => /*translators: City.*/ __( 'Morolica', 'describr' ),
        14 => /*translators: City.*/ __( 'Namasigüe', 'describr' ),
        15 => /*translators: City.*/ __( 'Orocuina', 'describr' ),
        16 => /*translators: City.*/ __( 'Pespire', 'describr' ),
        17 => /*translators: City.*/ __( 'San Antonio de Flores', 'describr' ),
        18 => /*translators: City.*/ __( 'San Isidro', 'describr' ),
        19 => /*translators: City.*/ __( 'San Jerónimo', 'describr' ),
        20 => /*translators: City.*/ __( 'San José', 'describr' ),
        21 => /*translators: City.*/ __( 'San José de Las Conchas', 'describr' ),
        22 => /*translators: City.*/ __( 'San Marcos de Colón', 'describr' ),
        23 => /*translators: City.*/ __( 'Santa Ana de Yusguare', 'describr' ),
        24 => /*translators: City.*/ __( 'Santa Cruz', 'describr' ),
      ),
    ),
    'CM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Comayagua Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aguas del Padre', 'describr' ),
        1 => /*translators: City.*/ __( 'Ajuterique', 'describr' ),
        2 => /*translators: City.*/ __( 'Cerro Blanco', 'describr' ),
        3 => /*translators: City.*/ __( 'Comayagua', 'describr' ),
        4 => /*translators: City.*/ __( 'Concepción de Guasistagua', 'describr' ),
        5 => /*translators: City.*/ __( 'El Agua Dulcita', 'describr' ),
        6 => /*translators: City.*/ __( 'El Porvenir', 'describr' ),
        7 => /*translators: City.*/ __( 'El Rancho', 'describr' ),
        8 => /*translators: City.*/ __( 'El Rincón', 'describr' ),
        9 => /*translators: City.*/ __( 'El Rosario', 'describr' ),
        10 => /*translators: City.*/ __( 'El Sauce', 'describr' ),
        11 => /*translators: City.*/ __( 'El Socorro', 'describr' ),
        12 => /*translators: City.*/ __( 'Esquías', 'describr' ),
        13 => /*translators: City.*/ __( 'Flores', 'describr' ),
        14 => /*translators: City.*/ __( 'Humuya', 'describr' ),
        15 => /*translators: City.*/ __( 'Jamalteca', 'describr' ),
        16 => /*translators: City.*/ __( 'La Libertad', 'describr' ),
        17 => /*translators: City.*/ __( 'La Trinidad', 'describr' ),
        18 => /*translators: City.*/ __( 'Lamaní', 'describr' ),
        19 => /*translators: City.*/ __( 'Las Lajas', 'describr' ),
        20 => /*translators: City.*/ __( 'Lejamaní', 'describr' ),
        21 => /*translators: City.*/ __( 'Meámbar', 'describr' ),
        22 => /*translators: City.*/ __( 'Minas de Oro', 'describr' ),
        23 => /*translators: City.*/ __( 'Ojos de Agua', 'describr' ),
        24 => /*translators: City.*/ __( 'Potrerillos', 'describr' ),
        25 => /*translators: City.*/ __( 'Río Bonito', 'describr' ),
        26 => /*translators: City.*/ __( 'San Antonio de la Cuesta', 'describr' ),
        27 => /*translators: City.*/ __( 'San Jerónimo', 'describr' ),
        28 => /*translators: City.*/ __( 'San José de Comayagua', 'describr' ),
        29 => /*translators: City.*/ __( 'San José del Potrero', 'describr' ),
        30 => /*translators: City.*/ __( 'San Luis', 'describr' ),
        31 => /*translators: City.*/ __( 'San Sebastián', 'describr' ),
        32 => /*translators: City.*/ __( 'Siguatepeque', 'describr' ),
        33 => /*translators: City.*/ __( 'Taulabé', 'describr' ),
        34 => /*translators: City.*/ __( 'Valle de Ángeles', 'describr' ),
        35 => /*translators: City.*/ __( 'Villa de San Antonio', 'describr' ),
      ),
    ),
    'EP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'El Paraíso Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alauca', 'describr' ),
        1 => /*translators: City.*/ __( 'Araulí', 'describr' ),
        2 => /*translators: City.*/ __( 'Cuyalí', 'describr' ),
        3 => /*translators: City.*/ __( 'Danlí', 'describr' ),
        4 => /*translators: City.*/ __( 'El Benque', 'describr' ),
        5 => /*translators: City.*/ __( 'El Chichicaste', 'describr' ),
        6 => /*translators: City.*/ __( 'El Obraje', 'describr' ),
        7 => /*translators: City.*/ __( 'El Paraíso', 'describr' ),
        8 => /*translators: City.*/ __( 'Güinope', 'describr' ),
        9 => /*translators: City.*/ __( 'Jacaleapa', 'describr' ),
        10 => /*translators: City.*/ __( 'Jutiapa', 'describr' ),
        11 => /*translators: City.*/ __( 'Las Trojes', 'describr' ),
        12 => /*translators: City.*/ __( 'Las Ánimas', 'describr' ),
        13 => /*translators: City.*/ __( 'Liure', 'describr' ),
        14 => /*translators: City.*/ __( 'Morocelí', 'describr' ),
        15 => /*translators: City.*/ __( 'Municipio de Texiguat', 'describr' ),
        16 => /*translators: City.*/ __( 'Ojo de Agua', 'describr' ),
        17 => /*translators: City.*/ __( 'Oropolí', 'describr' ),
        18 => /*translators: City.*/ __( 'Potrerillos', 'describr' ),
        19 => /*translators: City.*/ __( 'Quebrada Larga', 'describr' ),
        20 => /*translators: City.*/ __( 'San Antonio de Flores', 'describr' ),
        21 => /*translators: City.*/ __( 'San Diego', 'describr' ),
        22 => /*translators: City.*/ __( 'San Lucas', 'describr' ),
        23 => /*translators: City.*/ __( 'San Matías', 'describr' ),
        24 => /*translators: City.*/ __( 'Santa Cruz', 'describr' ),
        25 => /*translators: City.*/ __( 'Soledad', 'describr' ),
        26 => /*translators: City.*/ __( 'Teupasenti', 'describr' ),
        27 => /*translators: City.*/ __( 'Texíguat', 'describr' ),
        28 => /*translators: City.*/ __( 'Trojes', 'describr' ),
        29 => /*translators: City.*/ __( 'Vado Ancho', 'describr' ),
        30 => /*translators: City.*/ __( 'Yauyupe', 'describr' ),
        31 => /*translators: City.*/ __( 'Yuscarán', 'describr' ),
      ),
    ),
    'IN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Intibucá Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camasca', 'describr' ),
        1 => /*translators: City.*/ __( 'Colomoncagua', 'describr' ),
        2 => /*translators: City.*/ __( 'Concepción', 'describr' ),
        3 => /*translators: City.*/ __( 'Dolores', 'describr' ),
        4 => /*translators: City.*/ __( 'Intibucá', 'describr' ),
        5 => /*translators: City.*/ __( 'Jesús de Otoro', 'describr' ),
        6 => /*translators: City.*/ __( 'Jiquinlaca', 'describr' ),
        7 => /*translators: City.*/ __( 'La Esperanza', 'describr' ),
        8 => /*translators: City.*/ __( 'Magdalena', 'describr' ),
        9 => /*translators: City.*/ __( 'Masaguara', 'describr' ),
        10 => /*translators: City.*/ __( 'San Antonio', 'describr' ),
        11 => /*translators: City.*/ __( 'San Francisco de Opalaca', 'describr' ),
        12 => /*translators: City.*/ __( 'San Isidro', 'describr' ),
        13 => /*translators: City.*/ __( 'San Juan', 'describr' ),
        14 => /*translators: City.*/ __( 'San Marcos de la Sierra', 'describr' ),
        15 => /*translators: City.*/ __( 'San Miguelito', 'describr' ),
        16 => /*translators: City.*/ __( 'Santa Lucía', 'describr' ),
        17 => /*translators: City.*/ __( 'Yamaranguila', 'describr' ),
      ),
    ),
    'IB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bay Islands Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Coxen Hole', 'describr' ),
        1 => /*translators: City.*/ __( 'French Harbor', 'describr' ),
        2 => /*translators: City.*/ __( 'Guanaja', 'describr' ),
        3 => /*translators: City.*/ __( 'José Santos Guardiola', 'describr' ),
        4 => /*translators: City.*/ __( 'Roatán', 'describr' ),
        5 => /*translators: City.*/ __( 'Sandy Bay', 'describr' ),
        6 => /*translators: City.*/ __( 'Savannah Bight', 'describr' ),
        7 => /*translators: City.*/ __( 'Utila', 'describr' ),
      ),
    ),
    'CR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cortés Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agua Azul', 'describr' ),
        1 => /*translators: City.*/ __( 'Agua Azul Rancho', 'describr' ),
        2 => /*translators: City.*/ __( 'Armenta', 'describr' ),
        3 => /*translators: City.*/ __( 'Baja Mar', 'describr' ),
        4 => /*translators: City.*/ __( 'Baracoa', 'describr' ),
        5 => /*translators: City.*/ __( 'Bejuco', 'describr' ),
        6 => /*translators: City.*/ __( 'Casa Quemada', 'describr' ),
        7 => /*translators: City.*/ __( 'Cañaveral', 'describr' ),
        8 => /*translators: City.*/ __( 'Chivana', 'describr' ),
        9 => /*translators: City.*/ __( 'Choloma', 'describr' ),
        10 => /*translators: City.*/ __( 'Chotepe', 'describr' ),
        11 => /*translators: City.*/ __( 'Cofradía', 'describr' ),
        12 => /*translators: City.*/ __( 'Cuyamel', 'describr' ),
        13 => /*translators: City.*/ __( 'El Llano', 'describr' ),
        14 => /*translators: City.*/ __( 'El Marañón', 'describr' ),
        15 => /*translators: City.*/ __( 'El Milagro', 'describr' ),
        16 => /*translators: City.*/ __( 'El Olivar', 'describr' ),
        17 => /*translators: City.*/ __( 'El Perico', 'describr' ),
        18 => /*translators: City.*/ __( 'El Plan', 'describr' ),
        19 => /*translators: City.*/ __( 'El Porvenir', 'describr' ),
        20 => /*translators: City.*/ __( 'El Rancho', 'describr' ),
        21 => /*translators: City.*/ __( 'El Tigre', 'describr' ),
        22 => /*translators: City.*/ __( 'El Zapotal del Norte', 'describr' ),
        23 => /*translators: City.*/ __( 'La Guama', 'describr' ),
        24 => /*translators: City.*/ __( 'La Huesa', 'describr' ),
        25 => /*translators: City.*/ __( 'La Jutosa', 'describr' ),
        26 => /*translators: City.*/ __( 'La Lima', 'describr' ),
        27 => /*translators: City.*/ __( 'La Sabana', 'describr' ),
        28 => /*translators: City.*/ __( 'Los Caminos', 'describr' ),
        29 => /*translators: City.*/ __( 'Los Naranjos', 'describr' ),
        30 => /*translators: City.*/ __( 'Monterrey', 'describr' ),
        31 => /*translators: City.*/ __( 'Nuevo Chamelecón', 'describr' ),
        32 => /*translators: City.*/ __( 'Omoa', 'describr' ),
        33 => /*translators: City.*/ __( 'Oropéndolas', 'describr' ),
        34 => /*translators: City.*/ __( 'Peña Blanca', 'describr' ),
        35 => /*translators: City.*/ __( 'Pimienta', 'describr' ),
        36 => /*translators: City.*/ __( 'Pimienta Vieja', 'describr' ),
        37 => /*translators: City.*/ __( 'Potrerillos', 'describr' ),
        38 => /*translators: City.*/ __( 'Pueblo Nuevo', 'describr' ),
        39 => /*translators: City.*/ __( 'Puerto Alto', 'describr' ),
        40 => /*translators: City.*/ __( 'Puerto Cortez', 'describr' ),
        41 => /*translators: City.*/ __( 'Puerto Cortés', 'describr' ),
        42 => /*translators: City.*/ __( 'Quebrada Seca', 'describr' ),
        43 => /*translators: City.*/ __( 'Río Blanquito', 'describr' ),
        44 => /*translators: City.*/ __( 'Río Chiquito', 'describr' ),
        45 => /*translators: City.*/ __( 'Río Lindo', 'describr' ),
        46 => /*translators: City.*/ __( 'San Antonio de Cortés', 'describr' ),
        47 => /*translators: City.*/ __( 'San Buenaventura', 'describr' ),
        48 => /*translators: City.*/ __( 'San Francisco de Yojoa', 'describr' ),
        49 => /*translators: City.*/ __( 'San José del Boquerón', 'describr' ),
        50 => /*translators: City.*/ __( 'San Manuel', 'describr' ),
        51 => /*translators: City.*/ __( 'San Pedro Sula', 'describr' ),
        52 => /*translators: City.*/ __( 'Santa Cruz de Yojoa', 'describr' ),
        53 => /*translators: City.*/ __( 'Santa Elena', 'describr' ),
        54 => /*translators: City.*/ __( 'Travesía', 'describr' ),
        55 => /*translators: City.*/ __( 'Villanueva', 'describr' ),
      ),
    ),
    'AT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Atlántida Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arizona', 'describr' ),
        1 => /*translators: City.*/ __( 'Atenas de San Cristóbal', 'describr' ),
        2 => /*translators: City.*/ __( 'Corozal', 'describr' ),
        3 => /*translators: City.*/ __( 'El Pino', 'describr' ),
        4 => /*translators: City.*/ __( 'El Porvenir', 'describr' ),
        5 => /*translators: City.*/ __( 'El Triunfo de la Cruz', 'describr' ),
        6 => /*translators: City.*/ __( 'Esparta', 'describr' ),
        7 => /*translators: City.*/ __( 'Jutiapa', 'describr' ),
        8 => /*translators: City.*/ __( 'La Ceiba', 'describr' ),
        9 => /*translators: City.*/ __( 'La Masica', 'describr' ),
        10 => /*translators: City.*/ __( 'La Unión', 'describr' ),
        11 => /*translators: City.*/ __( 'Mezapa', 'describr' ),
        12 => /*translators: City.*/ __( 'Nueva Armenia', 'describr' ),
        13 => /*translators: City.*/ __( 'Sambo Creek', 'describr' ),
        14 => /*translators: City.*/ __( 'San Antonio', 'describr' ),
        15 => /*translators: City.*/ __( 'San Francisco', 'describr' ),
        16 => /*translators: City.*/ __( 'San Juan Pueblo', 'describr' ),
        17 => /*translators: City.*/ __( 'Santa Ana', 'describr' ),
        18 => /*translators: City.*/ __( 'Tela', 'describr' ),
        19 => /*translators: City.*/ __( 'Tornabé', 'describr' ),
      ),
    ),
    'GD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gracias a Dios Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ahuas', 'describr' ),
        1 => /*translators: City.*/ __( 'Auas', 'describr' ),
        2 => /*translators: City.*/ __( 'Auka', 'describr' ),
        3 => /*translators: City.*/ __( 'Barra Patuca', 'describr' ),
        4 => /*translators: City.*/ __( 'Brus Laguna', 'describr' ),
        5 => /*translators: City.*/ __( 'Iralaya', 'describr' ),
        6 => /*translators: City.*/ __( 'Juan Francisco Bulnes', 'describr' ),
        7 => /*translators: City.*/ __( 'Paptalaya', 'describr' ),
        8 => /*translators: City.*/ __( 'Puerto Lempira', 'describr' ),
        9 => /*translators: City.*/ __( 'Villeda Morales', 'describr' ),
        10 => /*translators: City.*/ __( 'Wampusirpi', 'describr' ),
        11 => /*translators: City.*/ __( 'Wawina', 'describr' ),
      ),
    ),
    'CP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Copán Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agua Caliente', 'describr' ),
        1 => /*translators: City.*/ __( 'Buenos Aires', 'describr' ),
        2 => /*translators: City.*/ __( 'Cabañas', 'describr' ),
        3 => /*translators: City.*/ __( 'Chalmeca', 'describr' ),
        4 => /*translators: City.*/ __( 'Concepción', 'describr' ),
        5 => /*translators: City.*/ __( 'Concepción de la Barranca', 'describr' ),
        6 => /*translators: City.*/ __( 'Copán', 'describr' ),
        7 => /*translators: City.*/ __( 'Copán Ruinas', 'describr' ),
        8 => /*translators: City.*/ __( 'Corquín', 'describr' ),
        9 => /*translators: City.*/ __( 'Cucuyagua', 'describr' ),
        10 => /*translators: City.*/ __( 'Dolores', 'describr' ),
        11 => /*translators: City.*/ __( 'Dulce Nombre', 'describr' ),
        12 => /*translators: City.*/ __( 'El Corpus', 'describr' ),
        13 => /*translators: City.*/ __( 'El Ocotón', 'describr' ),
        14 => /*translators: City.*/ __( 'El Paraíso', 'describr' ),
        15 => /*translators: City.*/ __( 'Florida', 'describr' ),
        16 => /*translators: City.*/ __( 'La Entrada', 'describr' ),
        17 => /*translators: City.*/ __( 'La Jigua', 'describr' ),
        18 => /*translators: City.*/ __( 'La Playona', 'describr' ),
        19 => /*translators: City.*/ __( 'La Unión', 'describr' ),
        20 => /*translators: City.*/ __( 'La Zumbadora', 'describr' ),
        21 => /*translators: City.*/ __( 'Los Tangos', 'describr' ),
        22 => /*translators: City.*/ __( 'Nueva Arcadia', 'describr' ),
        23 => /*translators: City.*/ __( 'Ojos de Agua', 'describr' ),
        24 => /*translators: City.*/ __( 'Pueblo Nuevo', 'describr' ),
        25 => /*translators: City.*/ __( 'Quezailica', 'describr' ),
        26 => /*translators: City.*/ __( 'San Agustín', 'describr' ),
        27 => /*translators: City.*/ __( 'San Antonio', 'describr' ),
        28 => /*translators: City.*/ __( 'San Jerónimo', 'describr' ),
        29 => /*translators: City.*/ __( 'San Joaquín', 'describr' ),
        30 => /*translators: City.*/ __( 'San José', 'describr' ),
        31 => /*translators: City.*/ __( 'San José de Copán', 'describr' ),
        32 => /*translators: City.*/ __( 'San Juan de Opoa', 'describr' ),
        33 => /*translators: City.*/ __( 'San Juan de Planes', 'describr' ),
        34 => /*translators: City.*/ __( 'San Nicolás', 'describr' ),
        35 => /*translators: City.*/ __( 'San Pedro de Copán', 'describr' ),
        36 => /*translators: City.*/ __( 'Santa Rita', 'describr' ),
        37 => /*translators: City.*/ __( 'Santa Rita, Copan', 'describr' ),
        38 => /*translators: City.*/ __( 'Santa Rosa de Copán', 'describr' ),
        39 => /*translators: City.*/ __( 'Trinidad de Copán', 'describr' ),
        40 => /*translators: City.*/ __( 'Veracruz', 'describr' ),
      ),
    ),
    'OL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Olancho Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arimís', 'describr' ),
        1 => /*translators: City.*/ __( 'Campamento', 'describr' ),
        2 => /*translators: City.*/ __( 'Catacamas', 'describr' ),
        3 => /*translators: City.*/ __( 'Concordia', 'describr' ),
        4 => /*translators: City.*/ __( 'Dulce Nombre de Culmí', 'describr' ),
        5 => /*translators: City.*/ __( 'El Guayabito', 'describr' ),
        6 => /*translators: City.*/ __( 'El Rosario', 'describr' ),
        7 => /*translators: City.*/ __( 'El Rusio', 'describr' ),
        8 => /*translators: City.*/ __( 'Esquipulas del Norte', 'describr' ),
        9 => /*translators: City.*/ __( 'Gualaco', 'describr' ),
        10 => /*translators: City.*/ __( 'Guarizama', 'describr' ),
        11 => /*translators: City.*/ __( 'Guata', 'describr' ),
        12 => /*translators: City.*/ __( 'Guayape', 'describr' ),
        13 => /*translators: City.*/ __( 'Jano', 'describr' ),
        14 => /*translators: City.*/ __( 'Juticalpa', 'describr' ),
        15 => /*translators: City.*/ __( 'Jutiquile', 'describr' ),
        16 => /*translators: City.*/ __( 'La Concepción', 'describr' ),
        17 => /*translators: City.*/ __( 'La Estancia', 'describr' ),
        18 => /*translators: City.*/ __( 'La Guata', 'describr' ),
        19 => /*translators: City.*/ __( 'La Unión', 'describr' ),
        20 => /*translators: City.*/ __( 'Laguna Seca', 'describr' ),
        21 => /*translators: City.*/ __( 'Mangulile', 'describr' ),
        22 => /*translators: City.*/ __( 'Manto', 'describr' ),
        23 => /*translators: City.*/ __( 'Municipio de San Francisco de La Paz', 'describr' ),
        24 => /*translators: City.*/ __( 'Patuca', 'describr' ),
        25 => /*translators: City.*/ __( 'Punuare', 'describr' ),
        26 => /*translators: City.*/ __( 'Salamá', 'describr' ),
        27 => /*translators: City.*/ __( 'San Esteban', 'describr' ),
        28 => /*translators: City.*/ __( 'San Francisco de Becerra', 'describr' ),
        29 => /*translators: City.*/ __( 'San Francisco de la Paz', 'describr' ),
        30 => /*translators: City.*/ __( 'San José de Río Tinto', 'describr' ),
        31 => /*translators: City.*/ __( 'San Nicolás', 'describr' ),
        32 => /*translators: City.*/ __( 'Santa María del Real', 'describr' ),
        33 => /*translators: City.*/ __( 'Silca', 'describr' ),
        34 => /*translators: City.*/ __( 'Yocón', 'describr' ),
        35 => /*translators: City.*/ __( 'Zopilotepe', 'describr' ),
      ),
    ),
    'CL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Colón Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balfate', 'describr' ),
        1 => /*translators: City.*/ __( 'Bonito Oriental', 'describr' ),
        2 => /*translators: City.*/ __( 'Corocito', 'describr' ),
        3 => /*translators: City.*/ __( 'Cusuna', 'describr' ),
        4 => /*translators: City.*/ __( 'Elíxir', 'describr' ),
        5 => /*translators: City.*/ __( 'Francia', 'describr' ),
        6 => /*translators: City.*/ __( 'Iriona', 'describr' ),
        7 => /*translators: City.*/ __( 'Jericó', 'describr' ),
        8 => /*translators: City.*/ __( 'La Brea', 'describr' ),
        9 => /*translators: City.*/ __( 'La Esperanza', 'describr' ),
        10 => /*translators: City.*/ __( 'Limón', 'describr' ),
        11 => /*translators: City.*/ __( 'Municipio de Sabá', 'describr' ),
        12 => /*translators: City.*/ __( 'Prieta', 'describr' ),
        13 => /*translators: City.*/ __( 'Puerto Castilla', 'describr' ),
        14 => /*translators: City.*/ __( 'Punta Piedra', 'describr' ),
        15 => /*translators: City.*/ __( 'Quebrada de Arena', 'describr' ),
        16 => /*translators: City.*/ __( 'Río Esteban', 'describr' ),
        17 => /*translators: City.*/ __( 'Sabá', 'describr' ),
        18 => /*translators: City.*/ __( 'Salamá', 'describr' ),
        19 => /*translators: City.*/ __( 'Santa Fe', 'describr' ),
        20 => /*translators: City.*/ __( 'Santa Rosa de Aguán', 'describr' ),
        21 => /*translators: City.*/ __( 'Sonaguera', 'describr' ),
        22 => /*translators: City.*/ __( 'Taujica', 'describr' ),
        23 => /*translators: City.*/ __( 'Tocoa', 'describr' ),
        24 => /*translators: City.*/ __( 'Trujillo', 'describr' ),
        25 => /*translators: City.*/ __( 'Zamora', 'describr' ),
      ),
    ),
    'FM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Francisco Morazán Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agalteca', 'describr' ),
        1 => /*translators: City.*/ __( 'Alubarén', 'describr' ),
        2 => /*translators: City.*/ __( 'Cedros', 'describr' ),
        3 => /*translators: City.*/ __( 'Cerro Grande', 'describr' ),
        4 => /*translators: City.*/ __( 'Cofradía', 'describr' ),
        5 => /*translators: City.*/ __( 'Curarén', 'describr' ),
        6 => /*translators: City.*/ __( 'Distrito Central', 'describr' ),
        7 => /*translators: City.*/ __( 'El Chimbo', 'describr' ),
        8 => /*translators: City.*/ __( 'El Escanito', 'describr' ),
        9 => /*translators: City.*/ __( 'El Escaño de Tepale', 'describr' ),
        10 => /*translators: City.*/ __( 'El Guante', 'describr' ),
        11 => /*translators: City.*/ __( 'El Guantillo', 'describr' ),
        12 => /*translators: City.*/ __( 'El Guapinol', 'describr' ),
        13 => /*translators: City.*/ __( 'El Lolo', 'describr' ),
        14 => /*translators: City.*/ __( 'El Pedernal', 'describr' ),
        15 => /*translators: City.*/ __( 'El Porvenir', 'describr' ),
        16 => /*translators: City.*/ __( 'El Suyatal', 'describr' ),
        17 => /*translators: City.*/ __( 'El Tablón', 'describr' ),
        18 => /*translators: City.*/ __( 'El Terrero', 'describr' ),
        19 => /*translators: City.*/ __( 'Guaimaca', 'describr' ),
        20 => /*translators: City.*/ __( 'La Ermita', 'describr' ),
        21 => /*translators: City.*/ __( 'La Libertad', 'describr' ),
        22 => /*translators: City.*/ __( 'La Venta', 'describr' ),
        23 => /*translators: City.*/ __( 'Lepaterique', 'describr' ),
        24 => /*translators: City.*/ __( 'Maraita', 'describr' ),
        25 => /*translators: City.*/ __( 'Marale', 'describr' ),
        26 => /*translators: City.*/ __( 'Mata de Plátano', 'describr' ),
        27 => /*translators: City.*/ __( 'Mateo', 'describr' ),
        28 => /*translators: City.*/ __( 'Nueva Armenia', 'describr' ),
        29 => /*translators: City.*/ __( 'Ojojona', 'describr' ),
        30 => /*translators: City.*/ __( 'Orica', 'describr' ),
        31 => /*translators: City.*/ __( 'Quebradas', 'describr' ),
        32 => /*translators: City.*/ __( 'Reitoca', 'describr' ),
        33 => /*translators: City.*/ __( 'Río Abajo', 'describr' ),
        34 => /*translators: City.*/ __( 'Sabanagrande', 'describr' ),
        35 => /*translators: City.*/ __( 'San Antonio de Oriente', 'describr' ),
        36 => /*translators: City.*/ __( 'San Buenaventura', 'describr' ),
        37 => /*translators: City.*/ __( 'San Ignacio', 'describr' ),
        38 => /*translators: City.*/ __( 'San Juan de Flores', 'describr' ),
        39 => /*translators: City.*/ __( 'San Miguelito', 'describr' ),
        40 => /*translators: City.*/ __( 'Santa Ana', 'describr' ),
        41 => /*translators: City.*/ __( 'Santa Lucía', 'describr' ),
        42 => /*translators: City.*/ __( 'Talanga', 'describr' ),
        43 => /*translators: City.*/ __( 'Tatumbla', 'describr' ),
        44 => /*translators: City.*/ __( 'Tegucigalpa', 'describr' ),
        45 => /*translators: City.*/ __( 'Támara', 'describr' ),
        46 => /*translators: City.*/ __( 'Valle de Ángeles', 'describr' ),
        47 => /*translators: City.*/ __( 'Vallecillo', 'describr' ),
        48 => /*translators: City.*/ __( 'Villa Nueva', 'describr' ),
        49 => /*translators: City.*/ __( 'Villa de San Francisco', 'describr' ),
        50 => /*translators: City.*/ __( 'Yaguacire', 'describr' ),
        51 => /*translators: City.*/ __( 'Zambrano', 'describr' ),
      ),
    ),
    'SB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Santa Bárbara Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agualote', 'describr' ),
        1 => /*translators: City.*/ __( 'Arada', 'describr' ),
        2 => /*translators: City.*/ __( 'Atima', 'describr' ),
        3 => /*translators: City.*/ __( 'Azacualpa', 'describr' ),
        4 => /*translators: City.*/ __( 'Berlín', 'describr' ),
        5 => /*translators: City.*/ __( 'Callejones', 'describr' ),
        6 => /*translators: City.*/ __( 'Camalote', 'describr' ),
        7 => /*translators: City.*/ __( 'Casa Quemada', 'describr' ),
        8 => /*translators: City.*/ __( 'Ceguaca', 'describr' ),
        9 => /*translators: City.*/ __( 'Chinda', 'describr' ),
        10 => /*translators: City.*/ __( 'Concepción del Norte', 'describr' ),
        11 => /*translators: City.*/ __( 'Concepción del Sur', 'describr' ),
        12 => /*translators: City.*/ __( 'Correderos', 'describr' ),
        13 => /*translators: City.*/ __( 'El Ciruelo', 'describr' ),
        14 => /*translators: City.*/ __( 'El Corozal', 'describr' ),
        15 => /*translators: City.*/ __( 'El Mochito', 'describr' ),
        16 => /*translators: City.*/ __( 'El Níspero', 'describr' ),
        17 => /*translators: City.*/ __( 'Guacamaya', 'describr' ),
        18 => /*translators: City.*/ __( 'Gualala', 'describr' ),
        19 => /*translators: City.*/ __( 'Gualjoco', 'describr' ),
        20 => /*translators: City.*/ __( 'Ilama', 'describr' ),
        21 => /*translators: City.*/ __( 'Joconal', 'describr' ),
        22 => /*translators: City.*/ __( 'La Flecha', 'describr' ),
        23 => /*translators: City.*/ __( 'Laguna Verde', 'describr' ),
        24 => /*translators: City.*/ __( 'Las Vegas', 'describr' ),
        25 => /*translators: City.*/ __( 'Las Vegas, Santa Barbara', 'describr' ),
        26 => /*translators: City.*/ __( 'Loma Alta', 'describr' ),
        27 => /*translators: City.*/ __( 'Macuelizo', 'describr' ),
        28 => /*translators: City.*/ __( 'Naco', 'describr' ),
        29 => /*translators: City.*/ __( 'Naranjito', 'describr' ),
        30 => /*translators: City.*/ __( 'Nueva Frontera', 'describr' ),
        31 => /*translators: City.*/ __( 'Nueva Jalapa', 'describr' ),
        32 => /*translators: City.*/ __( 'Nuevo Celilac', 'describr' ),
        33 => /*translators: City.*/ __( 'Petoa', 'describr' ),
        34 => /*translators: City.*/ __( 'Pinalejo', 'describr' ),
        35 => /*translators: City.*/ __( 'Protección', 'describr' ),
        36 => /*translators: City.*/ __( 'Quimistán', 'describr' ),
        37 => /*translators: City.*/ __( 'San Francisco de Ojuera', 'describr' ),
        38 => /*translators: City.*/ __( 'San José de Colinas', 'describr' ),
        39 => /*translators: City.*/ __( 'San José de Tarros', 'describr' ),
        40 => /*translators: City.*/ __( 'San Luis', 'describr' ),
        41 => /*translators: City.*/ __( 'San Luis de Planes', 'describr' ),
        42 => /*translators: City.*/ __( 'San Marcos', 'describr' ),
        43 => /*translators: City.*/ __( 'San Nicolás', 'describr' ),
        44 => /*translators: City.*/ __( 'San Pedro Zacapa', 'describr' ),
        45 => /*translators: City.*/ __( 'San Vicente Centenario', 'describr' ),
        46 => /*translators: City.*/ __( 'Santa Bárbara', 'describr' ),
        47 => /*translators: City.*/ __( 'Santa Rita', 'describr' ),
        48 => /*translators: City.*/ __( 'Sula', 'describr' ),
        49 => /*translators: City.*/ __( 'Tras Cerros', 'describr' ),
        50 => /*translators: City.*/ __( 'Trinidad', 'describr' ),
      ),
    ),
    'LE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lempira Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belén', 'describr' ),
        1 => /*translators: City.*/ __( 'Candelaria', 'describr' ),
        2 => /*translators: City.*/ __( 'Cololaca', 'describr' ),
        3 => /*translators: City.*/ __( 'El Achiotal', 'describr' ),
        4 => /*translators: City.*/ __( 'Erandique', 'describr' ),
        5 => /*translators: City.*/ __( 'Gracias', 'describr' ),
        6 => /*translators: City.*/ __( 'Gualcince', 'describr' ),
        7 => /*translators: City.*/ __( 'Guarita', 'describr' ),
        8 => /*translators: City.*/ __( 'La Campa', 'describr' ),
        9 => /*translators: City.*/ __( 'La Iguala', 'describr' ),
        10 => /*translators: City.*/ __( 'La Libertad', 'describr' ),
        11 => /*translators: City.*/ __( 'La Unión', 'describr' ),
        12 => /*translators: City.*/ __( 'La Virtud', 'describr' ),
        13 => /*translators: City.*/ __( 'Las Flores', 'describr' ),
        14 => /*translators: City.*/ __( 'Las Tejeras', 'describr' ),
        15 => /*translators: City.*/ __( 'Lepaera', 'describr' ),
        16 => /*translators: City.*/ __( 'Mapulaca', 'describr' ),
        17 => /*translators: City.*/ __( 'Piraera', 'describr' ),
        18 => /*translators: City.*/ __( 'San Andrés', 'describr' ),
        19 => /*translators: City.*/ __( 'San Francisco', 'describr' ),
        20 => /*translators: City.*/ __( 'San Juan Guarita', 'describr' ),
        21 => /*translators: City.*/ __( 'San Manuel Colohete', 'describr' ),
        22 => /*translators: City.*/ __( 'San Marcos de Caiquin', 'describr' ),
        23 => /*translators: City.*/ __( 'San Rafael', 'describr' ),
        24 => /*translators: City.*/ __( 'San Sebastián', 'describr' ),
        25 => /*translators: City.*/ __( 'Santa Cruz', 'describr' ),
        26 => /*translators: City.*/ __( 'Talgua', 'describr' ),
        27 => /*translators: City.*/ __( 'Tambla', 'describr' ),
        28 => /*translators: City.*/ __( 'Taragual', 'describr' ),
        29 => /*translators: City.*/ __( 'Tomalá', 'describr' ),
        30 => /*translators: City.*/ __( 'Valladolid', 'describr' ),
        31 => /*translators: City.*/ __( 'Virginia', 'describr' ),
      ),
    ),
    'VA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Valle Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agua Fría', 'describr' ),
        1 => /*translators: City.*/ __( 'Alianza', 'describr' ),
        2 => /*translators: City.*/ __( 'Amapala', 'describr' ),
        3 => /*translators: City.*/ __( 'Aramecina', 'describr' ),
        4 => /*translators: City.*/ __( 'Caridad', 'describr' ),
        5 => /*translators: City.*/ __( 'El Cubolero', 'describr' ),
        6 => /*translators: City.*/ __( 'El Tular', 'describr' ),
        7 => /*translators: City.*/ __( 'Goascorán', 'describr' ),
        8 => /*translators: City.*/ __( 'Jícaro Galán', 'describr' ),
        9 => /*translators: City.*/ __( 'La Alianza', 'describr' ),
        10 => /*translators: City.*/ __( 'La Criba', 'describr' ),
        11 => /*translators: City.*/ __( 'Langue', 'describr' ),
        12 => /*translators: City.*/ __( 'Nacaome', 'describr' ),
        13 => /*translators: City.*/ __( 'San Francisco de Coray', 'describr' ),
        14 => /*translators: City.*/ __( 'San Lorenzo', 'describr' ),
      ),
    ),
    'OC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ocotepeque Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Antigua Ocotepeque', 'describr' ),
        1 => /*translators: City.*/ __( 'Belén Gualcho', 'describr' ),
        2 => /*translators: City.*/ __( 'Concepción', 'describr' ),
        3 => /*translators: City.*/ __( 'Dolores Merendón', 'describr' ),
        4 => /*translators: City.*/ __( 'El Tránsito', 'describr' ),
        5 => /*translators: City.*/ __( 'Fraternidad', 'describr' ),
        6 => /*translators: City.*/ __( 'La Encarnación', 'describr' ),
        7 => /*translators: City.*/ __( 'La Labor', 'describr' ),
        8 => /*translators: City.*/ __( 'Lucerna', 'describr' ),
        9 => /*translators: City.*/ __( 'Mercedes', 'describr' ),
        10 => /*translators: City.*/ __( 'Nueva Ocotepeque', 'describr' ),
        11 => /*translators: City.*/ __( 'San Fernando', 'describr' ),
        12 => /*translators: City.*/ __( 'San Francisco de Cones', 'describr' ),
        13 => /*translators: City.*/ __( 'San Francisco del Valle', 'describr' ),
        14 => /*translators: City.*/ __( 'San Jorge', 'describr' ),
        15 => /*translators: City.*/ __( 'San Marcos', 'describr' ),
        16 => /*translators: City.*/ __( 'Santa Fe', 'describr' ),
        17 => /*translators: City.*/ __( 'Santa Lucía', 'describr' ),
        18 => /*translators: City.*/ __( 'Sensenti', 'describr' ),
        19 => /*translators: City.*/ __( 'Sinuapa', 'describr' ),
        20 => /*translators: City.*/ __( 'Yaruchel', 'describr' ),
      ),
    ),
    'YO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Yoro Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agua Blanca Sur', 'describr' ),
        1 => /*translators: City.*/ __( 'Arenal', 'describr' ),
        2 => /*translators: City.*/ __( 'Armenia', 'describr' ),
        3 => /*translators: City.*/ __( 'Ayapa', 'describr' ),
        4 => /*translators: City.*/ __( 'Bálsamo Oriental', 'describr' ),
        5 => /*translators: City.*/ __( 'Carbajales', 'describr' ),
        6 => /*translators: City.*/ __( 'Coyoles Central', 'describr' ),
        7 => /*translators: City.*/ __( 'El Bálsamo', 'describr' ),
        8 => /*translators: City.*/ __( 'El Juncal', 'describr' ),
        9 => /*translators: City.*/ __( 'El Negrito', 'describr' ),
        10 => /*translators: City.*/ __( 'El Ocote', 'describr' ),
        11 => /*translators: City.*/ __( 'El Progreso', 'describr' ),
        12 => /*translators: City.*/ __( 'Guaimitas', 'describr' ),
        13 => /*translators: City.*/ __( 'Jocón', 'describr' ),
        14 => /*translators: City.*/ __( 'La Estancia', 'describr' ),
        15 => /*translators: City.*/ __( 'La Guacamaya', 'describr' ),
        16 => /*translators: City.*/ __( 'La Mina', 'describr' ),
        17 => /*translators: City.*/ __( 'La Rosa', 'describr' ),
        18 => /*translators: City.*/ __( 'La Sarrosa', 'describr' ),
        19 => /*translators: City.*/ __( 'La Trinidad', 'describr' ),
        20 => /*translators: City.*/ __( 'Las Vegas', 'describr' ),
        21 => /*translators: City.*/ __( 'Lomitas', 'describr' ),
        22 => /*translators: City.*/ __( 'Mojimán', 'describr' ),
        23 => /*translators: City.*/ __( 'Morazán', 'describr' ),
        24 => /*translators: City.*/ __( 'Nombre de Jesús', 'describr' ),
        25 => /*translators: City.*/ __( 'Nueva Esperanza', 'describr' ),
        26 => /*translators: City.*/ __( 'Ocote Paulino', 'describr' ),
        27 => /*translators: City.*/ __( 'Olanchito', 'describr' ),
        28 => /*translators: City.*/ __( 'Paujiles', 'describr' ),
        29 => /*translators: City.*/ __( 'Punta Ocote', 'describr' ),
        30 => /*translators: City.*/ __( 'San Antonio', 'describr' ),
        31 => /*translators: City.*/ __( 'San José', 'describr' ),
        32 => /*translators: City.*/ __( 'Santa Rita', 'describr' ),
        33 => /*translators: City.*/ __( 'Subirana', 'describr' ),
        34 => /*translators: City.*/ __( 'Sulaco', 'describr' ),
        35 => /*translators: City.*/ __( 'Teguajinal', 'describr' ),
        36 => /*translators: City.*/ __( 'Tepusteca', 'describr' ),
        37 => /*translators: City.*/ __( 'Toyós', 'describr' ),
        38 => /*translators: City.*/ __( 'Trojas', 'describr' ),
        39 => /*translators: City.*/ __( 'Victoria', 'describr' ),
        40 => /*translators: City.*/ __( 'Yorito', 'describr' ),
        41 => /*translators: City.*/ __( 'Yoro', 'describr' ),
      ),
    ),
    'LP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Paz Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aguanqueterique', 'describr' ),
        1 => /*translators: City.*/ __( 'Cabañas', 'describr' ),
        2 => /*translators: City.*/ __( 'Cane', 'describr' ),
        3 => /*translators: City.*/ __( 'Chinacla', 'describr' ),
        4 => /*translators: City.*/ __( 'Guajiquiro', 'describr' ),
        5 => /*translators: City.*/ __( 'La Paz', 'describr' ),
        6 => /*translators: City.*/ __( 'Lauterique', 'describr' ),
        7 => /*translators: City.*/ __( 'Los Planes', 'describr' ),
        8 => /*translators: City.*/ __( 'Marcala', 'describr' ),
        9 => /*translators: City.*/ __( 'Mercedes de Oriente', 'describr' ),
        10 => /*translators: City.*/ __( 'Opatoro', 'describr' ),
        11 => /*translators: City.*/ __( 'San Antonio del Norte', 'describr' ),
        12 => /*translators: City.*/ __( 'San José', 'describr' ),
        13 => /*translators: City.*/ __( 'San Juan', 'describr' ),
        14 => /*translators: City.*/ __( 'San Pedro de Tutule', 'describr' ),
        15 => /*translators: City.*/ __( 'Santa Ana', 'describr' ),
        16 => /*translators: City.*/ __( 'Santa Elena', 'describr' ),
        17 => /*translators: City.*/ __( 'Santa María', 'describr' ),
        18 => /*translators: City.*/ __( 'Santiago Puringla', 'describr' ),
        19 => /*translators: City.*/ __( 'Tepanguare', 'describr' ),
        20 => /*translators: City.*/ __( 'Yarula', 'describr' ),
        21 => /*translators: City.*/ __( 'Yarumela', 'describr' ),
      ),
    ),
  ),
  'NZ' => 
  array (
    'NTL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Northland Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ahipara', 'describr' ),
        1 => /*translators: City.*/ __( 'Dargaville', 'describr' ),
        2 => /*translators: City.*/ __( 'Far North District', 'describr' ),
        3 => /*translators: City.*/ __( 'Kaipara District', 'describr' ),
        4 => /*translators: City.*/ __( 'Kaitaia', 'describr' ),
        5 => /*translators: City.*/ __( 'Kawakawa', 'describr' ),
        6 => /*translators: City.*/ __( 'Kerikeri', 'describr' ),
        7 => /*translators: City.*/ __( 'Maungatapere', 'describr' ),
        8 => /*translators: City.*/ __( 'Moerewa', 'describr' ),
        9 => /*translators: City.*/ __( 'Ngunguru', 'describr' ),
        10 => /*translators: City.*/ __( 'Paihia', 'describr' ),
        11 => /*translators: City.*/ __( 'Ruakaka', 'describr' ),
        12 => /*translators: City.*/ __( 'Taipa', 'describr' ),
        13 => /*translators: City.*/ __( 'Waimate North', 'describr' ),
        14 => /*translators: City.*/ __( 'Whangarei', 'describr' ),
      ),
    ),
    'MWT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manawatu-Wanganui Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bulls', 'describr' ),
        1 => /*translators: City.*/ __( 'Foxton', 'describr' ),
        2 => /*translators: City.*/ __( 'Horowhenua District', 'describr' ),
        3 => /*translators: City.*/ __( 'Levin', 'describr' ),
        4 => /*translators: City.*/ __( 'Manawatu District', 'describr' ),
        5 => /*translators: City.*/ __( 'Palmerston North', 'describr' ),
        6 => /*translators: City.*/ __( 'Waiouru', 'describr' ),
        7 => /*translators: City.*/ __( 'Wanganui', 'describr' ),
      ),
    ),
    'WKO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Waikato Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cambridge', 'describr' ),
        1 => /*translators: City.*/ __( 'Coromandel', 'describr' ),
        2 => /*translators: City.*/ __( 'Hamilton', 'describr' ),
        3 => /*translators: City.*/ __( 'Matamata', 'describr' ),
        4 => /*translators: City.*/ __( 'Ngaruawahia', 'describr' ),
        5 => /*translators: City.*/ __( 'Ngatea', 'describr' ),
        6 => /*translators: City.*/ __( 'Otorohanga', 'describr' ),
        7 => /*translators: City.*/ __( 'Paeroa', 'describr' ),
        8 => /*translators: City.*/ __( 'Raglan', 'describr' ),
        9 => /*translators: City.*/ __( 'South Waikato District', 'describr' ),
        10 => /*translators: City.*/ __( 'Tairua', 'describr' ),
        11 => /*translators: City.*/ __( 'Taupo', 'describr' ),
        12 => /*translators: City.*/ __( 'Te Kauwhata', 'describr' ),
        13 => /*translators: City.*/ __( 'Thames', 'describr' ),
        14 => /*translators: City.*/ __( 'Tokoroa', 'describr' ),
        15 => /*translators: City.*/ __( 'Turangi', 'describr' ),
        16 => /*translators: City.*/ __( 'Waihi', 'describr' ),
        17 => /*translators: City.*/ __( 'Whangamata', 'describr' ),
        18 => /*translators: City.*/ __( 'Whitianga', 'describr' ),
      ),
    ),
    'OTA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Otago Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arrowtown', 'describr' ),
        1 => /*translators: City.*/ __( 'Balclutha', 'describr' ),
        2 => /*translators: City.*/ __( 'Clutha District', 'describr' ),
        3 => /*translators: City.*/ __( 'Cromwell', 'describr' ),
        4 => /*translators: City.*/ __( 'Dunedin', 'describr' ),
        5 => /*translators: City.*/ __( 'Kingston', 'describr' ),
        6 => /*translators: City.*/ __( 'Milton', 'describr' ),
        7 => /*translators: City.*/ __( 'Oamaru', 'describr' ),
        8 => /*translators: City.*/ __( 'Papatowai', 'describr' ),
        9 => /*translators: City.*/ __( 'Portobello', 'describr' ),
        10 => /*translators: City.*/ __( 'Queenstown', 'describr' ),
        11 => /*translators: City.*/ __( 'Wanaka', 'describr' ),
      ),
    ),
    'MBH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Marlborough Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Blenheim', 'describr' ),
        1 => /*translators: City.*/ __( 'Picton', 'describr' ),
      ),
    ),
    'WTC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'West Coast Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Greymouth', 'describr' ),
        1 => /*translators: City.*/ __( 'Hokitika', 'describr' ),
        2 => /*translators: City.*/ __( 'Westport', 'describr' ),
      ),
    ),
    'WGN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Wellington Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brooklyn', 'describr' ),
        1 => /*translators: City.*/ __( 'Castlepoint', 'describr' ),
        2 => /*translators: City.*/ __( 'Kapiti Coast District', 'describr' ),
        3 => /*translators: City.*/ __( 'Kelburn', 'describr' ),
        4 => /*translators: City.*/ __( 'Khandallah', 'describr' ),
        5 => /*translators: City.*/ __( 'Lower Hutt', 'describr' ),
        6 => /*translators: City.*/ __( 'Masterton', 'describr' ),
        7 => /*translators: City.*/ __( 'Otaki', 'describr' ),
        8 => /*translators: City.*/ __( 'Paraparaumu', 'describr' ),
        9 => /*translators: City.*/ __( 'Petone', 'describr' ),
        10 => /*translators: City.*/ __( 'Porirua', 'describr' ),
        11 => /*translators: City.*/ __( 'South Wairarapa District', 'describr' ),
        12 => /*translators: City.*/ __( 'Upper Hutt', 'describr' ),
        13 => /*translators: City.*/ __( 'Waipawa', 'describr' ),
        14 => /*translators: City.*/ __( 'Wellington', 'describr' ),
        15 => /*translators: City.*/ __( 'Wellington City', 'describr' ),
      ),
    ),
    'CAN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Canterbury Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Amberley', 'describr' ),
        1 => /*translators: City.*/ __( 'Ashburton', 'describr' ),
        2 => /*translators: City.*/ __( 'Ashburton District', 'describr' ),
        3 => /*translators: City.*/ __( 'Burnham', 'describr' ),
        4 => /*translators: City.*/ __( 'Christchurch', 'describr' ),
        5 => /*translators: City.*/ __( 'Christchurch City', 'describr' ),
        6 => /*translators: City.*/ __( 'Darfield', 'describr' ),
        7 => /*translators: City.*/ __( 'Geraldine', 'describr' ),
        8 => /*translators: City.*/ __( 'Kaiapoi', 'describr' ),
        9 => /*translators: City.*/ __( 'Leeston', 'describr' ),
        10 => /*translators: City.*/ __( 'Lincoln', 'describr' ),
        11 => /*translators: City.*/ __( 'Mackenzie District', 'describr' ),
        12 => /*translators: City.*/ __( 'Methven', 'describr' ),
        13 => /*translators: City.*/ __( 'Oxford', 'describr' ),
        14 => /*translators: City.*/ __( 'Pleasant Point', 'describr' ),
        15 => /*translators: City.*/ __( 'Prebbleton', 'describr' ),
        16 => /*translators: City.*/ __( 'Rakaia', 'describr' ),
        17 => /*translators: City.*/ __( 'Rolleston', 'describr' ),
        18 => /*translators: City.*/ __( 'Selwyn District', 'describr' ),
        19 => /*translators: City.*/ __( 'Timaru', 'describr' ),
        20 => /*translators: City.*/ __( 'Timaru District', 'describr' ),
        21 => /*translators: City.*/ __( 'Tinwald', 'describr' ),
        22 => /*translators: City.*/ __( 'Waimakariri District', 'describr' ),
        23 => /*translators: City.*/ __( 'Woodend', 'describr' ),
      ),
    ),
    'CIT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chatham Islands', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Waitangi', 'describr' ),
      ),
    ),
    'GIS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gisborne District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gisborne', 'describr' ),
      ),
    ),
    'TKI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taranaki Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Eltham', 'describr' ),
        1 => /*translators: City.*/ __( 'Hawera', 'describr' ),
        2 => /*translators: City.*/ __( 'New Plymouth', 'describr' ),
        3 => /*translators: City.*/ __( 'New Plymouth District', 'describr' ),
        4 => /*translators: City.*/ __( 'Opunake', 'describr' ),
        5 => /*translators: City.*/ __( 'Patea', 'describr' ),
        6 => /*translators: City.*/ __( 'South Taranaki District', 'describr' ),
        7 => /*translators: City.*/ __( 'Waitara', 'describr' ),
      ),
    ),
    'NSN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nelson Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nelson', 'describr' ),
      ),
    ),
    'STL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Southland Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bluff', 'describr' ),
        1 => /*translators: City.*/ __( 'Gore', 'describr' ),
        2 => /*translators: City.*/ __( 'Invercargill', 'describr' ),
        3 => /*translators: City.*/ __( 'Riverton', 'describr' ),
        4 => /*translators: City.*/ __( 'Southland District', 'describr' ),
        5 => /*translators: City.*/ __( 'Te Anau', 'describr' ),
        6 => /*translators: City.*/ __( 'Winton', 'describr' ),
      ),
    ),
    'AUK' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Auckland Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Auckland', 'describr' ),
        1 => /*translators: City.*/ __( 'Mangere', 'describr' ),
        2 => /*translators: City.*/ __( 'Manukau City', 'describr' ),
        3 => /*translators: City.*/ __( 'Muriwai Beach', 'describr' ),
        4 => /*translators: City.*/ __( 'Murrays Bay', 'describr' ),
        5 => /*translators: City.*/ __( 'North Shore', 'describr' ),
        6 => /*translators: City.*/ __( 'Pakuranga', 'describr' ),
        7 => /*translators: City.*/ __( 'Papakura', 'describr' ),
        8 => /*translators: City.*/ __( 'Parakai', 'describr' ),
        9 => /*translators: City.*/ __( 'Pukekohe East', 'describr' ),
        10 => /*translators: City.*/ __( 'Red Hill', 'describr' ),
        11 => /*translators: City.*/ __( 'Rosebank', 'describr' ),
        12 => /*translators: City.*/ __( 'Rothesay Bay', 'describr' ),
        13 => /*translators: City.*/ __( 'Takanini', 'describr' ),
        14 => /*translators: City.*/ __( 'Tamaki', 'describr' ),
        15 => /*translators: City.*/ __( 'Titirangi', 'describr' ),
        16 => /*translators: City.*/ __( 'Waitakere', 'describr' ),
        17 => /*translators: City.*/ __( 'Waiuku', 'describr' ),
        18 => /*translators: City.*/ __( 'Warkworth', 'describr' ),
        19 => /*translators: City.*/ __( 'Wellsford', 'describr' ),
        20 => /*translators: City.*/ __( 'Wiri', 'describr' ),
      ),
    ),
    'TAS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tasman District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brightwater', 'describr' ),
        1 => /*translators: City.*/ __( 'Mapua', 'describr' ),
        2 => /*translators: City.*/ __( 'Motueka', 'describr' ),
        3 => /*translators: City.*/ __( 'Richmond', 'describr' ),
        4 => /*translators: City.*/ __( 'Takaka', 'describr' ),
        5 => /*translators: City.*/ __( 'Wakefield', 'describr' ),
      ),
    ),
    'BOP' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bay of Plenty Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Edgecumbe', 'describr' ),
        1 => /*translators: City.*/ __( 'Katikati', 'describr' ),
        2 => /*translators: City.*/ __( 'Kawerau', 'describr' ),
        3 => /*translators: City.*/ __( 'Maketu', 'describr' ),
        4 => /*translators: City.*/ __( 'Murupara', 'describr' ),
        5 => /*translators: City.*/ __( 'Opotiki', 'describr' ),
        6 => /*translators: City.*/ __( 'Rotorua', 'describr' ),
        7 => /*translators: City.*/ __( 'Tauranga', 'describr' ),
        8 => /*translators: City.*/ __( 'Waihi Beach', 'describr' ),
        9 => /*translators: City.*/ __( 'Whakatane', 'describr' ),
      ),
    ),
    'HKB' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hawke&#039;s Bay Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hastings', 'describr' ),
        1 => /*translators: City.*/ __( 'Napier', 'describr' ),
        2 => /*translators: City.*/ __( 'Taradale', 'describr' ),
        3 => /*translators: City.*/ __( 'Wairoa', 'describr' ),
      ),
    ),
  ),
  'DM' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint John Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Portsmouth', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Mark Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Soufrière', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint David Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Castle Bruce', 'describr' ),
        1 => /*translators: City.*/ __( 'Rosalie', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint George Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Roseau', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Patrick Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Berekua', 'describr' ),
        1 => /*translators: City.*/ __( 'La Plaine', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Andrew Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Calibishie', 'describr' ),
        1 => /*translators: City.*/ __( 'Marigot', 'describr' ),
        2 => /*translators: City.*/ __( 'Wesley', 'describr' ),
        3 => /*translators: City.*/ __( 'Woodford Hill', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Luke Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pointe Michel', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saint Joseph Parish', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Saint Joseph', 'describr' ),
        1 => /*translators: City.*/ __( 'Salisbury', 'describr' ),
      ),
    ),
  ),
  'DO' => 
  array (
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'El Seibo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Miches', 'describr' ),
        1 => /*translators: City.*/ __( 'Pedro Sánchez', 'describr' ),
        2 => /*translators: City.*/ __( 'Santa Cruz de El Seibo', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Barahona Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cabral', 'describr' ),
        1 => /*translators: City.*/ __( 'Cachón', 'describr' ),
        2 => /*translators: City.*/ __( 'Canoa', 'describr' ),
        3 => /*translators: City.*/ __( 'El Peñón', 'describr' ),
        4 => /*translators: City.*/ __( 'Enriquillo', 'describr' ),
        5 => /*translators: City.*/ __( 'Fundación', 'describr' ),
        6 => /*translators: City.*/ __( 'Jaquimeyes', 'describr' ),
        7 => /*translators: City.*/ __( 'La Ciénaga', 'describr' ),
        8 => /*translators: City.*/ __( 'Las Salinas', 'describr' ),
        9 => /*translators: City.*/ __( 'Paraíso', 'describr' ),
        10 => /*translators: City.*/ __( 'Pescadería', 'describr' ),
        11 => /*translators: City.*/ __( 'Polo', 'describr' ),
        12 => /*translators: City.*/ __( 'Santa Cruz de Barahona', 'describr' ),
        13 => /*translators: City.*/ __( 'Vicente Noble', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Distrito Nacional', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bella Vista', 'describr' ),
        1 => /*translators: City.*/ __( 'Ciudad Nueva', 'describr' ),
        2 => /*translators: City.*/ __( 'Cristo Rey', 'describr' ),
        3 => /*translators: City.*/ __( 'Ensanche Luperón', 'describr' ),
        4 => /*translators: City.*/ __( 'La Agustina', 'describr' ),
        5 => /*translators: City.*/ __( 'La Julia', 'describr' ),
        6 => /*translators: City.*/ __( 'San Carlos', 'describr' ),
        7 => /*translators: City.*/ __( 'Santo Domingo', 'describr' ),
        8 => /*translators: City.*/ __( 'Villa Consuelo', 'describr' ),
        9 => /*translators: City.*/ __( 'Villa Francisca', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Espaillat Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cayetano Germosén', 'describr' ),
        1 => /*translators: City.*/ __( 'Gaspar Hernández', 'describr' ),
        2 => /*translators: City.*/ __( 'Jamao al Norte', 'describr' ),
        3 => /*translators: City.*/ __( 'Joba Arriba', 'describr' ),
        4 => /*translators: City.*/ __( 'Juan López Abajo', 'describr' ),
        5 => /*translators: City.*/ __( 'Moca', 'describr' ),
        6 => /*translators: City.*/ __( 'San Víctor Arriba', 'describr' ),
        7 => /*translators: City.*/ __( 'Veragua Arriba', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baoruco Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Palmar', 'describr' ),
        1 => /*translators: City.*/ __( 'Galván', 'describr' ),
        2 => /*translators: City.*/ __( 'La Uvilla', 'describr' ),
        3 => /*translators: City.*/ __( 'Los Ríos', 'describr' ),
        4 => /*translators: City.*/ __( 'Neiba', 'describr' ),
        5 => /*translators: City.*/ __( 'Tamayo', 'describr' ),
        6 => /*translators: City.*/ __( 'Villa Jaragua', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dajabón Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dajabón', 'describr' ),
        1 => /*translators: City.*/ __( 'El Pino', 'describr' ),
        2 => /*translators: City.*/ __( 'Loma de Cabrera', 'describr' ),
        3 => /*translators: City.*/ __( 'Partido', 'describr' ),
        4 => /*translators: City.*/ __( 'Restauración', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Duarte Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Agua Santa del Yuna', 'describr' ),
        1 => /*translators: City.*/ __( 'Arenoso', 'describr' ),
        2 => /*translators: City.*/ __( 'Castillo', 'describr' ),
        3 => /*translators: City.*/ __( 'Hostos', 'describr' ),
        4 => /*translators: City.*/ __( 'Las Guáranas', 'describr' ),
        5 => /*translators: City.*/ __( 'Pimentel', 'describr' ),
        6 => /*translators: City.*/ __( 'San Francisco de Macorís', 'describr' ),
        7 => /*translators: City.*/ __( 'Villa Riva', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Azua Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Azua', 'describr' ),
        1 => /*translators: City.*/ __( 'El Guayabal', 'describr' ),
        2 => /*translators: City.*/ __( 'Estebanía', 'describr' ),
        3 => /*translators: City.*/ __( 'Las Charcas', 'describr' ),
        4 => /*translators: City.*/ __( 'Padre Las Casas', 'describr' ),
        5 => /*translators: City.*/ __( 'Palmar de Ocoa', 'describr' ),
        6 => /*translators: City.*/ __( 'Peralta', 'describr' ),
        7 => /*translators: City.*/ __( 'Pueblo Viejo', 'describr' ),
        8 => /*translators: City.*/ __( 'Sabana Yegua', 'describr' ),
        9 => /*translators: City.*/ __( 'Tábara Arriba', 'describr' ),
        10 => /*translators: City.*/ __( 'Villarpando', 'describr' ),
        11 => /*translators: City.*/ __( 'Yayas de Viajama', 'describr' ),
      ),
    ),
  ),
  'HT' => 
  array (
    'ND' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nord', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acul du Nord', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement de Plaisance', 'describr' ),
        2 => /*translators: City.*/ __( 'Arrondissement de la Grande Rivière du Nord', 'describr' ),
        3 => /*translators: City.*/ __( 'Arrondissement du Borgne', 'describr' ),
        4 => /*translators: City.*/ __( 'Bahon', 'describr' ),
        5 => /*translators: City.*/ __( 'Borgne', 'describr' ),
        6 => /*translators: City.*/ __( 'Dondon', 'describr' ),
        7 => /*translators: City.*/ __( 'Grande Rivière du Nord', 'describr' ),
        8 => /*translators: City.*/ __( 'Lenbe', 'describr' ),
        9 => /*translators: City.*/ __( 'Limonade', 'describr' ),
        10 => /*translators: City.*/ __( 'Milot', 'describr' ),
        11 => /*translators: City.*/ __( 'Okap', 'describr' ),
        12 => /*translators: City.*/ __( 'Pignon', 'describr' ),
        13 => /*translators: City.*/ __( 'Pilate', 'describr' ),
        14 => /*translators: City.*/ __( 'Plaine du Nord', 'describr' ),
        15 => /*translators: City.*/ __( 'Plaisance', 'describr' ),
        16 => /*translators: City.*/ __( 'Port-Margot', 'describr' ),
        17 => /*translators: City.*/ __( 'Quartier Morin', 'describr' ),
        18 => /*translators: City.*/ __( 'Ranquitte', 'describr' ),
        19 => /*translators: City.*/ __( 'Saint-Raphaël', 'describr' ),
      ),
    ),
    'NI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nippes', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ansavo', 'describr' ),
        1 => /*translators: City.*/ __( 'Baradères', 'describr' ),
        2 => /*translators: City.*/ __( 'Miragoâne', 'describr' ),
        3 => /*translators: City.*/ __( 'Petit Trou de Nippes', 'describr' ),
      ),
    ),
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grand&#039;Anse', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse-à-Veau', 'describr' ),
        1 => /*translators: City.*/ __( 'Chambellan', 'describr' ),
        2 => /*translators: City.*/ __( 'Corail', 'describr' ),
        3 => /*translators: City.*/ __( 'Dame-Marie', 'describr' ),
        4 => /*translators: City.*/ __( 'Jeremi', 'describr' ),
        5 => /*translators: City.*/ __( 'Jérémie', 'describr' ),
        6 => /*translators: City.*/ __( 'Les Abricots', 'describr' ),
        7 => /*translators: City.*/ __( 'Les Irois', 'describr' ),
        8 => /*translators: City.*/ __( 'Moron', 'describr' ),
        9 => /*translators: City.*/ __( 'Petite Rivière de Nippes', 'describr' ),
      ),
    ),
    'OU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ouest', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse à Galets', 'describr' ),
        1 => /*translators: City.*/ __( 'Arcahaie', 'describr' ),
        2 => /*translators: City.*/ __( 'Arrondissement de Croix des Bouquets', 'describr' ),
        3 => /*translators: City.*/ __( 'Arrondissement de Léogâne', 'describr' ),
        4 => /*translators: City.*/ __( 'Arrondissement de Port-au-Prince', 'describr' ),
        5 => /*translators: City.*/ __( 'Cabaret', 'describr' ),
        6 => /*translators: City.*/ __( 'Carrefour', 'describr' ),
        7 => /*translators: City.*/ __( 'Cornillon', 'describr' ),
        8 => /*translators: City.*/ __( 'Croix-des-Bouquets', 'describr' ),
        9 => /*translators: City.*/ __( 'Delmas 73', 'describr' ),
        10 => /*translators: City.*/ __( 'Fond Parisien', 'describr' ),
        11 => /*translators: City.*/ __( 'Fonds Verrettes', 'describr' ),
        12 => /*translators: City.*/ __( 'Grangwav', 'describr' ),
        13 => /*translators: City.*/ __( 'Gressier', 'describr' ),
        14 => /*translators: City.*/ __( 'Kenscoff', 'describr' ),
        15 => /*translators: City.*/ __( 'Lagonav', 'describr' ),
        16 => /*translators: City.*/ __( 'Léogâne', 'describr' ),
        17 => /*translators: City.*/ __( 'Port-au-Prince', 'describr' ),
        18 => /*translators: City.*/ __( 'Pétionville', 'describr' ),
        19 => /*translators: City.*/ __( 'Thomazeau', 'describr' ),
        20 => /*translators: City.*/ __( 'Tigwav', 'describr' ),
      ),
    ),
    'NE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nord-Est', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arrondissement de Fort Liberté', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement du Trou du Nord', 'describr' ),
        2 => /*translators: City.*/ __( 'Caracol', 'describr' ),
        3 => /*translators: City.*/ __( 'Carice', 'describr' ),
        4 => /*translators: City.*/ __( 'Dérac', 'describr' ),
        5 => /*translators: City.*/ __( 'Ferrier', 'describr' ),
        6 => /*translators: City.*/ __( 'Fort Liberté', 'describr' ),
        7 => /*translators: City.*/ __( 'Montòrganize', 'describr' ),
        8 => /*translators: City.*/ __( 'Ouanaminthe', 'describr' ),
        9 => /*translators: City.*/ __( 'Perches', 'describr' ),
        10 => /*translators: City.*/ __( 'Phaëton', 'describr' ),
        11 => /*translators: City.*/ __( 'Trou du Nord', 'describr' ),
        12 => /*translators: City.*/ __( 'Wanament', 'describr' ),
      ),
    ),
    'SD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sud', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aquin', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement de Port-Salut', 'describr' ),
        2 => /*translators: City.*/ __( 'Arrondissement des Cayes', 'describr' ),
        3 => /*translators: City.*/ __( 'Cavaillon', 'describr' ),
        4 => /*translators: City.*/ __( 'Chantal', 'describr' ),
        5 => /*translators: City.*/ __( 'Chardonnière', 'describr' ),
        6 => /*translators: City.*/ __( 'Fond des Blancs', 'describr' ),
        7 => /*translators: City.*/ __( 'Koto', 'describr' ),
        8 => /*translators: City.*/ __( 'Les Anglais', 'describr' ),
        9 => /*translators: City.*/ __( 'Les Cayes', 'describr' ),
        10 => /*translators: City.*/ __( 'Port-à-Piment', 'describr' ),
        11 => /*translators: City.*/ __( 'Roche-à-Bateau', 'describr' ),
        12 => /*translators: City.*/ __( 'Saint-Louis du Sud', 'describr' ),
        13 => /*translators: City.*/ __( 'Tiburon', 'describr' ),
        14 => /*translators: City.*/ __( 'Torbeck', 'describr' ),
      ),
    ),
    'AR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Artibonite', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse Rouge', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement de Saint-Marc', 'describr' ),
        2 => /*translators: City.*/ __( 'Dessalines', 'describr' ),
        3 => /*translators: City.*/ __( 'Désarmes', 'describr' ),
        4 => /*translators: City.*/ __( 'Ennery', 'describr' ),
        5 => /*translators: City.*/ __( 'Gonaïves', 'describr' ),
        6 => /*translators: City.*/ __( 'Grande Saline', 'describr' ),
        7 => /*translators: City.*/ __( 'Gros Morne', 'describr' ),
        8 => /*translators: City.*/ __( 'Marmelade', 'describr' ),
        9 => /*translators: City.*/ __( 'Saint-Marc', 'describr' ),
        10 => /*translators: City.*/ __( 'Verrettes', 'describr' ),
      ),
    ),
    'SE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sud-Est', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anse-à-Pitre', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement de Bainet', 'describr' ),
        2 => /*translators: City.*/ __( 'Arrondissement de Jacmel', 'describr' ),
        3 => /*translators: City.*/ __( 'Belle-Anse', 'describr' ),
        4 => /*translators: City.*/ __( 'Cayes-Jacmel', 'describr' ),
        5 => /*translators: City.*/ __( 'Jacmel', 'describr' ),
        6 => /*translators: City.*/ __( 'Kotdefè', 'describr' ),
        7 => /*translators: City.*/ __( 'Marigot', 'describr' ),
        8 => /*translators: City.*/ __( 'Thiotte', 'describr' ),
      ),
    ),
    'CE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Centre', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arrondissement de Cerca La Source', 'describr' ),
        1 => /*translators: City.*/ __( 'Cerca la Source', 'describr' ),
        2 => /*translators: City.*/ __( 'Hinche', 'describr' ),
        3 => /*translators: City.*/ __( 'Lascahobas', 'describr' ),
        4 => /*translators: City.*/ __( 'Mayisad', 'describr' ),
        5 => /*translators: City.*/ __( 'Mirebalais', 'describr' ),
        6 => /*translators: City.*/ __( 'Thomassique', 'describr' ),
        7 => /*translators: City.*/ __( 'Thomonde', 'describr' ),
      ),
    ),
    'NO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nord-Ouest', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arcahaie', 'describr' ),
        1 => /*translators: City.*/ __( 'Arrondissement de Port-de-Paix', 'describr' ),
        2 => /*translators: City.*/ __( 'Arrondissement de Saint-Louis du Nord', 'describr' ),
        3 => /*translators: City.*/ __( 'Arrondissement du Môle Saint-Nicolas', 'describr' ),
        4 => /*translators: City.*/ __( 'Baie de Henne', 'describr' ),
        5 => /*translators: City.*/ __( 'Bombardopolis', 'describr' ),
        6 => /*translators: City.*/ __( 'Fond Bassin Bleu', 'describr' ),
        7 => /*translators: City.*/ __( 'Jean-Rabel', 'describr' ),
        8 => /*translators: City.*/ __( 'Môle Saint-Nicolas', 'describr' ),
        9 => /*translators: City.*/ __( 'Petite Anse', 'describr' ),
        10 => /*translators: City.*/ __( 'Port-de-Paix', 'describr' ),
        11 => /*translators: City.*/ __( 'Saint-Louis du Nord', 'describr' ),
        12 => /*translators: City.*/ __( 'Ti Port-de-Paix', 'describr' ),
      ),
    ),
  ),
  'SV' => 
  array (
    'SV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Vicente Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Apastepeque', 'describr' ),
        1 => /*translators: City.*/ __( 'San Sebastián', 'describr' ),
        2 => /*translators: City.*/ __( 'San Vicente', 'describr' ),
      ),
    ),
    'SA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Santa Ana Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Candelaria de La Frontera', 'describr' ),
        1 => /*translators: City.*/ __( 'Chalchuapa', 'describr' ),
        2 => /*translators: City.*/ __( 'Coatepeque', 'describr' ),
        3 => /*translators: City.*/ __( 'El Congo', 'describr' ),
        4 => /*translators: City.*/ __( 'Metapán', 'describr' ),
        5 => /*translators: City.*/ __( 'Santa Ana', 'describr' ),
        6 => /*translators: City.*/ __( 'Texistepeque', 'describr' ),
      ),
    ),
    'US' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Usulután Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Berlín', 'describr' ),
        1 => /*translators: City.*/ __( 'Concepción Batres', 'describr' ),
        2 => /*translators: City.*/ __( 'Jiquilisco', 'describr' ),
        3 => /*translators: City.*/ __( 'Jucuapa', 'describr' ),
        4 => /*translators: City.*/ __( 'Jucuarán', 'describr' ),
        5 => /*translators: City.*/ __( 'Ozatlán', 'describr' ),
        6 => /*translators: City.*/ __( 'Puerto El Triunfo', 'describr' ),
        7 => /*translators: City.*/ __( 'San Agustín', 'describr' ),
        8 => /*translators: City.*/ __( 'Santa Elena', 'describr' ),
        9 => /*translators: City.*/ __( 'Santiago de María', 'describr' ),
        10 => /*translators: City.*/ __( 'Usulután', 'describr' ),
      ),
    ),
    'MO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Morazán Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cacaopera', 'describr' ),
        1 => /*translators: City.*/ __( 'Corinto', 'describr' ),
        2 => /*translators: City.*/ __( 'Guatajiagua', 'describr' ),
        3 => /*translators: City.*/ __( 'Jocoro', 'describr' ),
        4 => /*translators: City.*/ __( 'San Francisco', 'describr' ),
        5 => /*translators: City.*/ __( 'Sociedad', 'describr' ),
      ),
    ),
    'CH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chalatenango Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chalatenango', 'describr' ),
        1 => /*translators: City.*/ __( 'Nueva Concepción', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cabañas Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sensuntepeque', 'describr' ),
        1 => /*translators: City.*/ __( 'Victoria', 'describr' ),
      ),
    ),
    'SS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Salvador Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aguilares', 'describr' ),
        1 => /*translators: City.*/ __( 'Apopa', 'describr' ),
        2 => /*translators: City.*/ __( 'Ayutuxtepeque', 'describr' ),
        3 => /*translators: City.*/ __( 'Cuscatancingo', 'describr' ),
        4 => /*translators: City.*/ __( 'Delgado', 'describr' ),
        5 => /*translators: City.*/ __( 'El Paisnal', 'describr' ),
        6 => /*translators: City.*/ __( 'Guazapa', 'describr' ),
        7 => /*translators: City.*/ __( 'Ilopango', 'describr' ),
        8 => /*translators: City.*/ __( 'Mejicanos', 'describr' ),
        9 => /*translators: City.*/ __( 'Panchimalco', 'describr' ),
        10 => /*translators: City.*/ __( 'Rosario de Mora', 'describr' ),
        11 => /*translators: City.*/ __( 'San Marcos', 'describr' ),
        12 => /*translators: City.*/ __( 'San Salvador', 'describr' ),
        13 => /*translators: City.*/ __( 'Santo Tomás', 'describr' ),
        14 => /*translators: City.*/ __( 'Soyapango', 'describr' ),
        15 => /*translators: City.*/ __( 'Tonacatepeque', 'describr' ),
      ),
    ),
    'LI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Libertad Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Antiguo Cuscatlán', 'describr' ),
        1 => /*translators: City.*/ __( 'Ciudad Arce', 'describr' ),
        2 => /*translators: City.*/ __( 'La Libertad', 'describr' ),
        3 => /*translators: City.*/ __( 'Nuevo Cuscatlán', 'describr' ),
        4 => /*translators: City.*/ __( 'Quezaltepeque', 'describr' ),
        5 => /*translators: City.*/ __( 'San Juan Opico', 'describr' ),
        6 => /*translators: City.*/ __( 'San Pablo Tacachico', 'describr' ),
        7 => /*translators: City.*/ __( 'Santa Tecla', 'describr' ),
        8 => /*translators: City.*/ __( 'Zaragoza', 'describr' ),
      ),
    ),
    'SM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'San Miguel Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chapeltique', 'describr' ),
        1 => /*translators: City.*/ __( 'Chinameca', 'describr' ),
        2 => /*translators: City.*/ __( 'Chirilagua', 'describr' ),
        3 => /*translators: City.*/ __( 'Ciudad Barrios', 'describr' ),
        4 => /*translators: City.*/ __( 'El Tránsito', 'describr' ),
        5 => /*translators: City.*/ __( 'Lolotique', 'describr' ),
        6 => /*translators: City.*/ __( 'Moncagua', 'describr' ),
        7 => /*translators: City.*/ __( 'Nueva Guadalupe', 'describr' ),
        8 => /*translators: City.*/ __( 'San Miguel', 'describr' ),
        9 => /*translators: City.*/ __( 'San Rafael Oriente', 'describr' ),
        10 => /*translators: City.*/ __( 'Sesori', 'describr' ),
      ),
    ),
    'PA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Paz Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'El Rosario', 'describr' ),
        1 => /*translators: City.*/ __( 'Olocuilta', 'describr' ),
        2 => /*translators: City.*/ __( 'San Pedro Masahuat', 'describr' ),
        3 => /*translators: City.*/ __( 'Santiago Nonualco', 'describr' ),
        4 => /*translators: City.*/ __( 'Zacatecoluca', 'describr' ),
      ),
    ),
    'CU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cuscatlán Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cojutepeque', 'describr' ),
        1 => /*translators: City.*/ __( 'San Martín', 'describr' ),
        2 => /*translators: City.*/ __( 'Suchitoto', 'describr' ),
        3 => /*translators: City.*/ __( 'Tecoluca', 'describr' ),
        4 => /*translators: City.*/ __( 'Tenancingo', 'describr' ),
      ),
    ),
    'UN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'La Unión Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anamorós', 'describr' ),
        1 => /*translators: City.*/ __( 'Conchagua', 'describr' ),
        2 => /*translators: City.*/ __( 'Intipucá', 'describr' ),
        3 => /*translators: City.*/ __( 'La Unión', 'describr' ),
        4 => /*translators: City.*/ __( 'Nueva Esparta', 'describr' ),
        5 => /*translators: City.*/ __( 'Pasaquina', 'describr' ),
        6 => /*translators: City.*/ __( 'San Alejo', 'describr' ),
        7 => /*translators: City.*/ __( 'Santa Rosa de Lima', 'describr' ),
      ),
    ),
    'AH' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ahuachapán Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ahuachapán', 'describr' ),
        1 => /*translators: City.*/ __( 'Atiquizaya', 'describr' ),
        2 => /*translators: City.*/ __( 'Concepción de Ataco', 'describr' ),
        3 => /*translators: City.*/ __( 'Guaymango', 'describr' ),
        4 => /*translators: City.*/ __( 'Jujutla', 'describr' ),
        5 => /*translators: City.*/ __( 'San Francisco Menéndez', 'describr' ),
        6 => /*translators: City.*/ __( 'Tacuba', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sonsonate Department', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Acajutla', 'describr' ),
        1 => /*translators: City.*/ __( 'Armenia', 'describr' ),
        2 => /*translators: City.*/ __( 'Izalco', 'describr' ),
        3 => /*translators: City.*/ __( 'Juayúa', 'describr' ),
        4 => /*translators: City.*/ __( 'Nahuizalco', 'describr' ),
        5 => /*translators: City.*/ __( 'San Antonio del Monte', 'describr' ),
        6 => /*translators: City.*/ __( 'Sonsonate', 'describr' ),
        7 => /*translators: City.*/ __( 'Sonzacate', 'describr' ),
      ),
    ),
  ),
  'SI' => 
  array (
    '058' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lenart Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lenart v Slov. Goricah', 'describr' ),
      ),
    ),
    '092' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Podčetrtek Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Podčetrtek', 'describr' ),
      ),
    ),
    '045' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kidričevo Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kidričevo', 'describr' ),
      ),
    ),
    '015' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Črenšovci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Črenšovci', 'describr' ),
      ),
    ),
    '036' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Idrija Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Idrija', 'describr' ),
        1 => /*translators: City.*/ __( 'Spodnja Idrija', 'describr' ),
      ),
    ),
    '069' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Majšperk Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Majšperk', 'describr' ),
      ),
    ),
    '066' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Loški Potok Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hrib-Loški Potok', 'describr' ),
      ),
    ),
    '023' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Domžale Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dob', 'describr' ),
        1 => /*translators: City.*/ __( 'Domžale', 'describr' ),
        2 => /*translators: City.*/ __( 'Radomlje', 'describr' ),
        3 => /*translators: City.*/ __( 'Vir', 'describr' ),
      ),
    ),
    '013' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cerknica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cerknica', 'describr' ),
        1 => /*translators: City.*/ __( 'Rakek', 'describr' ),
      ),
    ),
    '008' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brezovica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brezovica pri Ljubljani', 'describr' ),
        1 => /*translators: City.*/ __( 'Notranje Gorice', 'describr' ),
        2 => /*translators: City.*/ __( 'Opština Ljubljana-Vič-Rudnik', 'describr' ),
        3 => /*translators: City.*/ __( 'Rečica ob Savinji', 'describr' ),
        4 => /*translators: City.*/ __( 'Vnanje Gorice', 'describr' ),
      ),
    ),
    '019' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Divača Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Divača', 'describr' ),
      ),
    ),
    '077' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Moravče Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Moravče', 'describr' ),
      ),
    ),
    '089' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pesnica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pesnica pri Mariboru', 'describr' ),
      ),
    ),
    '022' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dol pri Ljubljani Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dol pri Ljubljani', 'describr' ),
      ),
    ),
    '065' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Loška Dolina Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Leskova Dolina', 'describr' ),
      ),
    ),
    '082' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Naklo Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Naklo', 'describr' ),
      ),
    ),
    '014' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cerkno Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cerkno', 'describr' ),
      ),
    ),
    '043' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kamnik Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kamnik', 'describr' ),
        1 => /*translators: City.*/ __( 'Mekinje', 'describr' ),
        2 => /*translators: City.*/ __( 'Šmarca', 'describr' ),
      ),
    ),
    '006' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bovec Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bovec', 'describr' ),
        1 => /*translators: City.*/ __( 'Mirna', 'describr' ),
      ),
    ),
    '001' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ajdovščina Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ajdovščina', 'describr' ),
        1 => /*translators: City.*/ __( 'Cirkulane', 'describr' ),
        2 => /*translators: City.*/ __( 'Lokavec', 'describr' ),
      ),
    ),
    '091' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pivka Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pivka', 'describr' ),
      ),
    ),
    '051' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kozje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kozje', 'describr' ),
      ),
    ),
    '079' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mozirje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mozirje', 'describr' ),
      ),
    ),
    '011' => 
    array (
      'name' => /*translators: State/province.*/ __( 'City Municipality of Celje', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Celje', 'describr' ),
        1 => /*translators: City.*/ __( 'Ljubečna', 'describr' ),
        2 => /*translators: City.*/ __( 'Trnovlje pri Celju', 'describr' ),
      ),
    ),
    '099' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Radeče Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Radeče', 'describr' ),
      ),
    ),
    '055' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kungota', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Zgornja Kungota', 'describr' ),
      ),
    ),
    '088' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Osilnica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Osilnica', 'describr' ),
      ),
    ),
    '005' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Borovnica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Borovnica', 'describr' ),
        1 => /*translators: City.*/ __( 'Makole', 'describr' ),
      ),
    ),
    '090' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Piran Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lucija', 'describr' ),
        1 => /*translators: City.*/ __( 'Piran', 'describr' ),
        2 => /*translators: City.*/ __( 'Portorož', 'describr' ),
        3 => /*translators: City.*/ __( 'Seča', 'describr' ),
      ),
    ),
    '003' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bled Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bled', 'describr' ),
        1 => /*translators: City.*/ __( 'Kostanjevica na Krki', 'describr' ),
        2 => /*translators: City.*/ __( 'Zasip', 'describr' ),
      ),
    ),
    '098' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rače–Fram Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fram', 'describr' ),
        1 => /*translators: City.*/ __( 'Morje', 'describr' ),
        2 => /*translators: City.*/ __( 'Rače', 'describr' ),
      ),
    ),
    '084' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nova Gorica City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kromberk', 'describr' ),
        1 => /*translators: City.*/ __( 'Nova Gorica', 'describr' ),
        2 => /*translators: City.*/ __( 'Prvačina', 'describr' ),
        3 => /*translators: City.*/ __( 'Solkan', 'describr' ),
        4 => /*translators: City.*/ __( 'Šempas', 'describr' ),
      ),
    ),
    '081' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Muta Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Muta', 'describr' ),
      ),
    ),
    '028' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gorišnica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gorišnica', 'describr' ),
      ),
    ),
    '056' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kuzma Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kuzma', 'describr' ),
      ),
    ),
    '076' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mislinja Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mislinja', 'describr' ),
      ),
    ),
    '026' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Duplek Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Spodnji Duplek', 'describr' ),
        1 => /*translators: City.*/ __( 'Zgornji Duplek', 'describr' ),
      ),
    ),
    '009' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brežice Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brežice', 'describr' ),
        1 => /*translators: City.*/ __( 'Poljčane', 'describr' ),
      ),
    ),
    '020' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dobrepolje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Videm', 'describr' ),
      ),
    ),
    '078' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Moravske Toplice Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Moravske Toplice', 'describr' ),
      ),
    ),
    '067' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luče Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Luče', 'describr' ),
      ),
    ),
    '075' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Miren–Kostanjevica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bilje', 'describr' ),
        1 => /*translators: City.*/ __( 'Miren', 'describr' ),
      ),
    ),
    '087' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ormož Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ormož', 'describr' ),
      ),
    ),
    '033' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Šalovci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Šalovci', 'describr' ),
      ),
    ),
    '059' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lendava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lendava', 'describr' ),
      ),
    ),
    '044' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kanal ob Soči Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Deskle', 'describr' ),
        1 => /*translators: City.*/ __( 'Kanal', 'describr' ),
      ),
    ),
    '096' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ptuj City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ptuj', 'describr' ),
      ),
    ),
    '016' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Črna na Koroškem Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Črna na Koroškem', 'describr' ),
      ),
    ),
    '093' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Podvelka Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Podvelka', 'describr' ),
      ),
    ),
    '085' => 
    array (
      'name' => /*translators: State/province.*/ __( 'City Municipality of Novo Mesto', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Novo Mesto', 'describr' ),
      ),
    ),
    '007' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brda Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dobrovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Mokronog', 'describr' ),
      ),
    ),
    '070' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Maribor City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bresternica', 'describr' ),
        1 => /*translators: City.*/ __( 'Kamnica', 'describr' ),
        2 => /*translators: City.*/ __( 'Limbuš', 'describr' ),
        3 => /*translators: City.*/ __( 'Maribor', 'describr' ),
        4 => /*translators: City.*/ __( 'Pekre', 'describr' ),
        5 => /*translators: City.*/ __( 'Razvanje', 'describr' ),
      ),
    ),
    '046' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kobarid Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kobarid', 'describr' ),
      ),
    ),
    '074' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mežica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mežica', 'describr' ),
      ),
    ),
    '042' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Juršinci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Juršinci', 'describr' ),
      ),
    ),
    '061' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ljubljana City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dravlje District', 'describr' ),
        1 => /*translators: City.*/ __( 'Jarše District', 'describr' ),
        2 => /*translators: City.*/ __( 'Ljubljana', 'describr' ),
        3 => /*translators: City.*/ __( 'Opčina Ljubljana-Bežigrad', 'describr' ),
        4 => /*translators: City.*/ __( 'Opština Ljubljana-Center', 'describr' ),
        5 => /*translators: City.*/ __( 'Opština Ljubljana-Moste-Polje', 'describr' ),
        6 => /*translators: City.*/ __( 'Rožnik District', 'describr' ),
        7 => /*translators: City.*/ __( 'Sostro District', 'describr' ),
        8 => /*translators: City.*/ __( 'Trnovo District', 'describr' ),
        9 => /*translators: City.*/ __( 'Vič District', 'describr' ),
        10 => /*translators: City.*/ __( 'Šentvid District', 'describr' ),
      ),
    ),
    '031' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gornji Petrovci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gornji Petrovci', 'describr' ),
      ),
    ),
    '004' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bohinj Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bohinjska Bistrica', 'describr' ),
        1 => /*translators: City.*/ __( 'Dragomer', 'describr' ),
        2 => /*translators: City.*/ __( 'Log pri Brezovici', 'describr' ),
      ),
    ),
    '037' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ig Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ig', 'describr' ),
      ),
    ),
    '052' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kranj City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Britof', 'describr' ),
        1 => /*translators: City.*/ __( 'Golnik', 'describr' ),
        2 => /*translators: City.*/ __( 'Kokrica', 'describr' ),
        3 => /*translators: City.*/ __( 'Kranj', 'describr' ),
        4 => /*translators: City.*/ __( 'Mlaka pri Kranju', 'describr' ),
        5 => /*translators: City.*/ __( 'Zgornje Bitnje', 'describr' ),
      ),
    ),
    '097' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Puconci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Puconci', 'describr' ),
      ),
    ),
    '024' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dornava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dornava', 'describr' ),
      ),
    ),
    '017' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Črnomelj Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Črnomelj', 'describr' ),
      ),
    ),
    '027' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gorenja Vas–Poljane Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gorenja Vas', 'describr' ),
      ),
    ),
    '062' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ljubno Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ljubno ob Savinji', 'describr' ),
      ),
    ),
    '002' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beltinci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Beltinci', 'describr' ),
        1 => /*translators: City.*/ __( 'Gančani', 'describr' ),
        2 => /*translators: City.*/ __( 'Lipovci', 'describr' ),
        3 => /*translators: City.*/ __( 'Zgornje Gorje', 'describr' ),
      ),
    ),
    '068' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lukovica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lukovica pri Domžalah', 'describr' ),
      ),
    ),
    '095' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Preddvor Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Preddvor', 'describr' ),
      ),
    ),
    '018' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Destrnik Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Destrnik', 'describr' ),
      ),
    ),
    '039' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ivančna Gorica Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ivančna Gorica', 'describr' ),
        1 => /*translators: City.*/ __( 'Šentvid pri Stični', 'describr' ),
      ),
    ),
    '021' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dobrova–Polhov Gradec Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dobrova', 'describr' ),
      ),
    ),
    '012' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cerklje na Gorenjskem Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cerklje na Gorenjskem', 'describr' ),
      ),
    ),
    '010' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tišina Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tišina', 'describr' ),
      ),
    ),
    '080' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Murska Sobota City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bakovci', 'describr' ),
        1 => /*translators: City.*/ __( 'Krog', 'describr' ),
        2 => /*translators: City.*/ __( 'Murska Sobota', 'describr' ),
        3 => /*translators: City.*/ __( 'Rakičan', 'describr' ),
        4 => /*translators: City.*/ __( 'Černelavci', 'describr' ),
      ),
    ),
    '054' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Municipality of Krško', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Krško', 'describr' ),
        1 => /*translators: City.*/ __( 'Leskovec pri Krškem', 'describr' ),
        2 => /*translators: City.*/ __( 'Senovo', 'describr' ),
      ),
    ),
    '049' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Komen Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Komen', 'describr' ),
      ),
    ),
    '050' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Koper City Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dekani', 'describr' ),
        1 => /*translators: City.*/ __( 'Hrvatini', 'describr' ),
        2 => /*translators: City.*/ __( 'Koper', 'describr' ),
        3 => /*translators: City.*/ __( 'Pobegi', 'describr' ),
        4 => /*translators: City.*/ __( 'Prade', 'describr' ),
        5 => /*translators: City.*/ __( 'Spodnje Škofije', 'describr' ),
        6 => /*translators: City.*/ __( 'Sv. Anton', 'describr' ),
      ),
    ),
    '086' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Odranci Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Odranci', 'describr' ),
      ),
    ),
    '035' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hrpelje–Kozina Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kozina', 'describr' ),
      ),
    ),
    '040' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Izola Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Izola', 'describr' ),
        1 => /*translators: City.*/ __( 'Jagodje', 'describr' ),
      ),
    ),
    '073' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Metlika Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Metlika', 'describr' ),
      ),
    ),
    '047' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kobilje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kobilje', 'describr' ),
      ),
    ),
    '083' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nazarje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nazarje', 'describr' ),
      ),
    ),
    '094' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Postojna Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Postojna', 'describr' ),
      ),
    ),
    '048' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kočevje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kočevje', 'describr' ),
      ),
    ),
    '032' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grosuplje Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Grosuplje', 'describr' ),
        1 => /*translators: City.*/ __( 'Šmarje-Sap', 'describr' ),
      ),
    ),
    '041' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jesenice Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hrušica', 'describr' ),
        1 => /*translators: City.*/ __( 'Jesenice', 'describr' ),
        2 => /*translators: City.*/ __( 'Koroška Bela', 'describr' ),
        3 => /*translators: City.*/ __( 'Slovenski Javornik', 'describr' ),
      ),
    ),
    '057' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Laško Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Laško', 'describr' ),
      ),
    ),
    '030' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gornji Grad Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gornji Grad', 'describr' ),
      ),
    ),
    '053' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kranjska Gora Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kranjska Gora', 'describr' ),
        1 => /*translators: City.*/ __( 'Mojstrana', 'describr' ),
      ),
    ),
    '034' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hrastnik Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dol pri Hrastniku', 'describr' ),
        1 => /*translators: City.*/ __( 'Hrastnik', 'describr' ),
      ),
    ),
    '029' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gornja Radgona Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gornja Radgona', 'describr' ),
      ),
    ),
    '038' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Municipality of Ilirska Bistrica', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ilirska Bistrica', 'describr' ),
      ),
    ),
    '025' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dravograd Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dravograd', 'describr' ),
      ),
    ),
    '060' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Litija Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Litija', 'describr' ),
      ),
    ),
    '072' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mengeš Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mengeš', 'describr' ),
        1 => /*translators: City.*/ __( 'Preserje pri Radomljah', 'describr' ),
      ),
    ),
    '071' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Medvode Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Medvode', 'describr' ),
        1 => /*translators: City.*/ __( 'Opština [historical] Ljubljana-Šiška', 'describr' ),
        2 => /*translators: City.*/ __( 'Zgornje Pirniče', 'describr' ),
      ),
    ),
    '064' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Logatec Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Logatec', 'describr' ),
      ),
    ),
    '063' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ljutomer Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ljutomer', 'describr' ),
      ),
    ),
  ),
  'SK' => 
  array (
    'BC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Banská Bystrica Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Banská Bystrica', 'describr' ),
        1 => /*translators: City.*/ __( 'Banská Štiavnica', 'describr' ),
        2 => /*translators: City.*/ __( 'Brezno', 'describr' ),
        3 => /*translators: City.*/ __( 'Detva', 'describr' ),
        4 => /*translators: City.*/ __( 'Dudince', 'describr' ),
        5 => /*translators: City.*/ __( 'Fiľakovo', 'describr' ),
        6 => /*translators: City.*/ __( 'Hriňová', 'describr' ),
        7 => /*translators: City.*/ __( 'Hrochoť,Slovakia', 'describr' ),
        8 => /*translators: City.*/ __( 'Kováčová', 'describr' ),
        9 => /*translators: City.*/ __( 'Kremnica', 'describr' ),
        10 => /*translators: City.*/ __( 'Krupina', 'describr' ),
        11 => /*translators: City.*/ __( 'Lučenec', 'describr' ),
        12 => /*translators: City.*/ __( 'Nová Baňa', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Banská Bystrica', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Banská Štiavnica', 'describr' ),
        15 => /*translators: City.*/ __( 'Okres Brezno', 'describr' ),
        16 => /*translators: City.*/ __( 'Okres Detva', 'describr' ),
        17 => /*translators: City.*/ __( 'Okres Krupina', 'describr' ),
        18 => /*translators: City.*/ __( 'Okres Lučenec', 'describr' ),
        19 => /*translators: City.*/ __( 'Okres Poltár', 'describr' ),
        20 => /*translators: City.*/ __( 'Okres Revúca', 'describr' ),
        21 => /*translators: City.*/ __( 'Okres Veľký Krtíš', 'describr' ),
        22 => /*translators: City.*/ __( 'Okres Zvolen', 'describr' ),
        23 => /*translators: City.*/ __( 'Okres Žarnovica', 'describr' ),
        24 => /*translators: City.*/ __( 'Okres Žiar nad Hronom', 'describr' ),
        25 => /*translators: City.*/ __( 'Poltár', 'describr' ),
        26 => /*translators: City.*/ __( 'Revúca', 'describr' ),
        27 => /*translators: City.*/ __( 'Rimavská Sobota', 'describr' ),
        28 => /*translators: City.*/ __( 'Svätý Anton', 'describr' ),
        29 => /*translators: City.*/ __( 'Tisovec', 'describr' ),
        30 => /*translators: City.*/ __( 'Veľký Krtíš', 'describr' ),
        31 => /*translators: City.*/ __( 'Zvolen', 'describr' ),
        32 => /*translators: City.*/ __( 'Čierny Balog', 'describr' ),
        33 => /*translators: City.*/ __( 'Žarnovica', 'describr' ),
        34 => /*translators: City.*/ __( 'Žiar nad Hronom', 'describr' ),
      ),
    ),
    'KI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Košice Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dobšiná', 'describr' ),
        1 => /*translators: City.*/ __( 'Gelnica', 'describr' ),
        2 => /*translators: City.*/ __( 'Kavečany', 'describr' ),
        3 => /*translators: City.*/ __( 'Košice', 'describr' ),
        4 => /*translators: City.*/ __( 'Košice I', 'describr' ),
        5 => /*translators: City.*/ __( 'Košice II', 'describr' ),
        6 => /*translators: City.*/ __( 'Košice III', 'describr' ),
        7 => /*translators: City.*/ __( 'Košice IV', 'describr' ),
        8 => /*translators: City.*/ __( 'Krompachy', 'describr' ),
        9 => /*translators: City.*/ __( 'Medzev', 'describr' ),
        10 => /*translators: City.*/ __( 'Michalovce', 'describr' ),
        11 => /*translators: City.*/ __( 'Moldava nad Bodvou', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Gelnica', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Kosice-okolie', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Michalovce', 'describr' ),
        15 => /*translators: City.*/ __( 'Okres Rožňava', 'describr' ),
        16 => /*translators: City.*/ __( 'Okres Sobrance', 'describr' ),
        17 => /*translators: City.*/ __( 'Okres Spišská Nová Ves', 'describr' ),
        18 => /*translators: City.*/ __( 'Okres Trebišov', 'describr' ),
        19 => /*translators: City.*/ __( 'Rožňava', 'describr' ),
        20 => /*translators: City.*/ __( 'Sečovce', 'describr' ),
        21 => /*translators: City.*/ __( 'Sobrance', 'describr' ),
        22 => /*translators: City.*/ __( 'Spišská Nová Ves', 'describr' ),
        23 => /*translators: City.*/ __( 'Strážske', 'describr' ),
        24 => /*translators: City.*/ __( 'Trebišov', 'describr' ),
        25 => /*translators: City.*/ __( 'Vinné', 'describr' ),
        26 => /*translators: City.*/ __( 'Čierna nad Tisou', 'describr' ),
        27 => /*translators: City.*/ __( 'Žehra', 'describr' ),
      ),
    ),
    'PV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Prešov Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bardejov', 'describr' ),
        1 => /*translators: City.*/ __( 'Chlmec', 'describr' ),
        2 => /*translators: City.*/ __( 'Giraltovce', 'describr' ),
        3 => /*translators: City.*/ __( 'Humenné', 'describr' ),
        4 => /*translators: City.*/ __( 'Kežmarok', 'describr' ),
        5 => /*translators: City.*/ __( 'Levoča', 'describr' ),
        6 => /*translators: City.*/ __( 'Lipany', 'describr' ),
        7 => /*translators: City.*/ __( 'Medzilaborce', 'describr' ),
        8 => /*translators: City.*/ __( 'Nová Lesná', 'describr' ),
        9 => /*translators: City.*/ __( 'Okres Bardejov', 'describr' ),
        10 => /*translators: City.*/ __( 'Okres Humenné', 'describr' ),
        11 => /*translators: City.*/ __( 'Okres Kežmarok', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Levoča', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Medzilaborce', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Poprad', 'describr' ),
        15 => /*translators: City.*/ __( 'Okres Prešov', 'describr' ),
        16 => /*translators: City.*/ __( 'Okres Sabinov', 'describr' ),
        17 => /*translators: City.*/ __( 'Okres Snina', 'describr' ),
        18 => /*translators: City.*/ __( 'Okres Stará Ĺubovňa', 'describr' ),
        19 => /*translators: City.*/ __( 'Okres Stropkov', 'describr' ),
        20 => /*translators: City.*/ __( 'Okres Svidník', 'describr' ),
        21 => /*translators: City.*/ __( 'Okres Vranov nad Topľou', 'describr' ),
        22 => /*translators: City.*/ __( 'Podolínec', 'describr' ),
        23 => /*translators: City.*/ __( 'Poprad', 'describr' ),
        24 => /*translators: City.*/ __( 'Prešov', 'describr' ),
        25 => /*translators: City.*/ __( 'Sabinov', 'describr' ),
        26 => /*translators: City.*/ __( 'Snina', 'describr' ),
        27 => /*translators: City.*/ __( 'Spišská Belá', 'describr' ),
        28 => /*translators: City.*/ __( 'Spišské Podhradie', 'describr' ),
        29 => /*translators: City.*/ __( 'Stará Ľubovňa', 'describr' ),
        30 => /*translators: City.*/ __( 'Stropkov', 'describr' ),
        31 => /*translators: City.*/ __( 'Svidník', 'describr' ),
        32 => /*translators: City.*/ __( 'Svit', 'describr' ),
        33 => /*translators: City.*/ __( 'Vranov nad Topľou', 'describr' ),
        34 => /*translators: City.*/ __( 'Vrbov', 'describr' ),
        35 => /*translators: City.*/ __( 'Vysoké Tatry', 'describr' ),
        36 => /*translators: City.*/ __( 'Vyšné Ružbachy', 'describr' ),
        37 => /*translators: City.*/ __( 'Ľubica', 'describr' ),
        38 => /*translators: City.*/ __( 'Štrba', 'describr' ),
        39 => /*translators: City.*/ __( 'Ždiar', 'describr' ),
      ),
    ),
    'TA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Trnava Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dunajská Streda', 'describr' ),
        1 => /*translators: City.*/ __( 'Gabčíkovo', 'describr' ),
        2 => /*translators: City.*/ __( 'Galanta', 'describr' ),
        3 => /*translators: City.*/ __( 'Gbely', 'describr' ),
        4 => /*translators: City.*/ __( 'Hlohovec', 'describr' ),
        5 => /*translators: City.*/ __( 'Holíč', 'describr' ),
        6 => /*translators: City.*/ __( 'Leopoldov', 'describr' ),
        7 => /*translators: City.*/ __( 'Okres Dunajská Streda', 'describr' ),
        8 => /*translators: City.*/ __( 'Okres Galanta', 'describr' ),
        9 => /*translators: City.*/ __( 'Okres Hlohovec', 'describr' ),
        10 => /*translators: City.*/ __( 'Okres Piešťany', 'describr' ),
        11 => /*translators: City.*/ __( 'Okres Senica', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Skalica', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Trnava', 'describr' ),
        14 => /*translators: City.*/ __( 'Piešťany', 'describr' ),
        15 => /*translators: City.*/ __( 'Senica', 'describr' ),
        16 => /*translators: City.*/ __( 'Skalica', 'describr' ),
        17 => /*translators: City.*/ __( 'Sládkovičovo', 'describr' ),
        18 => /*translators: City.*/ __( 'Smolenice', 'describr' ),
        19 => /*translators: City.*/ __( 'Trnava', 'describr' ),
        20 => /*translators: City.*/ __( 'Veľký Meder', 'describr' ),
        21 => /*translators: City.*/ __( 'Vrbové', 'describr' ),
        22 => /*translators: City.*/ __( 'Šamorín', 'describr' ),
      ),
    ),
    'BL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bratislava Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bratislava', 'describr' ),
        1 => /*translators: City.*/ __( 'Bratislava - Vajnory', 'describr' ),
        2 => /*translators: City.*/ __( 'Dunajská Lužná', 'describr' ),
        3 => /*translators: City.*/ __( 'Ivanka pri Dunaji', 'describr' ),
        4 => /*translators: City.*/ __( 'Malacky', 'describr' ),
        5 => /*translators: City.*/ __( 'Marianka', 'describr' ),
        6 => /*translators: City.*/ __( 'Modra', 'describr' ),
        7 => /*translators: City.*/ __( 'Okres Bratislava I', 'describr' ),
        8 => /*translators: City.*/ __( 'Okres Bratislava II', 'describr' ),
        9 => /*translators: City.*/ __( 'Okres Bratislava III', 'describr' ),
        10 => /*translators: City.*/ __( 'Okres Bratislava IV', 'describr' ),
        11 => /*translators: City.*/ __( 'Okres Bratislava V', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Malacky', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Pezinok', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Senec', 'describr' ),
        15 => /*translators: City.*/ __( 'Pezinok', 'describr' ),
        16 => /*translators: City.*/ __( 'Senec', 'describr' ),
        17 => /*translators: City.*/ __( 'Stupava', 'describr' ),
        18 => /*translators: City.*/ __( 'Svätý Jur', 'describr' ),
        19 => /*translators: City.*/ __( 'Vinosady', 'describr' ),
      ),
    ),
    'NI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nitra Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Hurbanovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Kolárovo', 'describr' ),
        2 => /*translators: City.*/ __( 'Komárno', 'describr' ),
        3 => /*translators: City.*/ __( 'Levice', 'describr' ),
        4 => /*translators: City.*/ __( 'Nitra', 'describr' ),
        5 => /*translators: City.*/ __( 'Nové Zámky', 'describr' ),
        6 => /*translators: City.*/ __( 'Okres Komárno', 'describr' ),
        7 => /*translators: City.*/ __( 'Okres Levice', 'describr' ),
        8 => /*translators: City.*/ __( 'Okres Nitra', 'describr' ),
        9 => /*translators: City.*/ __( 'Okres Nové Zámky', 'describr' ),
        10 => /*translators: City.*/ __( 'Okres Topoľčany', 'describr' ),
        11 => /*translators: City.*/ __( 'Okres Zlaté Moravce', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Šaľa', 'describr' ),
        13 => /*translators: City.*/ __( 'Svodín', 'describr' ),
        14 => /*translators: City.*/ __( 'Tlmače', 'describr' ),
        15 => /*translators: City.*/ __( 'Topoľčany', 'describr' ),
        16 => /*translators: City.*/ __( 'Vráble', 'describr' ),
        17 => /*translators: City.*/ __( 'Zlaté Moravce', 'describr' ),
        18 => /*translators: City.*/ __( 'Šahy', 'describr' ),
        19 => /*translators: City.*/ __( 'Šaľa', 'describr' ),
        20 => /*translators: City.*/ __( 'Štúrovo', 'describr' ),
        21 => /*translators: City.*/ __( 'Šurany', 'describr' ),
        22 => /*translators: City.*/ __( 'Želiezovce', 'describr' ),
      ),
    ),
    'TC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Trenčín Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bojnice', 'describr' ),
        1 => /*translators: City.*/ __( 'Brezová pod Bradlom', 'describr' ),
        2 => /*translators: City.*/ __( 'Bánovce nad Bebravou', 'describr' ),
        3 => /*translators: City.*/ __( 'Dubnica nad Váhom', 'describr' ),
        4 => /*translators: City.*/ __( 'Handlová', 'describr' ),
        5 => /*translators: City.*/ __( 'Ilava', 'describr' ),
        6 => /*translators: City.*/ __( 'Lehota pod Vtáčnikom', 'describr' ),
        7 => /*translators: City.*/ __( 'Myjava', 'describr' ),
        8 => /*translators: City.*/ __( 'Nemšová', 'describr' ),
        9 => /*translators: City.*/ __( 'Nová Dubnica', 'describr' ),
        10 => /*translators: City.*/ __( 'Nováky', 'describr' ),
        11 => /*translators: City.*/ __( 'Nové Mesto nad Váhom', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Bánovce nad Bebravou', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Ilava', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Myjava', 'describr' ),
        15 => /*translators: City.*/ __( 'Okres Nové Mesto nad Váhom', 'describr' ),
        16 => /*translators: City.*/ __( 'Okres Partizánske', 'describr' ),
        17 => /*translators: City.*/ __( 'Okres Považská Bystrica', 'describr' ),
        18 => /*translators: City.*/ __( 'Okres Prievidza', 'describr' ),
        19 => /*translators: City.*/ __( 'Okres Púchov', 'describr' ),
        20 => /*translators: City.*/ __( 'Okres Trenčín', 'describr' ),
        21 => /*translators: City.*/ __( 'Partizánske', 'describr' ),
        22 => /*translators: City.*/ __( 'Považská Bystrica', 'describr' ),
        23 => /*translators: City.*/ __( 'Prievidza', 'describr' ),
        24 => /*translators: City.*/ __( 'Púchov', 'describr' ),
        25 => /*translators: City.*/ __( 'Stará Turá', 'describr' ),
        26 => /*translators: City.*/ __( 'Trenčianske Teplice', 'describr' ),
        27 => /*translators: City.*/ __( 'Trenčín', 'describr' ),
        28 => /*translators: City.*/ __( 'Čachtice', 'describr' ),
      ),
    ),
    'ZI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Žilina Region', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bytča', 'describr' ),
        1 => /*translators: City.*/ __( 'Dolný Kubín', 'describr' ),
        2 => /*translators: City.*/ __( 'Hybe', 'describr' ),
        3 => /*translators: City.*/ __( 'Krasňany', 'describr' ),
        4 => /*translators: City.*/ __( 'Kysucké Nové Mesto', 'describr' ),
        5 => /*translators: City.*/ __( 'Liptovský Hrádok', 'describr' ),
        6 => /*translators: City.*/ __( 'Liptovský Mikuláš', 'describr' ),
        7 => /*translators: City.*/ __( 'Lúčky', 'describr' ),
        8 => /*translators: City.*/ __( 'Martin', 'describr' ),
        9 => /*translators: City.*/ __( 'Nižná', 'describr' ),
        10 => /*translators: City.*/ __( 'Námestovo', 'describr' ),
        11 => /*translators: City.*/ __( 'Okres Bytča', 'describr' ),
        12 => /*translators: City.*/ __( 'Okres Dolný Kubín', 'describr' ),
        13 => /*translators: City.*/ __( 'Okres Kysucké Nové Mesto', 'describr' ),
        14 => /*translators: City.*/ __( 'Okres Liptovský Mikuláš', 'describr' ),
        15 => /*translators: City.*/ __( 'Okres Martin', 'describr' ),
        16 => /*translators: City.*/ __( 'Okres Namestovo', 'describr' ),
        17 => /*translators: City.*/ __( 'Okres Ružomberok', 'describr' ),
        18 => /*translators: City.*/ __( 'Okres Turčianske Teplice', 'describr' ),
        19 => /*translators: City.*/ __( 'Okres Tvrdošín', 'describr' ),
        20 => /*translators: City.*/ __( 'Okres Čadca', 'describr' ),
        21 => /*translators: City.*/ __( 'Okres Žilina', 'describr' ),
        22 => /*translators: City.*/ __( 'Oravská Lesná', 'describr' ),
        23 => /*translators: City.*/ __( 'Oravský Podzámok', 'describr' ),
        24 => /*translators: City.*/ __( 'Pribylina', 'describr' ),
        25 => /*translators: City.*/ __( 'Rajec', 'describr' ),
        26 => /*translators: City.*/ __( 'Ružomberok', 'describr' ),
        27 => /*translators: City.*/ __( 'Terchová', 'describr' ),
        28 => /*translators: City.*/ __( 'Trstená', 'describr' ),
        29 => /*translators: City.*/ __( 'Turzovka', 'describr' ),
        30 => /*translators: City.*/ __( 'Turčianske Teplice', 'describr' ),
        31 => /*translators: City.*/ __( 'Tvrdošín', 'describr' ),
        32 => /*translators: City.*/ __( 'Vrútky', 'describr' ),
        33 => /*translators: City.*/ __( 'Čadca', 'describr' ),
        34 => /*translators: City.*/ __( 'Žilina', 'describr' ),
      ),
    ),
  ),
  'MD' => 
  array (
    'CM' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cimișlia District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cimişlia', 'describr' ),
      ),
    ),
    'OR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Orhei District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Orhei', 'describr' ),
      ),
    ),
    'BD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bender Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bender', 'describr' ),
      ),
    ),
    'NI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nisporeni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nisporeni', 'describr' ),
      ),
    ),
    'SI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sîngerei District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bilicenii Vechi', 'describr' ),
        1 => /*translators: City.*/ __( 'Biruinţa', 'describr' ),
        2 => /*translators: City.*/ __( 'Sîngerei', 'describr' ),
      ),
    ),
    'CS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Căușeni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chiţcani', 'describr' ),
        1 => /*translators: City.*/ __( 'Căuşeni', 'describr' ),
      ),
    ),
    'CL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Călărași District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Călăraşi', 'describr' ),
      ),
    ),
    'GL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Glodeni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Glodeni', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anenii Noi District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anenii Noi', 'describr' ),
        1 => /*translators: City.*/ __( 'Varniţa', 'describr' ),
      ),
    ),
    'IA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ialoveni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ialoveni', 'describr' ),
      ),
    ),
    'FL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Florești District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Floreşti', 'describr' ),
        1 => /*translators: City.*/ __( 'Ghindești', 'describr' ),
        2 => /*translators: City.*/ __( 'Mărculeşti', 'describr' ),
      ),
    ),
    'TE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Telenești District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mîndreşti', 'describr' ),
        1 => /*translators: City.*/ __( 'Teleneşti', 'describr' ),
      ),
    ),
    'TA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Taraclia District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Taraclia', 'describr' ),
        1 => /*translators: City.*/ __( 'Tvardița', 'describr' ),
      ),
    ),
    'CU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Chișinău Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Chisinau', 'describr' ),
        1 => /*translators: City.*/ __( 'Ciorescu', 'describr' ),
        2 => /*translators: City.*/ __( 'Cricova', 'describr' ),
        3 => /*translators: City.*/ __( 'Stăuceni', 'describr' ),
        4 => /*translators: City.*/ __( 'Sîngera', 'describr' ),
        5 => /*translators: City.*/ __( 'Vadul lui Vodă', 'describr' ),
        6 => /*translators: City.*/ __( 'Vatra', 'describr' ),
      ),
    ),
    'SO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Soroca District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Soroca', 'describr' ),
      ),
    ),
    'BR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Briceni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Briceni', 'describr' ),
      ),
    ),
    'RI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rîșcani District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rîşcani', 'describr' ),
      ),
    ),
    'ST' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Strășeni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bucovăţ', 'describr' ),
        1 => /*translators: City.*/ __( 'Strășeni', 'describr' ),
      ),
    ),
    'SV' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ștefan Vodă District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ştefan Vodă', 'describr' ),
      ),
    ),
    'BS' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Basarabeasca District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Basarabeasca', 'describr' ),
      ),
    ),
    'CT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cantemir District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cantemir', 'describr' ),
        1 => /*translators: City.*/ __( 'Iargara', 'describr' ),
        2 => /*translators: City.*/ __( 'Vişniovca', 'describr' ),
      ),
    ),
    'FA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Fălești District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fălești', 'describr' ),
      ),
    ),
    'HI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hîncești District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dancu', 'describr' ),
        1 => /*translators: City.*/ __( 'Hînceşti', 'describr' ),
      ),
    ),
    'DU' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dubăsari District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cocieri', 'describr' ),
        1 => /*translators: City.*/ __( 'Ustia', 'describr' ),
      ),
    ),
    'DO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dondușeni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Briceni', 'describr' ),
        1 => /*translators: City.*/ __( 'Donduşeni', 'describr' ),
      ),
    ),
    'GA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gagauzia', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bugeac', 'describr' ),
        1 => /*translators: City.*/ __( 'Ceadîr-Lunga', 'describr' ),
        2 => /*translators: City.*/ __( 'Comrat', 'describr' ),
        3 => /*translators: City.*/ __( 'Vulcăneşti', 'describr' ),
      ),
    ),
    'UN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ungheni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ungheni', 'describr' ),
      ),
    ),
    'ED' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Edineț District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Edineţ', 'describr' ),
      ),
    ),
    'SD' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Șoldănești District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Şoldăneşti', 'describr' ),
      ),
    ),
    'OC' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ocnița District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ocniţa', 'describr' ),
        1 => /*translators: City.*/ __( 'Otaci', 'describr' ),
      ),
    ),
    'CR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Criuleni District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Criuleni', 'describr' ),
      ),
    ),
    'CA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cahul District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cahul', 'describr' ),
        1 => /*translators: City.*/ __( 'Giurgiuleşti', 'describr' ),
      ),
    ),
    'DR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Drochia District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Drochia', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bălți Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bălţi', 'describr' ),
      ),
    ),
    'RE' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rezina District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rezina', 'describr' ),
        1 => /*translators: City.*/ __( 'Saharna', 'describr' ),
      ),
    ),
    'SN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Transnistria autonomous territorial unit', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Camenca', 'describr' ),
        1 => /*translators: City.*/ __( 'Crasnoe', 'describr' ),
        2 => /*translators: City.*/ __( 'Dnestrovsc', 'describr' ),
        3 => /*translators: City.*/ __( 'Dubăsari', 'describr' ),
        4 => /*translators: City.*/ __( 'Hryhoriopol', 'describr' ),
        5 => /*translators: City.*/ __( 'Maiac', 'describr' ),
        6 => /*translators: City.*/ __( 'Pervomaisc', 'describr' ),
        7 => /*translators: City.*/ __( 'Rîbniţa', 'describr' ),
        8 => /*translators: City.*/ __( 'Slobozia', 'describr' ),
        9 => /*translators: City.*/ __( 'Tiraspol', 'describr' ),
        10 => /*translators: City.*/ __( 'Tiraspolul Nou', 'describr' ),
      ),
    ),
  ),
  'LV' => 
  array (
    '086' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Salacgrīva Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ainaži', 'describr' ),
        1 => /*translators: City.*/ __( 'Salacgrīva', 'describr' ),
      ),
    ),
    '064' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Naukšēni Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Naukšēni', 'describr' ),
      ),
    ),
    '036' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ilūkste Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ilūkste', 'describr' ),
      ),
    ),
    '033' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gulbene Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Gulbene', 'describr' ),
      ),
    ),
    '056' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Līvāni Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Līvāni', 'describr' ),
      ),
    ),
    '087' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Salaspils Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Salaspils', 'describr' ),
      ),
    ),
    '083' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rundāle Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pilsrundāle', 'describr' ),
      ),
    ),
    '072' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pļaviņas Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pļaviņas', 'describr' ),
      ),
    ),
    '090' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sēja Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Engure', 'describr' ),
        1 => /*translators: City.*/ __( 'Tukums', 'describr' ),
      ),
    ),
    '023' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cibla Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cibla', 'describr' ),
      ),
    ),
    '051' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ķegums Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ķegums', 'describr' ),
      ),
    ),
    '021' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cesvaine Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cesvaine', 'describr' ),
      ),
    ),
    '092' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Skrīveri Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Skrīveri', 'describr' ),
      ),
    ),
    '067' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ogre Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jumprava', 'describr' ),
        1 => /*translators: City.*/ __( 'Ogre', 'describr' ),
      ),
    ),
    '068' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Olaine Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Olaine', 'describr' ),
      ),
    ),
    '054' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Limbaži Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Limbaži', 'describr' ),
      ),
    ),
    '057' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lubāna Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lubāna', 'describr' ),
      ),
    ),
    '043' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kandava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kandava', 'describr' ),
      ),
    ),
    'VEN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ventspils', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ventspils', 'describr' ),
      ),
    ),
    '082' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rugāji Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rugāji', 'describr' ),
      ),
    ),
    '041' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jelgava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tīreļi', 'describr' ),
      ),
    ),
    '084' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rūjiena Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rūjiena', 'describr' ),
      ),
    ),
    '012' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Babīte Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Piņķi', 'describr' ),
      ),
    ),
    '027' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dundaga Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dundaga', 'describr' ),
      ),
    ),
    '074' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Priekule Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Priekule', 'describr' ),
      ),
    ),
    '065' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nereta Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nereta', 'describr' ),
      ),
    ),
    '059' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Madona Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Madona', 'describr' ),
      ),
    ),
    '052' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ķekava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baloži', 'describr' ),
        1 => /*translators: City.*/ __( 'Ķekava', 'describr' ),
      ),
    ),
    '066' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Nīca Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Nīca', 'describr' ),
      ),
    ),
    '026' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dobele Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dobele', 'describr' ),
      ),
    ),
    '042' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jēkabpils Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jēkabpils', 'describr' ),
        1 => /*translators: City.*/ __( 'Krustpils', 'describr' ),
      ),
    ),
    '088' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saldus Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Saldus', 'describr' ),
      ),
    ),
    '079' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Roja Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Roja', 'describr' ),
      ),
    ),
    '034' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Iecava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Iecava', 'describr' ),
      ),
    ),
    '069' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ozolnieki Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ozolnieki', 'describr' ),
      ),
    ),
    '089' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Saulkrasti Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Saulkrasti', 'describr' ),
      ),
    ),
    '030' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ērgļi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ērgļi', 'describr' ),
      ),
    ),
    '001' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aglona Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aglona', 'describr' ),
      ),
    ),
    'JUR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jūrmala', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jūrmala', 'describr' ),
      ),
    ),
    '093' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Skrunda Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Skrunda', 'describr' ),
      ),
    ),
    '029' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Engure Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Smārde', 'describr' ),
      ),
    ),
    '037' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Inčukalns Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Inčukalns', 'describr' ),
        1 => /*translators: City.*/ __( 'Vangaži', 'describr' ),
      ),
    ),
    '062' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mārupe Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mārupe', 'describr' ),
      ),
    ),
    '046' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Koknese Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Koknese', 'describr' ),
      ),
    ),
    '044' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kārsava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kārsava', 'describr' ),
      ),
    ),
    '020' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Carnikava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Carnikava', 'describr' ),
      ),
    ),
    '009' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ape Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ape', 'describr' ),
      ),
    ),
    '028' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Durbe Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lieģi', 'describr' ),
      ),
    ),
    '097' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Talsi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sabile', 'describr' ),
        1 => /*translators: City.*/ __( 'Stende', 'describr' ),
        2 => /*translators: City.*/ __( 'Talsi', 'describr' ),
        3 => /*translators: City.*/ __( 'Valdemārpils', 'describr' ),
      ),
    ),
    'LPX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Liepāja', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Karosta', 'describr' ),
        1 => /*translators: City.*/ __( 'Liepāja', 'describr' ),
      ),
    ),
    '061' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mālpils Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mālpils', 'describr' ),
      ),
    ),
    '094' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Smiltene Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Smiltene', 'describr' ),
      ),
    ),
    '016' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bauska Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bauska', 'describr' ),
      ),
    ),
    '071' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pāvilosta Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Pāvilosta', 'describr' ),
      ),
    ),
    '018' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Brocēni Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Brocēni', 'describr' ),
      ),
    ),
    '022' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cēsis Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Cēsis', 'describr' ),
      ),
    ),
    '032' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Grobiņa Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Grobiņa', 'describr' ),
      ),
    ),
    '017' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Beverīna Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mūrmuiža', 'describr' ),
      ),
    ),
    '002' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aizkraukle Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aizkraukle', 'describr' ),
      ),
    ),
    'VMR' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Valmiera', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Valmiera', 'describr' ),
      ),
    ),
    '047' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Krāslava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Krāslava', 'describr' ),
      ),
    ),
    '038' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jaunjelgava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jaunjelgava', 'describr' ),
      ),
    ),
    '091' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Sigulda Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Sigulda', 'describr' ),
      ),
    ),
    '095' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Stopiņi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ulbroka', 'describr' ),
      ),
    ),
    '076' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rauna Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rauna', 'describr' ),
      ),
    ),
    '098' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Tērvete Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tērvete', 'describr' ),
        1 => /*translators: City.*/ __( 'Zelmeņi', 'describr' ),
      ),
    ),
    '010' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Auce Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Auce', 'describr' ),
      ),
    ),
    '013' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baldone Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baldone', 'describr' ),
      ),
    ),
    '073' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Preiļi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jaunaglona', 'describr' ),
        1 => /*translators: City.*/ __( 'Preiļi', 'describr' ),
      ),
    ),
    '005' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aloja Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aloja', 'describr' ),
        1 => /*translators: City.*/ __( 'Staicele', 'describr' ),
      ),
    ),
    '006' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Alsunga Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alsunga', 'describr' ),
      ),
    ),
    '007' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Alūksne Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alūksne', 'describr' ),
      ),
    ),
    '055' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Līgatne Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Līgatne', 'describr' ),
      ),
    ),
    '040' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jaunpils Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jaunpils', 'describr' ),
      ),
    ),
    '050' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kuldīga Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kuldīga', 'describr' ),
      ),
    ),
    'RIX' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Riga', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bolderaja', 'describr' ),
        1 => /*translators: City.*/ __( 'Daugavgrīva', 'describr' ),
        2 => /*translators: City.*/ __( 'Jaunciems', 'describr' ),
        3 => /*translators: City.*/ __( 'Mežaparks', 'describr' ),
        4 => /*translators: City.*/ __( 'Riga', 'describr' ),
      ),
    ),
    '025' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Daugavpils Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Daugavpils', 'describr' ),
      ),
    ),
    '080' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ropaži Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ropaži', 'describr' ),
      ),
    ),
    '096' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Strenči Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Seda', 'describr' ),
        1 => /*translators: City.*/ __( 'Strenči', 'describr' ),
      ),
    ),
    '045' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kocēni Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Kocēni', 'describr' ),
      ),
    ),
    '003' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aizpute Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aizpute', 'describr' ),
      ),
    ),
    '014' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baltinava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baltinava', 'describr' ),
      ),
    ),
    '004' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aknīste Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aknīste', 'describr' ),
      ),
    ),
    'JEL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Jelgava', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Jelgava', 'describr' ),
      ),
    ),
    '058' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ludza Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ludza', 'describr' ),
      ),
    ),
    '078' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Riebiņi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Riebiņi', 'describr' ),
      ),
    ),
    '081' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rucava Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rucava', 'describr' ),
      ),
    ),
    '024' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dagda Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dagda', 'describr' ),
      ),
    ),
    '015' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Balvi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balvi', 'describr' ),
      ),
    ),
    '075' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Priekuļi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Priekuļi', 'describr' ),
      ),
    ),
    '070' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Pārgauja Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Stalbe', 'describr' ),
      ),
    ),
    'REZ' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Rēzekne', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Rēzekne', 'describr' ),
      ),
    ),
    '031' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Garkalne Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Garkalne', 'describr' ),
      ),
    ),
    '035' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ikšķile Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ikšķile', 'describr' ),
      ),
    ),
    '053' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lielvārde Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lielvārde', 'describr' ),
      ),
    ),
    '060' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Mazsalaca Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Mazsalaca', 'describr' ),
      ),
    ),
  ),
  'TL' => 
  array (
    'VI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Viqueque Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Lacluta', 'describr' ),
        1 => /*translators: City.*/ __( 'Ossu', 'describr' ),
        2 => /*translators: City.*/ __( 'Uatocarabau', 'describr' ),
        3 => /*translators: City.*/ __( 'Uatolari', 'describr' ),
        4 => /*translators: City.*/ __( 'Viqueque', 'describr' ),
      ),
    ),
    'LI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Liquiçá Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bazartete', 'describr' ),
        1 => /*translators: City.*/ __( 'Likisá', 'describr' ),
        2 => /*translators: City.*/ __( 'Maubara', 'describr' ),
      ),
    ),
    'ER' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ermera District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ermera Villa', 'describr' ),
        1 => /*translators: City.*/ __( 'Gleno', 'describr' ),
        2 => /*translators: City.*/ __( 'Hatulia', 'describr' ),
        3 => /*translators: City.*/ __( 'Letefoho', 'describr' ),
        4 => /*translators: City.*/ __( 'Railaco', 'describr' ),
      ),
    ),
    'MT' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manatuto District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Barique', 'describr' ),
        1 => /*translators: City.*/ __( 'Laclo', 'describr' ),
        2 => /*translators: City.*/ __( 'Laclubar', 'describr' ),
        3 => /*translators: City.*/ __( 'Manatuto', 'describr' ),
        4 => /*translators: City.*/ __( 'Manatutu', 'describr' ),
        5 => /*translators: City.*/ __( 'Soibada', 'describr' ),
      ),
    ),
    'AN' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Ainaro Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ainaro', 'describr' ),
        1 => /*translators: City.*/ __( 'Hato-Udo', 'describr' ),
      ),
    ),
    'MF' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Manufahi Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alas', 'describr' ),
        1 => /*translators: City.*/ __( 'Fatuberliu', 'describr' ),
        2 => /*translators: City.*/ __( 'Same', 'describr' ),
        3 => /*translators: City.*/ __( 'Turiscai', 'describr' ),
      ),
    ),
    'AL' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aileu municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aileu', 'describr' ),
        1 => /*translators: City.*/ __( 'Lequidoe', 'describr' ),
        2 => /*translators: City.*/ __( 'Remexio', 'describr' ),
      ),
    ),
    'BA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baucau Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baguia', 'describr' ),
        1 => /*translators: City.*/ __( 'Baucau', 'describr' ),
        2 => /*translators: City.*/ __( 'Baukau', 'describr' ),
        3 => /*translators: City.*/ __( 'Laga', 'describr' ),
        4 => /*translators: City.*/ __( 'Quelicai', 'describr' ),
        5 => /*translators: City.*/ __( 'Vemasse', 'describr' ),
        6 => /*translators: City.*/ __( 'Venilale', 'describr' ),
      ),
    ),
    'CO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Cova Lima Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Fatumean', 'describr' ),
        1 => /*translators: City.*/ __( 'Fohorem', 'describr' ),
        2 => /*translators: City.*/ __( 'Maucatar', 'describr' ),
        3 => /*translators: City.*/ __( 'Suai', 'describr' ),
        4 => /*translators: City.*/ __( 'Tilomar', 'describr' ),
      ),
    ),
    'LA' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Lautém Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Iliomar', 'describr' ),
        1 => /*translators: City.*/ __( 'Lautem', 'describr' ),
        2 => /*translators: City.*/ __( 'Lospalos', 'describr' ),
        3 => /*translators: City.*/ __( 'Luro', 'describr' ),
        4 => /*translators: City.*/ __( 'Tutuala', 'describr' ),
      ),
    ),
    'DI' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dili municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Atauro Island', 'describr' ),
        1 => /*translators: City.*/ __( 'Cristo Rei', 'describr' ),
        2 => /*translators: City.*/ __( 'Dili', 'describr' ),
        3 => /*translators: City.*/ __( 'Metinaro', 'describr' ),
      ),
    ),
    'BO' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Bobonaro Municipality', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Maliana', 'describr' ),
      ),
    ),
  ),
  'PW' => 
  array (
    '004' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Airai', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ngetkib', 'describr' ),
      ),
    ),
    '050' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Hatohobei', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Tobi Village', 'describr' ),
      ),
    ),
    '010' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Angaur', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Angaur State', 'describr' ),
      ),
    ),
    '002' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aimeliik', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ngchemiangel', 'describr' ),
      ),
    ),
  ),
  'SG' => 
  array (
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Central Singapore Community Development Council', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Singapore', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'North West Community Development Council', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Woodlands', 'describr' ),
      ),
    ),
  ),
  'NR' => 
  array (
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Aiwo District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Arijejen', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Anabar District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Anabar', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Baiti District', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Baiti', 'describr' ),
      ),
    ),
  ),
  'UA' => 
  array (
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vinnytsia Oblast', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bar', 'describr' ),
        1 => /*translators: City.*/ __( 'Barskiy Rayon', 'describr' ),
        2 => /*translators: City.*/ __( 'Bershad', 'describr' ),
        3 => /*translators: City.*/ __( 'Brailiv', 'describr' ),
        4 => /*translators: City.*/ __( 'Bratslav', 'describr' ),
        5 => /*translators: City.*/ __( 'Chechelnyk', 'describr' ),
        6 => /*translators: City.*/ __( 'Chernivets&#039;kyy Rayon', 'describr' ),
        7 => /*translators: City.*/ __( 'Chernivtsi', 'describr' ),
        8 => /*translators: City.*/ __( 'Dashiv', 'describr' ),
        9 => /*translators: City.*/ __( 'Haisyn', 'describr' ),
        10 => /*translators: City.*/ __( 'Illintsi', 'describr' ),
        11 => /*translators: City.*/ __( 'Kalynivka', 'describr' ),
        12 => /*translators: City.*/ __( 'Khmilnyk', 'describr' ),
        13 => /*translators: City.*/ __( 'Klembivka', 'describr' ),
        14 => /*translators: City.*/ __( 'Kopayhorod', 'describr' ),
        15 => /*translators: City.*/ __( 'Kozyatyn', 'describr' ),
        16 => /*translators: City.*/ __( 'Kryzhopil&#039;', 'describr' ),
        17 => /*translators: City.*/ __( 'Ladyzhyn', 'describr' ),
        18 => /*translators: City.*/ __( 'Lityn', 'describr' ),
        19 => /*translators: City.*/ __( 'Lityns&#039;kyy Rayon', 'describr' ),
        20 => /*translators: City.*/ __( 'Lypovets&#039;kyy Rayon', 'describr' ),
        21 => /*translators: City.*/ __( 'Mohyliv-Podilskyi', 'describr' ),
        22 => /*translators: City.*/ __( 'Murafa', 'describr' ),
        23 => /*translators: City.*/ __( 'Murovani Kurylivtsi', 'describr' ),
        24 => /*translators: City.*/ __( 'Nemyriv', 'describr' ),
        25 => /*translators: City.*/ __( 'Nova Pryluka', 'describr' ),
        26 => /*translators: City.*/ __( 'Obodivka', 'describr' ),
        27 => /*translators: City.*/ __( 'Orativ', 'describr' ),
        28 => /*translators: City.*/ __( 'Pavlivka', 'describr' ),
        29 => /*translators: City.*/ __( 'Pohrebyshche', 'describr' ),
        30 => /*translators: City.*/ __( 'Pohrebyshchens&#039;kyy Rayon', 'describr' ),
        31 => /*translators: City.*/ __( 'Serebriya', 'describr' ),
        32 => /*translators: City.*/ __( 'Sharhorod', 'describr' ),
        33 => /*translators: City.*/ __( 'Sobolivka', 'describr' ),
        34 => /*translators: City.*/ __( 'Sutysky', 'describr' ),
        35 => /*translators: City.*/ __( 'Teplyk', 'describr' ),
        36 => /*translators: City.*/ __( 'Tomashpil&#039;', 'describr' ),
        37 => /*translators: City.*/ __( 'Torkanivka', 'describr' ),
        38 => /*translators: City.*/ __( 'Tsybulevka', 'describr' ),
        39 => /*translators: City.*/ __( 'Tulchyn', 'describr' ),
        40 => /*translators: City.*/ __( 'Turbiv', 'describr' ),
        41 => /*translators: City.*/ __( 'Tyvriv', 'describr' ),
        42 => /*translators: City.*/ __( 'Ulaniv', 'describr' ),
        43 => /*translators: City.*/ __( 'Vapnyarka', 'describr' ),
        44 => /*translators: City.*/ __( 'Vendychany', 'describr' ),
        45 => /*translators: City.*/ __( 'Vinnitskiy Rayon', 'describr' ),
        46 => /*translators: City.*/ __( 'Vinnytsia', 'describr' ),
        47 => /*translators: City.*/ __( 'Viytivka', 'describr' ),
        48 => /*translators: City.*/ __( 'Voronovytsya', 'describr' ),
        49 => /*translators: City.*/ __( 'Yampil&#039;', 'describr' ),
        50 => /*translators: City.*/ __( 'Zhmerynka', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Luhansk Oblast', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Alchevs&#039;k', 'describr' ),
        1 => /*translators: City.*/ __( 'Alchevs&#039;ka Mis&#039;krada', 'describr' ),
        2 => /*translators: City.*/ __( 'Antratsyt', 'describr' ),
        3 => /*translators: City.*/ __( 'Antratsytivs&#039;kyy Rayon', 'describr' ),
        4 => /*translators: City.*/ __( 'Artemivs&#039;k', 'describr' ),
        5 => /*translators: City.*/ __( 'Bayrachky', 'describr' ),
        6 => /*translators: City.*/ __( 'Bile', 'describr' ),
        7 => /*translators: City.*/ __( 'Bilohorivka', 'describr' ),
        8 => /*translators: City.*/ __( 'Bilokurakyne', 'describr' ),
        9 => /*translators: City.*/ __( 'Bilovods&#039;k', 'describr' ),
        10 => /*translators: City.*/ __( 'Biryukove', 'describr' ),
        11 => /*translators: City.*/ __( 'Bryanka', 'describr' ),
        12 => /*translators: City.*/ __( 'Buran', 'describr' ),
        13 => /*translators: City.*/ __( 'Chervonopartyzans&#039;k', 'describr' ),
        14 => /*translators: City.*/ __( 'Chornukhyne', 'describr' ),
        15 => /*translators: City.*/ __( 'Dovzhanskyy Rayon', 'describr' ),
        16 => /*translators: City.*/ __( 'Hirs&#039;ke', 'describr' ),
        17 => /*translators: City.*/ __( 'Kadiyivka', 'describr' ),
        18 => /*translators: City.*/ __( 'Kirovs&#039;k', 'describr' ),
        19 => /*translators: City.*/ __( 'Kirovs&#039;ka Mis&#039;krada', 'describr' ),
        20 => /*translators: City.*/ __( 'Klenovyy', 'describr' ),
        21 => /*translators: City.*/ __( 'Krasnyy Kut', 'describr' ),
        22 => /*translators: City.*/ __( 'Krasnyy Luch', 'describr' ),
        23 => /*translators: City.*/ __( 'Kreminna', 'describr' ),
        24 => /*translators: City.*/ __( 'Kripens&#039;kyy', 'describr' ),
        25 => /*translators: City.*/ __( 'Lenina', 'describr' ),
        26 => /*translators: City.*/ __( 'Lozno-Oleksandrivka', 'describr' ),
        27 => /*translators: City.*/ __( 'Luhansk', 'describr' ),
        28 => /*translators: City.*/ __( 'Luhans&#039;ka Mis&#039;krada', 'describr' ),
        29 => /*translators: City.*/ __( 'Lutuhyne', 'describr' ),
        30 => /*translators: City.*/ __( 'Lutuhyns&#039;kyy Rayon', 'describr' ),
        31 => /*translators: City.*/ __( 'Lysychans&#039;k', 'describr' ),
        32 => /*translators: City.*/ __( 'Makariv Yar', 'describr' ),
        33 => /*translators: City.*/ __( 'Markivka', 'describr' ),
        34 => /*translators: City.*/ __( 'Millerovo', 'describr' ),
        35 => /*translators: City.*/ __( 'Milove', 'describr' ),
        36 => /*translators: City.*/ __( 'Miusyns&#039;k', 'describr' ),
        37 => /*translators: City.*/ __( 'Molodohvardiys&#039;k', 'describr' ),
        38 => /*translators: City.*/ __( 'Novopskov', 'describr' ),
        39 => /*translators: City.*/ __( 'Nyzhnya Duvanka', 'describr' ),
        40 => /*translators: City.*/ __( 'Pavlivka', 'describr' ),
        41 => /*translators: City.*/ __( 'Pereval&#039;s&#039;k', 'describr' ),
        42 => /*translators: City.*/ __( 'Pervomays&#039;k', 'describr' ),
        43 => /*translators: City.*/ __( 'Popasna', 'describr' ),
        44 => /*translators: City.*/ __( 'Pryvillya', 'describr' ),
        45 => /*translators: City.*/ __( 'Roven&#039;ky', 'describr' ),
        46 => /*translators: City.*/ __( 'Rozkishne', 'describr' ),
        47 => /*translators: City.*/ __( 'Rubizhans&#039;ka Mis&#039;krada', 'describr' ),
        48 => /*translators: City.*/ __( 'Rubizhne', 'describr' ),
        49 => /*translators: City.*/ __( 'Shchastya', 'describr' ),
        50 => /*translators: City.*/ __( 'Simeykyne', 'describr' ),
        51 => /*translators: City.*/ __( 'Slov`yanoserbsk', 'describr' ),
        52 => /*translators: City.*/ __( 'Sorokyne', 'describr' ),
        53 => /*translators: City.*/ __( 'Sorokyns&#039;kyi Rayon', 'describr' ),
        54 => /*translators: City.*/ __( 'Stanytsya Luhans&#039;ka', 'describr' ),
        55 => /*translators: City.*/ __( 'Starobil&#039;s&#039;k', 'describr' ),
        56 => /*translators: City.*/ __( 'Svatove', 'describr' ),
        57 => /*translators: City.*/ __( 'Sverdlovs&#039;k', 'describr' ),
        58 => /*translators: City.*/ __( 'Sverdlovs&#039;ka Mis&#039;krada', 'describr' ),
        59 => /*translators: City.*/ __( 'Syevyerodonets&#039;k', 'describr' ),
        60 => /*translators: City.*/ __( 'Teple', 'describr' ),
        61 => /*translators: City.*/ __( 'Toshkivka', 'describr' ),
        62 => /*translators: City.*/ __( 'Tr&#039;okhizbenka', 'describr' ),
        63 => /*translators: City.*/ __( 'Uralo-Kavkaz', 'describr' ),
        64 => /*translators: City.*/ __( 'Uspenka', 'describr' ),
        65 => /*translators: City.*/ __( 'Zalesnoye', 'describr' ),
        66 => /*translators: City.*/ __( 'Zoryns&#039;k', 'describr' ),
        67 => /*translators: City.*/ __( 'Zymohiria', 'describr' ),
      ),
    ),
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Volyn Oblast', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Berestechko', 'describr' ),
        1 => /*translators: City.*/ __( 'Blahodatne', 'describr' ),
        2 => /*translators: City.*/ __( 'Horokhiv', 'describr' ),
        3 => /*translators: City.*/ __( 'Hołoby', 'describr' ),
        4 => /*translators: City.*/ __( 'Kamin-Kashyrskyi', 'describr' ),
        5 => /*translators: City.*/ __( 'Kivertsi', 'describr' ),
        6 => /*translators: City.*/ __( 'Kovel', 'describr' ),
        7 => /*translators: City.*/ __( 'Kovel&#039;s&#039;ka Mis&#039;krada', 'describr' ),
        8 => /*translators: City.*/ __( 'Liuboml', 'describr' ),
        9 => /*translators: City.*/ __( 'Lokachi', 'describr' ),
        10 => /*translators: City.*/ __( 'Lukiv', 'describr' ),
        11 => /*translators: City.*/ __( 'Lutsk', 'describr' ),
        12 => /*translators: City.*/ __( 'Lyubeshivs&#039;kyy Rayon', 'describr' ),
        13 => /*translators: City.*/ __( 'Lyuboml&#039;s&#039;kyy Rayon', 'describr' ),
        14 => /*translators: City.*/ __( 'Manevychi', 'describr' ),
        15 => /*translators: City.*/ __( 'Manevyts&#039;kyy Rayon', 'describr' ),
        16 => /*translators: City.*/ __( 'Novovolyns&#039;k', 'describr' ),
        17 => /*translators: City.*/ __( 'Nuyno', 'describr' ),
        18 => /*translators: City.*/ __( 'Olyka', 'describr' ),
        19 => /*translators: City.*/ __( 'Pishcha', 'describr' ),
        20 => /*translators: City.*/ __( 'Rakiv Lis', 'describr' ),
        21 => /*translators: City.*/ __( 'Ratne', 'describr' ),
        22 => /*translators: City.*/ __( 'Ratnivs&#039;kyy Rayon', 'describr' ),
        23 => /*translators: City.*/ __( 'Rozhyshche', 'describr' ),
        24 => /*translators: City.*/ __( 'Shats&#039;k', 'describr' ),
        25 => /*translators: City.*/ __( 'Shats&#039;kyy Rayon', 'describr' ),
        26 => /*translators: City.*/ __( 'Stara Vyzhivka', 'describr' ),
        27 => /*translators: City.*/ __( 'Svityaz&#039;', 'describr' ),
        28 => /*translators: City.*/ __( 'Volodymyr-Volynskyi', 'describr' ),
      ),
    ),
  ),
  'BG' => 
  array (
    '07' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Gabrovo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Dryanovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Gabrovo', 'describr' ),
        2 => /*translators: City.*/ __( 'Obshtina Dryanovo', 'describr' ),
        3 => /*translators: City.*/ __( 'Obshtina Gabrovo', 'describr' ),
        4 => /*translators: City.*/ __( 'Obshtina Sevlievo', 'describr' ),
        5 => /*translators: City.*/ __( 'Obshtina Tryavna', 'describr' ),
        6 => /*translators: City.*/ __( 'Sevlievo', 'describr' ),
        7 => /*translators: City.*/ __( 'Tryavna', 'describr' ),
      ),
    ),
    '05' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vidin Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Belogradchik', 'describr' ),
        1 => /*translators: City.*/ __( 'Boynitsa', 'describr' ),
        2 => /*translators: City.*/ __( 'Bregovo', 'describr' ),
        3 => /*translators: City.*/ __( 'Chuprene', 'describr' ),
        4 => /*translators: City.*/ __( 'Dimovo', 'describr' ),
        5 => /*translators: City.*/ __( 'Drenovets', 'describr' ),
        6 => /*translators: City.*/ __( 'Dunavtsi', 'describr' ),
        7 => /*translators: City.*/ __( 'Gramada', 'describr' ),
        8 => /*translators: City.*/ __( 'Kula', 'describr' ),
        9 => /*translators: City.*/ __( 'Makresh', 'describr' ),
        10 => /*translators: City.*/ __( 'Novo Selo', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Belogradchik', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Boynitsa', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Dimovo', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Gramada', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Kula', 'describr' ),
        16 => /*translators: City.*/ __( 'Obshtina Ruzhintsi', 'describr' ),
        17 => /*translators: City.*/ __( 'Obshtina Vidin', 'describr' ),
        18 => /*translators: City.*/ __( 'Ruzhintsi', 'describr' ),
        19 => /*translators: City.*/ __( 'Vidin', 'describr' ),
      ),
    ),
    '01' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Blagoevgrad Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Bansko', 'describr' ),
        1 => /*translators: City.*/ __( 'Belitsa', 'describr' ),
        2 => /*translators: City.*/ __( 'Blagoevgrad', 'describr' ),
        3 => /*translators: City.*/ __( 'Garmen', 'describr' ),
        4 => /*translators: City.*/ __( 'Gotse Delchev', 'describr' ),
        5 => /*translators: City.*/ __( 'Hadzhidimovo', 'describr' ),
        6 => /*translators: City.*/ __( 'Kolarovo', 'describr' ),
        7 => /*translators: City.*/ __( 'Kresna', 'describr' ),
        8 => /*translators: City.*/ __( 'Obshtina Bansko', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Belitsa', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Blagoevgrad', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Garmen', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Gotse Delchev', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Kresna', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Petrich', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Razlog', 'describr' ),
        16 => /*translators: City.*/ __( 'Obshtina Sandanski', 'describr' ),
        17 => /*translators: City.*/ __( 'Obshtina Satovcha', 'describr' ),
        18 => /*translators: City.*/ __( 'Obshtina Simitli', 'describr' ),
        19 => /*translators: City.*/ __( 'Obshtina Strumyani', 'describr' ),
        20 => /*translators: City.*/ __( 'Obshtina Yakoruda', 'describr' ),
        21 => /*translators: City.*/ __( 'Petrich', 'describr' ),
        22 => /*translators: City.*/ __( 'Razlog', 'describr' ),
        23 => /*translators: City.*/ __( 'Sandanski', 'describr' ),
        24 => /*translators: City.*/ __( 'Satovcha', 'describr' ),
        25 => /*translators: City.*/ __( 'Simitli', 'describr' ),
        26 => /*translators: City.*/ __( 'Stara Kresna', 'describr' ),
        27 => /*translators: City.*/ __( 'Strumyani', 'describr' ),
        28 => /*translators: City.*/ __( 'Yakoruda', 'describr' ),
      ),
    ),
    '09' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Kardzhali Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Ardino', 'describr' ),
        1 => /*translators: City.*/ __( 'Dzhebel', 'describr' ),
        2 => /*translators: City.*/ __( 'Kardzhali', 'describr' ),
        3 => /*translators: City.*/ __( 'Kirkovo', 'describr' ),
        4 => /*translators: City.*/ __( 'Krumovgrad', 'describr' ),
        5 => /*translators: City.*/ __( 'Obshtina Ardino', 'describr' ),
        6 => /*translators: City.*/ __( 'Obshtina Chernoochene', 'describr' ),
        7 => /*translators: City.*/ __( 'Obshtina Dzhebel', 'describr' ),
        8 => /*translators: City.*/ __( 'Obshtina Kardzhali', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Kirkovo', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Momchilgrad', 'describr' ),
      ),
    ),
    '04' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Veliko Tarnovo Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Byala Cherkva', 'describr' ),
        1 => /*translators: City.*/ __( 'Debelets', 'describr' ),
        2 => /*translators: City.*/ __( 'Elena', 'describr' ),
        3 => /*translators: City.*/ __( 'Gorna Oryahovitsa', 'describr' ),
        4 => /*translators: City.*/ __( 'Kilifarevo', 'describr' ),
        5 => /*translators: City.*/ __( 'Lyaskovets', 'describr' ),
        6 => /*translators: City.*/ __( 'Obshtina Elena', 'describr' ),
        7 => /*translators: City.*/ __( 'Obshtina Gorna Oryahovitsa', 'describr' ),
        8 => /*translators: City.*/ __( 'Obshtina Lyaskovets', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Pavlikeni', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Polski Trambesh', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Strazhitsa', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Suhindol', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Svishtov', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Veliko Tŭrnovo', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Zlataritsa', 'describr' ),
        16 => /*translators: City.*/ __( 'Parvomaytsi', 'describr' ),
        17 => /*translators: City.*/ __( 'Pavlikeni', 'describr' ),
        18 => /*translators: City.*/ __( 'Polski Trambesh', 'describr' ),
        19 => /*translators: City.*/ __( 'Strazhitsa', 'describr' ),
        20 => /*translators: City.*/ __( 'Suhindol', 'describr' ),
        21 => /*translators: City.*/ __( 'Svishtov', 'describr' ),
        22 => /*translators: City.*/ __( 'Veliko Tŭrnovo', 'describr' ),
        23 => /*translators: City.*/ __( 'Zlataritsa', 'describr' ),
      ),
    ),
    '06' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Vratsa Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Borovan', 'describr' ),
        1 => /*translators: City.*/ __( 'Byala Slatina', 'describr' ),
        2 => /*translators: City.*/ __( 'Hayredin', 'describr' ),
        3 => /*translators: City.*/ __( 'Kozloduy', 'describr' ),
        4 => /*translators: City.*/ __( 'Krivodol', 'describr' ),
        5 => /*translators: City.*/ __( 'Mezdra', 'describr' ),
        6 => /*translators: City.*/ __( 'Mizia', 'describr' ),
        7 => /*translators: City.*/ __( 'Obshtina Borovan', 'describr' ),
        8 => /*translators: City.*/ __( 'Obshtina Hayredin', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Kozloduy', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Krivodol', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Mezdra', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Mizia', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Oryahovo', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Roman', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Vratsa', 'describr' ),
        16 => /*translators: City.*/ __( 'Oryahovo', 'describr' ),
        17 => /*translators: City.*/ __( 'Roman', 'describr' ),
        18 => /*translators: City.*/ __( 'Vratsa', 'describr' ),
      ),
    ),
    '02' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Burgas Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aheloy', 'describr' ),
        1 => /*translators: City.*/ __( 'Ahtopol', 'describr' ),
        2 => /*translators: City.*/ __( 'Aytos', 'describr' ),
        3 => /*translators: City.*/ __( 'Bata', 'describr' ),
        4 => /*translators: City.*/ __( 'Burgas', 'describr' ),
        5 => /*translators: City.*/ __( 'Chernomorets', 'describr' ),
        6 => /*translators: City.*/ __( 'Kameno', 'describr' ),
        7 => /*translators: City.*/ __( 'Karnobat', 'describr' ),
        8 => /*translators: City.*/ __( 'Kiten', 'describr' ),
        9 => /*translators: City.*/ __( 'Malko Tarnovo', 'describr' ),
        10 => /*translators: City.*/ __( 'Nesebar', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Aytos', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Burgas', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Kameno', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Karnobat', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Malko Tarnovo', 'describr' ),
        16 => /*translators: City.*/ __( 'Obshtina Nesebar', 'describr' ),
        17 => /*translators: City.*/ __( 'Obshtina Pomorie', 'describr' ),
        18 => /*translators: City.*/ __( 'Obshtina Primorsko', 'describr' ),
        19 => /*translators: City.*/ __( 'Obshtina Sozopol', 'describr' ),
        20 => /*translators: City.*/ __( 'Obshtina Sungurlare', 'describr' ),
        21 => /*translators: City.*/ __( 'Obzor', 'describr' ),
        22 => /*translators: City.*/ __( 'Pomorie', 'describr' ),
        23 => /*translators: City.*/ __( 'Primorsko', 'describr' ),
        24 => /*translators: City.*/ __( 'Ravda', 'describr' ),
        25 => /*translators: City.*/ __( 'Ruen', 'describr' ),
        26 => /*translators: City.*/ __( 'Sarafovo', 'describr' ),
        27 => /*translators: City.*/ __( 'Sozopol', 'describr' ),
        28 => /*translators: City.*/ __( 'Sredets', 'describr' ),
        29 => /*translators: City.*/ __( 'Sungurlare', 'describr' ),
        30 => /*translators: City.*/ __( 'Sveti Vlas', 'describr' ),
        31 => /*translators: City.*/ __( 'Tsarevo', 'describr' ),
      ),
    ),
    '03' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Varna Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Aksakovo', 'describr' ),
        1 => /*translators: City.*/ __( 'Asparuhovo', 'describr' ),
        2 => /*translators: City.*/ __( 'Balgarevo', 'describr' ),
        3 => /*translators: City.*/ __( 'Beloslav', 'describr' ),
        4 => /*translators: City.*/ __( 'Byala', 'describr' ),
        5 => /*translators: City.*/ __( 'Dalgopol', 'describr' ),
        6 => /*translators: City.*/ __( 'Devnya', 'describr' ),
        7 => /*translators: City.*/ __( 'Dolni Chiflik', 'describr' ),
        8 => /*translators: City.*/ __( 'Kiten', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Aksakovo', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Avren', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Beloslav', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Byala', 'describr' ),
        13 => /*translators: City.*/ __( 'Obshtina Dalgopol', 'describr' ),
        14 => /*translators: City.*/ __( 'Obshtina Devnya', 'describr' ),
        15 => /*translators: City.*/ __( 'Obshtina Dolni Chiflik', 'describr' ),
        16 => /*translators: City.*/ __( 'Obshtina Provadia', 'describr' ),
        17 => /*translators: City.*/ __( 'Obshtina Suvorovo', 'describr' ),
        18 => /*translators: City.*/ __( 'Obshtina Valchidol', 'describr' ),
        19 => /*translators: City.*/ __( 'Obshtina Varna', 'describr' ),
        20 => /*translators: City.*/ __( 'Obshtina Vetrino', 'describr' ),
        21 => /*translators: City.*/ __( 'Provadia', 'describr' ),
        22 => /*translators: City.*/ __( 'Suvorovo', 'describr' ),
        23 => /*translators: City.*/ __( 'Valchidol', 'describr' ),
        24 => /*translators: City.*/ __( 'Varna', 'describr' ),
        25 => /*translators: City.*/ __( 'Vetrino', 'describr' ),
        26 => /*translators: City.*/ __( 'Zlatni Pyasatsi', 'describr' ),
      ),
    ),
    '08' => 
    array (
      'name' => /*translators: State/province.*/ __( 'Dobrich Province', 'describr' ),
      'cities' => 
      array (
        0 => /*translators: City.*/ __( 'Balchik', 'describr' ),
        1 => /*translators: City.*/ __( 'Dobrich', 'describr' ),
        2 => /*translators: City.*/ __( 'General Toshevo', 'describr' ),
        3 => /*translators: City.*/ __( 'Kavarna', 'describr' ),
        4 => /*translators: City.*/ __( 'Krushari', 'describr' ),
        5 => /*translators: City.*/ __( 'Obshtina Balchik', 'describr' ),
        6 => /*translators: City.*/ __( 'Obshtina Dobrich', 'describr' ),
        7 => /*translators: City.*/ __( 'Obshtina Dobrich-Selska', 'describr' ),
        8 => /*translators: City.*/ __( 'Obshtina General Toshevo', 'describr' ),
        9 => /*translators: City.*/ __( 'Obshtina Kavarna', 'describr' ),
        10 => /*translators: City.*/ __( 'Obshtina Krushari', 'describr' ),
        11 => /*translators: City.*/ __( 'Obshtina Shabla', 'describr' ),
        12 => /*translators: City.*/ __( 'Obshtina Tervel', 'describr' ),
        13 => /*translators: City.*/ __( 'Shabla', 'describr' ),
        14 => /*translators: City.*/ __( 'Tervel', 'describr' ),
      ),
    ),
  ),
);