<?php
/**
 * Template for the "Activate Account Email".
 * 
 * Whether to send the user an email when account is activated.
 *
 * This template can be overridden by copying it to {your-theme}/describr/templates/email/send-user-active-account.php
 *
 * @package Describr
 * @since 3.0
 * 
 * @var string $slug
 * @var array  $args
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$this->get_template( 'header', $args );
?>
<tr>
	<td style="padding: 0; vertical-align: baseline;"><?php echo esc_html( sprintf(
		/*translators: %s: User's display name.*/
		__( 'Hello %s,', 'describr' ), 
		$args['user']->display_name 
		) ) . "\r\n\r\n"; ?></td>
</tr>
<tr>
	<td style="padding: 20px 0; vertical-align: baseline;"><?php esc_html_e( 'Your account has been activated.', 'describr' ) . "\r\n"; ?></td>
</tr>
<?php
$this->login_btn();

$this->get_template( 'footer', $args );