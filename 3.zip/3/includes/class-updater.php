<?php
namespace describr;

/**
 * Updater class
 *
 * @package Describr
 * @since 3.0
 */
class Updater {
    /**
     * URI to locate the server 
     * on which the changelog info 
     * is stored.
     * 
     * @since 3.0
     * @var string
     */
    private $update_uri;

    /**
     * Plugin's slug.
     * 
     * @since 3.0
     * @var string
     */
    private $slug;

    /**
     * Updater constructor.
     * 
     * @since 3.0
     */
    public function __construct() {
        add_action( 'init', array( $this, 'update_init' ), 10 );            
    }
    
    /**
     * Add the action and fitlers that perform the updating of the plugin.
     * 
     * @since 3.0
     */
    public function update_init() {
        /**
         * Filters whether the site can connect to WordPress' plugins' repository.
         * 
         * Filters can return false if the desire is to get updates but
         * has no connection to WordPress' plugins' repository.
         * 
         * @since 3.0
         * 
         * @param true $can_connect_to_wp_repo Whether a connection can be made
         *                                     to WordPress' plugins' repository.
         */
        if ( ! apply_filters( 'describr_can_connect_to_wp_repo', true ) ) {
            if( ! function_exists('get_plugin_data') ) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            } 
        
            $plugin_data = get_plugin_data( DESCRIBR_DIR . 'describr.php' );

            if ( ! empty( $plugin_data['UpdateURI'] ) && ! empty( $plugin_data['Name'] ) ) {
                $this->slug = strtolower( $plugin_data['Name'] );
                $this->update_uri = $plugin_data['UpdateURI'];
            
                $hostname = wp_parse_url( sanitize_url( $this->update_uri ), PHP_URL_HOST );
            
                add_filter( "update_plugins_{$hostname}", array( $this, 'update_plugin' ), 999, 3 );
                add_filter( 'plugins_api', array( $this, 'plugin_api' ), 999, 3 );
                add_action( 'upgrader_process_complete', array( $this, 'upgrader_process_complete' ), 10, 2 );
            }
        }
    }

    /**
     * Clears plugins' cache after update so wp_update_plugins() knows about the new plugin.
     * 
     * @since 3.0
     * 
     * @param object $upgrader WP_Upgrader object.
     * @param array  $args     Post-update data.
     */
    public function upgrader_process_complete( $upgrader, $args ) {
        if ( 'update' === $args['action'] && 'plugin' === $args['type'] && in_array( DESCRIBR_FILE, $args['plugins'], true ) ) {
            wp_clean_plugins_cache();
        }
    }

    /**
     * Instructs WordPress if and how update of plugin should be done.
     * 
     * Credit to Business Bloomer.
     * 
     * @see https://www.businessbloomer.com/woocommerce-update-self-hosted-plugin-wp-dashboard/
     * 
     * @since 3.0
     * 
     * @param array|false $update {
     *     The plugin update data with the latest details. Default false.
     *
     *     @type string   $id           Optional. ID of the plugin for update purposes, should be a URI
     *                                  specified in the `Update URI` header field.
     *     @type string   $slug         Slug of the plugin.
     *     @type string   $version      The version of the plugin.
     *     @type string   $url          The URL for details of the plugin.
     *     @type string   $package      Optional. The update ZIP for the plugin.
     *     @type string   $tested       Optional. The version of WordPress the plugin is tested against.
     *     @type string   $requires_php Optional. The version of PHP which the plugin requires.
     *     @type bool     $autoupdate   Optional. Whether the plugin should automatically update.
     *     @type string[] $icons        Optional. Array of plugin icons.
     *     @type string[] $banners      Optional. Array of plugin banners.
     *     @type string[] $banners_rtl  Optional. Array of plugin RTL banners.
     *     @type array    $translations {
     *         Optional. List of translation updates for the plugin.
     *
     *         @type string $language   The language the translation update is for.
     *         @type string $version    The version of the plugin this translation is for.
     *                                  This is not the version of the language file.
     *         @type string $updated    The update timestamp of the translation file.
     *                                  Should be a date in the `YYYY-MM-DD HH:MM:SS` format.
     *         @type string $package    The ZIP location containing the translation update.
     *         @type string $autoupdate Whether the translation should be automatically installed.
     *     }
     * }
     * @param array       $plugin_data Plugin headers (from describr.php).
     * @param string      $plugin_file Plugin filename (describr/describr.php). 
     * @return array
     */
    public function update_plugin( $update, $plugin_data, $plugin_file ) {
        //Bail if this plugin is not being updated.
        if ( DESCRIBR_FILE !== $plugin_file ) {
            return $update;
        }
            
        //Bail if update was already done.           
        if ( ! empty( $update ) ) {
            return $update;
        }


        $changelog = $this->http_request_plugin_info();
            
        //Bail if changelog.json file can't be reached.
        if ( ! $changelog ) {
            return $update;
        }

        //No update is available if the changelog's version is not greater than the current one, so bail.
        if ( ! version_compare( $plugin_data['Version'], $changelog->latest_version, '<' ) ) {
            return $update;
        }

        return array(
            'slug'         => $this->slug,
            'version'      => $plugin_data['Version'],
            'new_version'  => $changelog->latest_version,
            'url'          => $this->update_uri . '/versions/',//////Where to locate details about the plugin. Required. To be determined...
            'package'      => $changelog->download_url,//The full local path or URI of the package
            'tested_wp'    => $changelog->tested_wp,
            'requires_php' => $changelog->requires_php,
        );
    }
        
    /**
     * Displays plugin details when "View version details" is clicked in Admin.
     * 
     * Credit to Business Bloomer.
     * 
     * @see https://www.businessbloomer.com/woocommerce-update-self-hosted-plugin-wp-dashboard/
     * 
     * @since 3.0
     * 
     * @param object|bool|array $results The result.
     * @param string            $action  The type of information being requested from the Plugin Installation API.
     * @param object            $args    Plugin API arguments.
     * @return object|bool|array The result.
     */
    public function plugin_api( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || ! isset( $args->slug ) || $this->slug !== $args->slug ) {
            return $result;
        }
            
        $changelog = $this->http_request_plugin_info();
            
        if ( ! $changelog ) {
            return $result;
        }

        if ( ! isset( $changelog->plugin_name, $changelog->description, $changelog->latest_version, $changelog->download_url ) ) {
            return $result;
        }
        
        if ( ! is_object( $result ) ) {
            $result = new \stdClass();
        }

        $result->name          = $changelog->plugin_name;
        $result->sections      = array( 'description' => $changelog->description );
        $result->version       = $changelog->latest_version;
        $result->download_link = $changelog->download_url;//The full local path or URI of the package
        $result->slug          = $this->slug;
        $result->path          = DESCRIBR_FILE; 
            
        return $result;
    }
        
    /**
     * Fetches plugin changelog info remotely.
     * 
     * Credit to Business Bloomer.
     * 
     * @see https://www.businessbloomer.com/woocommerce-update-self-hosted-plugin-wp-dashboard/
     * 
     * @since 3.0
     * 
     * @return false|object.
     */
    private function http_request_plugin_info() {
        $access = wp_remote_get( 
            $this->update_uri . "/{$this->slug}/versions/changelog.json", 
            array( 
                'timeout' => 10,   
                'headers' => array( 
                    'Accept' => 'application/json', 
                ),  
            ) 
        );

        if ( ! is_wp_error( $access ) && 200 === wp_remote_retrieve_response_code( $access ) ) {
            return json_decode( wp_remote_retrieve_body( $access ) );
        }

        return false;
    }
}
